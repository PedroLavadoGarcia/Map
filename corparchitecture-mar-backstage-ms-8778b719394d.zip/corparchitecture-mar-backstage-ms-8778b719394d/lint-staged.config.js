module.exports = {
  '*.{js,jsx,ts,tsx,mjs,cjs}': filenames => [
    `yarn eslint --fix ${filenames.map(filename => `"${filename}"`).join(' ')}`,
    `yarn prettier --write ${filenames
      .map(filename => `"${filename}"`)
      .join(' ')}`,
  ],
  '*.{json,md}': filenames => [
    `yarn prettier --write ${filenames
      .map(filename => `"${filename}"`)
      .join(' ')}`,
  ],
};
