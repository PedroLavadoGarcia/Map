## Test Broken Link

Testing broken links on this component

## TEST

### Internal links

- [Valid link I](/docs/default/Component/Test) `/docs/default/Component/Test`
- [Invalid link I](/docs/default/Component/invalid_page) `/docs/default/Component/invalid_page`
- [Valid link II](./inner_page) `./inner_page`
- [Invalid link II](./invalid_page) `./invalid_page`

### External links

- [Valid link III](https://www.google.es/) `https://www.google.es/`
- [Invalid link III](https://invalid.marketplace.mapfre.com/) `https://invalid.marketplace.mapfre.com/`
- [Valid link IV](https://marketplace.mar.mapfre.com/catalog/default/component/cognito_usecase) `https://marketplace.mar.mapfre.com/catalog/default/component/cognito_usecase`
- [Invalid link IV](https://marketplace.mar.mapfre.com/catalog/default/component/invalid_page) `https://marketplace.mar.mapfre.com/catalog/default/component/invalid_page`
