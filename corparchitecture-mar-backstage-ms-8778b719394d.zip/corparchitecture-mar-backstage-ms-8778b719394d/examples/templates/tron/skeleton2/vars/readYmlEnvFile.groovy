
import org.yaml.snakeyaml.Yaml

/*
*   Funcion para la lectura de yml en la carpeta resources de la shared library
*   Esta funcion devuelve un objeto Yaml de la libreria snakeYaml.
*   La funcion recibe el path del archivo que necesitemos leer.
*/
def call(String path){

        def pathYml = 'com/mapfre/tron/deploy/' + path

        def request = libraryResource pathYml
        def yamlObject = new Yaml()
        def yml = yamlObject.load(request)

        println("-- tron-config-mpa: pathFile=${pathYml}--")

        return yml
}
