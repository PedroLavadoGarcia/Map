
def call(branch) {

    def environment = "none"
    
    if ( branch == 'development' ) {
        environment = 'DES'
    } else if ( branch.startsWith('release/')){
        environment = 'INT'
    } else if ( branch == 'production') {
        environment = 'PRO'
    } 
 
    return environment
}