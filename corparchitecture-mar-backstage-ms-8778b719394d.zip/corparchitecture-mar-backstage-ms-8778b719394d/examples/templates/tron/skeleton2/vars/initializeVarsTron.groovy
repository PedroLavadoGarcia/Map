import com.mapfre.tron.config.tronVars

def call() {
    return "${new tronVars().initializeEnvironmentVariables(this)}"
}
