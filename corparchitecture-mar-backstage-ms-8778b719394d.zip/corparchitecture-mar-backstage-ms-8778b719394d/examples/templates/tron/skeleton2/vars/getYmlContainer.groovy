#!/usr/bin/env groovy

import org.yaml.snakeyaml.Yaml

def call(String projectName) {
  def pathYml = "com/mapfre/tron/podTemplates/${projectName}.yml"
  def request = libraryResource pathYml
  def yamlObject = new Yaml()
  def yml = yamlObject.load(request)
  return yml
}



