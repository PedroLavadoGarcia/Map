package com.mapfre.tron.config

/*
*   Declarar variables globales del entorno del país
*/
class tronVars {
    private Map config = [                                // Plataforma produccion= true
        IS_PROD: true,                                   // Plataforma laboratorio= false
        NEXUS_URL: "http://nexus.tron.azure.mapfre.net",
        TEMP_REMOTE_ROOT: "/tmp/devops-tron",
        
        URL_ARTIFACT_SNAP: "https://pkgs.dev.azure.com/devopsmapfre/devopsmapfre/_packaging/snapshots/maven/v1",
        URL_ARTIFACT_RELE: "https://pkgs.dev.azure.com/devopsmapfre/devopsmapfre/_packaging/releases/maven/v1",
       
        BITBUCKET_CREDENTIALS: 'app-jenkins-tron-bitbucket',
        URL_API_BITBUCKET: 'https://api.bitbucket.org/2.0/repositories/',
        WORKSPACES_BITBUCKET: '${{values.WORKSPACE_LOCAL}}',
        BITBUCKET_WORKSPACE: '${{values.WORKSPACE_LOCAL}}',
        WEBHOOK_STEP: 'webhook-step',

        BITBUCKET_WORKSPACE_CORE: 'MAP_CORE_TRON',
        CORE_REPO_DEPLOY_REGISTRY: 'tron-core-deployment-registry',
        CORE_DEPLOY_REGISTRY_BRANCH: 'master',
        CORE_DEPENDENCIES_REGISTRY_FOLDER: 'PAISES',
        CORE_BASELINE_REGISTRY_FOLDER: 'BASELINES',
        CORE_DEPENDENCIES_REGISTRY_FILE: 'baseline-control.yaml',
        COUNTRY_OWNER: '${{values.COD_PAIS}}',
        DEVOPS_PLATFORM_ORGANIZATION: 'org-latamsurpy',

        LOCAL_DEPENDENCIES_REGISTRY_FILE: 'dependencias-${{values.COD_PAIS}}.yml',
        LOCAL_REPO_DEPLOY_REGISTRY: 'control-versiones-${{values.COD_PAIS}}',
        LOCAL_DEPLOY_REGISTRY_ENVIRONMENT_VERSIONS_FOLDER: '.',
        LOCAL_DEPLOY_REGISTRY_ENVIRONMENT_VERSIONS_FILE: '${{values.COD_PAIS}}-version-control.yml',
        LOCAL_DEPLOY_REGISTRY_BRANCH: 'master',

        YML_CONTROL_LANZADOR: 'tron_control_lanzador.yml',
        REPO_CONTROL_LANZADOR: 'lanzador_${{values.COD_PAIS}}_control',

        INTEGRATION_BRANCH: 'integration',
        PREPRODUCTION_BRANCH: 'preproduction',
        PRODUCTION_BRANCH: 'production',

        AA_CREDENTIAL_ID: 'app-jenkins-tron-bin-repo',
        LOCAL_PROFILE_MAVEN: 'ENV_LOCAL',
        
        START_LANZADOR: 'START',
        STOP_LANZADOR:  'STOP',
        ERROR_LANZADOR: 'ERROR',
        REPO_LANZADOR: 'lanzador_apis',
        LIB_CONF_LANZADOR: '.config/tron-pipeline-release.yml',
        PAIS: '${{values.COD_PAIS}}'

    ]

    String initializeEnvironmentVariables(final Script script) {
        config.each { k,v ->
            script.env."$k" = v
        }

        return "Tron's env.variables Initialization completed!"
    }
}
