package com.mapfre.tron.config

class deployUtils {
    
    // seleccionar el fichero para el despliegue por entorno
    def getFileEnvironmentJBoss(String environment) {
        def fileEnv = "jboss-tron-${environment.toLowerCase()}.yml"
        if(environment == "none") {
        fileEnv = 'fileEnv=ERROR_EN_ENTORNO-NOMBRE_FICHERO-jboss'
        }
        return fileEnv
    }

    // load properties needed to deploy
    def loadProperties(environmentYml) {

        def remote = [:]

        println ("Init loadProperties(${environmentYml})")

        remote.name = "${environmentYml.environment}"
        remote.host = "${environmentYml.host}"
        remote.port = "${environmentYml.port_ssh}" as int
        remote.allowAnyHosts = environmentYml.allow_any_hosts
        remote.backend_group = environmentYml.backend_group
        remote.frontend_group = environmentYml.frontend_group

        return remote;

    }

    // yaml de orden de despliegue
    def getDeploymentOrder() {
        return ('deployment-order.yml')
    }

}
