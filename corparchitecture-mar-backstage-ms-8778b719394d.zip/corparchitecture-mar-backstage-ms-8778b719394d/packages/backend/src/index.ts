/*
 * Hi!
 *
 * Note that this is an EXAMPLE Backstage backend. Please check the README.
 *
 * Happy hacking!
 */
import Router from 'express-promise-router';
import {
  createServiceBuilder,
  loadBackendConfig,
  getRootLogger,
  useHotMemoize,
  notFoundHandler,
  CacheManager,
  DatabaseManager,
  SingleHostDiscovery,
  UrlReaders,
  ServerTokenManager,
} from '@backstage/backend-common';
import { TaskScheduler } from '@backstage/backend-tasks';
import { Config } from '@backstage/config';
import app from './plugins/app';
import jenkins from './plugins/jenkins';
import auth from './plugins/auth';
import catalog from './plugins/catalog';
import scaffolder from './plugins/scaffolder';
import proxy from './plugins/proxy';
import techdocs from './plugins/techdocs';
import search from './plugins/search';
import changelog from './plugins/changelog';
import { PluginEnvironment } from './types';
import { ServerPermissionClient } from '@backstage/plugin-permission-node';
import subscriptions from './plugins/subscriptions';
import sendEmail from './plugins/sendEmail';
import mapfreapiEditor from './plugins/mapfreapi-editor';
import bodyParser from 'body-parser';
import permission from './plugins/permission';
import { DefaultIdentityClient } from '@backstage/plugin-auth-node';
import announcements from './plugins/announcements';
import wsrrUpload from './plugins/wsrr-upload';
import s3ZipDownload from './plugins/s3-zip-download';
import zipManager from './plugins/zip-manager';
import grafanaApigwOnprem from './plugins/grafana-apigw-onprem';
import cloudWatchLogs from './plugins/cloudWatch-logs';
import serviceManager from './plugins/service-manager';
import componentsEditor from './plugins/components-editor';
import adminCatalog from './plugins/admincatalog';
import metadata from './plugins/metadata';
import markia from './plugins/markia';
import brokenLinks from './plugins/brokenLinks';
import externalDocs from './plugins/external-docs';
import reviewValidation from './plugins/review-validation';
import audit from './plugins/audit';
import componentsResponsibles from './plugins/components-responsibles';
import wsdlToHtml from './plugins/wsdl-to-html';
import disma from './plugins/disma';
import forms from './plugins/forms';
import s3Images from './plugins/s3-images';
function makeCreateEnv(config: Config) {
  const root = getRootLogger();
  const reader = UrlReaders.default({ logger: root, config });
  const discovery = SingleHostDiscovery.fromConfig(config);
  const cacheManager = CacheManager.fromConfig(config);
  const databaseManager = DatabaseManager.fromConfig(config);
  const tokenManager = ServerTokenManager.fromConfig(config, { logger: root });
  const taskScheduler = TaskScheduler.fromConfig(config);
  const permissions = ServerPermissionClient.fromConfig(config, {
    discovery,
    tokenManager,
  });
  const identity = DefaultIdentityClient.create({
    discovery,
  });

  root.info(`Created UrlReader ${reader}`);

  return (plugin: string): PluginEnvironment => {
    const logger = root.child({ type: 'plugin', plugin });
    const database = databaseManager.forPlugin(plugin);
    const cache = cacheManager.forPlugin(plugin);
    const scheduler = taskScheduler.forPlugin(plugin);
    return {
      logger,
      database,
      cache,
      config,
      reader,
      discovery,
      tokenManager,
      scheduler,
      permissions,
      identity,
    };
  };
}
async function main() {
  const config = await loadBackendConfig({
    argv: process.argv,
    logger: getRootLogger(),
  });
  const createEnv = makeCreateEnv(config);
  const catalogEnv = useHotMemoize(module, () => createEnv('catalog'));
  const scaffolderEnv = useHotMemoize(module, () => createEnv('scaffolder'));
  const authEnv = useHotMemoize(module, () => createEnv('auth'));
  const proxyEnv = useHotMemoize(module, () => createEnv('proxy'));
  const techdocsEnv = useHotMemoize(module, () => createEnv('techdocs'));
  const searchEnv = useHotMemoize(module, () => createEnv('search'));
  const appEnv = useHotMemoize(module, () => createEnv('app'));
  const jenkinsEnv = useHotMemoize(module, () => createEnv('jenkins'));
  const changelogEnv = useHotMemoize(module, () => createEnv('changelog'));
  const subscriptionsEnv = useHotMemoize(module, () =>
    createEnv('subscriptions'),
  );
  const sendEmailEnv = useHotMemoize(module, () => createEnv('sendEmail'));
  const permissionEnv = useHotMemoize(module, () => createEnv('permission'));
  const announcementsEnv = useHotMemoize(module, () =>
    createEnv('announcements'),
  );
  const mapfreapiEditorEnv = useHotMemoize(module, () =>
    createEnv('mapfreapi-editor'),
  );
  const wsrrUploadEnv = useHotMemoize(module, () => createEnv('wsrr-upload'));
  const s3ZipDownloadEnv = useHotMemoize(module, () =>
    createEnv('s3-zip-download'),
  );
  const zipManagerEnv = useHotMemoize(module, () => createEnv('zip-manager'));
  const grafanaApigwOnpremEnv = useHotMemoize(module, () =>
    createEnv('grafana-apigw-onprem'),
  );
  const cloudWatchLogsEnv = useHotMemoize(module, () =>
    createEnv('cloudWatchLogs'),
  );

  const serviceManagerEnv = useHotMemoize(module, () =>
    createEnv('serviceManager'),
  );
  const adminCatalogEnv = useHotMemoize(module, () =>
    createEnv('admincatalog'),
  );
  const markiaEnv = useHotMemoize(module, () => createEnv('markia'));

  const externalDocsEnv = useHotMemoize(module, () =>
    createEnv('external-docs'),
  );

  const componentsEditorEnv = useHotMemoize(module, () =>
    createEnv('components-editor'),
  );
  const brokenLinksEnv = useHotMemoize(module, () => createEnv('broken-links'));
  const validateMetadataEnv = useHotMemoize(module, () =>
    createEnv('review-validation'),
  );
  const auditEnv = useHotMemoize(module, () => createEnv('audit'));
  const componentsResponsiblesEnv = useHotMemoize(module, () =>
    createEnv('components-responsibles'),
  );
  const dismaEnv = useHotMemoize(module, () => createEnv('disma'));
  const formsEnv = useHotMemoize(module, () => createEnv('forms'));
  const s3ImagesEnv = useHotMemoize(module, () => createEnv('s3-images'));
  const wsdlToHtmlEnv = useHotMemoize(module, () => createEnv('wsdl-to-html'));

  const apiRouter = Router();
  apiRouter.use(bodyParser.json({ limit: '50mb' }));
  apiRouter.use(
    bodyParser.urlencoded({
      limit: '50mb',
      extended: true,
      parameterLimit: 50000,
    }),
  );
  apiRouter.use('/catalog', await catalog(catalogEnv));
  apiRouter.use('/jenkins', await jenkins(jenkinsEnv));
  apiRouter.use('/scaffolder', await scaffolder(scaffolderEnv));
  apiRouter.use('/auth', await auth(authEnv));
  apiRouter.use('/techdocs', await techdocs(techdocsEnv));
  apiRouter.use('/proxy', await proxy(proxyEnv));
  apiRouter.use('/changelog', await changelog(changelogEnv));
  apiRouter.use('/search', await search(searchEnv));
  apiRouter.use('/subscriptions', await subscriptions(subscriptionsEnv));
  apiRouter.use('/permission', await permission(permissionEnv));
  apiRouter.use('/announcements', await announcements(announcementsEnv));
  apiRouter.use('/mapfreapi-editor', await mapfreapiEditor(mapfreapiEditorEnv));
  apiRouter.use('/wsrr-upload', await wsrrUpload(wsrrUploadEnv));
  apiRouter.use('/s3-zip-download', await s3ZipDownload(s3ZipDownloadEnv));
  apiRouter.use('/zip-manager', await zipManager(zipManagerEnv));
  apiRouter.use('/send-email', await sendEmail(sendEmailEnv));
  apiRouter.use(
    '/grafana-apigw-onprem',
    await grafanaApigwOnprem(grafanaApigwOnpremEnv),
  );
  apiRouter.use('/cloudwatch-logs', await cloudWatchLogs(cloudWatchLogsEnv));
  apiRouter.use('/service-manager', await serviceManager(serviceManagerEnv));
  apiRouter.use('/admincatalog', await adminCatalog(adminCatalogEnv));
  apiRouter.use(
    '/components-editor',
    await componentsEditor(componentsEditorEnv),
  );
  apiRouter.use('/metadata', await metadata());
  apiRouter.use('/markia', await markia(markiaEnv));
  apiRouter.use('/broken-links', await brokenLinks(brokenLinksEnv));
  apiRouter.use('/external-docs', await externalDocs(externalDocsEnv));
  apiRouter.use(
    '/review-validation',
    await reviewValidation(validateMetadataEnv),
  );
  apiRouter.use('/audit', await audit(auditEnv));
  apiRouter.use(
    '/components-responsibles',
    await componentsResponsibles(componentsResponsiblesEnv),
  );
  apiRouter.use('/disma', await disma(dismaEnv));
  apiRouter.use('/forms', await forms(formsEnv));
  apiRouter.use('/s3-images', await s3Images(s3ImagesEnv));
  apiRouter.use('/wsdl-to-html', await wsdlToHtml(wsdlToHtmlEnv));

  // Add backends ABOVE this line; this 404 handler is the catch-all fallback
  apiRouter.use(notFoundHandler());

  const service = createServiceBuilder(module)
    .loadConfig(config)
    .addRouter('/api', apiRouter)
    .addRouter('', await app(appEnv));

  await service.start().catch(err => {
    console.log(err);
    process.exit(1);
  });
}

module.hot?.accept();
main().catch(error => {
  console.error(`Backend failed to start up, ${error}`);
  process.exit(1);
});
