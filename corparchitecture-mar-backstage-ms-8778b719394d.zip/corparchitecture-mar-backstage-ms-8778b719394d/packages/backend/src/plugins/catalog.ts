/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { CatalogBuilder } from '@backstage/plugin-catalog-backend';
import { ScaffolderEntitiesProcessor } from '@backstage/plugin-scaffolder-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';
import { UserEntity, makeValidator } from '@backstage/catalog-model';
import {
  MicrosoftGraphOrgEntityProvider,
  defaultUserTransformer,
} from '@backstage/plugin-catalog-backend-module-msgraph';
import { RefArchEntitiesProcessor } from './RefArchEntityProcessor';
import { MapfreApiEntitiesProcessor } from './MapfreApiEntityProcessor';
import { MapfreApiLegacyEspEntitiesProcessor } from './MapfreApiLegacyEspEntityProcessor';
import { MapfreApiLegacyPerEntitiesProcessor } from './MapfreApiLegacyPerEntityProcessor';
import { MapfreApiLegacyBraEntitiesProcessor } from './MapfreApiLegacyBraEntityProcessor';
import { MethodEntitiesProcessor } from './MethodEntityProcessor';
import { MapfreApiLegacyGlobalEntitiesProcessor } from './MapfreApiLegacyGlobalEntityProcessor';
import { AwsS3EntityProvider } from '@backstage/plugin-catalog-backend-module-aws';
import { jsonSchemaRefPlaceholderResolver } from '@backstage/plugin-catalog-backend-module-openapi';
import {
  isLiablePersonRule,
  isLiableTeamRule,
  isLocalGovRule,
} from './permissions_custom_rules';
import { MapfreDocumentEntitiesProcessor } from './MapfreDocumentEntityProcessor';
import { MapfreSolutionEntitiesProcessor } from './MapfreSolutionEntityProcessor';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  const builder = await CatalogBuilder.create(env);
  builder.setFieldFormatValidators(
    makeValidator({
      isValidApiVersion: () => true,
      isValidKind: () => true,
      isValidEntityName: () => true,
      isValidNamespace: () => true,
      isValidLabelKey: () => true,
      isValidLabelValue: () => true,
      isValidAnnotationKey: () => true,
      isValidAnnotationValue: () => true,
      isValidTag: () => true,
    }),
  );

  builder.addEntityProvider(
    MicrosoftGraphOrgEntityProvider.fromConfig(env.config, {
      logger: env.logger,
      userTransformer: userTransformer,
      schedule: env.scheduler.createScheduledTaskRunner({
        frequency: { minutes: 20 },
        timeout: { minutes: 30 },
        initialDelay: { seconds: 3 },
      }),
    }),
  );

  builder.addEntityProvider(
    AwsS3EntityProvider.fromConfig(env.config, {
      logger: env.logger,
      // optional: alternatively, use scheduler with schedule defined in app-config.yaml
      schedule: env.scheduler.createScheduledTaskRunner({
        frequency: { minutes: 30 },
        timeout: { minutes: 3 },
      }),
      // optional: alternatively, use schedule
      scheduler: env.scheduler,
    }),
  );

  builder.addProcessor(new ScaffolderEntitiesProcessor());
  builder.addProcessor(new RefArchEntitiesProcessor());
  builder.addProcessor(new MapfreApiEntitiesProcessor());
  builder.addProcessor(new MapfreApiLegacyEspEntitiesProcessor());
  builder.addProcessor(new MapfreApiLegacyPerEntitiesProcessor());
  builder.addProcessor(new MapfreApiLegacyBraEntitiesProcessor());
  builder.addProcessor(new MethodEntitiesProcessor());
  builder.addProcessor(new MapfreDocumentEntitiesProcessor());
  builder.addProcessor(new MapfreApiLegacyGlobalEntitiesProcessor());
  builder.addProcessor(new MapfreSolutionEntitiesProcessor());
  builder.setPlaceholderResolver('openapi', jsonSchemaRefPlaceholderResolver);
  builder.setPlaceholderResolver('asyncapi', jsonSchemaRefPlaceholderResolver);
  builder.addPermissionRules(isLiablePersonRule);
  builder.addPermissionRules(isLiableTeamRule);
  builder.addPermissionRules(isLocalGovRule);
  const seconds = env.config.getNumber('catalog.interval.seconds');
  const { processingEngine, router } = await builder
    .setProcessingIntervalSeconds(seconds)
    .build();
  await processingEngine.start();
  return router;
}

export async function userTransformer(
  user: microsoftgraph.User,
  userPhoto?: string,
): Promise<UserEntity | undefined> {
  const entity = await defaultUserTransformer(user, userPhoto);

  if (entity) {
    const annotations = entity.metadata.annotations || {};

    const userFields: Partial<
      Pick<
        microsoftgraph.User,
        | 'companyName'
        | 'department'
        | 'officeLocation'
        | 'userType'
        | 'mobilePhone'
        | 'country'
        | 'preferredLanguage'
        | 'userPrincipalName'
      >
    > = {
      companyName: user.companyName,
      department: user.department,
      officeLocation: user.officeLocation,
      userType: user.userType,
      mobilePhone: user.mobilePhone,
      country: user.country,
      preferredLanguage: user.preferredLanguage,
      userPrincipalName: user.userPrincipalName,
    };

    for (const [key, value] of Object.entries(userFields)) {
      if (value) {
        annotations[key] = value;
      }
    }

    if (user.businessPhones && user.businessPhones.length > 0) {
      annotations['businessPhones'] = user.businessPhones.join(', ');
    }

    entity.metadata.annotations = annotations;
  }

  return entity;
}
