import { createRouter } from '@backstage/plugin-admincatalog-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger: env.logger,
    accessKeyId: env.config.getString(
      'adminCatalog.dynamoDB.credentials.accessKeyId',
    ),
    secretAccessKey: env.config.getString(
      'adminCatalog.dynamoDB.credentials.secretAccessKey',
    ),
    region: env.config.getString('adminCatalog.dynamoDB.region'),
    auth: env.config
      .getConfigArray('integrations.awsS3')
      .concat(env.config.getConfigArray('integrations.bitbucketCloud')),
    bucket: env.config.getString('adminCatalog.s3.systemsBucket'),
    catalogClientThemesTable: env.config.getString(
      'adminCatalog.dynamoDB.catalogClientThemesTable',
    ),
    catalogPropertiesTable: env.config.getString(
      'adminCatalog.dynamoDB.catalogPropertiesTable',
    ),
    catalogTemplatesTable: env.config.getString(
      'adminCatalog.dynamoDB.catalogTemplatesTable',
    ),
    catalogFormsTable: env.config.getString(
      'adminCatalog.dynamoDB.catalogFormsTable',
    ),
  });
}
