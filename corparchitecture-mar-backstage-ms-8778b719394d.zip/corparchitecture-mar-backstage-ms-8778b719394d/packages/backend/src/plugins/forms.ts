import { createRouter } from '@backstage/plugin-forms-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';
export default async function createPlugin({
  logger,
  config,
}: PluginEnvironment): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!
  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger,
    auth: config.getConfigArray('integrations.awsS3'),
    dashboardAccessKeyId: config.getString('apiDashboard.accessKeyId'),
    dashboardSecretAccessKey: config.getString('apiDashboard.secretAccessKey'),
    dashboardDomainTable: config.getString('apiDashboard.domainTable'),
    dashboardCountryTable: config.getString('apiDashboard.countryTable'),
  });
}
