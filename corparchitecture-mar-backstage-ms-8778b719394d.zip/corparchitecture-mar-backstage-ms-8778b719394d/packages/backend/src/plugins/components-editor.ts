import { createRouter } from '@backstage/plugin-components-catalog-edit-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin({
  logger,
  config,
  permissions,
}: PluginEnvironment): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger,
    auth: config
      .getConfigArray('integrations.awsS3')
      .concat(config.getConfigArray('integrations.github'))
      .concat(config.getConfigArray('integrations.bitbucketCloud')),
    permissions,
    zeus: config.getConfig('zeus'),
  });
}
