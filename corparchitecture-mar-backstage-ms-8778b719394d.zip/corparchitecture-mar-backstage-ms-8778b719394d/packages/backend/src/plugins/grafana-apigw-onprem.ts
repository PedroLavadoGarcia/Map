import { createRouter } from '@backstage/plugin-grafana-apigw-onprem-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin({
  logger,
  config,
}: PluginEnvironment): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger,
    tenant_id: config.getOptionalString('add.catalogapi_onprem.tenant_id'),
    grant_type: config.getOptionalString('add.catalogapi_onprem.grant_type'),
    client_id: config.getOptionalString('add.catalogapi_onprem.client_id'),
    client_secret: config.getOptionalString(
      'add.catalogapi_onprem.client_secret',
    ),
    username: config.getOptionalString('add.catalogapi_onprem.username'),
    password: config.getOptionalString('add.catalogapi_onprem.password'),
    scope: config.getOptionalString('add.catalogapi_onprem.scope'),
    apigwUrl: config.getOptionalString('grafana.apigwUrl'),
    stage: config.getOptionalString('grafana.stage'),
    host: config.getOptionalString('grafana.host'),
  });
}
