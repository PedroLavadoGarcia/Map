import {
  CatalogProcessor,
  CatalogProcessorEmit,
  processingResult,
} from '@backstage/plugin-catalog-node';
import { LocationSpec } from '@backstage/plugin-catalog-common';
import {
  Entity,
  entityKindSchemaValidator,
  EntityMeta,
  getCompoundEntityRef,
  parseEntityRef,
  RELATION_OWNED_BY,
  RELATION_OWNER_OF,
} from '@backstage/catalog-model';

import mapfreDocumentEntityV1alpha1Schema from './schema/MapfreDocument.v1alpha1.schema.json';
import Countries from '../enums/Countries';

export interface MapfreDocumentEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'MapfreDocument';
  metadata: EntityMeta & {
    country: Countries;
    global_business_areas: boolean;
    state: string;
    name_beta: string;
    header_icon: string;
    liableTeam?: {
      'mapfre.com/responsible': string;
      'mapfre.com/writers': string;
      'mapfre.com/reviewers': string;
    };
    contextData: {
      pro_doc_repo_url: string;
      beta_doc_repo_url: string;
    };
    historyLog: {
      creation_date: string;
      acceptance_date: string;
      publication_date: string;
      last_update_date: string;
      retired_date: string;
      creation_user: string;
      last_update_user: string;
      retired_user: string;
    };
  };
  spec: {
    type: string;
    lifecycle: string;
    owner: string;
  };
}

export class MapfreDocumentEntitiesProcessor implements CatalogProcessor {
  // You often end up wanting to support multiple versions of your kind as you
  // iterate on the definition, so we keep each version inside this array.
  private readonly validators = [
    // This is where we use the JSONSchema that we export from our isomorphic package
    entityKindSchemaValidator(mapfreDocumentEntityV1alpha1Schema),
  ];

  // validateEntityKind is responsible for signaling to the catalog processing engine
  // that this entity is valid and should therefore be submitted for further processing.
  async validateEntityKind(entity: Entity): Promise<boolean> {
    for (const validator of this.validators) {
      if (validator(entity)) {
        return true;
      }
    }

    return false;
  }

  getProcessorName(): string {
    return 'MapfreDocumentEntityProcessor';
  }

  async postProcessEntity(
    entity: Entity,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _location: LocationSpec,
    emit: CatalogProcessorEmit,
  ): Promise<Entity> {
    const selfRef = getCompoundEntityRef(entity);

    function doEmit(
      targets: string | string[] | undefined,
      context: { defaultKind?: string; defaultNamespace: string },
      outgoingRelation: string,
      incomingRelation: string,
    ): void {
      if (!targets) {
        return;
      }
      for (const target of [targets].flat()) {
        const targetRef = parseEntityRef(target, context);
        emit(
          processingResult.relation({
            source: selfRef,
            type: outgoingRelation,
            target: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
          }),
        );
        emit(
          processingResult.relation({
            source: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
            type: incomingRelation,
            target: selfRef,
          }),
        );
      }
    }
    const MapfreDocument = entity as MapfreDocumentEntityV1alpha1;
    doEmit(
      MapfreDocument.spec.owner,
      { defaultKind: 'Group', defaultNamespace: selfRef.namespace },
      RELATION_OWNED_BY,
      RELATION_OWNER_OF,
    );

    return entity as MapfreDocumentEntityV1alpha1;
  }
}
