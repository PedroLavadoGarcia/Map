import {
  DEFAULT_NAMESPACE,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import {
  createRouter,
  providers,
  defaultAuthProviderFactories,
  getDefaultOwnershipEntityRefs,
} from '@backstage/plugin-auth-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

// Change to test the group membership
const LOCAL_EXTRA_GROUPS = [
  'group:default/gazr-gov-backstage-admin-dev',
  'group:default/gazr-gov-backstage-doc-global-dev',
];

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  return await createRouter({
    logger: env.logger,
    config: env.config,
    database: env.database,
    discovery: env.discovery,
    tokenManager: env.tokenManager,
    providerFactories: {
      ...defaultAuthProviderFactories,
      bitbucket: providers.bitbucket.create({
        authHandler: async ({ fullProfile }) => {
          let email: string | undefined = undefined;
          if (fullProfile.emails && fullProfile.emails.length > 0) {
            const [firstEmail] = fullProfile.emails;
            email = firstEmail.value;
          }

          let picture: string | undefined = undefined;
          if (fullProfile.photos && fullProfile.photos.length > 0) {
            const [firstPhoto] = fullProfile.photos;
            picture = firstPhoto.value;
          }

          const displayName: string | undefined =
            fullProfile.displayName ?? fullProfile.username ?? fullProfile.id;

          if (fullProfile.emails === undefined) {
            email = fullProfile.displayName;
          }
          return {
            profile: {
              email,
              picture,
              displayName,
            },
          };
        },
      }),
      awsalb: providers.awsAlb.create({
        authHandler: async ({ fullProfile }) => {
          let email: string | undefined = undefined;
          if (fullProfile.emails && fullProfile.emails.length > 0) {
            const [firstEmail] = fullProfile.emails;
            email = firstEmail.value;
          }

          let picture: string | undefined = undefined;
          if (fullProfile.name && fullProfile.name.givenName) {
            picture = fullProfile.name.givenName;
          }

          const displayName: string | undefined =
            fullProfile.displayName ?? fullProfile.username ?? fullProfile.id;

          if (fullProfile.emails === undefined) {
            email = fullProfile.displayName;
          }

          return {
            profile: {
              email,
              picture,
              displayName,
            },
          };
        },
        signIn: {
          resolver: async ({ profile: { email, picture } }, ctx) => {
            if (email === undefined) {
              throw new Error('Email is undefined');
            }
            try {
              const id = email?.replace('@', '_') ?? '';

              // Fetch from an external system that returns entity claims like:
              // ['user:default/breanna.davison', ...]
              const userEntityRef = stringifyEntityRef({
                kind: 'User',
                namespace: DEFAULT_NAMESPACE,
                name: id,
              });

              // Resolve group membership from the Backstage catalog test

              const { entity } = await ctx.findCatalogUser({
                entityRef: userEntityRef,
              });
              const ent = getDefaultOwnershipEntityRefs(entity);

              const token = await ctx.issueToken({
                claims: { sub: userEntityRef, ent, id },
              });

              return token;
            } catch (error) {
              console.error(error);
              const id = email?.replace('@', '_') ?? '';
              const userEntityRef = stringifyEntityRef({
                kind: 'User',
                namespace: DEFAULT_NAMESPACE,
                name: id,
              });

              const ent: string[] = [];

              if (picture) {
                ent.push(picture);
              }

              const token = await ctx.issueToken({
                claims: {
                  sub: userEntityRef,
                  ent: [userEntityRef],
                  id: id,
                },
              });

              return token;
            }
          },
        },
      }),
      microsoft: providers.microsoft.create({
        authHandler: async ({ fullProfile }) => {
          let email: string | undefined = undefined;
          if (fullProfile.emails && fullProfile.emails.length > 0) {
            const [firstEmail] = fullProfile.emails;
            email = firstEmail.value;
          }

          const displayName: string | undefined =
            fullProfile.displayName ?? fullProfile.username ?? fullProfile.id;

          return {
            profile: {
              email,
              displayName,
            },
          };
        },
        signIn: {
          resolver: async ({ profile: { email } }, ctx) => {
            if (!email) {
              throw new Error(
                'Login failed, user profile does not contain an email',
              );
            }

            const id = email.replace('@', '_');

            const userEntityRef = stringifyEntityRef({
              kind: 'User',
              name: id,
              namespace: DEFAULT_NAMESPACE,
            });

            const ent: string[] = [];

            try {
              const { entity } = await ctx.findCatalogUser({
                entityRef: userEntityRef,
              });

              ent.push(...getDefaultOwnershipEntityRefs(entity));
            } catch (error) {
              console.log(error);
            }

            ent.push(userEntityRef);
            ent.push(...LOCAL_EXTRA_GROUPS);

            const token = await ctx.issueToken({
              claims: {
                sub: userEntityRef,
                ent: ent.length > 0 ? ent : [userEntityRef],
                id: id,
              },
            });

            return token;
          },
        },
      }),
    },
  });
}
