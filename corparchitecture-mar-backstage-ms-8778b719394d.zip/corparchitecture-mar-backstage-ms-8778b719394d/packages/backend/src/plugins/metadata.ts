import { createRouter } from '@backstage/plugin-metadata-backend';
import { Router } from 'express';

export default async function createPlugin(): Promise<Router> {
  return await createRouter();
}
