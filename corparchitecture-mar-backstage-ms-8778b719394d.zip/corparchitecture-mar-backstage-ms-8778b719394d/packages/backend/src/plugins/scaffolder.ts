import { CatalogClient } from '@backstage/catalog-client';
import {
  createRouter,
  createBuiltinActions,
} from '@backstage/plugin-scaffolder-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

import { ScmIntegrations } from '@backstage/integration';

import {
  createZipAction,
  createWriteFileAction,
  createAppendFileAction,
  createSleepAction,
} from '@roadiehq/scaffolder-backend-module-utils';
import {
  initializrAction,
  CreateZipAction,
  FrontCLIAction,
  BackCLIAction,
  ZeusCreateTask,
  ZeusDoneTask,
  WorkspaceDecision,
  outputFileAction,
  repositoryNameAction,
  creationDateAction,
  creationIdAction,
  putLogsCreatedAction,
  NotifyComponentCreationAction,
  validateApiAction,
  createAwsS3Action,
  registerLocationAwsS3Action,
  createAwsS3ActionComponents,
  getLoggedUser,
  TronApiAction,
  MoveFileAction,
  CheckConfigRepo,
  ResponsiblesAction,
  createMapfrePublishBitbucketCloudAction,
  GithubCreateRepo,
} from './scaffolder/actions';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  const { config } = env;
  const catalogClient = new CatalogClient({
    discoveryApi: env.discovery,
  });

  const integrations = ScmIntegrations.fromConfig(env.config);

  const builtInActions = createBuiltinActions({
    integrations,
    catalogClient,
    config,
    reader: env.reader,
  });

  const actions = [
    ...builtInActions,
    initializrAction(),
    CreateZipAction({
      config,
    }),
    FrontCLIAction({
      config,
    }),
    BackCLIAction({
      config,
    }),
    TronApiAction({
      config,
    }),
    MoveFileAction({
      config,
    }),
    CheckConfigRepo({
      config,
    }),
    // MoveFileAction({
    //   config,
    // }),
    GithubCreateRepo({
      config
    }),
    NotifyComponentCreationAction({
      config,
    }),
    WorkspaceDecision(),
    createZipAction(),
    createWriteFileAction(),
    createAppendFileAction(),
    createSleepAction(),
    outputFileAction(),
    ZeusCreateTask({
      db: env.database,
      config,
    }),
    ZeusDoneTask({
      config,
    }),
    repositoryNameAction(),
    creationDateAction(),
    creationIdAction(),
    putLogsCreatedAction({
      config,
    }),
    validateApiAction({
      catalogClient,
      config,
    }),
    createAwsS3Action({
      config,
    }),
    createAwsS3ActionComponents({
      config,
    }),
    registerLocationAwsS3Action({
      catalogClient,
    }),
    getLoggedUser({
      config,
    }),
    ResponsiblesAction({
      config,
      catalog: catalogClient,
    }),
    createMapfrePublishBitbucketCloudAction({
      config,
      integrations,
    }),
  ];

  return await createRouter({
    actions,
    logger: env.logger,
    config,
    database: env.database,
    reader: env.reader,
    catalogClient,
  });
}
