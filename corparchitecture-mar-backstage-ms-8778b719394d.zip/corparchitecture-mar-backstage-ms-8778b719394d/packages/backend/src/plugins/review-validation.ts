import { createRouter } from '@backstage/plugin-review-validation-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin({
  logger,
  config,
}: PluginEnvironment): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger,
    apigwUrl: config.getOptionalString('grafana.apigwUrl'),
    stage: config.getString('grafana.stage'),
    host: config.getOptionalString('grafana.host'),
    authS3: config.getConfigArray('integrations.awsS3'),
    backendUrl: config.getOptionalString('backend.baseUrl') ?? '',
    email: config.getOptionalString('ses.email') ?? '',
    env: config.getOptionalString('app.env') ?? '',
  });
}
