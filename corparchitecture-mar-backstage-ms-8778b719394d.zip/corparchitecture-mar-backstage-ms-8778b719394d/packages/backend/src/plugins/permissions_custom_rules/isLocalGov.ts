import { parseEntityRef } from '@backstage/catalog-model';
import { createCatalogPermissionRule } from '@backstage/plugin-catalog-backend/alpha';
import { RESOURCE_TYPE_CATALOG_ENTITY } from '@backstage/plugin-catalog-common/alpha';
import { createConditionFactory } from '@backstage/plugin-permission-node';
import { z } from 'zod';

const getUserCountries = (ownershipEntityRefs: string[] | undefined) => {
  return ownershipEntityRefs
    ?.filter((ref: string) => {
      const entityRef = parseEntityRef(ref);
      return (
        entityRef.kind.toLowerCase() === 'group' &&
        entityRef.name.toLowerCase().startsWith('gazr-gov-backstage')
      );
    })
    .map((ref: string) => {
      const parts = parseEntityRef(ref).name.split('-');
      return parts[parts.length - 2].toUpperCase();
    });
};

export const isLocalGovRule = createCatalogPermissionRule({
  name: 'IS_LOCAL_GOV',
  description:
    'Allow if the user is a member of the local government of an API',
  resourceType: RESOURCE_TYPE_CATALOG_ENTITY,
  paramsSchema: z.object({
    ownershipEntityRefs: z
      .array(z.string())
      .optional()
      .describe('User ownership entity refs'),
  }),
  apply: (resource, { ownershipEntityRefs }) => {
    if (!resource.kind.toLocaleLowerCase().startsWith('mapfreapi')) {
      return true;
    }

    const userCountries = getUserCountries(ownershipEntityRefs);

    const resourceCountry = resource.metadata?.country as string | undefined;
    return (
      !!resourceCountry &&
      !!userCountries &&
      userCountries.includes(resourceCountry.toUpperCase())
    );
  },
  toQuery: ({ ownershipEntityRefs }) => {
    const userCountries = getUserCountries(ownershipEntityRefs);

    return {
      allOf: [
        { key: 'kind', values: ['MapfreApi'] },
        ...(userCountries
          ? userCountries.map(country => ({
              key: 'metadata.country',
              values: [country],
            }))
          : []),
      ],
    };
  },
});

export const isLocalGov = createConditionFactory(isLocalGovRule);
