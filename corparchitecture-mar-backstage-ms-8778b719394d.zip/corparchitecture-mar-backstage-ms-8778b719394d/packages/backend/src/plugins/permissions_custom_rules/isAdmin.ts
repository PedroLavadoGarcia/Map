import { BasicPermission } from '@backstage/plugin-permission-common';

export const marketplaceAdminView: BasicPermission = {
  type: 'basic',
  name: 'catalog.marketplace.view.all',
  attributes: {
    action: 'read',
  },
};
