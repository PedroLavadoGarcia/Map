import { createCatalogPermissionRule } from '@backstage/plugin-catalog-backend/alpha';
import { RESOURCE_TYPE_CATALOG_ENTITY } from '@backstage/plugin-catalog-common/alpha';
import { createConditionFactory } from '@backstage/plugin-permission-node';
import { z } from 'zod';

export const isGlobalDocGovRule = createCatalogPermissionRule({
  name: 'IS_GLOBAL_DOC_GOV',
  description:
    'Allow if the user is a member of the global government documentation group',
  resourceType: RESOURCE_TYPE_CATALOG_ENTITY,
  paramsSchema: z.object({
    ownershipEntityRefs: z
      .array(z.string())
      .optional()
      .describe('User ownership entity refs'),
  }),
  apply: (_resource, { ownershipEntityRefs }) => {
    return !!ownershipEntityRefs?.some(ref =>
      ref.toLowerCase().includes('group:gazr-gov-backstage-doc-global'),
    );
  },
  toQuery: () => {
    return {
      allOf: [{ key: 'kind', values: ['MapfreDocument'] }],
    };
  },
});

export const isGlobalDocGov = createConditionFactory(isGlobalDocGovRule);
