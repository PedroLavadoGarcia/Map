import { parseEntityRef, stringifyEntityRef } from '@backstage/catalog-model';
import { createCatalogPermissionRule } from '@backstage/plugin-catalog-backend/alpha';
import { RESOURCE_TYPE_CATALOG_ENTITY } from '@backstage/plugin-catalog-common/alpha';
import { createConditionFactory } from '@backstage/plugin-permission-node';
import { z } from 'zod';

/**
 * A catalog {@link @backstage/plugin-permission-node#PermissionRule} which
 * filters for the presence of an annotation inside liableTeam on a given MapfreDocument.
 *
 * If a userRef is given (in local dev env defaults to undefined), it filters for the annotation value, too.
 *
 */
export const isLiableTeamRule = createCatalogPermissionRule({
  name: 'IS_LIABLE_TEAM',
  description:
    'Allow if the user initiating the request is a liable team of the MapfreDocument',
  resourceType: RESOURCE_TYPE_CATALOG_ENTITY,
  paramsSchema: z.object({
    liableTeam: z.string().describe('Name of the annotation to match on'),
    userRef: z.string().optional().describe('Requesting user entity ref'),
  }),
  apply: (resource, { liableTeam, userRef }) => {
    if (
      !resource.kind.toLocaleLowerCase().startsWith('mapfredocument') ||
      !resource.kind.toLocaleLowerCase().startsWith('mapfresolution')
    ) {
      return true;
    }

    return (
      // eslint-disable-next-line no-prototype-builtins
      !!resource.metadata.liableTeam?.hasOwnProperty(liableTeam) &&
      (userRef === undefined
        ? true
        : !!(resource.metadata?.liableTeam as Record<string, string[]>)?.[
            liableTeam
          ].find(
            ref => parseEntityRef(ref).name === parseEntityRef(userRef).name,
          ))
    );
  },
  toQuery: ({ liableTeam, userRef }) =>
    userRef === undefined
      ? {
          allOf: [
            { key: 'kind', values: ['MapfreDocument', 'MapfreSolution'] },
            {
              key: `metadata.liableTeam.${liableTeam}`,
            },
          ],
        }
      : {
          allOf: [
            { key: 'kind', values: ['MapfreDocument', 'MapfreSolution'] },
            {
              key: `metadata.liableTeam.${liableTeam}`,
              values: [
                `${parseEntityRef(userRef).kind}:${
                  parseEntityRef(userRef).name
                }`,
                stringifyEntityRef(parseEntityRef(userRef)),
              ],
            },
          ],
        },
});

export const isLiableTeam = createConditionFactory(isLiableTeamRule);
