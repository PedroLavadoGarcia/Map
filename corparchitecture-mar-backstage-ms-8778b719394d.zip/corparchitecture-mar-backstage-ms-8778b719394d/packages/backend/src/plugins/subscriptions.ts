import { createRouter } from '@backstage/plugin-subscriptions-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger: env.logger,
    accessKeyId: env.config.getString(
      'subscriptions.dynamoDB.credentials.accessKeyId',
    ),
    secretAccessKey: env.config.getString(
      'subscriptions.dynamoDB.credentials.secretAccessKey',
    ),
    region: env.config.getString('subscriptions.dynamoDB.region'),
    env: env.config.getString('subscriptions.dynamoDB.env'),
    apiLogsChangesTable: env.config.getString(
      'subscriptions.dynamoDB.apiLogsChangesTable',
    ),
    userSubscriptionsTable: env.config.getString(
      'subscriptions.dynamoDB.userSubscriptionsTable',
    ),
    catalogSubscriptions: env.config.getString(
      'subscriptions.dynamoDB.catalogSubscriptions',
    ),
    governmentGroupsByCountryTable: env.config.getString(
      'subscriptions.dynamoDB.governmentGroupsByCountryTable',
    ),
    // This env is for market event bus integration for eventbridge.
  });
}
