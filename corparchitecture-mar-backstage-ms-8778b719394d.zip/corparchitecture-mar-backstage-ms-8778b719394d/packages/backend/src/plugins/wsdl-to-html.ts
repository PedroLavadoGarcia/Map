import { createRouter } from '@backstage/plugin-wsdl-to-html-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin({
  logger,
  config,
}: PluginEnvironment): Promise<Router> {
  return await createRouter({
    logger,
    authS3: config.getConfigArray('integrations.awsS3'),
  });
}
