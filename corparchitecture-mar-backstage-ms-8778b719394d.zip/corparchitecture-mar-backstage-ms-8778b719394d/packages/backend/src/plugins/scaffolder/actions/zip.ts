import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { exec, pwd, mkdir, test, rm } from 'shelljs';
import { Config } from '@backstage/config';
import { v4 } from 'uuid';
import * as path from 'path';

const ZIP_DURATION = 5; // In minutes

export const CreateZipAction = (options: { config: Config }) => {
  return createTemplateAction<{ componentId: string }>({
    id: 'mapfre:utils:zip',
    async handler(ctx) {
      const { config } = options;
      const backendUrl = config.getString('backend.baseUrl');
      const zipsPath = config.getOptionalString('zipManager.path') ?? '/';

      const root = path.join(pwd().stdout, '../../..');

      const fullZipsPath = path.join(root, zipsPath);
      if (!test('-d', fullZipsPath)) {
        mkdir(fullZipsPath);
      }
      const id = `${ctx.input.componentId}-${v4()}`;
      const filePath = path.join(root, zipsPath, `${id}.zip`);
      console.log(filePath);
      exec(`tar -czvf ${filePath} -C ${ctx.workspacePath} .`);

      ctx.logger.info(`${ctx.input.componentId} zipped success`);
      const url = `${backendUrl}/api/zip-manager/download/${id}`;
      ctx.output('zipUrl', url);

      setTimeout(() => {
        rm(`${filePath}`);
        console.log(`${filePath} delated`);
      }, ZIP_DURATION * 60 * 1000);
    },
  });
};
