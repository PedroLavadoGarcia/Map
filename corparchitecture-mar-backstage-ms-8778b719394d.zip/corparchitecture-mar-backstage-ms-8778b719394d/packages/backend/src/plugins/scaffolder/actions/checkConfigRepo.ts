import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { Config } from '@backstage/config';
import fetch from 'node-fetch';

export const CheckConfigRepo = (options: { config: Config }) => {
  return createTemplateAction<{
    repoName: string;
    repoWorkspace: string;
  }>({
    id: 'mapfre:check:configRepo',
    async handler(ctx) {
      // Make a fetch to a Bitbucket repository. If the response is 200, then the repository exists. Use fetch and authorization.
      const { config } = options;

      const auth = config.getConfigArray('integrations.bitbucketCloud');
      const username: string = auth[0].getString('username');
      const appPassword: string = auth[0].getString('appPassword');

      const repoName = ctx.input.repoName;
      const repoWorkspace = ctx.input.repoWorkspace;
      ctx.logger.info(
        'Repo Name: ' + repoName + ' Repo Owner: ' + repoWorkspace,
      );

      const URL = `https://api.bitbucket.org/2.0/repositories/${repoWorkspace}/${repoName}`;

      const response = await fetch(URL, {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          Authorization: `Basic ${Buffer.from(
            `${username}:${appPassword}`,
            'binary',
          ).toString(`base64`)}`,
        },
      });

      if (response.ok) {
        ctx.logger.info('Repository exists');
        ctx.output('repoExists', true);
      } else {
        ctx.logger.info('Repository does not exist');
        ctx.output('repoExists', false);
      }
    },
  });
};
