import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';

export function repositoryNameAction() {
  return createTemplateAction<{
    name: string;
  }>({
    id: 'mapfre:utils:repository',
    description: 'Composes the repository name with uuid created previously',
    schema: {
      input: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
          },
        },
      },
      output: {
        type: 'object',
        properties: {
          repoName: {
            title: 'repository Name',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      ctx.output(`repoName`, ctx.input.name);
    },
  });
}
