import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';

export function creationDateAction() {
  return createTemplateAction<{ date: string }>({
    id: 'mapfre:utils:date',
    description: 'Creates a current date to register as modification date',
    schema: {
      output: {
        properties: {
          date: {
            title: 'Modification Date',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      const now = Date.now();

      ctx.output('date', now);
    },
  });
}
