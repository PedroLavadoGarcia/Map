import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { Config } from '@backstage/config';
import axios from 'axios';

export const GithubCreateRepo = (options: { config: Config }) => {
  return createTemplateAction<{
    entity: string;
    product: string;
    component: string;
    template: string;
  }>({
    id: 'mapfre:cli:github',
    async handler(ctx) {
      const { config } = options;
      const { entity, product, component, template } = ctx.input;
      const clientId = config.getOptionalString('add.backstage.clientId') ?? '';
      const clientSecret =
        config.getOptionalString('add.backstage.clientSecret') ?? '';
      const zeusTenantId =
        config.getOptionalString('controlplane.tenantId') ?? '';
      const zeusClientId =
        config.getOptionalString('controlplane.clientId') ?? '';
      const controlplaneApiUrl =
        config.getOptionalString('controlplane.apiUrl') ?? '';
      const controlplaneApiKey =
        config.getOptionalString('controlplane.apiKey') ?? '';
      const appUrl = config.getOptionalString('app.baseUrl') ?? '';

      ctx.logger.info(
        `Running with input...\n${JSON.stringify(
          {
            entity,
            product,
            component,
            template,
          },
          null,
          2,
        )}`,
      );

      const body = {
        grant_type: 'client_credentials',
        client_id: clientId,
        scope: `${zeusClientId}/.default`,
        client_secret: clientSecret,
      };
      const params = new URLSearchParams();
      for (const key in body) {
        params.append(key, body[key as keyof typeof body]);
      }
      let accessToken = '';
      try {
        const tokenResponse = await axios.post(
          `https://login.microsoftonline.com/${zeusTenantId}/oauth2/v2.0/token`,
          params,
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          },
        );
        ctx.logger.info('token getted');
        accessToken = tokenResponse.data.access_token;
      } catch (error) {
        console.log(error);
        throw new Error('error getting token');
      }

      const headers: any = {
        Authorization: `Bearer ${accessToken}`,
        'x-atlas-api-key': controlplaneApiKey,
        'X-User-Requester':
          ctx.user?.entity?.metadata.annotations?.userPrincipalName ?? '',
        origin: !appUrl.includes('localhost') ? appUrl : 'marketplace',
      };

      try {
        const response = await axios.post(
          `${controlplaneApiUrl}/repositories`,
          {
            entity,
            product,
            component,
            template: template ? template : null,
            ignorePrefix: false,
            defaultBranch: true,
          },
          {
            headers,
          },
        );

        console.log(response.data);
        ctx.logger.info('repository created');
      } catch (error: any) {
        console.log(error);
        if (error.response.data) {
          throw new Error(error.response.data.message);
        } else {
          throw new Error('error creating repo');
        }
      }
    },
  });
};
