import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import fs from 'fs-extra';

export const MoveFileAction = (options: { config: Config }) => {
  return createTemplateAction<{
    // GENERAL
    sourcePath: string;
    targetPath: string;
  }>({
    id: 'mapfre:tron:moveFile',
    async handler(ctx) {
      const { config } = options;

      ctx.logger.info(
        `Init action with input:\n${JSON.stringify(ctx.input, null, 2)}`,
      );

      const { sourcePath, targetPath } = ctx.input;

      fs.renameSync(
        `${ctx.workspacePath}${sourcePath}`,
        `${ctx.workspacePath}${targetPath}`,
      );
    },
  });
};
