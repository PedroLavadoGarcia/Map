import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import {
  LambdaClient,
  InvokeWithResponseStreamCommand,
} from '@aws-sdk/client-lambda';
import {
  S3Client,
  ListObjectsCommand,
  GetObjectCommand,
} from '@aws-sdk/client-s3';
import { ShellString, mkdir } from 'shelljs';
import { dirname } from 'path';

const lambdaClient = new LambdaClient({});
const s3Client = new S3Client({});
const textDecoder = new TextDecoder();
const textEncoder = new TextEncoder();

export const TronApiAction = (options: { config: Config }) => {
  return createTemplateAction<{
    // GENERAL
    countryCod: string;
    apiType: string;
  }>({
    id: 'mapfre:tron:api',
    async handler(ctx) {
      const { config } = options;
      const functionName = config.getString(
        'archetypes.tron.api.function.name',
      );
      const bucketName = config.getString('archetypes.bucket.name');
      const taskPath = ctx.workspacePath;

      ctx.logger.info(
        `Init action with input:\n${JSON.stringify(ctx.input, null, 2)}`,
      );

      const { countryCod, apiType } = ctx.input;
      let projectName = '';
      if (apiType == 'business') {
        projectName = `business_api_${countryCod}_be`;
      } else {
        projectName = `nwt_${apiType}_api_${countryCod}_be`;
      }

      const tronApiInput = {
        countryCod,
        apiType,
      };

      await createTronApiArch();
      await downloadTronApiArch();

      async function createTronApiArch() {
        ctx.logger.info('⏳ Creating arch...');
        const response = await lambdaClient.send(
          new InvokeWithResponseStreamCommand({
            FunctionName: functionName,
            Payload: textEncoder.encode(JSON.stringify(tronApiInput)),
          }),
        );

        const stream = response.EventStream;
        if (stream) {
          for await (const response of stream) {
            if (response.PayloadChunk) {
              const decodedPayload = textDecoder.decode(
                response.PayloadChunk.Payload,
              );
              try {
                const payload = JSON.parse(
                  `[${decodedPayload.replace(/}\s*{/g, '},{')}]`,
                );
                for (const res of payload) {
                  switch (res.type) {
                    case 'message':
                      ctx.logger.info(res.message);
                      break;
                    case 'warn':
                      ctx.logger.warn(res.message);
                      break;
                    case 'error':
                      throw new Error(res.message);
                  }
                }
              } catch (error) {
                ctx.logger.info(decodedPayload);
              }
            }
          }
        }
      }

      async function downloadTronApiArch() {
        ctx.logger.info(
          `⏳ Downloading ${projectName} from bucket ${bucketName}...`,
        );
        const listObjectsResponse = await s3Client.send(
          new ListObjectsCommand({
            Bucket: bucketName,
            Prefix: `${projectName}/`,
          }),
        );
        const objects = listObjectsResponse.Contents!;

        for (const obj of objects) {
          const objectKey = obj.Key!;
          const downloadParams = {
            Bucket: bucketName,
            Key: objectKey,
          };

          const downloadCommand = new GetObjectCommand(downloadParams);
          const downloadResponse = await s3Client.send(downloadCommand);
          const body = downloadResponse.Body;

          const objectPath = objectKey.substring(objectKey.indexOf('/') + 1);
          const localFilePath = `${taskPath}/${objectPath}`;
          mkdir('-p', dirname(localFilePath));
          const content = await body?.transformToString('utf8');
          if (content) {
            ShellString(content).to(localFilePath);
          }
        }
      }
    },
  });
};
