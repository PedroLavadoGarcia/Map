import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import axios from 'axios';
import { createWriteStream } from 'fs';
import { exec, rm } from 'shelljs';

export function initializrAction() {
  return createTemplateAction<{
    params: any;
    type: 'gaia' | 'spring';
  }>({
    id: 'mapfre:utils:initializr',
    async handler(ctx) {
      console.log(ctx.input)
      const root = ctx.workspacePath;
      const zipPath = `${root}/starter.zip`;
      const sourcePath = `${root}/source/`;
      let url;
      switch (ctx.input.type) {
        case 'gaia':
          url = 'https://gaia-boot-initializr.azurewebsites.net/starter.zip';
          break;
        case 'spring':
          url = 'https://start.spring.io/starter.zip'
          break;
      }

      const params = {
        ...ctx.input.params
      }

      if (ctx.input.params.artifactId) {
        params['baseDir'] = ctx.input.params.artifactId
      }

      url = addUrlParams(url, params);

      ctx.logger.info(
        `Calling ${ctx.input.type} initializr with params:\n${JSON.stringify(
          params,
          null,
          2,
        )}`,
      );
      const response = await axios.get(url, {
        responseType: 'stream'
      });

      ctx.logger.info('Writing response to source');
      const writer = createWriteStream(zipPath);

      response.data.pipe(writer);
      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });

      rm(`${sourcePath}/.gitkeep`);
      exec(`unzip ${zipPath} -d ${sourcePath} && mv ${sourcePath}/${params.baseDir}/* ${sourcePath}/ && rm -rf ${sourcePath}/${params.baseDir}`);
      rm(`${zipPath}`);
      ctx.logger.info('Source is ready');
    },
  });
}

function addUrlParams(
  url: string,
  params: { [key: string]: string | number | string[] },
) {
  const urlSearchParams = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (Array.isArray(value)) {
      for (const v of value) {
        urlSearchParams.append(key, v.toString());
      }
    } else {
      urlSearchParams.set(key, value.toString());
    }
  }
  const paramString = urlSearchParams.toString();
  return paramString ? `${url}?${paramString}` : url;
}
