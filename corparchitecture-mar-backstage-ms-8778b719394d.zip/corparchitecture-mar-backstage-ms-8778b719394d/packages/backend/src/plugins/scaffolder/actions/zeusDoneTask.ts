import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import axios from 'axios';

export const ZeusDoneTask = (options: { config: Config }) => {
  return createTemplateAction<{
    zeusAccessToken: string;
    zeusTaskId: string;
  }>({
    id: 'mapfre:integration:zeus:2',
    async handler(ctx) {
      const { config } = options;
      const zeusApiUrl = config.getOptionalString('zeus.apiUrl');
      ctx.logger.info('Init connection');

      const zeusDoneTaskResponse = await axios.post(
        `${zeusApiUrl}/taskmanager/tasks/${ctx.input.zeusTaskId}/done`,
        {},
        {
          headers: {
            Authorization: `Bearer ${ctx.input.zeusAccessToken}`,
            'User-Agent': 'Backstage',
          },
        },
      );
      ctx.logger.info(
        `Zeus done task request, status: ${zeusDoneTaskResponse.status}`,
      );
    },
  });
};
