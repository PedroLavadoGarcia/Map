import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { CatalogApi } from '@backstage/catalog-client';
import { Entity } from '@backstage/catalog-model';
import AWS from 'aws-sdk';
import moment from 'moment';
import {
  DynamoDBClient,
  PutItemCommand,
  UpdateItemCommand,
} from '@aws-sdk/client-dynamodb';
import { marshall } from '@aws-sdk/util-dynamodb';
import handlebars from 'handlebars';
import nodemailer from 'nodemailer';

export const ResponsiblesAction = (options: {
  config: Config;
  catalog: CatalogApi;
}) => {
  return createTemplateAction<{
    entityRef: string;
  }>({
    id: 'mapfre:api:responsibles',
    async handler(ctx) {
      const { config, catalog } = options;
      const accessKeyId = config.getString(
        'subscriptions.dynamoDB.credentials.accessKeyId',
      );
      const secretAccessKey = config.getString(
        'subscriptions.dynamoDB.credentials.secretAccessKey',
      );
      const region = config.getString('subscriptions.dynamoDB.region');
      const apiLogsChangesTable = config.getString(
        'subscriptions.dynamoDB.apiLogsChangesTable',
      );
      const componentsResponsiblesTable = config.getString(
        'componentsResponsibles.tableName',
      );
      const appUrl = config.getString('app.baseUrl');
      const from = config.getString('ses.email');
      const dynamo = new DynamoDBClient({
        credentials: {
          accessKeyId,
          secretAccessKey,
        },
        region,
      });
      const ses = new AWS.SES({
        region,
        apiVersion: '2012-08-10',
        credentials: {
          accessKeyId,
          secretAccessKey,
        },
      });
      const transporter = nodemailer.createTransport({
        SES: ses,
      });
      const entity = await catalog.getEntityByRef(ctx.input.entityRef);
      if (!entity) {
        throw new Error('No entity found');
      }

      ctx.logger.info('Adding responsibles...');
      const owner = ctx.user?.ref?.split('/')[1].replace('_', '@') ?? '';

      const respsFunc = (
        ((entity.metadata.liablePeople as any)[
          'mapfre.com/resp_func'
        ] as string[]) ?? []
      ).map((r: string) => r.split(':')[1].replace('_', '@'));
      for (const responsible of respsFunc) {
        ctx.logger.info(`Adding functional responsible ${responsible}...`);
        await addResponsible(
          entity,
          responsible,
          'functional',
          entity.kind,
          owner,
        );
      }
      const respsTech = (
        ((entity.metadata.liablePeople as any)[
          'mapfre.com/resp_tech'
        ] as string[]) ?? []
      ).map((r: string) => r.split(':')[1].replace('_', '@'));
      for (const responsible of respsTech) {
        ctx.logger.info(`Adding technical responsible ${responsible}...`);
        await addResponsible(
          entity,
          responsible,
          'technical',
          entity.kind,
          owner,
        );
      }
      ctx.logger.info('Responsibles added successfully');

      async function addResponsible(
        entity: Entity,
        user: string,
        type: 'functional' | 'technical' | 'owner',
        kind: string,
        owner = '',
      ) {
        try {
          const name = entity.metadata.name;
          const title = entity.metadata.title ?? '';
          await dynamo.send(
            new PutItemCommand({
              TableName: componentsResponsiblesTable,
              Item: marshall({
                entity: name,
                'responsible-type': `${user.toLowerCase()}-${type}`,
                approval: 'pending',
                kind,
              }),
            }),
          );

          const entityUrl = `${appUrl}/catalog/default/${kind.toLowerCase()}/${name}`;
          let message = `You have been selected ${type} responsable for ${title} and your approval is pending, if it does not correspond select reject, please update the request in the following link ${entityUrl}`;
          message += `<br><br> Has sido seleccionado como responsable ${type} de ${title} y tu aprobación está pendiente, si no corresponde selecciona rechazar, por favor actualiza la solicitud en el siguiente enlace ${entityUrl}`;
          message += `<br><br> Você foi selecionado como responsável ${type} por ${title} e sua aprovação está pendente, caso não corresponda selecione rejeitar, atualize a solicitação no seguinte link ${entityUrl}`;
          const template = handlebars.compile(emailTemplateHtml);
          const html = template({
            title,
            subtitle: 'Approval pending',
            message,
          });
          await transporter.sendMail({
            to: user,
            from,
            subject: 'Approval pending',
            html,
          });
          await writeLogToDynamo({
            uidApi: entity.metadata.name,
            date: moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
            modifiedBy: owner,
            nameApi: entity.metadata.title,
            kind: entity.kind,
            desc: 'responsibles.approval.message',
            descParams: {
              user,
              type: `responsibles.type.${type}`,
              approval: 'responsibles.approval.pending',
            },
          });
        } catch (error) {
          ctx.logger.error(error);
        }
      }

      async function writeLogToDynamo(body: Record<string, unknown>) {
        await dynamo.send(
          new UpdateItemCommand({
            TableName: apiLogsChangesTable,
            Key: marshall({
              key: body.uidApi,
              date: body.date,
            }),
            UpdateExpression:
              'SET #modifiedBy = :modifiedBy, #nameApi = :nameApi, #kind = :kind, #desc = :desc, #diff = :diff, #descParams = :descParams',

            ExpressionAttributeNames: {
              '#modifiedBy': 'modifiedBy',
              '#nameApi': 'nameApi',
              '#kind': 'kind',
              '#desc': 'desc',
              '#diff': 'diff',
              '#descParams': 'descParams',
            },
            ExpressionAttributeValues: marshall({
              ':modifiedBy': body.modifiedBy,
              ':nameApi': body.nameApi,
              ':kind': body.kind,
              ':desc': body.desc,
              ':diff': '[]',
              ':descParams': body.descParams,
            }),
            ReturnValues: 'ALL_NEW',
          }),
        );
      }
    },
  });
};

const emailTemplateHtml = `<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>{{title}}</title>
  <style>
    body {
      font-family: Helvetica, Arial, sans-serif;
    }
    .header {
      border: 2px solid #DB271C;
      margin: 3px;
      color: #ffffff;
      background-color: #DB271C;
    }
    .content {
      border: 2px solid #DB271C;
      padding: 5px;
      margin: 3px;
    }
    .message {
      border: 1px solid #808080;
      padding: 10px;
      margin: 2px;
    }
    h1, h2 {color: #ffffff; padding: 10px}
  </style>
</head>
<body>
  <div class="header">
  <h1>{{title}}</h1>
  <h2>{{subtitle}}</h2>
  </div>
  <div class="content">
    <div class="message">
      <p>{{{message}}}</p>
    </div>
  </div>
</body>
</html>`;
