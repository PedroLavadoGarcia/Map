import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import moment from 'moment';
import AWS from 'aws-sdk';
import { Config } from '@backstage/config';
import fs from 'fs-extra';
import * as Diff from 'diff';
import { gzipSync } from 'zlib';

function isBinary(filename: string) {
  const binaryExtensions = [
    'pdf',
    'docx',
    'doc',
    'xlsx',
    'xlsm',
    'xls',
    'abw',
    'bin',
    'bmp',
    'bz',
    'bz2',
    'gz',
    'gif',
    'ico',
    'jar',
    'jpeg',
    'jpg',
    'mjs',
    'odp',
    'ods',
    'odt',
    'otf',
    'ppt',
    'pptx',
    'rar',
    'rtf',
    'tar',
    'tif',
    'tiff',
    'vsd',
    'zip',
    '7z',
  ];
  const extension = filename.match(/\.([A-Za-z0-9]+$)/);

  return binaryExtensions.includes(extension?.[1] ?? '');
}

export function putLogsCreatedAction(options: { config: Config }) {
  return createTemplateAction<{
    name: string;
    title: string;
    path1: string;
    content1: string;
    path2: string;
    content2: string;
    path3: string;
    content3: string;
    path4: string;
    content4: string;
    path5: string;
    content5: string;
    path6: string;
    content6: string;
    path7: string;
    content7: string;
    path8: string;
    content8: string;
    path9: string;
    content9: string;
    path10: string;
    content10: string;
    path11: string;
    content11: string;
    path12: string;
    content12: string;
    path13: string;
    content13: string;
    path14: string;
    content14: string;
    path15: string;
    content15: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    instances_files: Array<any>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wsrr_files: Array<any>;
  }>({
    id: 'mapfre:utils:putlogs',
    description: 'Sent to DynamoDb the log of creation of an entity',
    schema: {
      input: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
          },
          title: {
            type: 'string',
          },
          path1: {
            type: 'string',
          },
          content1: {
            type: 'string',
          },
          path2: {
            type: 'string',
          },
          content2: {
            type: 'string',
          },
          path3: {
            type: 'string',
          },
          content3: {
            type: 'string',
          },
          path4: {
            type: 'string',
          },
          content4: {
            type: 'string',
          },
          path5: {
            type: 'string',
          },
          content5: {
            type: 'string',
          },
          path6: {
            type: 'string',
          },
          content6: {
            type: 'string',
          },
          path7: {
            type: 'string',
          },
          content7: {
            type: 'string',
          },
          path8: {
            type: 'string',
          },
          content8: {
            type: 'string',
          },
          path9: {
            type: 'string',
          },
          content9: {
            type: 'string',
          },
          path10: {
            type: 'string',
          },
          content10: {
            type: 'string',
          },
          path11: {
            type: 'string',
          },
          content11: {
            type: 'string',
          },
          path12: {
            type: 'string',
          },
          content12: {
            type: 'string',
          },
          path13: {
            type: 'string',
          },
          content13: {
            type: 'string',
          },
          path14: {
            type: 'string',
          },
          content14: {
            type: 'string',
          },
          path15: {
            type: 'string',
          },
          content15: {
            type: 'string',
          },
          instances_files: {
            type: 'array',
          },
          wsrr_files: {
            type: 'array',
          },
        },
      },
    },
    async handler(ctx) {
      const { config } = options;
      const accessKeyId = config.getString(
        'subscriptions.dynamoDB.credentials.accessKeyId',
      );
      const secretAccessKey = config.getString(
        'subscriptions.dynamoDB.credentials.secretAccessKey',
      );
      const region = config.getString('subscriptions.dynamoDB.region');
      const apiLogsChangesTable = config.getString(
        'subscriptions.dynamoDB.apiLogsChangesTable',
      );
      const diff = JSON.stringify(
        Diff.diffLines(
          '',
          fs.readFileSync(`${ctx.workspacePath}/catalog-info.yaml`, {
            encoding: 'utf8',
            flag: 'r',
          }),
        ),
      );

      try {
        const creds = new AWS.Credentials(accessKeyId, secretAccessKey);
        const dynamoDB = new AWS.DynamoDB.DocumentClient({
          region: region,
          apiVersion: '2012-08-10',
          credentials: creds,
        });
        const uidApi = ctx.input.name;
        const nameApi = ctx.input.title;
        const modifiedBy = ctx.user?.entity?.spec.profile?.email ?? '';
        const date = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
        const body = {
          date,
          uidApi,
          file: 'catalog-info.yaml',
          modifiedBy,
          diff,
          nameApi,
          kind: 'mapfreapi',
          comment: '',
          desc: `Entity creation --- ${nameApi}`,
        };
        const response = await writeLogToDynamo(
          dynamoDB,
          body,
          apiLogsChangesTable,
        );

        if (response) {
          ctx.logger.info(
            'catalog-info.yaml logged: ' + JSON.stringify(response),
          );
        }

        for (let i = 1; i <= 15; i++) {
          if (ctx.input[`content${i}` as `content1`] !== undefined) {
            const path = ctx.input[`path${i}` as `path1`];
            ctx.logger.info(`path: ${path}`);
            const nameContent = ctx.input[`content${i}` as `content1`]
              .split(';')[1]
              .substring(5);
            ctx.logger.info(`nameContent: ${nameContent}`);
            const file = `${path}${nameContent}`;
            const diff = isBinary(path)
              ? JSON.stringify(
                  Diff.diffLines('Binary content', 'Binary content'),
                )
              : JSON.stringify(
                  Diff.diffLines(
                    '',
                    atob(ctx.input[`content${i}` as `content1`].split(',')[1]),
                  ),
                );
            const dateFile = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
            const body = {
              date: dateFile,
              uidApi,
              file,
              modifiedBy,
              diff,
              nameApi,
              kind: 'mapfreapi',
              comment: '',
              desc: `Uploaded file in entity creation --- ${file}`,
            };
            const response = await writeLogToDynamo(
              dynamoDB,
              body,
              apiLogsChangesTable,
            );

            if (response) {
              ctx.logger.info(`${file} logged: ${JSON.stringify(response)}`);
            }
          }
        }

        const instances_files = ctx.input.instances_files;
        const wsrr_files = ctx.input.wsrr_files;

        for (const file of instances_files) {
          if (file && file !== '') {
            const diff = JSON.stringify(
              Diff.diffLines('File Added', 'File Added'),
            );

            const dateFile = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
            const body = {
              date: dateFile,
              uidApi,
              file,
              modifiedBy,
              diff,
              nameApi,
              kind: 'mapfreapi',
              comment: '',
              desc: `Uploaded file in entity creation --- ${file}`,
            };
            const response = await writeLogToDynamo(
              dynamoDB,
              body,
              apiLogsChangesTable,
            );

            if (response) {
              ctx.logger.info(`${file} logged: ${JSON.stringify(response)}`);
            }
          }
        }

        const envs = ['ic', 'desa', 'pre', 'pro'];

        for (const wfiles of wsrr_files) {
          for (const env of envs) {
            const files = wfiles[env].split(',');
            if (files.length > 0) {
              for (const file of files) {
                if (file && file !== '') {
                  const fileName = file.replace(/"/g, '');
                  const diff = JSON.stringify(
                    Diff.diffLines('File Added', 'File Added'),
                  );

                  const dateFile = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
                  const body = {
                    date: dateFile,
                    uidApi,
                    file: fileName,
                    modifiedBy,
                    diff,
                    nameApi,
                    kind: 'mapfreapi',
                    comment: '',
                    desc: `Uploaded file in entity creation --- ${fileName}`,
                  };
                  const response = await writeLogToDynamo(
                    dynamoDB,
                    body,
                    apiLogsChangesTable,
                  );

                  if (response) {
                    ctx.logger.info(
                      `${fileName} logged: ${JSON.stringify(response)}`,
                    );
                  }
                }
              }
            }
          }
        }
      } catch (error) {
        if (error instanceof Error) {
          ctx.logger.error(error.message);
        }
      }
    },
  });
}

async function writeLogToDynamo(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, unknown>,
  tableName: string,
) {
  let diff = body.diff;
  if (diff && typeof diff === 'string') {
    diff = gzipSync(diff);
  }
  const params = {
    TableName: tableName,
    Key: {
      key: body.uidApi,
      date: body.date,
    },
    UpdateExpression:
      'SET #file = :file, #diff = :diff, #modifiedBy = :modifiedBy, #nameApi = :nameApi, #kind = :kind, #desc = :desc, #comment = :comment',

    ExpressionAttributeNames: {
      '#diff': 'diff',
      '#file': 'file',
      '#modifiedBy': 'modifiedBy',
      '#nameApi': 'nameApi',
      '#kind': 'kind',
      '#desc': 'desc',
      '#comment': 'comment',
    },
    ExpressionAttributeValues: {
      ':diff': body.diff ?? '',
      ':file': body.file,
      ':modifiedBy': body.modifiedBy,
      ':nameApi': body.nameApi,
      ':kind': body.kind,
      ':desc': body.desc,
      ':comment': body.comment,
    },
    ReturnValues: 'ALL_NEW',
  };

  return dynamoDB.update(params).promise();
}
