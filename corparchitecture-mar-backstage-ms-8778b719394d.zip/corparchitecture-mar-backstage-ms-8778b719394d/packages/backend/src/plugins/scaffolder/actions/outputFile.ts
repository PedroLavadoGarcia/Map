/*
 * Copyright 2021 Larder Software Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { resolveSafeChildPath } from '@backstage/backend-common';
import fs from 'fs-extra';

export function outputFileAction() {
  return createTemplateAction<{
    path1: string;
    content1: string;
    path2: string;
    content2: string;
    path3: string;
    content3: string;
    path4: string;
    content4: string;
    path5: string;
    content5: string;
    path6: string;
    content6: string;
    path7: string;
    content7: string;
    path8: string;
    content8: string;
    path9: string;
    content9: string;
    path10: string;
    content10: string;
    path11: string;
    content11: string;
    path12: string;
    content12: string;
    path13: string;
    content13: string;
    path14: string;
    content14: string;
    path15: string;
    content15: string;
    path16: string;
    content16: string;
    path17: string;
    content17: string;
    path18: string;
    content18: string;
    path19: string;
    content19: string;
    path20: string;
    content20: string;
    path21: string;
    content21: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    instances: Array<any>;
  }>({
    id: 'mapfre:utils:fs:write',
    description: 'Creates a file with the content on the given path',
    schema: {
      input: {
        type: 'object',
        properties: {
          path1: {
            type: 'string',
          },
          content1: {
            type: 'string',
          },
          path2: {
            type: 'string',
          },
          content2: {
            type: 'string',
          },
          path3: {
            type: 'string',
          },
          content3: {
            type: 'string',
          },
          path4: {
            type: 'string',
          },
          content4: {
            type: 'string',
          },
          path5: {
            type: 'string',
          },
          content5: {
            type: 'string',
          },
          path6: {
            type: 'string',
          },
          content6: {
            type: 'string',
          },
          path7: {
            type: 'string',
          },
          content7: {
            type: 'string',
          },
          path8: {
            type: 'string',
          },
          content8: {
            type: 'string',
          },
          path9: {
            type: 'string',
          },
          content9: {
            type: 'string',
          },
          path10: {
            type: 'string',
          },
          content10: {
            type: 'string',
          },
          path11: {
            type: 'string',
          },
          content11: {
            type: 'string',
          },
          path12: {
            type: 'string',
          },
          content12: {
            type: 'string',
          },
          path13: {
            type: 'string',
          },
          content13: {
            type: 'string',
          },
          path14: {
            type: 'string',
          },
          content14: {
            type: 'string',
          },
          path15: {
            type: 'string',
          },
          content15: {
            type: 'string',
          },
          path16: {
            type: 'string',
          },
          content16: {
            type: 'string',
          },
          path17: {
            type: 'string',
          },
          content17: {
            type: 'string',
          },
          path18: {
            type: 'string',
          },
          content18: {
            type: 'string',
          },
          path19: {
            type: 'string',
          },
          content19: {
            type: 'string',
          },
          path20: {
            type: 'string',
          },
          content20: {
            type: 'string',
          },
          path21: {
            type: 'string',
          },
          content21: {
            type: 'string',
          },
          path22: {
            type: 'string',
          },
          content22: {
            type: 'string',
          },
          path23: {
            type: 'string',
          },
          content23: {
            type: 'string',
          },
          instances: {
            type: 'array',
          },
        },
      },
      output: {
        type: 'object',
        properties: {
          path1: {
            title: 'Path 1',
            type: 'string',
          },
          path2: {
            title: 'Path 2',
            type: 'string',
          },
          path3: {
            title: 'Path 3',
            type: 'string',
          },
          path4: {
            title: 'Path 4',
            type: 'string',
          },
          path5: {
            title: 'Path 5',
            type: 'string',
          },
          path6: {
            title: 'Path 6',
            type: 'string',
          },
          path7: {
            title: 'Path 7',
            type: 'string',
          },
          path8: {
            title: 'Path 8',
            type: 'string',
          },
          path9: {
            title: 'Path 9',
            type: 'string',
          },
          path10: {
            title: 'Path 10',
            type: 'string',
          },
          path11: {
            title: 'Path 11',
            type: 'string',
          },
          path12: {
            title: 'Path 12',
            type: 'string',
          },
          path13: {
            title: 'Path 13',
            type: 'string',
          },
          path14: {
            title: 'Path 14',
            type: 'string',
          },
          path15: {
            title: 'Path 15',
            type: 'string',
          },
          path16: {
            title: 'Path 16',
            type: 'string',
          },
          path17: {
            title: 'Path 17',
            type: 'string',
          },
          path18: {
            title: 'Path 18',
            type: 'string',
          },
          path19: {
            title: 'Path 19',
            type: 'string',
          },
          path20: {
            title: 'Path 20',
            type: 'string',
          },
          path21: {
            title: 'Path 21',
            type: 'string',
          },
          instances: {
            title: 'instances',
            type: 'array',
          },
          instances_wsrr: {
            title: 'instances_wsrr',
            type: 'array',
          },
        },
      },
    },
    async handler(ctx) {
      for (let i = 1; i <= 21; i++) {
        if (ctx.input[`content${i}` as `content1`] !== undefined) {
          const destFilepath = resolveSafeChildPath(
            ctx.workspacePath,
            ctx.input[`path${i}` as `path1`],
          );

          const content = ctx.input[`content${i}` as `content1`].split(',')[1];
          const filename = decodeURIComponent(
            ctx.input[`content${i}` as `content1`].match(
              /name=(.*);base64,/,
            )?.[1] as string,
          ).replaceAll(' ', '_');

          fs.outputFileSync(`${destFilepath}/${filename}`, content, 'base64');
          ctx.output(`path${i}`, ctx.input[`path${i}` as `path1`] + filename);
        }
      }

      //Instances files processor
      if (ctx.input[`instances`]) {
        const fileInstances = ctx.input[`instances`];

        const instances = [];
        const instances_wsrr = [];

        for (let i = 0; i < fileInstances.length; i++) {
          const wsrr: Record<string, string> = {};

          if (
            fileInstances[i].gwDeployment_content &&
            fileInstances[i].gwDeployment_content !== undefined
          ) {
            const destFilepath = resolveSafeChildPath(
              ctx.workspacePath,
              'doc/gwDeployment/',
            );

            const content = fileInstances[i].gwDeployment_content.split(',')[1];
            const filename = decodeURIComponent(
              fileInstances[i].gwDeployment_content.match(
                /name=(.*);base64,/,
              )?.[1] as string,
            ).replaceAll(' ', '_');

            fs.outputFileSync(`${destFilepath}/${filename}`, content, 'base64');
            instances.push('doc/gwDeployment/' + filename);
          } else {
            instances.push('');
          }

          const instancesWsrr = [
            'wsrr_files_ic',
            'wsrr_files_desa',
            'wsrr_files_pre',
            'wsrr_files_pro',
          ];

          instancesWsrr.forEach(env => {
            if (fileInstances[i][env] && fileInstances[i][env].length > 0) {
              const destFilepath = resolveSafeChildPath(
                ctx.workspacePath,
                env.split('_')[2] + '/',
              );

              const wsrr_files = fileInstances[i][env];
              let fileNames = '';
              for (let j = 0; j < wsrr_files.length; j++) {
                if (fileInstances[i][env][j] !== undefined) {
                  const content = fileInstances[i][env][j].split(',')[1];
                  const filename = decodeURIComponent(
                    fileInstances[i][env][j].match(
                      /name=(.*);base64,/,
                    )?.[1] as string,
                  ).replaceAll(' ', '_');

                  fs.outputFileSync(
                    `${destFilepath}/${filename}`,
                    content,
                    'base64',
                  );
                  fileNames =
                    fileNames +
                    '"' +
                    filename +
                    '"' +
                    (wsrr_files.length > j + 1 ? ',' : '');
                }
              }

              wsrr[env.split('_')[2]] = fileNames;
            } else {
              wsrr[env.split('_')[2]] = '';
            }
          });

          instances_wsrr.push(wsrr);
        }

        ctx.output(`instances`, instances);
        ctx.output(`instances_wsrr`, instances_wsrr);
      }
    },
  });
}
