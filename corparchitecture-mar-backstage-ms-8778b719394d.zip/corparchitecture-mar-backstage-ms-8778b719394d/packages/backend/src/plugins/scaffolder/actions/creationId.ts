import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import { v4 as uuidv4 } from 'uuid';
export function creationIdAction() {
  return createTemplateAction<{ date: string }>({
    id: 'mapfre:utils:id',
    description: 'Creates a uuid to register as name Entity',
    schema: {
      output: {
        properties: {
          id: {
            title: 'Id',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      const idName = uuidv4();
      ctx.output('id', idName);
    },
  });
}
