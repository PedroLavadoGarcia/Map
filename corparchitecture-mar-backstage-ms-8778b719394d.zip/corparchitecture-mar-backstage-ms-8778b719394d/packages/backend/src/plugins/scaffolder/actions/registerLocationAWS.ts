/*
 * Copyright 2021 Larder Software Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import { CatalogApi } from '@backstage/catalog-client';
import { stringifyEntityRef, Entity } from '@backstage/catalog-model';
import sleep from './sleep';
import { AddLocationResponse } from '@backstage/catalog-client';

export function registerLocationAwsS3Action(options: {
  catalogClient: CatalogApi;
}) {
  const { catalogClient } = options;

  return createTemplateAction<{
    catalogInfoUrl: string;
  }>({
    id: 'aws:registerLocationS3',
    description: 'Copies the path to the given bucket',
    schema: {
      input: {
        required: ['catalogInfoUrl'],
        type: 'object',
        properties: {
          catalogInfoUrl: {
            description:
              'An absolute URL pointing to the root of a repository directory tree',
            type: 'string',
          },
        },
      },
      output: {
        type: 'object',
        properties: {
          entityRef: {
            title: 'entityRef',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      let added = false;
      const retry = 5;
      for (let i = 1; i <= retry; i++) {
        try {
          ctx.logger.info(`Registering: ${ctx.input.catalogInfoUrl}`);
          const result = await registerLocation(ctx.input.catalogInfoUrl, true);
          if (result.location) {
            added = true;
            break;
          }
        } catch (e) {
          ctx.logger.info(`An error occurred adding the entity ` + e);
          ctx.logger.info(`Retry ${i} of ${retry}`);
          await sleep(3);
        }
      }
      // }

      if (added) {
        const result = await registerLocation(ctx.input.catalogInfoUrl, false);
        ctx.logger.info(`Added ${result.location.id}`);
        const resultDryrun = await registerLocation(
          ctx.input.catalogInfoUrl,
          true,
        );
        const entity = await getEntityRef(resultDryrun);
        ctx.logger.info(`entity ${stringifyEntityRef(entity)}`);
        await sleep(3);
        const entityRefresh = await getEntityRefresh(resultDryrun);
        //Refreshing entity
        await catalogClient.refreshEntity(stringifyEntityRef(entityRefresh));
        ctx.logger.info(`refresh ${stringifyEntityRef(entityRefresh)}`);
        ctx.output('entityRef', stringifyEntityRef(entity));
      } else {
        throw Error(`Unable to add location ` + ctx.input.catalogInfoUrl);
      }
    },
  });

  async function registerLocation(
    catalogUrl: string,
    dryRun: boolean,
  ): Promise<AddLocationResponse> {
    const result = await catalogClient.addLocation({
      dryRun: dryRun,
      type: 'url',
      target: catalogUrl,
    });

    return result;
  }

  async function getEntityRef(location: AddLocationResponse): Promise<Entity> {
    const { entities } = location;
    let entity: Entity | undefined;
    // prioritise 'Component' type as it is the most central kind of entity
    entity = entities.find(
      e => !e.metadata.name.startsWith('generated-') && e.kind === 'Component',
    );
    if (!entity) {
      entity = entities.find(e => !e.metadata.name.startsWith('generated-'));
    }
    if (!entity) {
      entity = entities[0];
    }

    return entity;
  }

  async function getEntityRefresh(
    location: AddLocationResponse,
  ): Promise<Entity> {
    const { entities } = location;
    let entity: Entity | undefined;
    // prioritise 'Component' type as it is the most central kind of entity
    entity = entities.find(
      e => !e.metadata.name.startsWith('generated-') && e.kind === 'Location',
    );
    if (!entity) {
      entity = entities[0];
    }

    return entity;
  }
}
