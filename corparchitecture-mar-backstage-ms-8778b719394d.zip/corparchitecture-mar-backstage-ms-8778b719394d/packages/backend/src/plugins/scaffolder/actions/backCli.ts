import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import axios from 'axios';
import {
  LambdaClient,
  InvokeWithResponseStreamCommand,
} from '@aws-sdk/client-lambda';
import {
  S3Client,
  ListObjectsCommand,
  GetObjectCommand,
} from '@aws-sdk/client-s3';
import { ShellString, mkdir } from 'shelljs';
import { dirname } from 'path';

const lambdaClient = new LambdaClient({});
const s3Client = new S3Client({});
const textDecoder = new TextDecoder();
const textEncoder = new TextEncoder();

export const BackCLIAction = (options: { config: Config }) => {
  return createTemplateAction<{
    zeusAccessToken: string;
    zeusTaskId: string;
    // GENERAL
    componentId: string;
    description: string;
    productId?: string;
    productShortName?: string;
    owner?: string;
    architectureType: string;

    // DEVOPS
    source: string;
    devops: string;
  }>({
    id: 'mapfre:cli:back',
    async handler(ctx) {
      const { config } = options;
      const functionName = config.getString('archetypes.back.function.name');
      const bucketName = config.getString('archetypes.bucket.name');
      const taskPath = ctx.workspacePath;

      const { componentId, architectureType, productId, description } = ctx.input;

      const marInput = {
        appName: componentId,
        componentId,
        architectureType,
        productId,
        description
      };

      await createBackArch();
      await downloadBackArch();

      async function createBackArch() {
        ctx.logger.info('⏳ Creating arch...');
        ctx.logger.info(`With input:\n${JSON.stringify(marInput, null, 2)}`);

        const response = await lambdaClient.send(
          new InvokeWithResponseStreamCommand({
            FunctionName: functionName,
            Payload: textEncoder.encode(JSON.stringify(marInput)),
          }),
        );

        const stream = response.EventStream;
        if (stream) {
          for await (const response of stream) {
            if (response.PayloadChunk) {
              const decodedPayload = textDecoder.decode(
                response.PayloadChunk.Payload,
              );
              try {
                const payload = JSON.parse(
                  `[${decodedPayload.replace(/}\s*{/g, '},{')}]`,
                );
                for (const res of payload) {
                  switch (res.type) {
                    case 'message':
                      ctx.logger.info(res.message);
                      break;
                    case 'warn':
                      ctx.logger.warn(res.message);
                      break;
                    case 'error':
                      if (ctx.input.productId) {
                        await putZeusTaskError();
                      }
                      throw new Error(res.message);
                  }
                }
              } catch (error) {
                ctx.logger.info(decodedPayload);
              }
            }
          }
        }
      }

      async function downloadBackArch() {
        ctx.logger.info('⏳ Downloading arch...');
        const listObjectsResponse = await s3Client.send(
          new ListObjectsCommand({
            Bucket: bucketName,
            Prefix: `${componentId}/`,
          }),
        );
        const objects = listObjectsResponse.Contents!;

        for (const obj of objects) {
          const objectKey = obj.Key!;
          const downloadParams = {
            Bucket: bucketName,
            Key: objectKey,
          };

          const downloadCommand = new GetObjectCommand(downloadParams);
          const downloadResponse = await s3Client.send(downloadCommand);
          const body = downloadResponse.Body;

          const objectPath = objectKey.substring(objectKey.indexOf('/') + 1);
          const localFilePath = `${taskPath}/${objectPath}`;
          mkdir('-p', dirname(localFilePath));
          const content = await body?.transformToString('utf8');
          if (content) {
            ShellString(content).to(localFilePath);
          }
        }
      }

      async function putZeusTaskError() {
        const zeusApiUrl = config.getOptionalString('zeus.apiUrl');
        const response = await axios.put(
          `${zeusApiUrl}/taskmanager/tasks/${ctx.input.zeusTaskId}`,
          {
            status: 'ERROR',
          },
          {
            headers: {
              Authorization: `Bearer ${ctx.input.zeusAccessToken}`,
            },
          },
        );
        if (response.status === 200) {
          ctx.logger.info('Zeus has been informed of the error');
        }
      }
    },
  });
};
