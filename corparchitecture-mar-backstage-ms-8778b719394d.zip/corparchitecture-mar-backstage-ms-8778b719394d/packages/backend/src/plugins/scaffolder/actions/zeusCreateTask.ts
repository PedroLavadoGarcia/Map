import { Config } from '@backstage/config';
import {
  createTemplateAction,
  DatabaseTaskStore,
} from '@backstage/plugin-scaffolder-backend';
import { PluginDatabaseManager } from '@backstage/backend-common';
import axios from 'axios';

export const ZeusCreateTask = (options: {
  db: PluginDatabaseManager;
  config: Config;
}) => {
  return createTemplateAction<{
    productId: string;
    componentName: string;
    description: string;
    archetype: string;
    configRepo?: boolean;
    ownerEmail: string;
    archetypeRepoConfig: string;
    repoName: string;
  }>({
    id: 'mapfre:integration:zeus:1',
    async handler(ctx) {
      const { db, config } = options;
      const tasksDb = await DatabaseTaskStore.create({ database: db });
      const tasks = (await tasksDb.list({})).tasks;
      const taskId = tasks[0].id;
      ctx.logger.info(`Running task ${taskId}`);
      const baseUrl = config.getString('app.baseUrl');
      const isLocal = baseUrl.includes('localhost');

      const backstageAppUrl = config.getString('app.baseUrl');
      const zeusApiUrl = config.getOptionalString('zeus.apiUrl');
      const zeusTenantId = config.getOptionalString('zeus.tenantId');
      const zeusClientId = config.getOptionalString('zeus.clientId');
      const zeusClientSecret = config.getOptionalString('zeus.clientSecret');
      if (!zeusTenantId || !zeusClientId || !zeusClientSecret) {
        throw new Error('Zeus azure ad credentials not have been configured');
      }

      ctx.logger.info('Starting Zeus Auth & Requests...');
      const tokenResponseBody = `grant_type=client_credentials&client_id=${zeusClientId}&scope=https://management.core.windows.net/.default&client_secret=${zeusClientSecret}`;
      const tokenResponse = await axios.post(
        `https://login.microsoftonline.com/${zeusTenantId}/oauth2/v2.0/token`,
        tokenResponseBody,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': tokenResponseBody.length,
          },
        },
      );
      ctx.logger.info(`Token request, status: ${tokenResponse.status}`);

      const { access_token: accessToken } = tokenResponse.data;
      ctx.output('zeusAccessToken', accessToken);

      const taskUrl = `${backstageAppUrl}/create/tasks/${taskId}`;
      const zeusCreateTaskResponse = await axios.post(
        `${zeusApiUrl}/taskmanager/tasks`,
        {
          description: 'Solicitud creación nuevo componente MAR',
          comment: 'Solicitud creación nuevo componente MAR',
          type: 'CREATE_COMPONENT_REQUEST',
          productId: ctx.input.productId,
          createdBy: ctx.input.ownerEmail,
          parameters: [
            {
              id: '',
              key: 'componentType',
              value: ctx.input.archetype,
            },
            {
              id: '',
              key: 'archetypeRepoConfig',
              value: ctx.input.configRepo ?? false,
            },
            {
              id: '',
              key: 'name',
              value: ctx.input.componentName,
            },
            {
              id: '',
              key: 'description',
              value: ctx.input.description,
            },
            {
              id: '',
              key: 'jenkinsJob',
              value: '',
            },
            {
              id: '',
              key: 'repoName',
              value: ctx.input.repoName,
            },
            {
              id: '',
              key: 'taskUrl',
              value: !isLocal ? taskUrl : '',
            },
            {
              id: '',
              key: 'archetypeRepoConfig',
              value: ctx.input.archetypeRepoConfig,
            },
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'User-Agent': 'Backstage',
          },
        },
      );
      ctx.logger.info(
        `Zeus create task request, status: ${zeusCreateTaskResponse.status}`,
      );
      ctx.logger.info(JSON.stringify(zeusCreateTaskResponse.data, null, 2));
      const { id: zeusTaskId } = zeusCreateTaskResponse.data;
      ctx.logger.info(`Zeus task id: ${zeusTaskId}`);
      ctx.output('zeusTaskId', zeusTaskId);
    },
  });
};
