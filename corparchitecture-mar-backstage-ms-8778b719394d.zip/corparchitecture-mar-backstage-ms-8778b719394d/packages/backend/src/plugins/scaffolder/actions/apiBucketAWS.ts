/*
 * Copyright 2021 Larder Software Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import { S3Client, PutObjectCommand, S3ClientConfig } from '@aws-sdk/client-s3';
import fs, { createReadStream } from 'fs-extra';
import { resolveSafeChildPath } from '@backstage/backend-common';
import glob from 'glob';
import { Config } from '@backstage/config';

export function createAwsS3Action(options: { config: Config }) {
  const { config } = options;
  const auth = config.getConfigArray('integrations.awsS3');
  const accessKeyId: string = auth[0].getString('accessKeyId');
  const secretAccessKey: string = auth[0].getString('secretAccessKey');
  const region: string = auth[0].getString('region');
  const env: string = auth[0].getString('env');

  return createTemplateAction<{
    bucket: string;
    kind: string;
    country: string;
    id: string;
  }>({
    id: 'aws:s3',
    description: 'Copies the path to the given bucket',
    schema: {
      input: {
        required: ['id', 'country'],
        type: 'object',
        properties: {
          country: {
            description: 'Country or Mapfre Entity',
            type: 'string',
          },
          id: {
            description: 'Uuid to register as name Entity',
            type: 'string',
          },
          kind: {
            description: 'kind of Entity',
            type: 'string',
          },
        },
      },
      output: {
        type: 'object',
        properties: {
          catalogInfoUrl: {
            title: 'Catalog Info Url',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      const config: S3ClientConfig = {
        credentials: {
          accessKeyId: accessKeyId,
          secretAccessKey: secretAccessKey,
        },
        region: region,
      };

      const s3Client = new S3Client(config);

      ctx.logger.info(`Catalog API Identification: ${ctx.input.id}`);
      ctx.logger.info(`WorkspacePath: ${ctx.workspacePath}`);
      ctx.logger.info(`Region: ${region}`);
      ctx.logger.info(`Environment: ${env}`);

      ctx.logger.info(`Id: ${ctx.input.id}`);

      ctx.logger.info(`Country: ${ctx.input.country}`);

      let country: string = `${ctx.input.country}`.toLowerCase();
      if (country == '' || country == null) {
        country = 'global';
      }

      let bucketCountry = `catalog-api-${country}-${env}`;

      if (ctx.input.kind && ctx.input.kind.toLowerCase().includes('system')) {
        bucketCountry = `catalog-sys-${country}-${env}`;
      }

      ctx.logger.info(`Bucket: ${bucketCountry}`);

      const files = glob
        .sync(resolveSafeChildPath(ctx.workspacePath, '**'))
        .filter(filePath => fs.lstatSync(filePath).isFile());

      let catalogInfoUrl = '';
      try {
        await Promise.all(
          files.map((filePath: string) => {
            //FilePath contains the temporary folder, not the catalogue identifier.
            //Example url: 200ed955-ce09-48e5-acef-e99b17d0069d/catalog-info.yaml
            const workspacePath = `${ctx.workspacePath}`.replaceAll('\\', '/');
            const url = filePath.replace(workspacePath, `${ctx.input.id}`);

            ctx.logger.info(`url: ${url}`);
            return s3Client.send(
              new PutObjectCommand({
                Bucket: bucketCountry,
                Key: url,
                Body: createReadStream(filePath),
              }),
            );
          }),
        );
        const protocol = 'https://';
        const s3 = '.s3.';
        const amazonaws = '.amazonaws.com/';
        const catalogInfoFile = '/catalog-info.yaml';

        catalogInfoUrl = protocol
          .concat(bucketCountry)
          .concat(s3)
          .concat(region)
          .concat(amazonaws)
          .concat(`${ctx.input.id}`)
          .concat(catalogInfoFile);
        //Example catalogInfoUrl = "https://catalog-api-per.s3.eu-west-1.amazonaws.com/ee3559c9-694d-45d5-834b-058f43330359/catalog-info.yaml

        ctx.logger.info(catalogInfoUrl);
        ctx.output(`catalogInfoUrl`, catalogInfoUrl);
      } catch (e) {
        ctx.logger.error("wasn't able to upload the whole context " + e);
        throw Error('Error creating repository in AWS S3. ' + e);
      }
      ctx.logger.info(`Successfully uploaded: ${catalogInfoUrl}`);
    },
  });
}
