import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import { CatalogApi } from '@backstage/catalog-client';
import fetch, { Response, Headers } from 'node-fetch';
import { Config } from '@backstage/config';

export function validateApiAction(options: {
  catalogClient: CatalogApi;
  config: Config;
}) {
  const { catalogClient, config } = options;
  const auth = config.getConfigArray('integrations.github');
  const token: string = auth[0].getString('token');
  return createTemplateAction<{ mapfreapiName: string }>({
    id: 'mapfre:api:validate',
    description:
      'Validate the API metadata through the processor schema and deletes the repository if it is invalid',
    schema: {
      input: {
        properties: {
          mapfreapiName: {
            title: 'Mapfre API name',
            description: 'Unique identifier for the corresponding Mapfre API',
            type: 'string',
          },
        },
      },
    },
    async handler(ctx) {
      const { mapfreapiName } = ctx.input;

      try {
        //DELETE branch protection

        const url = new URL(
          `https://api.github.com/repos/mapfre-tech/${mapfreapiName}/branches/master/protection`,
        );

        const response = await fetch(url, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${Buffer.from(`${token}`, 'binary')}`,
          },
        });

        if (response.ok) {
          //PUT repository in Corporateintegrationarchitectureteam

          const urlTeam = new URL(
            `https://api.github.com/orgs/mapfre-tech/teams/corporateintegrationarchitectureteam/repos/mapfre-tech/${mapfreapiName}`,
          );

          const body = JSON.stringify({
            permission: 'admin',
          });

          const responseTeam = await fetch(urlTeam, {
            method: 'PUT',
            body,
            headers: {
              Authorization: `Bearer ${Buffer.from(`${token}`, 'binary')}`,
            },
          });

          if (responseTeam.ok) {
            await catalogClient.addLocation(
              {
                dryRun: true,
                type: 'url',
                target: `https://github.com/mapfre-tech/${mapfreapiName}/blob/master/catalog-info.yaml`,
              },
              ctx.secrets?.backstageToken
                ? { token: ctx.secrets.backstageToken }
                : {},
            );
          }
        }
      } catch (e) {
        const url = new URL(
          `/repos/mapfre-tech/${mapfreapiName}`,
          'https://api.github.com',
        );

        const method = 'DELETE';

        const headers = new Headers();
        headers.set(
          'Authorization',
          `Bearer ${Buffer.from(`${token}`, 'binary')}`,
        );
        let response: Response;
        try {
          response = await fetch(url, {
            method,
            headers: Object.fromEntries(headers.entries()),
          });
        } catch (e) {
          throw new Error(`Unable to delete repository, ${e}`);
        }

        if (response.status !== 204) {
          throw new Error(
            `Unable to delete repository, ${response.status} ${
              response.statusText
            }, ${await response.text()}`,
          );
        }
        throw Error('Invalid MAPFRE API metadata.');
      }
    },
  });
}
