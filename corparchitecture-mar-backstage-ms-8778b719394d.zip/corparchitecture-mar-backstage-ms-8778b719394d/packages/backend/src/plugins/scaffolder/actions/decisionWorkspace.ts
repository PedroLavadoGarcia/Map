import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';

export const WorkspaceDecision = () => {
  return createTemplateAction<{
    repoWorkspaceZeus: string | undefined;
    repoWorkspaceBackstage: string | undefined;
  }>({
    id: 'decision:workspace',
    async handler(ctx) {
      if (ctx.input.repoWorkspaceZeus == undefined) {
        ctx.output('workspace', `${ctx.input.repoWorkspaceBackstage}`);
        ctx.logger.info(
          'Selected workspace: ' + `${ctx.input.repoWorkspaceBackstage}`,
        );
      } else if (ctx.input.repoWorkspaceBackstage === undefined) {
        ctx.output('workspace', `${ctx.input.repoWorkspaceZeus}`);
        ctx.logger.info(
          'Selected workspace: ' + `${ctx.input.repoWorkspaceZeus}`,
        );
      }
    },
  });
};
