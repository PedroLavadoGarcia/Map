import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-backend';
import AWS from 'aws-sdk';

export const NotifyComponentCreationAction = (options: { config: Config }) => {
  return createTemplateAction<{
    productId: string;
    componentName: string;
    description: string;
    archetype: string;
    repoUrl: string;
    whoCreated: string;
  }>({
    id: 'mapfre:notify',
    async handler(ctx) {
      let actionEnd = false;
      const { config } = options;
      ctx.logger.info('Init connection');

      const accessKeyId = config.getString(
        'techdocs.publisher.awsS3.credentials.accessKeyId',
      );
      const secretAccessKey = config.getString(
        'techdocs.publisher.awsS3.credentials.secretAccessKey',
      );
      const region = config.getString('techdocs.publisher.awsS3.region');
      const creds = new AWS.Credentials(accessKeyId, secretAccessKey);
      const eventBridge = new AWS.EventBridge({
        credentials: creds,
        region: region,
      });

      if (ctx.input.productId) {
        const component = {
          id: ctx.input.componentName,
          description: ctx.input.description,
          archetype: ctx.input.archetype,
          ownerEmail: ctx.user?.entity?.spec.profile?.email,
          repositoryUrl: ctx.input.repoUrl,
          productId: ctx.input.productId,
          subscriptions: '',
          whoCreated: ctx.input.whoCreated,
        };
        const params = {
          Entries: [
            {
              Source: 'backstage',
              DetailType: 'component-created',
              Detail: JSON.stringify(component),
              EventBusName: `default`,
            },
          ],
        };
        eventBridge.putEvents(params, (err, data) => {
          if (err) {
            ctx.logger.error(err);
            actionEnd = true;
          } else {
            ctx.logger.info(JSON.stringify(data));
            actionEnd = true;
          }
        });
      } else {
        const component = {
          id: ctx.input.componentName,
          description: ctx.input.description,
          ownerEmail: ctx.user?.entity?.spec.profile?.email,
          repositoryUrl: ctx.input.repoUrl,
          archetype: ctx.input.archetype,
          whoCreated: ctx.input.whoCreated,
          subscriptions: '',
        };
        const params = {
          Entries: [
            {
              Source: 'backstage',
              DetailType: 'component-created',
              Detail: JSON.stringify(component),
              EventBusName: `default`,
            },
          ],
        };
        eventBridge.putEvents(params, (err, data) => {
          if (err) {
            ctx.logger.error(err);
            actionEnd = true;
          } else {
            ctx.logger.info(JSON.stringify(data));
            actionEnd = true;
          }
        });

        const waitForEnd = () => {
          return new Promise<void>(resolve => {
            const intervalTime = 200; //ms
            const interval = setInterval(() => {
              if (actionEnd) {
                clearInterval(interval);
                resolve();
              }
            }, intervalTime);
          });
        };
        await waitForEnd();
      }
    },
  });
};
