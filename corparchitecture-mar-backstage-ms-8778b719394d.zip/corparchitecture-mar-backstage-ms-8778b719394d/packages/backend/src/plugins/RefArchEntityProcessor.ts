import {
  CatalogProcessor,
  LocationSpec,
} from '@backstage/plugin-catalog-backend';
import { Entity, entityKindSchemaValidator } from '@backstage/catalog-model';
import refArchEntityV1alpha1Schema from './schema/RefArch.v1alpha1.schema.json';

export interface RefArchEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'RefArch';
  spec: {
    type: string;
    owner: string;
  };
}

export class RefArchEntitiesProcessor implements CatalogProcessor {
  // You often end up wanting to support multiple versions of your kind as you
  // iterate on the definition, so we keep each version inside this array.
  private readonly validators = [
    // This is where we use the JSONSchema that we export from our isomorphic package
    entityKindSchemaValidator(refArchEntityV1alpha1Schema),
  ];

  // validateEntityKind is responsible for signaling to the catalog processing engine
  // that this entity is valid and should therefore be submitted for further processing.
  async validateEntityKind(entity: Entity): Promise<boolean> {
    for (const validator of this.validators) {
      if (validator(entity)) {
        return true;
      }
    }

    return false;
  }

  getProcessorName(): string {
    return 'RefArchEntityProcessor';
  }

  async postProcessEntity(
    entity: Entity,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _location: LocationSpec,
  ): Promise<Entity> {
    return entity as RefArchEntityV1alpha1;
  }
}
