import { createRouter } from '@backstage/plugin-wsrr-upload-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin({
  logger,
  config,
  permissions,
}: PluginEnvironment): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger,
    auth: config.getConfigArray('integrations.awsS3'),
    permissions,
    tenant_id: config.getString('add.catalogapi_onprem.tenant_id'),
    grant_type: config.getString('add.catalogapi_onprem.grant_type'),
    client_id: config.getString('add.catalogapi_onprem.client_id'),
    client_secret: config.getString('add.catalogapi_onprem.client_secret'),
    aadUsername: config.getString('add.catalogapi_onprem.username'),
    aadPassword: config.getString('add.catalogapi_onprem.password'),
    scope: config.getString('add.catalogapi_onprem.scope'),
    apigwUrl: config.getString('wsrr.apigwUrl'),
    stage: config.getString('wsrr.stage'),
    host: config.getString('wsrr.host'),
    baseUrl: config.getString('backend.baseUrl'),
    apiLogsChangesTable: config.getString(
      'subscriptions.dynamoDB.apiLogsChangesTable',
    ),
  });
}
