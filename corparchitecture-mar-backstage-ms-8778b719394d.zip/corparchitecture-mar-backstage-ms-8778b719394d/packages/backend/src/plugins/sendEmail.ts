import { createRouter } from '@backstage/plugin-sendemail-backend';
import { Router } from 'express';
import { PluginEnvironment } from '../types';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  // Here is where you will add all of the required initialization code that
  // your backend plugin needs to be able to start!

  // The env contains a lot of goodies, but our router currently only
  // needs a logger
  return await createRouter({
    logger: env.logger,
    accessKeyId: env.config.getString(
      'subscriptions.dynamoDB.credentials.accessKeyId',
    ),
    secretAccessKey: env.config.getString(
      'subscriptions.dynamoDB.credentials.secretAccessKey',
    ),
    baseUrl: env.config.getString('backend.baseUrl'),
    region: env.config.getString('subscriptions.dynamoDB.region'),
    from: env.config.getString('ses.email'),
  });
}
