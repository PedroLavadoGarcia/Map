import { BackstageIdentityResponse } from '@backstage/plugin-auth-node';
import { createRouter } from '@backstage/plugin-permission-backend';
import {
  AuthorizeResult,
  PolicyDecision,
  isPermission,
  ResourcePermission,
  PermissionCriteria,
  PermissionCondition,
} from '@backstage/plugin-permission-common';
import {
  PermissionPolicy,
  PolicyQuery,
} from '@backstage/plugin-permission-node';
import { Router } from 'express';
import { PluginEnvironment } from '../types';
import {
  catalogConditions,
  createCatalogConditionalDecision,
} from '@backstage/plugin-catalog-backend/alpha';
import {
  isLiablePerson,
  isLiableTeam,
  isLocalGov,
  marketplaceAdminView,
} from './permissions_custom_rules';

import {
  catalogLocationCreatePermission,
  catalogLocationReadPermission,
  catalogLocationDeletePermission,
  catalogEntityReadPermission,
  catalogEntityRefreshPermission,
} from '@backstage/plugin-catalog-common/alpha';
import { parseEntityRef } from '@backstage/catalog-model';
import {
  mapfreapiEditPermission,
  mapfredocEditPermission,
  mapfreapiReviewPermission,
  mapfreapiManagePermission,
  mapfreapiPublishWsrrEdicPermission,
  mapfreapiPublishWsrrPermission,
  mapfreapiDismaPermission,
} from '@backstage/plugin-mapfreapi-editor-common';
import { componentsEditPermission } from '@backstage/plugin-components-catalog-edit-common';

type NonEmptyArray<T> = [T, ...T[]];

const allKindsButMapfreApi = [
  'Component',
  'Template',
  'Api',
  'Group',
  'User',
  'Resource',
  'System',
  'Domain',
  'Location',
  'Documentation',
  'RefArch',
];

class TestPermissionPolicy implements PermissionPolicy {
  async handle(
    request: PolicyQuery,
    user?: BackstageIdentityResponse,
  ): Promise<PolicyDecision> {
    /**
     * Si el usuario es administrador de Backstage o es miembro del gobierno global
     * de APIs tienen permisos de superusuario.
     */
    if (
      [
        'gazr-gov-backstage-admin',
        'gazr-gov-backstage-global',
        'gazr-gov-backstage-doc-global',
        'gazr-gov-backstage-soluciones-global',
      ].some(el =>
        user?.identity.ownershipEntityRefs.find(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            parseEntityRef(entityRef).name.toLowerCase().includes(el),
        ),
      )
    ) {
      return { result: AuthorizeResult.ALLOW };
    }

    if (isPermission(request.permission, componentsEditPermission)) {
      const result = createCatalogConditionalDecision(
        request.permission,
        catalogConditions.isEntityOwner({
          claims: user?.identity.ownershipEntityRefs ?? [],
        }),
      );
      console.log('AUTH RESULT ', result);
      return result;
    }

    if (isPermission(request.permission, catalogEntityReadPermission)) {
      /* Si el usuario es miembro de WSRR o Disma puede ver TODAS las entidades */

      if (
        user?.identity.ownershipEntityRefs.find(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            (parseEntityRef(entityRef)
              .name.toLowerCase()
              .includes('gazr-api-backstage-wsrr') ||
              parseEntityRef(entityRef)
                .name.toLowerCase()
                .includes('gazr-gov-backstage-disma')),
        )
      ) {
        return { result: AuthorizeResult.ALLOW };
      }

      /* Si el usuario es miembro de algún gobierno, excepto españa puede ver
       * todas las entidades excepto 'MapfreApiLegacyEsp', SOAP de España y Drafts de otros paises
       */

      if (
        user?.identity.ownershipEntityRefs.find(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            parseEntityRef(entityRef)
              .name.toLowerCase()
              .startsWith('gazr-gov-backstage'),
        )
      ) {
        const entityRefs = user?.identity.ownershipEntityRefs.filter(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            parseEntityRef(entityRef)
              .name.toLowerCase()
              .startsWith('gazr-gov-backstage'),
        );

        const countries = entityRefs.map((entityRef: string) =>
          //GAZR-API-BACKSTAGE-COUNTRY split
          entityRef?.split('-')[3].toUpperCase(),
        );

        const countriesArray = countries.map(ref =>
          catalogConditions.hasMetadata({ key: 'country', value: ref }),
        );

        if (countries.includes('ESP')) {
          return createCatalogConditionalDecision(request.permission, {
            anyOf: [
              /* Ocultamos Draft de otros paises si alguno de los gobiernos es España*/
              {
                allOf: [
                  {
                    not: {
                      allOf: [
                        catalogConditions.hasSpec({
                          key: 'lifecycle',
                          value: 'Draft',
                        }),
                        {
                          not: {
                            anyOf: countriesArray as unknown as NonEmptyArray<
                              PermissionCriteria<
                                PermissionCondition<'catalog-entity'>
                              >
                            >,
                          },
                        },
                      ],
                    },
                  },
                ],
              },
              /* Mostramos las entidades de las que el usuario es liablePerson*/
              catalogConditions.isEntityKind({
                kinds: allKindsButMapfreApi,
              }),
              ...[
                'mapfre.com/owners',
                'mapfre.com/resp_tech',
                'mapfre.com/resp_func',
              ].map(key =>
                isLiablePerson({
                  liablePerson: key,
                  userRef: user?.identity.userEntityRef,
                }),
              ),
            ],
          });
        } else {
          return createCatalogConditionalDecision(request.permission, {
            anyOf: [
              {
                /* Ocultamos MapfreApiLegacyEsp, SOAP de España y Draft de otros paises si algun gobierno no es España*/
                allOf: [
                  {
                    not: catalogConditions.isEntityKind({
                      kinds: ['MapfreApiLegacyEsp'],
                    }),
                  },
                  {
                    not: {
                      allOf: [
                        catalogConditions.hasMetadata({
                          key: 'typology',
                          value: 'SOAP Services',
                        }),
                        catalogConditions.hasMetadata({
                          key: 'country',
                          value: 'ESP',
                        }),
                      ],
                    },
                  },
                  {
                    not: {
                      allOf: [
                        catalogConditions.hasSpec({
                          key: 'lifecycle',
                          value: 'Draft',
                        }),
                        {
                          not: {
                            anyOf: countriesArray as unknown as NonEmptyArray<
                              PermissionCriteria<
                                PermissionCondition<'catalog-entity'>
                              >
                            >,
                          },
                        },
                      ],
                    },
                  },
                ],
              },
              /* Mostramos las entidades de las que el usuario es liablePerson*/
              catalogConditions.isEntityKind({
                kinds: allKindsButMapfreApi,
              }),
              ...[
                'mapfre.com/owners',
                'mapfre.com/resp_tech',
                'mapfre.com/resp_func',
              ].map(key =>
                isLiablePerson({
                  liablePerson: key,
                  userRef: user?.identity.userEntityRef,
                }),
              ),
            ],
          });
        }
      }

      /* Si el usuario pertenece a uno o mas sistemas externos permite ver solo las API
      en estado Approved */
      if (
        user?.identity.ownershipEntityRefs.find(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            parseEntityRef(entityRef)
              .name.toLowerCase()
              .startsWith('gazr-api-backstage-ext'),
        )
      ) {
        const extEntityRefs = user?.identity.ownershipEntityRefs.filter(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            parseEntityRef(entityRef)
              .name.toLowerCase()
              .startsWith('gazr-api-backstage-ext'),
        );

        const mappedApiSystem = extEntityRefs.map(
          (entityRef: string) =>
            //GAZR-API-BACKSTAGE-EXT split
            entityRef?.split('-')[4].toLowerCase() +
            '-' +
            entityRef?.split('-')[5].toLowerCase(),
        );

        const systemsArray = mappedApiSystem.map(ref =>
          catalogConditions.hasSpec({ key: 'system', value: ref }),
        );

        return createCatalogConditionalDecision(request.permission, {
          anyOf: [
            catalogConditions.isEntityKind({
              kinds: ['Component', 'MapfreDocument'],
            }),
            {
              allOf: [
                catalogConditions.isEntityKind({
                  kinds: ['MapfreApi'],
                }),
                {
                  anyOf: systemsArray as unknown as NonEmptyArray<
                    PermissionCriteria<PermissionCondition<'catalog-entity'>>
                  >,
                },
                catalogConditions.hasSpec({
                  key: 'lifecycle',
                  value: 'Approved',
                }),
              ],
            },
          ],
        });
      }

      /* Si el usuario no es de ningún gobierno verá todas las entidades
       * excepto 'MapfreApiLegacyEsp' y SOAP de España
       */
      return createCatalogConditionalDecision(request.permission, {
        anyOf: [
          {
            /* Ocultamos MapfreApiLegacyEsp y SOAP de España */
            allOf: [
              {
                not: catalogConditions.isEntityKind({
                  kinds: ['MapfreApiLegacyEsp'],
                }),
              },
              {
                not: {
                  allOf: [
                    catalogConditions.hasMetadata({
                      key: 'typology',
                      value: 'SOAP Services',
                    }),
                    catalogConditions.hasMetadata({
                      key: 'country',
                      value: 'ESP',
                    }),
                  ],
                },
              },
              /* Mostramos sólo las MapfreApi 'Approved' y legacy global, bra y per. Mostramos los liablePeople
               * de MapfreApi y MapfreApiLegacyEsp (allKindsButMapfreApi) aunque
               * sean SOAP España o MapfreApiLegacyEsp
               */
              {
                allOf: [
                  {
                    anyOf: [
                      catalogConditions.hasSpec({
                        key: 'lifecycle',
                        value: 'Approved',
                      }),
                      catalogConditions.hasSpec({
                        key: 'lifecycle',
                        value: 'Edited',
                      }),
                      catalogConditions.hasSpec({
                        key: 'lifecycle',
                        value: 'Review edited',
                      }),
                      catalogConditions.hasSpec({
                        key: 'lifecycle',
                        value: 'Retired candidate',
                      }),
                    ],
                  },
                  catalogConditions.isEntityKind({
                    kinds: [
                      'MapfreApi',
                      'MapfreApiLegacyGlobal',
                      'MapfreApiLegacyBra',
                      'MapfreApiLegacyPer',
                      'MapfreDocument',
                      'MapfreSolution',
                    ],
                  }),
                ],
              },
            ],
          },
          /* Mostramos las entidades de las que el usuario es liablePerson*/
          catalogConditions.isEntityKind({
            kinds: allKindsButMapfreApi,
          }),
          ...[
            'mapfre.com/owners',
            'mapfre.com/resp_tech',
            'mapfre.com/resp_func',
          ].map(key =>
            isLiablePerson({
              liablePerson: key,
              userRef: user?.identity.userEntityRef,
            }),
          ),

          ...[
            'responsible',
            'writers',
            'reviewers',
            'func_team.responsible',
            'tech_team.responsible',
          ].map(key =>
            isLiableTeam({
              liableTeam: key,
              userRef: user?.identity.userEntityRef,
            }),
          ),
        ],
      });
    }

    if (
      [mapfreapiEditPermission].some(perm =>
        isPermission(request.permission, perm),
      )
    ) {
      return createCatalogConditionalDecision(
        request.permission as ResourcePermission<'catalog-entity'>,
        {
          anyOf: [
            catalogConditions.isEntityKind({
              kinds: allKindsButMapfreApi,
            }),
            isLocalGov({
              ownershipEntityRefs: user?.identity.ownershipEntityRefs,
            }),
            ...[
              'mapfre.com/owners',
              'mapfre.com/resp_tech',
              'mapfre.com/resp_func',
            ].map(key =>
              isLiablePerson({
                liablePerson: key,
                userRef: user?.identity.userEntityRef,
              }),
            ),
          ],
        },
      );
    }
    if (
      [mapfredocEditPermission].some(
        perm =>
          isPermission(request.permission, perm) ||
          user?.identity.ownershipEntityRefs.find(
            entityRef =>
              parseEntityRef(entityRef).kind === 'group' &&
              parseEntityRef(entityRef)
                .name.toLowerCase()
                .includes('gazr-gov-backstage-doc-global'),
          ),
      )
    ) {
      return createCatalogConditionalDecision(
        request.permission as ResourcePermission<'catalog-entity'>,
        {
          allOf: [
            {
              anyOf: [
                catalogConditions.isEntityKind({
                  kinds: ['MapfreDocument'],
                }),
              ],
              ...['responsible', 'writers'].map(key =>
                isLiableTeam({
                  liableTeam: key,
                  userRef: user?.identity.userEntityRef,
                }),
              ),
            },
          ],
        },
      );
    }

    if (
      [mapfreapiDismaPermission].some(perm =>
        isPermission(request.permission, perm),
      )
    ) {
      //Check is disma Group
      if (isDisma(user?.identity.ownershipEntityRefs)) {
        return { result: AuthorizeResult.ALLOW };
      }
    }

    if (
      [catalogEntityRefreshPermission].some(perm =>
        isPermission(request.permission, perm),
      )
    ) {
      //Check is WSRR Group
      if (isWsrr(user?.identity.ownershipEntityRefs)) {
        return { result: AuthorizeResult.ALLOW };
      }

      return createCatalogConditionalDecision(
        request.permission as ResourcePermission<'catalog-entity'>,
        {
          anyOf: [
            catalogConditions.isEntityKind({
              kinds: allKindsButMapfreApi,
            }),

            isLocalGov({
              ownershipEntityRefs: user?.identity.ownershipEntityRefs,
            }),
            ...[
              'mapfre.com/owners',
              'mapfre.com/resp_tech',
              'mapfre.com/resp_func',
            ].map(key =>
              isLiablePerson({
                liablePerson: key,
                userRef: user?.identity.userEntityRef,
              }),
            ),
            ...['responsible', 'writers'].map(key =>
              isLiableTeam({
                liableTeam: key,
                userRef: user?.identity.userEntityRef,
              }),
            ),
          ],
        },
      );
    }

    if (
      [
        catalogLocationCreatePermission,
        catalogLocationReadPermission,
        catalogLocationDeletePermission,
      ].some(perm => isPermission(request.permission, perm))
    ) {
      return { result: AuthorizeResult.ALLOW };
    }

    if (isPermission(request.permission, mapfreapiReviewPermission)) {
      return createCatalogConditionalDecision(
        request.permission as ResourcePermission<'catalog-entity'>,
        {
          anyOf: [
            isLocalGov({
              ownershipEntityRefs: user?.identity.ownershipEntityRefs,
            }),
          ],
        },
      );
    }

    if (
      request.permission.name === 'access.register' &&
      user?.identity.ownershipEntityRefs.find(
        entityRef =>
          parseEntityRef(entityRef).kind === 'group' &&
          parseEntityRef(entityRef).name.toLowerCase() ===
            'gaws-backstage-integrators-mar2',
      )
    ) {
      return { result: AuthorizeResult.ALLOW };
    }

    if (
      isPermission(request.permission, marketplaceAdminView) &&
      user?.identity.ownershipEntityRefs.find(
        entityRef =>
          parseEntityRef(entityRef).kind === 'group' &&
          parseEntityRef(entityRef)
            .name.toLowerCase()
            .includes('gazr-gov-backstage-admin'),
      )
    ) {
      return { result: AuthorizeResult.ALLOW };
    }

    if (
      isPermission(request.permission, mapfreapiManagePermission) &&
      user?.identity.ownershipEntityRefs.find(
        entityRef =>
          parseEntityRef(entityRef).kind === 'group' &&
          (parseEntityRef(entityRef)
            .name.toLowerCase()
            .startsWith('gazr-gov-backstage') ||
            parseEntityRef(entityRef)
              .name.toLowerCase()
              .includes('gazr-gov-backstage-doc-global')),
      )
    ) {
      return { result: AuthorizeResult.ALLOW };
    }

    if (isPermission(request.permission, mapfreapiPublishWsrrPermission)) {
      if (isWsrr(user?.identity.ownershipEntityRefs)) {
        return { result: AuthorizeResult.ALLOW };
      }
    }

    if (
      [mapfreapiPublishWsrrEdicPermission].some(perm =>
        isPermission(request.permission, perm),
      )
    ) {
      if (
        user?.identity.ownershipEntityRefs?.find((ref: string) => {
          const entityRef = parseEntityRef(ref);
          return (
            entityRef.kind.toLowerCase() === 'group' &&
            entityRef.name.toLowerCase().includes('gazr-gov-backstage') &&
            !entityRef.name.toLowerCase().includes('gazr-gov-backstage-disma')
          );
        })
      ) {
        return { result: AuthorizeResult.ALLOW };
      } else {
        return createCatalogConditionalDecision(
          request.permission as ResourcePermission<'catalog-entity'>,
          {
            allOf: [
              catalogConditions.isEntityKind({
                kinds: [
                  'MapfreApi',
                  'MapfreApiLegacyGlobal',
                  'MapfreApiLegacyBra',
                  'MapfreApiLegacyPer',
                ],
              }),
              ...[
                'mapfre.com/owners',
                'mapfre.com/resp_tech',
                'mapfre.com/resp_func',
              ].map(key =>
                isLiablePerson({
                  liablePerson: key,
                  userRef: user?.identity.userEntityRef,
                }),
              ),
            ],
          },
        );
      }
    }
    return { result: AuthorizeResult.DENY };
  }
}

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  return await createRouter({
    config: env.config,
    logger: env.logger,
    discovery: env.discovery,
    policy: new TestPermissionPolicy(),
    identity: env.identity,
  });
}

function isWsrr(ownershipEntityRefs: string[] | undefined): string | undefined {
  return ownershipEntityRefs?.find((ref: string) => {
    const entityRef = parseEntityRef(ref);
    return (
      entityRef.kind.toLowerCase() === 'group' &&
      entityRef.name.toLowerCase().includes('gazr-api-backstage-wsrr')
    );
  });
}

function isDisma(
  ownershipEntityRefs: string[] | undefined,
): string | undefined {
  return ownershipEntityRefs?.find((ref: string) => {
    const entityRef = parseEntityRef(ref);
    return (
      entityRef.kind.toLowerCase() === 'group' &&
      entityRef.name.toLowerCase().includes('gazr-gov-backstage-disma')
    );
  });
}
