import {
  CatalogProcessor,
  CatalogProcessorEmit,
  processingResult,
} from '@backstage/plugin-catalog-node';
import { LocationSpec } from '@backstage/plugin-catalog-common';
import {
  Entity,
  entityKindSchemaValidator,
  EntityMeta,
  getCompoundEntityRef,
  parseEntityRef,
  RELATION_API_CONSUMED_BY,
  RELATION_CONSUMES_API,
  RELATION_HAS_PART,
  RELATION_OWNED_BY,
  RELATION_OWNER_OF,
  RELATION_PART_OF,
} from '@backstage/catalog-model';
import {
  RELATION_AUTHORIZES_API,
  RELATION_API_AUTHORIZED_BY,
  RELATION_INVOKES_API,
  RELATION_API_INVOKED_BY,
  RELATION_NEXT_VERSION_OF,
  RELATION_PREVIOUS_VERSION_OF,
} from '../plugins/relations/relations';
import mapfreApiLegacyBraEntityV1alpha1Schema from './schema/MapfreApiLegacyBra.v1alpha1.schema.json';
import AuthType from '../enums/AuthType';
import Architecture from '../enums/Architecture';
//import ServUbic from '../enums/ServUbic';
import Types from '../enums/Types';
import Countries from '../enums/Countries';
import BusinessEntity from '../enums/BusinessEntity';
import Life from '../enums/Life';

export interface MapfreApiLegacyBraEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'MapfreApiLegacyBra';
  metadata: EntityMeta & {
    typology: Types;
    country: Countries;
    version: string;
    modDate?: string;
    liablePeople?: {
      'mapfre.com/owners': string;
      'mapfre.com/resp_func': string;
      'mapfre.com/resp_tech': string;
      'mapfre.com/resp_alt': string;
    };
    contextData?: {
      'mapfre.com/NNII': 'Yes' | 'No';
      'mapfre.com/NNII_code': string[];
      'mapfre.com/externalAccess': 'Yes' | 'No';
    };
    technicalData?: {
      //'mapfre.com/serv_ubic': ServUbic;
      'mapfre.com/architecture': Architecture;
      'mapfre.com/perm_type':
        | 'All authenticated users'
        | 'Roles'
        | 'Scopes'
        | 'Users'
        | 'Other'
        | '';
      'mapfre.com/ip_filter': 'Yes' | 'No';
      'mapfre.com/scope_of_use': 'Public' | 'Private';
      'mapfre.com/event_classification': 'fct' | 'cdc' | 'sys';
      'mapfre.com/compaction_logs': 'Yes' | 'No';
      'mapfre.com/sorted_message':
        | 'There is no sorted message'
        | 'By Partition'
        | 'Global';
      'mapfre.com/retention_time': string;
      'mapfre.com/num_partitions': string;
    };
    serviceAvailability?: {
      'mapfre.com/endpoint_DEV': string;
      'mapfre.com/endpoint_PRE': string;
      'mapfre.com/endpoint_PRO': string;
      'mapfre.com/portal_pub': 'Yes' | 'No';
    };
    wsrr?: {
      'mapfre.com/wsrr_last_pub_DEV': string;
      'mapfre.com/wsrr_last_pub_IC': string;
      'mapfre.com/wsrr_last_pub_PRE': string;
      'mapfre.com/wsrr_last_pub_PRO': string;
      'mapfre.com/wsrr_last_pub_PROBIS': string;
    };
    executionPermissions?: {
      'mapfre.com/auth_type': AuthType;
      'mapfre.com/scopes': string;
      'mapfre.com/rol_serv_IC': string;
      'mapfre.com/rol_serv_PRE': string;
      'mapfre.com/rol_serv_PRO': string;
    };
    historyLog?: {
      'mapfre.com/approvalDate': string;
      'mapfre.com/deprecationDate': string;
      'mapfre.com/modDate': string;
      'mapfre.com/user_mod': string;
    };
    functionalCategory?: {
      'mapfre.com/businessEntity': BusinessEntity;
      'mapfre.com/business_line': {
        life: Life;
        noLife: 'Savings' | 'Other' | 'Risk';
        health: 'Health Care' | 'Medical Centers' | 'Other';
      };
    };
    'mapfre.com/state': string;
    'mapfre.com/consumer_type'?: 'Internal' | 'External' | '';
    'mapfre.com/provider_type'?: 'Internal' | 'External' | '';
    'mapfre.com/organization'?: string;
    'mapfre.com/id_ram'?: string;
  };
  spec: {
    type: string;
    lifecycle: string;
    owner: string;
    system: string;
    consumesApis: string;
    apiConsumedBy: string;
    authorizesApis: string;
    apiAuthorizedBy: string;
    invokesApis: string;
    apiInvokedBy: string;
    nextVersionOf: string;
    previousVersionOf: string;
  };
}

export class MapfreApiLegacyBraEntitiesProcessor implements CatalogProcessor {
  // You often end up wanting to support multiple versions of your kind as you
  // iterate on the definition, so we keep each version inside this array.
  private readonly validators = [
    // This is where we use the JSONSchema that we export from our isomorphic package
    entityKindSchemaValidator(mapfreApiLegacyBraEntityV1alpha1Schema),
  ];

  // validateEntityKind is responsible for signaling to the catalog processing engine
  // that this entity is valid and should therefore be submitted for further processing.
  async validateEntityKind(entity: Entity): Promise<boolean> {
    for (const validator of this.validators) {
      if (validator(entity)) {
        return true;
      }
    }

    return false;
  }

  getProcessorName(): string {
    return 'MapfreApiLegacyBraEntityProcessor';
  }

  async postProcessEntity(
    entity: Entity,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _location: LocationSpec,
    emit: CatalogProcessorEmit,
  ): Promise<Entity> {
    const selfRef = getCompoundEntityRef(entity);

    function doEmit(
      targets: string | string[] | undefined,
      context: { defaultKind?: string; defaultNamespace: string },
      outgoingRelation: string,
      incomingRelation: string,
    ): void {
      if (!targets) {
        return;
      }
      for (const target of [targets].flat()) {
        const targetRef = parseEntityRef(target, context);
        emit(
          processingResult.relation({
            source: selfRef,
            type: outgoingRelation,
            target: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
          }),
        );
        emit(
          processingResult.relation({
            source: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
            type: incomingRelation,
            target: selfRef,
          }),
        );
      }
    }
    const MapfreApiLegacyBra = entity as MapfreApiLegacyBraEntityV1alpha1;
    doEmit(
      MapfreApiLegacyBra.spec.owner,
      { defaultKind: 'Group', defaultNamespace: selfRef.namespace },
      RELATION_OWNED_BY,
      RELATION_OWNER_OF,
    );
    doEmit(
      MapfreApiLegacyBra.spec.system,
      { defaultKind: 'System', defaultNamespace: selfRef.namespace },
      RELATION_PART_OF,
      RELATION_HAS_PART,
    );
    doEmit(
      MapfreApiLegacyBra.spec.consumesApis,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_CONSUMES_API,
      RELATION_API_CONSUMED_BY,
    );
    doEmit(
      MapfreApiLegacyBra.spec.apiConsumedBy,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_API_CONSUMED_BY,
      RELATION_CONSUMES_API,
    );
    doEmit(
      MapfreApiLegacyBra.spec.authorizesApis,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_AUTHORIZES_API,
      RELATION_API_AUTHORIZED_BY,
    );
    doEmit(
      MapfreApiLegacyBra.spec.apiAuthorizedBy,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_API_AUTHORIZED_BY,
      RELATION_AUTHORIZES_API,
    );
    doEmit(
      MapfreApiLegacyBra.spec.invokesApis,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_INVOKES_API,
      RELATION_API_INVOKED_BY,
    );
    doEmit(
      MapfreApiLegacyBra.spec.apiInvokedBy,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_API_INVOKED_BY,
      RELATION_INVOKES_API,
    );
    doEmit(
      MapfreApiLegacyBra.spec.nextVersionOf,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_NEXT_VERSION_OF,
      RELATION_PREVIOUS_VERSION_OF,
    );
    doEmit(
      MapfreApiLegacyBra.spec.previousVersionOf,
      { defaultKind: 'MapfreApi', defaultNamespace: selfRef.namespace },
      RELATION_PREVIOUS_VERSION_OF,
      RELATION_NEXT_VERSION_OF,
    );
    return entity as MapfreApiLegacyBraEntityV1alpha1;
  }
}
