import {
  CatalogProcessor,
  CatalogProcessorEmit,
  processingResult,
} from '@backstage/plugin-catalog-node';
import { LocationSpec } from '@backstage/plugin-catalog-common';
import {
  Entity,
  entityKindSchemaValidator,
  EntityMeta,
  getCompoundEntityRef,
  parseEntityRef,
  RELATION_OWNED_BY,
  RELATION_OWNER_OF,
} from '@backstage/catalog-model';
import mapfreSolutionEntityV1alpha1Schema from './schema/MapfreSolution.v1alpha1.schema.json';
export interface MapfreSolutionEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'MapfreSolution';
  metadata: EntityMeta & {
    potential: string;
    integration: string;
    country: string;
  };
  spec: {
    type: string;
    lifecycle: string;
    owner: string;
  };
}
export class MapfreSolutionEntitiesProcessor implements CatalogProcessor {
  // You often end up wanting to support multiple versions of your kind as you
  // iterate on the definition, so we keep each version inside this array.
  private readonly validators = [
    // This is where we use the JSONSchema that we export from our isomorphic package
    entityKindSchemaValidator(mapfreSolutionEntityV1alpha1Schema),
  ];
  // validateEntityKind is responsible for signaling to the catalog processing engine
  // that this entity is valid and should therefore be submitted for further processing.
  async validateEntityKind(entity: Entity): Promise<boolean> {
    for (const validator of this.validators) {
      if (validator(entity)) {
        return true;
      }
    }
    return false;
  }
  getProcessorName(): string {
    return 'MapfreSolutionEntityProcessor';
  }
  async postProcessEntity(
    entity: Entity,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _location: LocationSpec,
    emit: CatalogProcessorEmit,
  ): Promise<Entity> {
    const selfRef = getCompoundEntityRef(entity);
    function doEmit(
      targets: string | string[] | undefined,
      context: { defaultKind?: string; defaultNamespace: string },
      outgoingRelation: string,
      incomingRelation: string,
    ): void {
      if (!targets) {
        return;
      }
      for (const target of [targets].flat()) {
        const targetRef = parseEntityRef(target, context);
        emit(
          processingResult.relation({
            source: selfRef,
            type: outgoingRelation,
            target: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
          }),
        );
        emit(
          processingResult.relation({
            source: {
              kind: targetRef.kind,
              namespace: targetRef.namespace,
              name: targetRef.name,
            },
            type: incomingRelation,
            target: selfRef,
          }),
        );
      }
    }
    const MapfreSolution = entity as MapfreSolutionEntityV1alpha1;
    doEmit(
      MapfreSolution.spec.owner,
      { defaultKind: 'Group', defaultNamespace: selfRef.namespace },
      RELATION_OWNED_BY,
      RELATION_OWNER_OF,
    );
    return entity as MapfreSolutionEntityV1alpha1;
  }
}
