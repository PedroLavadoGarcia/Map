import React, { ReactElement, useState } from 'react';
import { Route } from 'react-router';
import { apiDocsPlugin } from '@backstage/plugin-api-docs';
import {
  CatalogEntityPage,
  CatalogIndexPage,
  catalogPlugin,
} from '@backstage/plugin-catalog';
import {
  CatalogImportPage as CustomCatalogImportPage,
  catalogImportPlugin,
} from '@internal/plugin-custom-catalog-import';
import {
  EntityPickerFieldExtension,
  EntityTagsPickerFieldExtension,
  OwnedEntityPickerFieldExtension,
  OwnerPickerFieldExtension,
  RepoUrlPickerFieldExtension,
  ScaffolderPage,
  scaffolderPlugin,
} from '@backstage/plugin-scaffolder';
import { ScaffolderFieldExtensions } from '@backstage/plugin-scaffolder-react';
import { orgPlugin } from '@backstage/plugin-org';
import { SearchPage } from '@backstage/plugin-search';
import { TechRadarPage } from '@backstage/plugin-tech-radar';
import {
  TechDocsIndexPage,
  techdocsPlugin,
  TechDocsReaderPage,
} from '@backstage/plugin-techdocs';
import { GridColDef, GridValidRowModel } from '@mui/x-data-grid';
import { TechDocsAddons } from '@backstage/plugin-techdocs-react';
import { ExpandableNavigation } from '@backstage/plugin-techdocs-module-addons-contrib';
import { apis } from './apis';
import { entityPage } from './components/catalog/EntityPage';
import { SearchPage as SearchPageComponent } from './components/search/SearchPage';
import { Root } from './components/Root';
import { CustomGiscusPage } from './components/giscus/discuss';
import {
  AlertDisplay,
  OAuthRequestDialog,
  ProxiedSignInPage,
  SignInPage,
} from '@backstage/core-components';
import { createApp } from '@backstage/app-defaults';
import { FlatRoutes } from '@backstage/core-app-api';
import { CatalogGraphPage } from '@backstage/plugin-catalog-graph';
import { CostInsightsPage } from '@backstage/plugin-cost-insights';
import { HomepageCompositionRoot } from '@backstage/plugin-home';
import { HomePage } from './components/home/HomePage';
import { LighthousePage } from '@backstage/plugin-lighthouse';
import { ThemeProvider } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import { mapfreLightTheme } from './themes/mapfre-light';
import { mapfreDarkTheme } from './themes/mapfre-dark';
import { Mermaid } from 'backstage-plugin-techdocs-addon-mermaid';
import {
  AdaptBitbucketHrefsAddon,
  CustomExpandableAddon,
  CustomBreadcrumbsAddon,
  BrokenLinksAddon,
  HidePrevNextButtonsAddon,
} from '@internal/plugin-custom-addons';

import './i18n';
import { CustomSettingsPage } from './components/settingsPage/CustomSettingsPage';
import { useTranslation } from 'react-i18next';
import { TFunction } from 'i18next';
import { ApiHomePage } from './components/catalog/ApiCatalog/ApiHomePage';
import { AnnouncementsPage } from '@k-phoen/backstage-plugin-announcements';
import { MapfreApiEditorPage } from '@backstage/plugin-mapfreapi-editor';
import {
  useApi,
  identityApiRef,
  //AppTheme,
  appThemeApiRef,
  microsoftAuthApiRef,
  configApiRef,
  IdentityApi,
  SignInPageProps,
} from '@backstage/core-plugin-api';
import { RequirePermission } from '@backstage/plugin-permission-react';
import { accessRegisterPermission } from './permissions';
import { RelationsFieldExtension } from './scaffolder/relations';
import { SystemFieldExtension } from './scaffolder/relations';
import { OwnerFieldExtension } from './scaffolder/relations';
import { OauthFieldExtension } from './scaffolder/relations/extensions';
import { ComponentListPage } from './components/catalog/ComponentCatalog/ComponentListPage';
import { ComponentHomePage } from './components/catalog/ComponentCatalog/ComponentHomePage';
import { Copytron } from './components/catalog/Copytron/Copytron';
import { Updatetron } from './components/catalog/Copytron/Updatetron';
import { CUSTOM_PAIRS } from './components/relations-graph/EntityRelationsGraph';
import { UserEntitiesPage } from './components/userEntitiesPage/UserEntitiesPage';
import { DeleteFileFieldExtension } from './scaffolder/relations/extensions';
import { ActionsFileFieldExtension } from './scaffolder/relations/extensions';
import { MetadataFieldExtension } from './scaffolder/metadata';
import { TypologyFieldExtension } from './scaffolder/relations';
import { Button, Typography } from '@material-ui/core';
import { ApiListLayout } from './components/catalog/ApiCatalog/ApiListLayout';
import { EntityListProvider } from './components/catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import { apiColumnFactories } from './components/columns/apiColumns';

import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import {
  Archive,
  Build,
  Business,
  Category,
  Code,
  Description,
  Apps,
} from '@mui/icons-material';
//import { getThemeColors } from './components/Root/utils';
//import { systemExternalTheme } from './themes/system-external';
import { parseEntityRef } from '@backstage/catalog-model';
import useAsync from 'react-use/lib/useAsync';
import {
  TechDocsHome,
  TechDocsLegacyHome,
} from './components/tech-docs/TechDocsPage';
import { AuditService } from './api/audit';
import { FormsPage } from '@backstage/plugin-forms';
import { MapfreDocumentListLayout } from './components/catalog/ApiCatalog/MapfreDocumentListLayout';

import ResponsiblePage from './components/catalog/pages/ResponsiblePage';
import { MapfreSolutionListLayout } from './components/catalog/ApiCatalog/MapfreSolutionListLayout';
import {
  MarkiaRoutePage,
  ChatProvider,
  useChatKeyboardBinding,
  ChatOpenButtonComponent,
} from '@backstage/plugin-markia';
import SolutionsListView from './components/catalog/SolutionCatalog/SolutionsListView';
import SolutionsGridView from './components/catalog/SolutionCatalog/SolutionsGridView';
import DocumentationListView from './components/tech-docs/TechDocsListViewPage';
import { TemplatesPage } from './components/catalog/TemplatesCatalog/TemplatesPage';

function apiColumns(t: TFunction<'translation', undefined>) {
  return [
    apiColumnFactories.createTitleColumn(t),
    apiColumnFactories.createIdColumn(t),
    apiColumnFactories.createVersionColumn(t),
    apiColumnFactories.createStateColumn(t),
    apiColumnFactories.createSubTypeColumn(t),
    apiColumnFactories.createCountryColumn(t),
    apiColumnFactories.createShortDescColumn(t),
    apiColumnFactories.createModDateColumn(t),
    apiColumnFactories.createBusinessEntityColumn(t),
    apiColumnFactories.createBusinessLineColumn(t),
    apiColumnFactories.createRespFuncColumn(t),
    apiColumnFactories.createRespTechColumn(t),
    apiColumnFactories.createRespAltColumn(t),
    apiColumnFactories.createNNIIColumn(t),
    apiColumnFactories.createNNIICodeColumn(t),
    apiColumnFactories.createExternalAccessColumn(t),
    apiColumnFactories.createServNameColumn(t),
    //apiColumnFactories.createServUbicColumn(t),
    apiColumnFactories.createArchitectureColumn(t),
    apiColumnFactories.createIpFilterColumn(t),
    apiColumnFactories.createEndpointIcColumn(t),
    apiColumnFactories.createEndpointDevColumn(t),
    apiColumnFactories.createEndpointPreColumn(t),
    apiColumnFactories.createEndpointProColumn(t),
    apiColumnFactories.createPortalPubColumn(t),
    apiColumnFactories.createAuthTypeColumn(t),
    apiColumnFactories.createPermTypeColumn(t),
    apiColumnFactories.createScopesColumn(t),
    apiColumnFactories.createRolServICColumn(t),
    apiColumnFactories.createRolServPreColumn(t),
    apiColumnFactories.createRolServProColumn(t),
    apiColumnFactories.createApisColumn(),
  ];
}

function documentColumns(t: TFunction<'translation', undefined>) {
  return [
    apiColumnFactories.createTitleColumn(t),
    apiColumnFactories.createStateColumn(t),
    apiColumnFactories.createShortDescColumn(t),
    apiColumnFactories.createUpdateDateColumn(t),
  ];
}

function solutionColumns(t: TFunction<'translation', undefined>) {
  return [
    apiColumnFactories.createTitleColumn(t),
    apiColumnFactories.createStateColumn(t),
    apiColumnFactories.createMacroProcess(t),
    apiColumnFactories.createShortDescColumn(t),
    apiColumnFactories.createUpdateDateSolColumn(t),
  ];
}

const buttonsBackend = [
  {
    text: 'Blueprint',
    icon: <Archive />,
    href: '/catalog/default/refarch/arqref_backend/blueprint',
  },
  {
    text: 'General Configuration',
    icon: <Build />,
    href: '/catalog/default/refarch/arqref_backend/general-configuration',
  },
  {
    text: 'Scenarios',
    icon: <Business />,
    href: '/catalog/default/refarch/arqref_backend/scenarios',
  },
  {
    text: 'Archetype',
    icon: <Category />,
    href: '/catalog/default/refarch/arqref_backend/archetype',
  },
  {
    text: 'Pipeline',
    icon: <Code />,
    href: '/catalog/default/refarch/arqref_backend/pipeline',
  },
  {
    text: 'Changelog',
    icon: <Description />,
    href: '/catalog/default/refarch/arqref_backend/changelog',
  },
];

const buttonsFrontend = [
  {
    text: 'Blueprint',
    icon: <Archive />,
    href: '/catalog/default/refarch/arqref_frontend/blueprint',
  },
  {
    text: 'Scenarios',
    icon: <Business />,
    href: '/catalog/default/refarch/arqref_frontend/scenarios',
  },
  {
    text: 'Archetype',
    icon: <Category />,
    href: '/catalog/default/refarch/arqref_frontend/archetype',
  },
  {
    text: 'Pipeline',
    icon: <Code />,
    href: '/catalog/default/refarch/arqref_frontend/pipeline',
  },
  {
    text: 'Changelog',
    icon: <Description />,
    href: '/catalog/default/refarch/arqref_frontend/changelog',
  },
  {
    text: 'Use Cases',
    icon: <Apps />,
    href: '/catalog/default/refarch/arqref_frontend/useCases',
  },
];

const BackendGroup = () => {
  return (
    <Grid container spacing={2} marginBottom={2}>
      {buttonsBackend.map((button, index) => (
        <Grid item xs={6} sm={4} md={3} lg={2} key={index}>
          <Button
            variant="contained"
            color="default"
            component={Link}
            to={button.href}
            style={{
              marginBottom: '10px',
              width: '100%',
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            {button.icon}
            <Typography variant="caption">{button.text}</Typography>
          </Button>
        </Grid>
      ))}
    </Grid>
  );
};

const FrontendGroup = () => {
  return (
    <Grid container spacing={2} marginBottom={2}>
      {buttonsFrontend.map((button, index) => (
        <Grid item xs={6} sm={4} md={3} lg={2} key={index}>
          <Button
            variant="contained"
            color="default"
            component={Link}
            to={button.href}
            style={{
              marginBottom: '10px',
              width: '100%',
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            {button.icon}
            <Typography variant="caption">{button.text}</Typography>
          </Button>
        </Grid>
      ))}
    </Grid>
  );
};

const ThemeSwitcher = ({
  children,
}: {
  children: ReactElement;
}): ReactElement => {
  const identityApi = useApi(identityApiRef);
  const appThemeApi = useApi(appThemeApiRef);

  useAsync(async () => {
    const fetchData = async () => {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();
      const extEntityRefs = entityRefs.filter(
        entityRef =>
          parseEntityRef(entityRef).kind === 'group' &&
          parseEntityRef(entityRef)
            .name.toLowerCase()
            .startsWith('gazr-api-backstage-ext'),
      );

      const mappedApiSystem = extEntityRefs.map(
        (entityRef: string) =>
          //GAZR-API-BACKSTAGE-EXT split
          entityRef?.split('-')[4].toLowerCase() +
          '-' +
          entityRef?.split('-')[5].toLowerCase(),
      );

      appThemeApi.setActiveThemeId(mappedApiSystem[0]);
    };
    fetchData();
  });

  return <>{children}</>;
};

/*
const systemColorsFromDatabase: Record<string, string>[] =
  (await getThemeColors()) as unknown as Record<string, string>[];

const systemExternalThemes = Array.isArray(systemColorsFromDatabase)
  ? systemColorsFromDatabase.map(system => ({
      id: system.system,
      title: system.system,
      variant: 'light' as AppTheme['variant'],
      Provider: ({ children }: { children: JSX.Element }) => (
        <ThemeProvider theme={systemExternalTheme(system.primaryColor)}>
          <CssBaseline>{children}</CssBaseline>
        </ThemeProvider>
      ),
    }))
  : [];
*/

const SignInPageComponent = (props: SignInPageProps) => {
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl') ?? '';
  const audit = new AuditService(backendUrl);
  const onSignInSuccess = async (identityApi: IdentityApi) => {
    const { email } = await identityApi.getProfileInfo();
    if (email) {
      audit.pushLoginLog(email);
    }
    props.onSignInSuccess(identityApi);
  };
  return location.hostname === 'localhost' ? (
    <SignInPage
      {...props}
      providers={[
        'guest',
        {
          id: 'azure-auth-provider',
          title: 'Azure',
          message: 'Sign in using Azure',
          apiRef: microsoftAuthApiRef,
        },
      ]}
      onSignInSuccess={onSignInSuccess}
    />
  ) : (
    <ProxiedSignInPage
      {...props}
      provider="awsalb"
      onSignInSuccess={onSignInSuccess}
    />
  );
};

const app = createApp({
  apis,
  components: {
    SignInPage: SignInPageComponent,
  },
  themes: [
    {
      id: 'mapfre-light',
      title: 'Light',
      variant: 'light',
      Provider: ({ children }: { children: JSX.Element }) => (
        <ThemeProvider theme={mapfreLightTheme}>
          <CssBaseline>{children}</CssBaseline>
        </ThemeProvider>
      ),
    },
    {
      id: 'mapfre-dark',
      title: 'Dark',
      variant: 'dark',
      Provider: ({ children }: { children: JSX.Element }) => (
        <ThemeProvider theme={mapfreDarkTheme}>
          <CssBaseline>{children}</CssBaseline>
        </ThemeProvider>
      ),
    },
    //...systemExternalThemes,
  ],

  bindRoutes({ bind }) {
    bind(catalogPlugin.externalRoutes, {
      createComponent: scaffolderPlugin.routes.root,
      viewTechDoc: techdocsPlugin.routes.docRoot,
    });
    bind(apiDocsPlugin.externalRoutes, {
      registerApi: catalogImportPlugin.routes.importPage,
    });
    bind(scaffolderPlugin.externalRoutes, {
      registerComponent: catalogImportPlugin.routes.importPage,
    });
    bind(orgPlugin.externalRoutes, {
      catalogIndex: catalogPlugin.routes.catalogIndex,
    });
  },
});

const AppProvider = app.getProvider();
const AppRouter = app.getRouter();

function routes(t: TFunction<'translation', undefined>) {
  return (
    <FlatRoutes>
      <Route path="/" element={<HomepageCompositionRoot />}>
        <HomePage />
      </Route>
      <Route
        path="/components_old"
        element={
          <CatalogIndexPage
            initialKind="component"
            initiallySelectedFilter="all"
          />
        }
      />
      <Route path="/components" element={<ComponentHomePage />} />

      <Route
        path="/components_v2"
        element={
          // <CatalogIndexPage
          //   initialKind="component"
          //   initiallySelectedFilter="all"
          // />
          <ComponentListPage />
        }
      />
      <Route path="/templates_v2" element={<TemplatesPage />} />
      <Route
        path="/templates"
        element={
          <CatalogIndexPage
            initialKind="template"
            initiallySelectedFilter="all"
          />
        }
      />
      <Route
        path="/catalog/:namespace/:kind/:name"
        element={<CatalogEntityPage />}
      >
        {entityPage(t)}
      </Route>

      <Route path="/forms" element={<FormsPage />}></Route>
      <Route path="/copytron" element={<Copytron />} />
      <Route path="/updatetron" element={<Updatetron />} />
      <Route
        path="/docs/grid"
        element={<TechDocsIndexPage initialFilter={undefined} />}
      >
        <EntityListProvider>
          <TechDocsHome />
        </EntityListProvider>
      </Route>

      <Route
        path="/docs/list"
        element={<TechDocsIndexPage initialFilter={undefined} />}
      >
        <EntityListProvider>
          <DocumentationListView />
        </EntityListProvider>
      </Route>

      <Route
        path="/solutions/list"
        element={
          <EntityListProvider>
            <SolutionsListView t={t} />
          </EntityListProvider>
        }
      ></Route>

      <Route
        path="/solutions/grid"
        element={
          <EntityListProvider>
            <SolutionsGridView t={t} />
          </EntityListProvider>
        }
      ></Route>

      <Route path="/documentation" element={<TechDocsIndexPage />}>
        <EntityListProvider>
          <TechDocsLegacyHome />
        </EntityListProvider>
      </Route>
      <Route
        path="/docs/:namespace/:kind/:name/*"
        element={<TechDocsReaderPage />}
      >
        <TechDocsAddons>
          <ExpandableNavigation />
          <CustomBreadcrumbsAddon />
          <BrokenLinksAddon />
          <CustomExpandableAddon />
          <Mermaid />
          <AdaptBitbucketHrefsAddon />
          <HidePrevNextButtonsAddon />
        </TechDocsAddons>
      </Route>
      <Route
        path="/create"
        element={
          <ScaffolderPage
            groups={[
              {
                title: (
                  <>
                    <Typography variant="h2" color="textPrimary">
                      MAR Backend
                    </Typography>
                    <BackendGroup />
                    <Typography variant="h5" color="textPrimary">
                      Create
                    </Typography>
                  </>
                ),
                filter: entity =>
                  entity?.metadata?.tags?.includes('backend') ?? false,
              },
              {
                title: (
                  <>
                    <Typography variant="h2" color="textPrimary">
                      MAR Frontend
                    </Typography>
                    <FrontendGroup />
                    <Typography variant="h5" color="textPrimary">
                      Create
                    </Typography>
                  </>
                ),
                filter: entity =>
                  entity?.metadata?.tags?.includes('frontend') ?? false,
              },
              {
                title: (
                  <>
                    <Typography variant="h2" color="textPrimary">
                      API
                    </Typography>
                  </>
                ),
                filter: entity =>
                  entity?.metadata?.tags?.includes('api') ?? false,
              },
            ]}
            templateFilter={entity =>
              (entity?.metadata?.tags?.includes('backend') ||
                entity?.metadata?.tags?.includes('api') ||
                entity?.metadata?.tags?.includes('system') ||
                entity?.metadata?.tags?.includes('documentation') ||
                entity?.metadata?.tags?.includes('frontend') ||
                entity?.metadata?.tags?.includes('container') ||
                entity?.metadata?.tags?.includes('tron') ||
                entity?.metadata?.tags?.includes('nodejs')) ??
              false
            }
          />
        }
      >
        <ScaffolderFieldExtensions>
          <RelationsFieldExtension />
          <SystemFieldExtension />
          <DeleteFileFieldExtension />
          <ActionsFileFieldExtension />
          <TypologyFieldExtension />
          <OwnerFieldExtension />
          <MetadataFieldExtension />
          <OauthFieldExtension />
        </ScaffolderFieldExtensions>
      </Route>
      <Route
        path="/apis"
        element={
          <EntityListProvider>
            <ApiListLayout
              columns={apiColumns(t) as GridColDef<GridValidRowModel>[]}
            />
          </EntityListProvider>
        }
      />

      <Route path="/responsible" element={<ResponsiblePage />} />
      <Route
        path="/mapfredocument"
        element={
          <EntityListProvider>
            <MapfreDocumentListLayout
              columns={documentColumns(t) as GridColDef<GridValidRowModel>[]}
            />
          </EntityListProvider>
        }
      />

      <Route
        path="/mapfresolution"
        element={
          <EntityListProvider>
            <MapfreSolutionListLayout
              columns={solutionColumns(t) as GridColDef<GridValidRowModel>[]}
            />
          </EntityListProvider>
        }
      />

      <Route path="/api-home" element={<ApiHomePage />} />
      <Route path="/cost-insights" element={<CostInsightsPage />} />
      <Route path="/lighthouse" element={<LighthousePage />} />
      <Route
        path="/tech-radar"
        element={<TechRadarPage width={1500} height={800} />}
      />
      <Route path="/search" element={<SearchPage />}>
        <SearchPageComponent />
      </Route>
      <Route path="/settings" element={<CustomSettingsPage />} />
      <Route path="/discuss" element={<CustomGiscusPage />} />
      <Route path="/my-entities" element={<UserEntitiesPage />} />

      <Route
        path="/catalog-graph"
        element={
          <CatalogGraphPage
            relationPairs={CUSTOM_PAIRS}
            initialState={{
              maxDepth: 2,
              mergeRelations: false,
              unidirectional: true,
              selectedKinds: [
                'mapfreapi',
                'mapfreapilegacyesp',
                'mapfreapilegacybra',
                'mapfreapilegacyglobal',
                'mapfreapilegacyper',
              ],
            }}
          />
        }
      />
      <Route
        path="/custom-catalog-import"
        element={
          <RequirePermission permission={accessRegisterPermission}>
            <CustomCatalogImportPage />
          </RequirePermission>
        }
      />

      {/* <RequirePermission permission={accessRegisterPermission}>
      <Route
        path="/custom-catalog-import"
        element={<CustomCatalogImportPage />}
      />
      {/* </RequirePermission> */}

      <Route path="/announcements" element={<AnnouncementsPage />} />
      <Route path="/mapfreapi-editor" element={<MapfreApiEditorPage />}>
        <ScaffolderFieldExtensions>
          <EntityPickerFieldExtension />
          <EntityTagsPickerFieldExtension />
          <OwnedEntityPickerFieldExtension />
          <TypologyFieldExtension />
          <OwnerPickerFieldExtension />
          <RepoUrlPickerFieldExtension />
          <RelationsFieldExtension />
          <SystemFieldExtension />
          <OwnerFieldExtension />
          <DeleteFileFieldExtension />
          <ActionsFileFieldExtension />
        </ScaffolderFieldExtensions>
      </Route>
      <Route path="/markia" element={<MarkiaRoutePage />} />
    </FlatRoutes>
  );
}

const App = () => {
  const { t } = useTranslation();

  // State to control opening of Mark:IA sidebar chatbot
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = (open: boolean) => () => {
    setDrawerOpen(open);
  };

  const handleChatKeyboardBinding = () => {
    toggleDrawer(true)();
  };

  useChatKeyboardBinding(handleChatKeyboardBinding);

  return (
    <AppProvider>
      <ChatOpenButtonComponent onClick={toggleDrawer(true)} />
      <ChatProvider open={drawerOpen} toggleDrawer={toggleDrawer} />
      <AlertDisplay />
      <OAuthRequestDialog />
      <ThemeSwitcher>
        <AppRouter>
          <Root>{routes(t)}</Root>
        </AppRouter>
      </ThemeSwitcher>
    </AppProvider>
  );
};

export default App;
