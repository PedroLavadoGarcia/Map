import { createPermission } from '@backstage/plugin-permission-common';
import { BasicPermission } from '@backstage/plugin-permission-common';

export const accessRegisterPermission = createPermission({
  name: 'access.register',

  attributes: {},
});

export const marketplaceAdminView: BasicPermission = {
  type: 'basic',
  name: 'catalog.marketplace.view.all',
  attributes: {
    action: 'read',
  },
};
