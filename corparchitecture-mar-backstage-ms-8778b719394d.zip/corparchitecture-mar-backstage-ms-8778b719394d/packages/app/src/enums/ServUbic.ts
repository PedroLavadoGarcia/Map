enum ServUbic {
  'Internal network (CPD Mapfre)' = 'Internal network (CPD de Mapfre)',
  'Third-Party infrastructure' = 'Third-Party infrastructure',
  'Google' = 'Google',
  'Azure' = 'Azure',
  'AWS' = 'AWS',
  'Oracle' = 'Oracle',
  'Other' = 'Other',
}

export default ServUbic;
