enum Types {
  'BFF API' = 'BFF API',
  'GW Services' = 'GW Services',
  'API Consumer' = 'API Consumer',
  'API Provider' = 'API Provider',
  'Business API' = 'Business API',
  'Edge API' = 'Edge API',
  'Event' = 'Event',
  'External Services' = 'External Services',
  'Login API' = 'Login API',
  'Mediation API' = 'Mediation API',
  'REST Services' = 'REST Services',
  'SOAP Services' = 'SOAP Services',
  'Virtual Services' = 'Virtual Services',
}

export default Types;
