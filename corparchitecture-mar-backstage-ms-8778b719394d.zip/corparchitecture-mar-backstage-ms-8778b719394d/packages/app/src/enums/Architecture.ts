enum Architecture {
  'GAIA' = 'GAIA',
  'CA API Gateway' = 'CA API Gateway',
  'ARQOS' = 'ARQOS',
  'AWS' = 'AWS',
  'v1' = 'v1',
  'v2' = 'v2',
  'Life' = 'Life',
  'BPM WebMethods' = 'BPM WebMethods',
  'Azure' = 'Azure',
  '.NET' = '.NET',
  'Spring integration' = 'Spring integration',
  'Spring' = 'Spring',
  'Spring boot' = 'Spring boot',
  'TRON' = 'TRON',
  'MAR2' = 'MAR2',
  'Guidewire' = 'Guidewire',
  'Other' = 'Other',
  'Unknown' = 'Unknown',
}

export default Architecture;
