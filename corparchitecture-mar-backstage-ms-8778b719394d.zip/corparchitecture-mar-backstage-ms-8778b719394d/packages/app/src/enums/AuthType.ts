enum AuthType {
  'Basic HTTP Security' = 'Basic HTTP Security',
  'JWT' = 'JWT',
  'oAuth2' = 'oAuth2',
  'WS-Security Username Token' = 'WS-Security Username Token',
  'AWS4Sign' = 'AWS4Sign',
  'Red Hat' = 'Red Hat',
  'LTPA Token' = 'LTPA Token',
  'SLL' = 'SLL',
  'Unknown' = 'Unknown',
  'Unsecured' = 'Unsecured',
  'Other' = 'Other',
}

export default AuthType;
