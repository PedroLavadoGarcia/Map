enum BusinessEntity {
  'Quote And Buy' = 'Quote And Buy',
  'Claim' = 'Claim',
  'Receipt' = 'Receipt',
  'Provider' = 'Provider',
  'Distributor' = 'Distributor',
  'Client' = 'Client',
  'Catalog' = 'Catalog',
  'Document' = 'Document',
  'Application Utilities' = 'Application Utilities',
  '' = '',
}

export default BusinessEntity;
