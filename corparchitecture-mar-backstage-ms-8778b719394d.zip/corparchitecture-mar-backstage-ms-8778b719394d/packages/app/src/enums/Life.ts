enum Life {
  'Accidents' = 'Accidents',
  'Autos' = 'Autos',
  'Bicycles & cyclists' = 'Bicycles & cyclists',
  'Community' = 'Community',
  'Deaths' = 'Deaths',
  'Legal Defense' = 'Legal Defense',
  'Business' = 'Business',
  'Home' = 'Home',
  'Pets' = 'Pets',
  'Other' = 'Other',
  'Property & Contingency' = 'Property & Contingency',
  'Rural' = 'Rural',
  'Umbrella' = 'Umbrella',
  'Travel' = 'Travel',
}

export default Life;
