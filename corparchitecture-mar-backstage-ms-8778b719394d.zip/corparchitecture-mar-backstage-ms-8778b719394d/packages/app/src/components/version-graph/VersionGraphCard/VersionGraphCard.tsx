import { getCompoundEntityRef, parseEntityRef } from '@backstage/catalog-model';
import { InfoCard, InfoCardVariants } from '@backstage/core-components';
import { useAnalytics, useRouteRef } from '@backstage/core-plugin-api';
import {
  humanizeEntityRef,
  useEntity,
  entityRouteRef,
} from '@backstage/plugin-catalog-react';
import { makeStyles, Theme } from '@material-ui/core';
import React, { MouseEvent, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  RelationVersionPair,
  VERSION_PAIR,
  EntityVersionsGraph,
  Direction,
  EntityNode,
} from '../EntityVersionsGraph';
import { t } from 'i18next';

const useStyles = makeStyles<Theme, { height: number | undefined }>(
  {
    card: ({ height }) => ({
      display: 'flex',
      flexDirection: 'column',
      maxHeight: height,
      minHeight: height,
    }),
    graph: {
      flex: 1,
      minHeight: 0,
    },
  },
  { name: 'PluginCatalogGraphCatalogGraphCard' },
);

export const VersionGraphCard = (props: {
  variant?: InfoCardVariants;
  relationPairs?: RelationVersionPair;
  maxDepth?: number;
  unidirectional?: boolean;
  mergeRelations?: boolean;
  kinds?: string[];
  relations?: string[];
  direction?: Direction;
  height?: number;
  title?: string;
  zoom?: 'enabled' | 'disabled' | 'enable-on-click';
}) => {
  const {
    variant = 'gridItem',
    relationPairs = VERSION_PAIR,
    maxDepth = 1,
    unidirectional = true,
    mergeRelations = true,
    kinds,
    relations,
    direction = Direction.TOP_BOTTOM,
    height,
    title = t('Versions'),
    zoom = 'enable-on-click',
  } = props;

  const { entity } = useEntity();
  const entityName = getCompoundEntityRef(entity);
  const catalogEntityRoute = useRouteRef(entityRouteRef);
  const navigate = useNavigate();
  const classes = useStyles({ height });
  const analytics = useAnalytics();

  const onNodeClick = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    (node: EntityNode, _: MouseEvent<unknown>) => {
      const nodeEntityName = parseEntityRef(node.id);
      const path = catalogEntityRoute({
        kind: nodeEntityName.kind.toLocaleLowerCase('en-US'),
        namespace: nodeEntityName.namespace.toLocaleLowerCase('en-US'),
        name: nodeEntityName.name,
      });
      analytics.captureEvent(
        'click',
        node.title ?? humanizeEntityRef(nodeEntityName),
        { attributes: { to: path } },
      );
      navigate(path);
    },
    [catalogEntityRoute, navigate, analytics],
  );
  let versions = false;
  entity.relations?.forEach(relation => {
    if (
      relation.type === 'previousVersionOf' ||
      relation.type === 'nextVersionOf'
    ) {
      versions = true;
    }
  });
  if (versions) {
    return (
      <InfoCard
        title={title}
        cardClassName={classes.card}
        variant={variant}
        noPadding
      >
        <EntityVersionsGraph
          rootEntityNames={entityName}
          maxDepth={maxDepth}
          unidirectional={unidirectional}
          mergeRelations={mergeRelations}
          kinds={kinds}
          relations={relations}
          direction={direction}
          onNodeClick={onNodeClick}
          className={classes.graph}
          relationPairs={relationPairs}
          zoom={zoom}
        />
      </InfoCard>
    );
  } else {
    return <></>;
  }
};
