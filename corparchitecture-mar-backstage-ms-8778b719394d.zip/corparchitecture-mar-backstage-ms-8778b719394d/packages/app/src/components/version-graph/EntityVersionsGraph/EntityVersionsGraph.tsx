import {
  CompoundEntityRef,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import {
  DependencyGraph,
  DependencyGraphTypes,
} from '@backstage/core-components';
import { errorApiRef, useApi } from '@backstage/core-plugin-api';
import { CircularProgress, makeStyles, useTheme } from '@material-ui/core';
import classNames from 'classnames';
import React, { MouseEvent, useEffect, useMemo } from 'react';
import { CustomLabel } from './CustomLabel';
import { CustomNode } from './CustomNode';
import { RelationVersionPair, VERSION_PAIR } from './version-relations';
import { Direction, EntityEdge, EntityNode } from './types';
import {
  CustomEntityNode,
  useEntityRelationNodesAndEdges,
} from './useEntityRelationNodesAndEdges';
import {
  RELATION_NEXT_VERSION_OF,
  RELATION_PREVIOUS_VERSION_OF,
} from '../../relations-graph/EntityRelationsGraph';

const useStyles = makeStyles(
  theme => ({
    progress: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      marginLeft: '-20px',
      marginTop: '-20px',
    },
    container: {
      position: 'relative',
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
    },
    graph: {
      width: '100%',
      flex: 1,
      // Right now there is no good way to style edges between nodes, we have to
      // fallback to these hacks:
      '& path[marker-end]': {
        transition: 'filter 0.1s ease-in-out',
      },
      '& path[marker-end]:hover': {
        filter: `drop-shadow(2px 2px 4px ${theme.palette.primary.dark});`,
      },
      '& g[data-testid=label]': {
        transition: 'transform 0s',
      },
    },
  }),
  { name: 'PluginCatalogGraphEntityRelationsGraph' },
);

/**
 * Core building block for custom entity relations diagrams.
 *
 * @public
 */
export const EntityVersionsGraph = (props: {
  rootEntityNames: CompoundEntityRef | CompoundEntityRef[];
  maxDepth?: number;
  unidirectional?: boolean;
  mergeRelations?: boolean;
  kinds?: string[];
  relations?: string[];
  direction?: Direction;
  onNodeClick?: (value: EntityNode, event: MouseEvent<unknown>) => void;
  relationPairs?: RelationVersionPair;
  className?: string;
  zoom?: 'enabled' | 'disabled' | 'enable-on-click';
  renderNode?: DependencyGraphTypes.RenderNodeFunction<CustomEntityNode>;
  renderLabel?: DependencyGraphTypes.RenderLabelFunction<EntityEdge>;
  curve?: 'curveStepBefore' | 'curveMonotoneX';
}) => {
  const {
    rootEntityNames,
    maxDepth = 2,
    unidirectional = true,
    mergeRelations = true,
    kinds,
    relations = [RELATION_NEXT_VERSION_OF, RELATION_PREVIOUS_VERSION_OF],
    direction = Direction.LEFT_RIGHT,
    onNodeClick,
    relationPairs = VERSION_PAIR,
    className,
    zoom = 'enabled',
    renderNode,
    renderLabel,
  } = props;

  const theme = useTheme();
  const classes = useStyles();
  const rootEntityRefs = useMemo(
    () =>
      (Array.isArray(rootEntityNames)
        ? rootEntityNames
        : [rootEntityNames]
      ).map(e => stringifyEntityRef(e)),
    [rootEntityNames],
  );
  const errorApi = useApi(errorApiRef);
  const { loading, error, nodes, edges } = useEntityRelationNodesAndEdges({
    rootEntityRefs,
    maxDepth,
    unidirectional,
    mergeRelations,
    kinds,
    relations,
    onNodeClick,
    relationPairs,
  });

  useEffect(() => {
    if (error) {
      errorApi.post(error);
    }
  }, [errorApi, error]);

  return (
    <div className={classNames(classes.container, className)}>
      {loading && <CircularProgress className={classes.progress} />}
      {nodes && edges && (
        <DependencyGraph
          nodes={nodes}
          edges={edges}
          renderNode={renderNode || CustomNode}
          renderLabel={renderLabel || CustomLabel}
          direction={direction}
          className={classes.graph}
          paddingX={theme.spacing(4)}
          paddingY={theme.spacing(4)}
          labelPosition={DependencyGraphTypes.LabelPosition.RIGHT}
          labelOffset={theme.spacing(1)}
          zoom={zoom}
        />
      )}
    </div>
  );
};
