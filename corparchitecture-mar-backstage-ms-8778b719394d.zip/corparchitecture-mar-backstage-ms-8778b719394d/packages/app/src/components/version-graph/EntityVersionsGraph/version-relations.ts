import {
  RELATION_NEXT_VERSION_OF,
  RELATION_PREVIOUS_VERSION_OF,
} from '../../relations-graph/EntityRelationsGraph';

export type RelationVersionPair = [string, string][];
export const VERSION_PAIR: RelationVersionPair = [
  [RELATION_NEXT_VERSION_OF, RELATION_PREVIOUS_VERSION_OF],
];
