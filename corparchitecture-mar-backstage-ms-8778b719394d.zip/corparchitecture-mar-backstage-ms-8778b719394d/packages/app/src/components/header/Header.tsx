import React, { useEffect, useState } from 'react';
import logo from './mapfre_logo.png';
import marketplace from './logo_marketplace.png';
import Avatar from '@mui/material/Avatar';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useUserProfile } from '@backstage/plugin-user-settings';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useApi } from '@backstage/core-plugin-api';
import { EntityFilterQuery } from '@backstage/catalog-client';
import { JsonObject } from '@backstage/types';
import { Typography } from '@mui/material';

const style = {
  header: {
    padding: '12px 3rem',
    borderTop: '3px solid red',
    borderBottom: '2px solid #e8ebed',
    color: '#aaa',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
  },
  textRed: {
    color: 'red',
  },
  inline: {
    display: 'inline',
  },
  flex: {
    display: 'flex',
  },
  languageMenu: {
    zIndex: 1000,
  },
};

function Header() {
  const { i18n } = useTranslation();
  const currentLang = i18n.resolvedLanguage;
  const [lang, setLang] = useState(currentLang);
  const catalogApi = useApi(catalogApiRef);
  const [initialsForAvatar, setInitialsForAvatar] = useState('');
  const { profile } = useUserProfile();

  const handleLanguageChange = (event: SelectChangeEvent) => {
    setLang(event.target.value);
    const newLangId = event.target.value;
    i18n.changeLanguage(newLangId);
    window.location.reload();
  };

  useEffect(() => {
    const fetchData = async () => {
      if (profile.email) {
        const user = profile.email.replace('@', '_');

        const catalogFilter: EntityFilterQuery = {
          kind: 'User',
          'metadata.name': user,
        };

        const fetchedEntities = await catalogApi.getEntities({
          filter: catalogFilter,
        });
        const username = fetchedEntities?.items[0];
        const picture = (username?.spec?.profile as JsonObject)?.picture;

        if (picture) {
          profile.picture = picture as string;
        }
      }

      const name = profile.displayName;
      let initials = '';
      if (name) {
        const parts = name.split(', ');
        const lastName = parts[0];
        const lastNameParts = lastName.split(' ');
        for (let i = 0; i < (lastNameParts.length < 2 ? 1 : 2); i++) {
          initials += lastNameParts[i].charAt(0);
        }
        setInitialsForAvatar(initials);
      }
    };
    fetchData();
  }, [profile]);

  return (
    <header style={style.header}>
      <div>
        <h1 style={style.inline}>
          <img src={logo} height="23px" width="180px" /> /{' '}
          <img src={marketplace} height="28px" width="220px" />
        </h1>
      </div>

      <div style={style.flex}>
        <MenuItem component={NavLink} to="/settings">
          <Avatar
            sx={{ bgcolor: 'gray' }}
            src={profile.picture ? profile.picture : ''}
          >
            <Typography sx={{ fontSize: 16 }}>{initialsForAvatar}</Typography>
          </Avatar>
        </MenuItem>

        <FormControl variant="standard" sx={{ m: 1, minWidth: 7 }}>
          <InputLabel id="demo-simple-select-standard-label"></InputLabel>
          <Select
            style={style.languageMenu}
            labelId="demo-simple-select-standard-label"
            id="demo-simple-select-standard"
            value={lang}
            onChange={handleLanguageChange}
            label="Age"
          >
            <MenuItem value={'en'}>EN</MenuItem>
            <MenuItem value={'es'}>ES</MenuItem>
            <MenuItem value={'pt'}>PT</MenuItem>
          </Select>
        </FormControl>
      </div>
    </header>
  );
}

export default Header;
