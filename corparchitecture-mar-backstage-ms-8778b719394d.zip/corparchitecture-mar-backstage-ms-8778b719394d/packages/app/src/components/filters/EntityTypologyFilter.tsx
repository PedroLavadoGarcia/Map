import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntityTypologyFilter implements EntityFilter {
  constructor(readonly values: string[]) {}

  filterEntity(entity: Entity): boolean {
    return this.values.some(v => entity.metadata.typology === v);
  }

  toQueryValue(): string[] {
    return this.values;
  }
}
