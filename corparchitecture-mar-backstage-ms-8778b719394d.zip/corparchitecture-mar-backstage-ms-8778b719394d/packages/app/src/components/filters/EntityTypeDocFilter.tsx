import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';
export class EntityTypeDocFilter implements EntityFilter {
  constructor(readonly values: string[]) {}
  filterEntity(entity: Entity): boolean {
    if (entity && entity.spec && entity.spec.type) {
      return this.values.some(v => (entity?.spec?.type as string).includes(v));
    }
    return false;
  }
  toQueryValue(): string[] {
    return this.values;
  }
}
