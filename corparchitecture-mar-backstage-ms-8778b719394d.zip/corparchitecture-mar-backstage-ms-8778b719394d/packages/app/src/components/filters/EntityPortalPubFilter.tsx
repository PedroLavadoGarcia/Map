import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntityPortalPubFilter implements EntityFilter {
  constructor(readonly values: string[]) {}

  filterEntity(entity: Entity): boolean {
    const instances: [] = entity?.metadata?.instances as [];

    return this.values.some(
      v =>
        (entity?.metadata?.serviceAvailability as Record<string, string>)?.[
          'mapfre.com/portal_pub'
        ] === v ||
        instances?.some(
          (objeto: { [x: string]: string }) =>
            objeto['mapfre.com/portal_pub'] === v,
        ),
    );
  }

  toQueryValue(): string[] {
    return this.values;
  }
}
