import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';
export class EntityBusinessEntityFilter implements EntityFilter {
  constructor(readonly values: string[]) {}
  filterEntity(entity: Entity): boolean {
    if (
      entity &&
      entity.metadata &&
      entity.metadata['mapfre.com/businessEntity']
    ) {
      return this.values.some(v =>
        (entity?.metadata?.['mapfre.com/businessEntity'] as string[]).includes(
          v,
        ),
      );
    }
    return false;
  }
  toQueryValue(): string[] {
    return this.values;
  }
}
