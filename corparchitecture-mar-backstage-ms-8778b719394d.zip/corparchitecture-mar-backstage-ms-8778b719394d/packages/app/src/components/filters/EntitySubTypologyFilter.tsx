import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntitySubTypologyFilter implements EntityFilter {
  constructor(readonly values: string[]) {}

  filterEntity(entity: Entity): boolean {
    return this.values.some(v => entity.metadata.subtypology === v);
  }

  toQueryValue(): string[] {
    return this.values;
  }
}
