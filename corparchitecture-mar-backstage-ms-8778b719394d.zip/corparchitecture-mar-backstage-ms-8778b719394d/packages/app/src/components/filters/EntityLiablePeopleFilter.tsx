import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntityLiablePeopleFilter implements EntityFilter {
  constructor(private readonly userEmail: string) {}

  filterEntity(entity: Entity): boolean {
    const liablePeople = entity.metadata.liablePeople as Record<
      string,
      unknown
    >;

    for (const groupOrRole in liablePeople) {
      const isOwnedProperty = Object.prototype.hasOwnProperty.call(
        liablePeople,
        groupOrRole,
      );
      if (isOwnedProperty) {
        const users = liablePeople[groupOrRole];

        if (Array.isArray(users) && users.includes(`${this.userEmail}`)) {
          return true;
        }
      }
    }

    return false;
  }

  toQueryValue(): string | string[] {
    return this.userEmail;
  }
}
