import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntityOwnerFilter implements EntityFilter {
  constructor(readonly values: string[]) {}

  filterEntity(entity: Entity): boolean {
    return this.values.some(v => (entity.spec?.owner as string[])?.includes(v));
  }

  toQueryValue(): string[] {
    return this.values;
  }
}
