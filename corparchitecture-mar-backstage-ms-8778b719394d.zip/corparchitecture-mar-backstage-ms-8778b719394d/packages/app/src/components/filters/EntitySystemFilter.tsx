import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';

export class EntitySystemFilter implements EntityFilter {
  constructor(readonly values: string[]) {}

  filterEntity(entity: Entity): boolean {
    return this.values.some(v =>
      (entity.spec?.system as string[])?.includes(v),
    );
  }

  toQueryValue(): string[] {
    return this.values;
  }
}
