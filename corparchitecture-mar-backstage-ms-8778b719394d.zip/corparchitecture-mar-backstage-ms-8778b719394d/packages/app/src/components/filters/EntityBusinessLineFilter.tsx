import { Entity } from '@backstage/catalog-model';
import { EntityFilter } from '@backstage/plugin-catalog-react';
export class EntityBusinessLineFilter implements EntityFilter {
  constructor(readonly values: string[]) {}
  filterEntity(entity: Entity): boolean {
    if (
      entity &&
      entity.metadata &&
      entity.metadata['mapfre.com/business_line']
    ) {
      return this.values.some(v =>
        (entity?.metadata?.['mapfre.com/business_line'] as string[]).includes(
          v,
        ),
      );
    }
    return false;
  }
  toQueryValue(): string[] {
    return this.values;
  }
}
