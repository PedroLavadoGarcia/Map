import { CatalogTableRow } from '@backstage/plugin-catalog';
import { TableColumn } from '@backstage/core-components';

export const refArchColumn = Object.freeze({
  createTypeColumn(options?: {
    hidden?: boolean;
  }): TableColumn<CatalogTableRow> {
    return {
      title: 'type',
      field: 'entity.spec.type',
      hidden: options?.hidden,
      searchable: true,
    };
  },
});
