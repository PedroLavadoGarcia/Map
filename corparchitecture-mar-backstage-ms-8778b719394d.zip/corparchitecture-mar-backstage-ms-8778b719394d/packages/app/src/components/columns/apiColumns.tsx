/* eslint-disable @typescript-eslint/no-explicit-any */
import { TFunction } from 'i18next';
import { refStrings } from '@internal/plugin-custom-cards/src/components/AboutCustomCard/AboutCustomContent';
import { GridCellParams, GridValueGetterParams } from '@mui/x-data-grid';
import { EntityRefLink } from '@backstage/plugin-catalog-react';
import React from 'react';

/** @public */
export const apiColumnFactories = Object.freeze({
  createStateColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('State') as string,
      field: 'lifecycle',
      width: 120,
      filterable: false,
      renderHeader: () => <strong>{t('State') as string}</strong>,
      valueGetter: (params: GridValueGetterParams) => {
        const stateValue: string = params.row.entity.spec.lifecycle as string;
        const refString = refStrings[stateValue]
          ? refStrings[stateValue]
          : stateValue;
        return t(refString) as string;
      },
    };
  },

  createSubTypeColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Typology') as string,
      field: 'typology',
      width: 150,
      filterable: false,
      renderHeader: () => <strong>{t('Typology') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.typology || '';
      },
    };
  },

  createCountryColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Country') as string,
      field: 'country',
      width: 120,
      filterable: false,
      renderHeader: () => <strong>{t('Country') as string}</strong>,
      valueGetter: (params: GridValueGetterParams) => {
        const countryValue: string = params.row.entity.metadata
          ?.country as string;
        const refString = refStrings[countryValue]
          ? refStrings[countryValue]
          : countryValue;
        return t(refString) as string;
      },
    };
  },

  createUpdateDateColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Last update date') as string,
      field: 'last_update_date',
      width: 180,
      renderHeader: () => <strong>{t('Last Upd. Date') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const modDate: string = params.row.entity.metadata?.historyLog
          ?.last_update_date as string;

        if (!modDate) {
          return '';
        }
        const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } =
          {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          };
        const optionsHours: {
          hour: '2-digit';
          minute: '2-digit';
          second: '2-digit';
        } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const formatted = `${new Date(Number(modDate))
          .toLocaleDateString('es-ES', optionsDate)
          .split(' ')
          .join('-')} ${new Date(Number(modDate)).toLocaleTimeString(
          'es-ES',
          optionsHours,
        )}`;

        return formatted;
      },
      sortComparator: (a: string, b: string) => {
        const fechaA = parseDateFromCustomFormat(a);
        const fechaB = parseDateFromCustomFormat(b);

        if (fechaA < fechaB) {
          return -1;
        } else if (fechaA > fechaB) {
          return 1;
        } else {
          return 0;
        }
      },
    };
  },

  createUpdateDateSolColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Last update date') as string,
      field: 'last_update_date',
      width: 180,
      renderHeader: () => <strong>{t('Last Upd. Date') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const modDate: string = params.row.entity.metadata?.changelog
          ?.modDate as string;

        if (!modDate) {
          return '';
        }
        const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } =
          {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          };
        const optionsHours: {
          hour: '2-digit';
          minute: '2-digit';
          second: '2-digit';
        } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const formatted = `${new Date(Number(modDate))
          .toLocaleDateString('es-ES', optionsDate)
          .split(' ')
          .join('-')} ${new Date(Number(modDate)).toLocaleTimeString(
          'es-ES',
          optionsHours,
        )}`;

        return formatted;
      },
      sortComparator: (a: string, b: string) => {
        const fechaA = parseDateFromCustomFormat(a);
        const fechaB = parseDateFromCustomFormat(b);

        if (fechaA < fechaB) {
          return -1;
        } else if (fechaA > fechaB) {
          return 1;
        } else {
          return 0;
        }
      },
    };
  },

  createModDateColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Modified') as string,
      field: 'modDate',
      width: 180,
      renderHeader: () => <strong>{t('Modified') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const modDate: string = params.row.entity.metadata?.modDate as string;
        const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } =
          {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          };
        const optionsHours: {
          hour: '2-digit';
          minute: '2-digit';
          second: '2-digit';
        } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const formatted = `${new Date(Number(modDate))
          .toLocaleDateString('es-ES', optionsDate)
          .split(' ')
          .join('-')} ${new Date(Number(modDate)).toLocaleTimeString(
          'es-ES',
          optionsHours,
        )}`;

        return formatted;
      },
      sortComparator: (a: string, b: string) => {
        const fechaA = parseDateFromCustomFormat(a);
        const fechaB = parseDateFromCustomFormat(b);

        if (fechaA < fechaB) {
          return -1;
        } else if (fechaA > fechaB) {
          return 1;
        } else {
          return 0;
        }
      },
    };
  },

  createShortDescColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Description') as string,
      field: 'description',
      width: 250,
      wrapText: true,
      renderHeader: () => <strong>{t('Description') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.description || '';
      },
    };
  },

  createTitleColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Name') as string,
      field: 'title',
      minWidth: 200,
      hideable: false,
      renderHeader: () => <strong>{t('Name') as string}</strong>,
      renderCell: (params: GridCellParams) => {
        return (
          <strong
            style={{
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            <EntityRefLink
              entityRef={params.row.entity}
              defaultKind={'mapfreApi'}
              title={params.row.entity?.metadata?.title}
              state={localStorage.setItem(
                'isExternalGov',
                false as unknown as string,
              )}
              target="_blank"
            />
          </strong>
        );
      },
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.title || '';
      },
    };
  },

  createVersionColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Version') as string,
      field: 'version',
      width: 100,
      renderHeader: () => <strong>{t('Version') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.version || '';
      },
    };
  },

  createIdColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('id') as string,
      field: 'id',
      width: 100,
      hideable: false,
      renderHeader: () => <strong>{t('Id') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.name || '';
      },
    };
  },

  createBusinessEntityColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Business Entity') as string,
      field: 'businessEntity',
      width: 150,
      renderHeader: () => <strong>{t('Business Entity') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const businessEntity: string =
          params.row.entity?.metadata?.['mapfre.com/businessEntity'] || '';
        const normalizedBusinessEntity = businessEntity.toLowerCase();
        const refString: string = refStrings[normalizedBusinessEntity]
          ? refStrings[normalizedBusinessEntity]
          : businessEntity;
        return t(refString) as string;
      },
    };
  },

  createBusinessLineColumn(t: TFunction<'translation', undefined>) {
    const refStrings: Record<string, string> = {
      Cross: t('Cross'),
      'Health::Health Care': t('Health Care'),
      'Health::Medical Centers': t('Medical Centers'),
      'Health::Other': t('Health - Other'),
      'NoLife::Bicycles and cyclists': t('Bicycles and cyclists'),
      'NoLife::Business': t('Business'),
      'NoLife::Home Insurance': t('Home Insurance'),
      'NoLife::Legal Defense': t('Legal Defense'),
      'NoLife::Pets': t('Pets'),
      'NoLife::Accidents': t('Accidents'),
      'NoLife::Autos': t('Auto'),
      'NoLife::Community': t('Community'),
      'NoLife::Deaths': t('Deaths'),
      'NoLife::Property and Contingency': t('Property and Contingency'),
      'NoLife::Rural': t('Rural'),
      'NoLife::Umbrella': t('Umbrella'),
      'NoLife::Other': t('NoLife - Other'),
      'NoLife::Travel': t('Travel'),
      'Life::Savings': t('Savings'),
      'Life::Risk': t('Risk'),
      'Life::Other': t('Life - Other'),
    };
    return {
      headerName: t('Business Line') as string,
      field: 'businessLine',
      width: 150,
      renderHeader: () => <strong>{t('Business Line') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const businessLine: string[] =
          params.row.entity?.metadata?.['mapfre.com/business_line'] || [];
        const tbusinessLine: string[] = businessLine
          ?.filter(item => refStrings[item] !== undefined)
          ?.map(item => t(refStrings[item]) as string);
        return tbusinessLine.join(', ');
      },
    };
  },

  // LIABLE PEOPLE

  createRespFuncColumn(t: TFunction<'translation', undefined>) {
    return {
      headerName: t('Functional Manager') as string,
      field: 'respFunc',
      width: 200,
      renderHeader: () => <strong>{t('Functional Manager') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return (
          (
            params.row.entity?.metadata?.liablePeople as Record<string, string>
          )?.['mapfre.com/resp_func'] || ''
        );
      },
    };
  },

  createRespTechColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'respTech',
      headerName: t('Technical Manager') as string,
      width: 200,
      renderHeader: () => <strong>{t('Technical Manager') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return (
          (
            params.row.entity?.metadata?.liablePeople as Record<string, string>
          )?.['mapfre.com/resp_tech'] || ''
        );
      },
    };
  },

  createRespAltColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'respAlt',
      headerName: t('Alternative Manager') as string,
      width: 200,
      renderHeader: () => <strong>{t('Alternative Manager') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        return (
          (
            params.row.entity?.metadata?.liablePeople as Record<string, string>
          )?.['mapfre.com/resp_alt'] || ''
        );
      },
    };
  },

  // CONTEXT DATA

  createNNIIColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'NNII',
      width: 100,
      align: 'center',
      renderHeader: () => <strong>{t('NNII') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const nnii: string =
          (
            params.row.entity?.metadata?.contextData as Record<string, string>
          )?.['mapfre.com/NNII'] || '';
        const normalizedNnii = nnii.toLowerCase();
        return t(normalizedNnii) as string;
      },
    };
  },

  createNNIICodeColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'NNIICcode',
      headerName: t('NNII code') as string,
      width: 200,
      renderHeader: () => <strong>{t('NNII code') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const nnii_code: string[] =
          (
            params.row.entity?.metadata?.contextData as Record<string, string[]>
          )?.['mapfre.com/NNII_code'] || null;
        return nnii_code ? nnii_code.join(',') : '';
      },
    };
  },

  createMacroProcess(t: TFunction<'translation', undefined>) {
    return {
      field: 'Macroprocess',
      headerName: t('Macroprocess') as string,
      width: 200,
      renderHeader: () => <strong>{t('Macroprocess') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const macroprocess: string | null =
          (
            params.row.entity?.metadata?.functional_catalog as Record<
              string,
              string
            >
          )?.['macroprocess'] || null;
        return macroprocess;
      },
    };
  },

  createExternalAccessColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'externalAccess',
      headerName: t('External Access') as string,
      width: 150,
      align: 'center',
      renderHeader: () => <strong>{t('External Access') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const externalAccess: string =
          (
            params.row.entity?.metadata?.contextData as Record<string, string>
          )?.['mapfre.com/externalAccess'] || '';
        const normalizeExternalAccess = externalAccess.toLowerCase();
        return t(normalizeExternalAccess) as string;
      },
    };
  },

  // TECHNICAL DATA

  createServNameColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'servName',
      headerName: t('Service Name') as string,
      width: 200,
      renderHeader: () => <strong>{t('Service Name') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const servName = instances?.map(
            (instance: Record<string, string>) =>
              instance['mapfre.com/serv_type'] || '',
          );
          return servName.join(', ');
        } else {
          return (
            (
              params.row.entity?.metadata?.technicalData as Record<
                string,
                string
              >
            )?.['mapfre.com/serv_type'] || ''
          );
        }
      },
    };
  },

  /*createServUbicColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'servUbic',
      headerName: t('Service Location') as string,
      width: 200,
      renderHeader: () => <strong>{t('Service Location') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const servUbic = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const servUbic = instance['mapfre.com/serv_ubic'];
              if (servUbic && servUbic.length > 0) {
                return servType
                  ? `${servType}: ${servUbic.join(', ')}`
                  : servUbic.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return servUbic;
        } else {
          return (
            (
              params.row.entity?.metadata?.technicalData as Record<
                string,
                string
              >
            )?.['mapfre.com/serv_ubic'] || ''
          );
        }
      },
    };
  },*/

  createArchitectureColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'architecture',
      headerName: t('Architecture') as string,
      width: 200,
      renderHeader: () => <strong>{t('Architecture') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const architecture = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const architecture = instance['mapfre.com/architecture'];
              if (architecture && architecture.length > 0) {
                return servType
                  ? `${servType}: ${architecture.join(', ')}`
                  : architecture.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return architecture;
        } else {
          return (
            (
              params.row.entity?.metadata?.technicalData as Record<
                string,
                string
              >
            )?.['mapfre.com/architecture'] || ''
          );
        }
      },
    };
  },

  createIpFilterColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'ipFilter',
      headerName: t('Ip Filter') as string,
      width: 150,
      align: 'center',
      renderHeader: () => <strong>{t('Ip Filter') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const ipFilter = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const ipFilter = instance['mapfre.com/ip_filter'];
              if (ipFilter && ipFilter.length > 0) {
                return servType
                  ? `${t(servType)}: ${t(ipFilter)}`
                  : t(ipFilter);
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return ipFilter;
        } else {
          const ipFilter =
            params.row.entity?.metadata?.technicalData?.[
              'mapfre.com/ip_filter'
            ] || '';
          const normalizedIpFilter = ipFilter.toLowerCase();
          return t(normalizedIpFilter) as string;
        }
      },
    };
  },

  //SERVICE AVAILABILITY

  createEndpointIcColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'endpointIc',
      headerName: t('Endpoint IC') as string,
      width: 200,
      renderHeader: () => <strong>{t('Endpoint IC') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const endpointsIC = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const endpointsIC = instance['mapfre.com/endpoint_IC'];
              if (endpointsIC && endpointsIC.length > 0) {
                return servType
                  ? `${servType}: ${endpointsIC.join(', ')}`
                  : endpointsIC.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return endpointsIC;
        } else {
          return (
            (
              params.row.entity?.metadata?.serviceAvailability as Record<
                string,
                string
              >
            )?.['mapfre.com/endpoint_IC'] || ''
          );
        }
      },
    };
  },

  createEndpointDevColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'endpointDev',
      headerName: t('Endpoint DEV') as string,
      width: 200,
      renderHeader: () => <strong>{t('Endpoint DEV') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const endpointsDEV = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const endpointsDEV = instance['mapfre.com/endpoint_DEV'];
              if (endpointsDEV && endpointsDEV.length > 0) {
                return servType
                  ? `${servType}: ${endpointsDEV.join(', ')}`
                  : endpointsDEV.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return endpointsDEV;
        } else {
          return (
            (
              params.row.entity?.metadata?.serviceAvailability as Record<
                string,
                string
              >
            )?.['mapfre.com/endpoint_DEV'] || ''
          );
        }
      },
    };
  },

  createEndpointPreColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'endpointPre',
      headerName: t('Endpoint PRE') as string,
      width: 200,
      renderHeader: () => <strong>{t('Endpoint PRE') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const endpointsPRE = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const endpointsPRE = instance['mapfre.com/endpoint_PRE'];
              if (endpointsPRE && endpointsPRE.length > 0) {
                return servType
                  ? `${servType}: ${endpointsPRE.join(', ')}`
                  : endpointsPRE.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return endpointsPRE;
        } else {
          return (
            (
              params.row.entity?.metadata?.serviceAvailability as Record<
                string,
                string
              >
            )?.['mapfre.com/endpoint_PRE'] || ''
          );
        }
      },
    };
  },

  createEndpointProColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'endpointPro',
      headerName: t('Endpoint PRO') as string,
      width: 200,
      renderHeader: () => <strong>{t('Endpoint PRO') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const endpointsPRO = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const endpointsPRO = instance['mapfre.com/endpoint_PRO'];
              if (endpointsPRO && endpointsPRO.length > 0) {
                return servType
                  ? `${servType}: ${endpointsPRO.join(', ')}`
                  : endpointsPRO.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return endpointsPRO;
        } else {
          return (
            (
              params.row.entity?.metadata?.serviceAvailability as Record<
                string,
                string
              >
            )?.['mapfre.com/endpoint_PRO'] || ''
          );
        }
      },
    };
  },

  createPortalPubColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'portalPub',
      headerName: t('Publish in Portal') as string,
      width: 150,
      renderHeader: () => <strong>{t('Publish in Portal') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const portalPub = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const portalPub = instance['mapfre.com/portal_pub'];
              if (portalPub && portalPub.length > 0) {
                return servType
                  ? `${t(servType)}: ${t(portalPub)}`
                  : t(portalPub);
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return portalPub;
        } else {
          const portalPub =
            params.row.entity?.metadata?.serviceAvailability?.[
              'mapfre.com/portal_pub'
            ] || '';
          const normalizedPortalPub = portalPub.toLowerCase();
          return t(normalizedPortalPub) as string;
        }
      },
    };
  },

  // EXECUTION PERMISSIONS

  createAuthTypeColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'authType',
      headerName: t('Auth Type') as string,
      width: 200,
      renderHeader: () => <strong>{t('Auth Type') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const authType = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const authType = instance['mapfre.com/auth_type'];
              if (authType && authType.length > 0) {
                return servType
                  ? `${servType}: ${authType.join(', ')}`
                  : authType.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return authType;
        } else {
          const authType =
            params.row.entity?.metadata?.executionPermissions?.[
              'mapfre.com/auth_type'
            ] || [];

          const normalizedAuthType: string[] = authType?.map((value: string) =>
            t(value.toLowerCase()),
          );
          const joinValues = normalizedAuthType?.join(', ');
          return joinValues;
        }
      },
    };
  },

  createPermTypeColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'permType',
      headerName: t('Perm Type') as string,
      width: 200,
      renderHeader: () => <strong>{t('Perm Type') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const permType = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const permType = instance['mapfre.com/perm_type'];
              if (permType && permType.length > 0) {
                return servType
                  ? `${t(servType)}: ${t(permType)}`
                  : t(permType);
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return permType;
        } else {
          const permType =
            params.row.entity?.metadata?.executionPermissions?.[
              'mapfre.com/perm_type'
            ] || '';
          const normalizedPermType = permType.toLowerCase();
          return t(normalizedPermType) as string;
        }
      },
    };
  },

  createScopesColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'scopes',
      headerName: t('Scopes') as string,
      width: 200,
      renderHeader: () => <strong>{t('Scopes') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const scopes = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const scopes = instance['mapfre.com/scopes'];
              if (scopes && scopes.length > 0) {
                return servType
                  ? `${servType}: ${scopes.join(', ')}`
                  : scopes.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return scopes;
        } else {
          return (
            (
              params.row.entity?.metadata?.executionPermissions as Record<
                string,
                string
              >
            )?.['mapfre.com/scopes'] || ''
          );
        }
      },
    };
  },

  createRolServICColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'rolServIC',
      headerName: t('Role/Service IC') as string,
      width: 200,
      renderHeader: () => <strong>{t('Role/Service IC') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const rolServIC = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const rolServIC = instance['mapfre.com/rol_serv_IC'];
              if (rolServIC && rolServIC.length > 0) {
                return servType
                  ? `${servType}: ${rolServIC.join(', ')}`
                  : rolServIC.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return rolServIC;
        } else {
          return (
            (
              params.row.entity?.metadata?.executionPermissions as Record<
                string,
                string
              >
            )?.['mapfre.com/rol_serv_IC'] || ''
          );
        }
      },
    };
  },

  createRolServPreColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'rolServPre',
      headerName: t('Role/Service PRE') as string,
      width: 200,
      renderHeader: () => <strong>{t('Role/Service PRE') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const rolServPre = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const rolServPre = instance['mapfre.com/rol_serv_PRE'];
              if (rolServPre && rolServPre.length > 0) {
                return servType
                  ? `${servType}: ${rolServPre.join(', ')}`
                  : rolServPre.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return rolServPre;
        } else {
          return (
            (
              params.row.entity?.metadata?.executionPermissions as Record<
                string,
                string
              >
            )?.['mapfre.com/rol_serv_PRE'] || ''
          );
        }
      },
    };
  },

  createRolServProColumn(t: TFunction<'translation', undefined>) {
    return {
      field: 'rolServPro',
      headerName: t('Role/Service PRO') as string,
      width: 200,
      renderHeader: () => <strong>{t('Role/Service PRO') as string}</strong>,
      valueGetter: (params: GridCellParams) => {
        const instances = params.row.entity?.metadata?.instances;
        if (instances && instances !== undefined) {
          const rolServPre = instances
            ?.map((instance: Record<string, any>) => {
              const servType = instance['mapfre.com/serv_type'];
              const rolServPre = instance['mapfre.com/endpoint_IC'];
              if (rolServPre && rolServPre.length > 0) {
                return servType
                  ? `${servType}: ${rolServPre.join(', ')}`
                  : rolServPre.join(', ');
              }
              return '';
            })
            .filter(Boolean)
            .join(', ');
          return rolServPre;
        } else {
          return (
            (
              params.row.entity?.metadata?.executionPermissions as Record<
                string,
                string
              >
            )?.['mapfre.com/rol_serv_PRO'] || ''
          );
        }
      },
    };
  },

  createApisColumn() {
    return {
      headerName: 'APIS',
      field: 'apis',
      width: 100,
      renderHeader: () => <strong>APIS</strong>,
      valueGetter: (params: GridCellParams) => {
        return params.row.entity?.metadata?.annotations?.apis || '';
      },
    };
  },
});

function parseDateFromCustomFormat(dateStr: string) {
  const months = [
    'ene',
    'feb',
    'mar',
    'abr',
    'may',
    'jun',
    'jul',
    'ago',
    'sept',
    'oct',
    'nov',
    'dic',
  ];

  const parts = dateStr.split(' ');
  const dateParts = parts[0].split('-');
  const timeParts = parts[1].split(':');

  const day = parseInt(dateParts[0], 10);
  const month = months.indexOf(dateParts[1].toLowerCase());
  const year = parseInt(dateParts[2], 10);
  const hour = parseInt(timeParts[0], 10);
  const minute = parseInt(timeParts[1], 10);
  const second = parseInt(timeParts[2], 10);

  return new Date(year, month, day, hour, minute, second);
}
