import { CatalogTableRow } from '@backstage/plugin-catalog';
import { OverflowTooltip, TableColumn } from '@backstage/core-components';
import { Entity } from '@backstage/catalog-model';
import {
  EntityRefLink,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import React from 'react';

export const nameDescriptionColumns = Object.freeze({
  createNameColumn(options?: {
    defaultKind?: string;
  }): TableColumn<CatalogTableRow> {
    function formatContent(entity: Entity): string {
      return (
        entity.metadata?.title ||
        humanizeEntityRef(entity, {
          defaultKind: options?.defaultKind,
        })
      );
    }
    return {
      title: 'Name',
      field: 'resolved.name',
      highlight: true,
      width: 'auto',

      customSort({ entity: entity1 }, { entity: entity2 }) {
        // TODO: We could implement this more efficiently by comparing field by field.
        // This has similar issues as above.
        return formatContent(entity1).localeCompare(formatContent(entity2));
      },
      render: ({ entity }) => (
        <EntityRefLink
          entityRef={entity}
          defaultKind={options?.defaultKind || 'Component'}
          title={entity.metadata?.title}
        />
      ),
    };
  },

  createTypeColumn(options?: {
    hidden?: boolean;
  }): TableColumn<CatalogTableRow> {
    return {
      title: 'type',
      field: 'entity.spec.type',
      hidden: options?.hidden,
      searchable: true,
      width: 'auto',
    };
  },

  createMetadataDescriptionColumn(): TableColumn<CatalogTableRow> {
    return {
      title: 'Description',
      field: 'entity.metadata.description',
      render: ({ entity }) => (
        <OverflowTooltip
          text={entity.metadata.description}
          placement="bottom-start"
        />
      ),
      width: '100rem',
    };
  },
});
