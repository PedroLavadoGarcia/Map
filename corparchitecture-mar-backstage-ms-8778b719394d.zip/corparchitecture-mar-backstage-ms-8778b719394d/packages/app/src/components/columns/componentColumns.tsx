import { CatalogTableRow } from '@backstage/plugin-catalog';
import { TableColumn } from '@backstage/core-components';
import { TFunction } from 'i18next';
import { refStrings } from '@internal/plugin-custom-cards/src/components/AboutCustomCard/AboutCustomContent';
import { Button, Chip, IconButton, Tooltip } from '@material-ui/core';
import PendingIconOutlined from '@mui/icons-material/PendingOutlined';
import { CheckCircleOutline, WarningOutlined } from '@material-ui/icons';
import CancelIcon from '@mui/icons-material/CancelOutlined';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import React from 'react';

/** @public */
export const componentColumnFactories = Object.freeze({
  createStateColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('State') as string,
      field: 'entity.spec.lifecycle',
      hidden: options?.hidden,
      searchable: true,
      width: '27%',
      customFilterAndSearch(filter, rowData) {
        const stateValue: string = rowData.entity.spec?.lifecycle as string;
        const refString = refStrings[stateValue]
          ? refStrings[stateValue]
          : stateValue;
        return t(refString).toLowerCase().includes(filter.toLowerCase());
      },
      render: ({ entity }) => {
        const stateValue: string = entity.spec?.lifecycle as string;
        const refString = refStrings[stateValue]
          ? refStrings[stateValue]
          : stateValue;

        const getIcon = (stateValue: string) => {
          switch (stateValue) {
            case 'approved':
              return <CheckCircleOutline style={{ color: '#48c915' }} />;
            case 'experimental':
              return <WarningOutlined style={{ color: 'orange' }} />;
            case 'pending':
              return <PendingIconOutlined style={{ color: '#5572f1' }} />;
            case 'blocked':
              return <RemoveCircleOutlineIcon style={{ color: 'secondary' }} />;
            case 'deprecated':
              return <CancelIcon style={{ color: 'red' }} />;
            default:
              return null;
          }
        };
        const stateIcon = getIcon(stateValue);

        return (
          <div>
            {stateIcon && (
              <Tooltip title={refString}>
                <IconButton aria-label={stateValue}>{stateIcon}</IconButton>
              </Tooltip>
            )}
          </div>
        );
      },
    };
  },
  createSubTypeColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('Typology') as string,
      field: 'entity.metadata.typology',
      hidden: options?.hidden,
      searchable: true,
      width: '32%',
    };
  },
  createTagsColumn(options?: {
    hidden?: boolean;
  }): TableColumn<CatalogTableRow> {
    return {
      title: 'Tags',
      field: 'entity.metadata.tags',
      cellStyle: {
        padding: '0px 16px 0px 20px',
      },
      hidden: options?.hidden,
      searchable: true,
      render: ({ entity }) => (
        <>
          {entity.metadata.tags &&
            entity.metadata.tags.map(t => (
              <Chip
                key={t}
                label={t}
                size="small"
                variant="outlined"
                style={{ marginBottom: '0px' }}
              />
            ))}
        </>
      ),
      width: 'auto',
    };
  },
  createSubSubTypeColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('SubTypology') as string,
      field: 'entity.metadata.subtypology',
      align: 'left',
      hidden: options?.hidden,
      searchable: true,
      width: '40%',
    };
  },
  createCountryColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('Country') as string,
      field: 'entity.metadata.country',
      hidden: options?.hidden,
      searchable: true,
      width: '25%',
      customFilterAndSearch(filter, rowData) {
        const countryValue: string = rowData.entity.metadata?.country as string;
        const refString = refStrings[countryValue]
          ? refStrings[countryValue]
          : countryValue;
        return t(refString).toLowerCase().includes(filter.toLowerCase());
      },
      render: ({ entity }) => {
        const countryValue: string = entity.metadata?.country as string;
        const refString = refStrings[countryValue]
          ? refStrings[countryValue]
          : countryValue;
        return t(refString);
      },
    };
  },

  createModDateColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('Modified') as string,
      field: 'entity.metadata.modDate',
      hidden: options?.hidden,
      searchable: false,
      width: '33%',
      render: ({ entity }) => {
        const modDate: string = entity.metadata?.modDate as string;
        const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } =
          {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          };
        const optionsHours: {
          hour: '2-digit';
          minute: '2-digit';
          second: '2-digit';
        } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        const formatted = `${new Date(Number(modDate))
          .toLocaleDateString('es-ES', optionsDate)
          .split(' ')
          .join('-')} ${new Date(Number(modDate)).toLocaleTimeString(
          'es-ES',
          optionsHours,
        )}`;

        return formatted;
      },
    };
  },
  createOwnerColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('Responsible') as string,
      field: 'entity.spec.owner',
      hidden: options?.hidden,
      searchable: true,
      width: '33%',
      render: ({ entity }) => (
        //button when click, redirect to: /catalog?owner=entity.spec.owner
        <Button
          variant="text"
          color="primary"
          size="small"
          //no hover color
          style={{ textTransform: 'none' }}
          onClick={() => {
            window.location.href = `/catalog/default/group/${entity.spec?.owner}`;
          }}
        >
          {entity.spec?.owner}
        </Button>
      ),
    };
  },

  createShortDescColumn(
    t: TFunction<'translation', undefined>,
    options?: {
      hidden?: boolean;
    },
  ): TableColumn<CatalogTableRow> {
    return {
      title: t('Short Description') as string,
      field: 'entity.metadata.description',
      hidden: options?.hidden,
      searchable: true,
      width: '76%',
    };
  },
  createTitleColumn(): TableColumn<CatalogTableRow> {
    return {
      title: 'Title' as string,
      field: 'entity.metadata.title',
      hidden: true,
      searchable: true,
    };
  },
});
