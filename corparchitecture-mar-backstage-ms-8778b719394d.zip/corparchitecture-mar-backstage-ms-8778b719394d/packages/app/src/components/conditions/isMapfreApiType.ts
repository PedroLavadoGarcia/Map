import { Entity } from '@backstage/catalog-model';
import { MapfreApiEntityV1alpha1 } from '../../interfaces/MapfreApiEntityV1alpha1';
import { MapfreApiLegacyPerEntityV1alpha1 } from '../../interfaces/MapfreApiLegacyPerEntityV1alpha1';
import { MapfreApiLegacyEspEntityV1alpha1 } from '../../interfaces/MapfreApiLegacyEspEntityV1alpha1';
import { MapfreApiLegacyBraEntityV1alpha1 } from '../../interfaces/MapfreApiLegacyBraEntityV1alpha1';
import { MapfreApiLegacyGlobalEntityV1alpha1 } from '../../interfaces/MapfreApiLegacyGlobalEntityV1alpha1';

function strCmp(a: string | undefined, b: string | undefined): boolean {
  return Boolean(
    a && a?.toLocaleLowerCase('en-US') === b?.toLocaleLowerCase('en-US'),
  );
}

function strCmpAll(value: string | undefined, cmpValues: string | string[]) {
  return typeof cmpValues === 'string'
    ? strCmp(value, cmpValues)
    : cmpValues.some(cmpVal => strCmp(value, cmpVal));
}

export function isMapfreApiType(types: string | string[]) {
  return (entity: Entity) => {
    if (strCmp(entity.kind, 'mapfreapi')) {
      const apiEntity = entity as MapfreApiEntityV1alpha1;
      return strCmpAll(apiEntity.metadata.typology, types);
    }

    if (strCmp(entity.kind, 'mapfreapilegacybra')) {
      const apiEntityLegacyBra = entity as MapfreApiLegacyBraEntityV1alpha1;
      return strCmpAll(apiEntityLegacyBra.metadata.typology, types);
    }
    if (strCmp(entity.kind, 'mapfreapilegacyper')) {
      const apiEntityLegacyPer = entity as MapfreApiLegacyPerEntityV1alpha1;
      return strCmpAll(apiEntityLegacyPer.metadata.typology, types);
    }
    if (strCmp(entity.kind, 'mapfreapilegacyesp')) {
      const apiEntityLegacyEsp = entity as MapfreApiLegacyEspEntityV1alpha1;
      return strCmpAll(apiEntityLegacyEsp.metadata.typology, types);
    }
    if (strCmp(entity.kind, 'mapfreapilegacyglobal')) {
      const apiEntityLegacyGlobal =
        entity as MapfreApiLegacyGlobalEntityV1alpha1;
      return strCmpAll(apiEntityLegacyGlobal.metadata.typology, types);
    }
    return false;
  };
}
