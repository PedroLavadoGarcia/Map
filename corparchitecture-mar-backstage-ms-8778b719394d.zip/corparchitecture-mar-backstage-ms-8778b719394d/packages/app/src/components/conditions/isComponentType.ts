import { Entity } from '@backstage/catalog-model';
import { ComponentEntityV1alpha1 } from '../../interfaces/ComponentEntityV1alpha1';

function strCmp(a: string | undefined, b: string | undefined): boolean {
  return Boolean(
    a && a?.toLocaleLowerCase('en-US') === b?.toLocaleLowerCase('en-US'),
  );
}

function strCmpAll(value: string | undefined, cmpValues: string | string[]) {
  return typeof cmpValues === 'string'
    ? strCmp(value, cmpValues)
    : cmpValues.some(cmpVal => strCmp(value, cmpVal));
}

export function isComponentType(types: string | string[]) {
  return (entity: Entity) => {
    if (!strCmp(entity.kind, 'component')) {
      return false;
    }
    const apiEntity = entity as ComponentEntityV1alpha1;

    return strCmpAll(apiEntity.metadata.typology, types);
  };
}
