import { Entity } from '@backstage/catalog-model';

export interface RefArchEntity extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'RefArch';
  spec: {
    type: string;
    owner: string;
  };
}

function strCmp(a: string | undefined, b: string | undefined): boolean {
  return Boolean(
    a && a?.toLocaleLowerCase('en-US') === b?.toLocaleLowerCase('en-US'),
  );
}

function strCmpAll(value: string | undefined, cmpValues: string | string[]) {
  return typeof cmpValues === 'string'
    ? strCmp(value, cmpValues)
    : cmpValues.some(cmpVal => strCmp(value, cmpVal));
}

export function isRefArchType(types: string | string[]) {
  return (entity: Entity) => {
    if (!strCmp(entity.kind, 'refarch')) {
      return false;
    }
    const componentEntity = entity as RefArchEntity;
    return strCmpAll(componentEntity.spec.type, types);
  };
}
