/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import './CatalogTable.css';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Divider,
  Box,
  TablePagination,
  Button,
} from '@mui/material';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { t } from 'i18next';
import { Entity } from '@backstage/catalog-model';
import { useNavigate } from 'react-router';
import { GroupChecker } from '../../../utils/GroupChecker';
import { Progress } from '@backstage/core-components';
import { EntityFieldsQuery } from '@backstage/catalog-client';

export const CatalogTable = () => {
  const catalogApi = useApi(catalogApiRef);
  const identityApi = useApi(identityApiRef);
  const navigate = useNavigate();
  const [user, setUser] = useState<string>('');
  const [filter, setFilter] = useState<string>('');
  const [entities, setEntities] = useState<Entity[]>([]);
  const [userEntities, setUserEntities] = useState<Entity[]>([]);
  const [pendingEntities, setPendingEntities] = useState<Entity[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);

  const fields: EntityFieldsQuery = [
    'kind',
    'metadata.name',
    'metadata.title',
    'metadata.typology',
    'metadata.country',
    'metadata.description',
    'metadata.modDate',
    'metadata.historyLog.last_update_date',
    'metadata.changelog.modDate',
    'spec.lifecycle',
  ];

  useEffect(() => {
    (async () => {
      const userIdentity = await identityApi.getBackstageIdentity();
      const user = userIdentity.userEntityRef.replace('default/', '');

      setUser(user);
      await getUserEntities(user);
      setLoading(false);
    })();
  }, [catalogApi]);

  async function getUserEntities(user: string) {
    setFilter('my_entities');
    if (userEntities.length) {
      setEntities(userEntities);
      return;
    }
    try {
      const response = await catalogApi.getEntities({
        filter: [
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/owners': user,
          },
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/resp_func': user,
          },
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/resp_tech': user,
          },
          {
            kind: 'MapfreDocument',
            'metadata.liableTeam.responsible': user,
            'spec.type': 'simple',
          },
          {
            kind: 'MapfreDocument',
            'metadata.liableTeam.writers': user,
            'spec.type': 'simple',
          },
          {
            kind: 'MapfreSolution',
            'metadata.liableTeam.func_team.responsible': user,
          },
          {
            kind: 'MapfreSolution',
            'metadata.liableTeam.tech_team.responsible': user,
          },
        ],

        fields,
      });

      const entities = response.items;

      sortEntities(entities);
      setUserEntities(entities);
      setEntities(entities);
    } catch (error) {
      console.log(error);
      setError('Failed to fetch entities');
    }
  }

  async function getPendingEntities(user: string) {
    setFilter('pending_entities');
    if (pendingEntities.length) {
      setEntities(pendingEntities);
      return;
    }
    try {
      const filter: { [field: string]: string | string[] }[] = [];
      const groupChecker = await GroupChecker.init(identityApi);
      const isGlobalGovDocGroup = groupChecker.isGlobalGovDocGroup();
      const isGlobalGovGroup = groupChecker.isGlobalGovGroup();
      const isCountryGroup = groupChecker.isCountryGroup();
      const isGlobalGovSolGroup = groupChecker.isGlobalGovSolGroup();
      const isDismaGroup = groupChecker.isDisma();
      if (isGlobalGovDocGroup) {
        filter.push(
          ...[
            {
              kind: 'MapfreDocument',
              'spec.lifecycle': [
                'pending acceptance',
                'pending approval',
                'retired candidate',
              ],
              'spec.type': 'simple',
            },
          ],
        );
      }
      if (isGlobalGovGroup) {
        filter.push(
          ...[
            {
              kind: [
                'MapfreApi',
                'MapfreApiLegacyGlobal',
                'MapfreApiLegacyEsp',
              ],
              'spec.lifecycle': [
                'review',
                'review edited',
                'retired candidate',
              ],
            },
          ],
        );
      } else if (isCountryGroup) {
        const countries = isCountryGroup.map(group =>
          group.split('-')[3].toUpperCase(),
        );
        filter.push(
          ...[
            {
              kind: [
                'MapfreApi',
                'MapfreApiLegacyGlobal',
                'MapfreApiLegacyEsp',
              ],
              'spec.lifecycle': [
                'review',
                'review edited',
                'retired candidate',
              ],
              'metadata.country': countries,
            },
          ],
        );
      }
      if (isGlobalGovSolGroup) {
        filter.push(
          ...[
            {
              kind: 'MapfreSolution',
              'metadata.state': ['review', 'review_edited'],
            },
          ],
        );
      } else {
        filter.push(
          ...[
            {
              kind: 'MapfreSolution',
              'metadata.state': ['draft', 'edited'],
              'metadata.liableTeam.func_team.responsible': user,
            },
            {
              kind: 'MapfreSolution',
              'metadata.state': ['draft', 'edited'],
              'metadata.liableTeam.tech_team.responsible': user,
            },
          ],
        );
      }
      if (isDismaGroup) {
        filter.push(
          ...[
            {
              kind: 'MapfreApi',
              'spec.lifecycle': ['security review', 'security review edited'],
            },
          ],
        );
      }
      filter.push(
        ...[
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/owners': user,
            'spec.lifecycle': ['draft', 'edited'],
          },
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/resp_func': user,
            'spec.lifecycle': ['draft', 'edited'],
          },
          {
            kind: ['MapfreApi', 'MapfreApiLegacyGlobal', 'MapfreApiLegacyEsp'],
            'metadata.liablePeople.mapfre.com/resp_tech': user,
            'spec.lifecycle': ['draft', 'edited'],
          },
          {
            kind: ['MapfreDocument'],
            'metadata.liableTeam.responsible': user,
            'spec.lifecycle': ['accepted', 'draft'],
            'spec.type': 'simple',
          },
          {
            kind: ['MapfreDocument'],
            'metadata.liableTeam.writers': user,
            'spec.lifecycle': ['accepted', 'draft'],
            'spec.type': 'simple',
          },
          {
            kind: 'MapfreSolution',
            'metadata.state': ['draft', 'edited'],
            'metadata.liableTeam.func_team.responsible': user,
          },
          {
            kind: 'MapfreSolution',
            'metadata.state': ['draft', 'edited'],
            'metadata.liableTeam.tech_team.responsible': user,
          },
        ],
      );
      const response = await catalogApi.getEntities({
        filter,
        fields,
      });
      const entities = response.items;
      sortEntities(entities);
      setPendingEntities(entities);
      setEntities(entities);
    } catch (error) {
      console.log(error);
      setError('Failed to fetch entities');
    }
  }

  const getModDate = (entity: Entity) => {
    try {
      let timestamp = 0;
      switch (entity.kind) {
        case 'MapfreApi':
        case 'MapfreApiLegacyGlobal':
        case 'MapfreApiLegacyEsp':
          timestamp = +(entity.metadata.modDate as number);
          break;
        case 'MapfreDocument':
          timestamp = +(entity.metadata.historyLog as any)
            .last_update_date as number;
          break;
        case 'MapfreSolution':
          timestamp = +(entity.metadata.changelog as any).modDate as number;
          break;
      }
      if (timestamp) {
        return new Date(timestamp).toUTCString();
      }
    } catch (error) {
      console.log(error);
    }
    return '';
  };

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  if (loading) return <Progress />;
  if (error) return <Typography>Error: {error}</Typography>;

  return (
    <Paper>
      <Box className="Box" display="flex" alignItems="center">
        <Typography variant="h6" style={{ marginRight: '8px' }}>
          {t(`table.filter.${filter}`)}
        </Typography>
        <Typography variant="body2">({entities.length})</Typography>
        <Divider className="Divider" orientation="vertical" flexItem />
        <Button
          className="FilterButton"
          sx={{ fontWeight: filter === 'my_entities' ? 'bold' : '' }}
          onClick={() => getUserEntities(user)}
          variant="text"
        >
          {t('table.filter.my_entities')}
        </Button>
        <Button
          className="FilterButton"
          sx={{ fontWeight: filter === 'pending_entities' ? 'bold' : '' }}
          onClick={() => getPendingEntities(user)}
          variant="text"
        >
          {t('table.filter.pending_entities')}
        </Button>
      </Box>
      <TableContainer>
        <Table>
          <TableHead className="TableHead">
            <TableRow>
              <TableCell sx={{ width: '20%' }}>
                {t('table.titles.name')}
              </TableCell>
              <TableCell sx={{ width: '10%' }}>
                {t('table.titles.kind')}
              </TableCell>
              <TableCell sx={{ width: '10%' }}>
                {t('table.titles.lyfecycle')}
              </TableCell>
              <TableCell sx={{ width: '10%' }}>
                {t('table.titles.state')}
              </TableCell>
              <TableCell sx={{ width: '10%' }}>
                {t('table.titles.country')}
              </TableCell>
              <TableCell sx={{ width: '10%' }}>
                {t('table.titles.modDate')}
              </TableCell>
              <TableCell sx={{ width: '40%' }}>
                {t('table.titles.description')}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {entities
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map(entity => (
                <TableRow className="TableRow" key={entity.metadata.name}>
                  <TableCell
                    sx={{ width: '20%' }}
                    className="TableCell-link"
                    onClick={() => navEntity(entity)}
                  >
                    {entity.metadata.title}
                  </TableCell>
                  <TableCell sx={{ width: '10%' }}>{t(entity.kind)}</TableCell>
                  <TableCell sx={{ width: '10%' }}>
                    {t(entity.metadata.typology as string)}
                  </TableCell>
                  <TableCell sx={{ width: '10%' }}>
                    {t(entity.spec?.lifecycle as string)}
                  </TableCell>
                  <TableCell>{t(entity.metadata.country as string)}</TableCell>
                  <TableCell>{getModDate(entity)}</TableCell>
                  <TableCell sx={{ width: '40%' }}>
                    {entity.metadata.description}
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[1, 5, 10, 25]}
        component="div"
        count={entities.length}
        page={page}
        rowsPerPage={rowsPerPage}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        labelRowsPerPage={t('table.rows_per_page')}
        labelDisplayedRows={({ from, to, count }) =>
          t('table.of', { from, to, count })
        }
      />
    </Paper>
  );

  function navEntity(entity: Entity) {
    const name = entity.metadata.name;
    const kind = entity.kind.toLowerCase();
    navigate(`/catalog/default/${kind}/${name}`);
  }

  function sortEntities(entities: Entity[]) {
    entities.sort((a, b) => {
      if (a.kind < b.kind) return -1;
      if (a.kind > b.kind) return 1;

      if (a.metadata.modDate && b.metadata.modDate) {
        if (a.metadata.modDate >= b.metadata.modDate) return -1;
        if (a.metadata.modDate < b.metadata.modDate) return 1;
      }

      if (a.metadata.modDate && !b.metadata.modDate) return -1;
      if (!a.metadata.modDate && b.metadata.modDate) return 1;

      if (a.metadata.historyLog && b.metadata.historyLog) {
        if (
          (a.metadata.historyLog as any).last_update_date &&
          (b.metadata.historyLog as any).last_update_date
        ) {
          if (
            (a.metadata.historyLog as any).last_update_date >=
            (b.metadata.historyLog as any).last_update_date
          )
            return -1;
          if (
            (a.metadata.historyLog as any).last_update_date <
            (b.metadata.historyLog as any).last_update_date
          )
            return 1;
        }

        if (
          (a.metadata.historyLog as any).last_update_date &&
          !(b.metadata.historyLog as any).last_update_date
        )
          return -1;
        if (
          !(a.metadata.historyLog as any).last_update_date &&
          (b.metadata.historyLog as any).last_update_date
        )
          return 1;
      }

      if (a.metadata.changelog) {
        if (
          (a.metadata.changelog as any).modDate &&
          (b.metadata.changelog as any).modDate
        ) {
          if (
            (a.metadata.changelog as any).modDate >=
            (b.metadata.changelog as any).modDate
          )
            return -1;
          if (
            (a.metadata.changelog as any).modDate <
            (b.metadata.changelog as any).modDate
          )
            return 1;

          if (
            (a.metadata.changelog as any).modDate &&
            !(b.metadata.changelog as any).modDate
          )
            return -1;
          if (
            !(a.metadata.changelog as any).modDate &&
            (b.metadata.changelog as any).modDate
          )
            return 1;
        }
      }

      return 0;
    });
  }
};
