import React from 'react';
import { Header, Page, Progress } from '@backstage/core-components';
import { Box } from '@mui/material';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import useAsync from 'react-use/lib/useAsync';
import { CatalogTable } from './CatalogTable';
import { GroupChecker } from '../../utils/GroupChecker';
import { t } from 'i18next';
import { Navigate } from 'react-router';

export const UserEntitiesPage = () => {
  const identityApi = useApi(identityApiRef);

  const { value: groupChecker } = useAsync(async () => {
    return await GroupChecker.init(identityApi);
  });

  if (!groupChecker) {
    return <Progress />;
  }

  if (groupChecker.isExternal()) {
    return <Navigate to='/' />;
  }

  return (
    <Page themeId={'theme'}>
      <Box display='flex' justifyContent='center' minWidth='100vw'>
        <Box padding='0 20px' width='1500px' maxWidth='1500px'>
          <Header
            title={t('title')}
            style={{ padding: '80px 0px 100px 0px' }}
          ></Header>
          <CatalogTable />
        </Box>
      </Box>
    </Page>
  );
};
