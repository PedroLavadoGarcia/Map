const ROUTE = '/api/admincatalog';
const LOCATION = window.location.origin.replace('3000', '7007');

export async function getAllProperties() {
  const url = new URL(`${ROUTE}/properties`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();
      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}

export async function getAllTemplates() {
  const url = new URL(`${ROUTE}/templates`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();
      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}

export async function getTemplate(template: string) {
  const url = new URL(`${ROUTE}/templates/${template}`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();

      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}

export async function postTemplate(template: Record<string, unknown>) {
  const url = new URL(`${ROUTE}/templates/new`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  const body = JSON.stringify({ data: template });

  try {
    const req = new Request(url.toString(), {
      method: 'POST',
      headers,
      body,
    });

    const response = await fetch(req);

    if (!response.ok) {
      throw Error(`
            ${`ERROR ${response.status}`}`);
    } else {
      return true;
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}

export async function createYamlTemplate(template: Record<string, any>) {
  const url = new URL(`${ROUTE}/templates/createYaml`, LOCATION);

  try {
    const headers = new Headers();
    headers.set('Content-Type', 'application/json');

    const body = JSON.stringify({ template });

    const request = new Request(url.toString(), {
      method: 'POST',
      headers,
      body,
    });
    const response = await fetch(request);
    return response.status;
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}

export async function getAllThemes() {
  const url = new URL(`${ROUTE}/themes`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();
      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`
            ${`ERROR ${error}`}`);
    }
    return false;
  }
}

export async function getTheme(systemName: string) {
  const url = new URL(`${ROUTE}/themes/${systemName}`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();
      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`
            ${`ERROR ${error}`}`);
    }
    return false;
  }
}
