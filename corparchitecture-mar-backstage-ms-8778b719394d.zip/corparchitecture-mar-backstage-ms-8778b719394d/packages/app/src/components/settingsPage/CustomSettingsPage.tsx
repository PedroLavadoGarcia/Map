/*
 * Copyright 2020 The Backstage Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Header,
  InfoCard,
  Link,
  Page,
  Progress,
  TabbedLayout,
  useSidebarPinState,
} from '@backstage/core-components';
import React, { useEffect, useState } from 'react';
import {
  UserSettingsAuthProviders,
  UserSettingsMenu,
  UserSettingsSignInAvatar,
  useUserProfile,
} from '@backstage/plugin-user-settings';
import Button from '@material-ui/core/Button';
import Chip from '@material-ui/core/Chip';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemText from '@material-ui/core/ListItemText';
import { makeStyles } from '@material-ui/core/styles';
import Switch from '@material-ui/core/Switch';
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';
import { Typography as Typography2 } from '@mui/material';
import { useTranslation } from 'react-i18next';
import {
  getSubscriptionsGetReq,
  getUserSubscriptions,
} from '../../api/subscriptions/requests';
import {
  alertApiRef,
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { Entity, parseEntityRef } from '@backstage/catalog-model';
import { useNavigate } from 'react-router';
import TranslateWidget from './GoogleTranslateWidget';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import MenuItem from '@material-ui/core/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { GroupChecker } from '../../utils/GroupChecker';
import { useAsync } from 'react-use';
import { TabsPage } from './TabsPage';
import Avatar from '@mui/material/Avatar';

const freqs: Record<string, Record<string, unknown>> = {
  1: { period: 'Daily' },
  7: { period: 'Weekly' },
  30: { period: 'Monthly' },
};

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 8,
    paddingRight: 16,
  },
  list: {
    width: 'initial',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      padding: `0 0 12px`,
    },
  },
  listItemText: {
    paddingRight: 0,
    paddingLeft: 0,
  },
  listItemSecondaryAction: {
    position: 'relative',
    transform: 'unset',
    top: 'auto',
    right: 'auto',
    paddingLeft: 16,
    [theme.breakpoints.down('xs')]: {
      paddingLeft: 0,
    },
  },
  buttonSubscriptions: {
    position: 'relative',
    marginLeft: '10px',
    transform: 'unset',
    top: 'auto',
    right: 'auto',
    paddingLeft: 16,
    [theme.breakpoints.down('xs')]: {
      paddingLeft: 0,
    },
  },
  gridList: {
    display: 'flex',
    marginRight: '100px',
  },
  mySubscriptionsHeaders: {
    marginTop: '20px',
  },
}));

/**
 * @public
 */
export const CustomSettingsPage = () => {
  const { t } = useTranslation();
  const alertApi = useApi(alertApiRef);
  const { isMobile } = useSidebarPinState();
  const classes = useStyles();
  const { profile, displayName, backstageIdentity } = useUserProfile();
  const isGuest = profile.email === 'guest@example.com';
  const [initialsForAvatar, setInitialsForAvatar] = useState('');
  const configApi = useApi(configApiRef);
  const catalogApi = useApi(catalogApiRef);
  const [freq, setFreq] = useState<string>();
  const [entitySuscriptions, setEntitySuscriptions] = useState<
    {
      entity: Entity;
      suscription: {
        freq: string;
        metadata?: boolean;
        swagger?: boolean;
      };
    }[]
  >([]);
  const [isDialogSubOpen, setIsDialogSubOpen] = useState(false);

  const identityApi = useApi(identityApiRef);

  const { value: groupChecker } = useAsync(async () => {
    return await GroupChecker.init(identityApi);
  });

  const handleChange = (event: SelectChangeEvent) => {
    setFreq(event.target.value as string);
  };

  function handleClose() {
    setIsDialogSubOpen(false);
  }

  const navigate = useNavigate();

  function isApi(entity: Entity) {
    const kind = entity.kind.toLowerCase();
    return kind.includes('mapfreapi');
  }

  async function getDefaultFreq() {
    const response = await fetch(
      getSubscriptionsGetReq(
        configApi.getString('backend.baseUrl'),
        profile.email,
      ),
    );
    if (response.status === 200) {
      const json = await response.json();
      return json.Items.freq;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  }
  async function getMySubscriptions() {
    try {
      const response = await fetch(
        getUserSubscriptions(
          configApi.getString('backend.baseUrl'),
          profile.email,
        ),
      );
      if (response.status === 200) {
        const json = await response.json();

        return json.Items;
      } else {
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      if (error instanceof Error) {
        alertApi.post({
          message: error.message,
          severity: 'error',
        });
      }
      return false;
    }
  }

  useEffect(() => {
    (async function () {
      if (profile.email && !isGuest) {
        try {
          setFreq(await getDefaultFreq());
          const userSubscriptions = await getMySubscriptions();
          const entitySubs: {
            entity: Entity;
            suscription: {
              freq: string;
              metadata?: boolean | undefined;
              swagger?: boolean | undefined;
            };
          }[] = [];
          for (const sub of userSubscriptions) {
            const response = await catalogApi.getEntities({
              filter: {
                'metadata.name': sub.entity,
              },
            });
            if (response.items[0]) {
              entitySubs.push({
                entity: response.items[0],
                suscription: {
                  freq: sub.freq,
                  metadata: sub.metadata,
                  swagger: sub.swagger,
                },
              });
            }
          }
          setEntitySuscriptions(entitySubs);
        } catch (error) {
          if (error instanceof Error) {
            alertApi.post({
              message: error.message,
              severity: 'error',
            });
          }
        }
      }

      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();
      const extEntityRefs = entityRefs.filter(
        entityRef =>
          parseEntityRef(entityRef).kind === 'group' &&
          parseEntityRef(entityRef)
            .name.toLowerCase()
            .startsWith('gazr-api-backstage-ext'),
      );
      setExtOwnershipEntityRefs(extEntityRefs);
      setIsExternal(Boolean(extEntityRefs.length));

      const name = profile.displayName;
      let initials = '';
      if (name) {
        const parts = name.split(', ');
        const lastName = parts[0];
        const lastNameParts = lastName.split(' ');
        for (let i = 0; i < (lastNameParts.length < 2 ? 1 : 2); i++) {
          initials += lastNameParts[i].charAt(0);
        }
        setInitialsForAvatar(initials);
      }
    })();
  }, [profile]);
  const [isExternal, setIsExternal] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();

  const formattedEmail = profile.email?.replace('@', '_');

  if (!groupChecker) {
    return <Progress />;
  }

  return (
    <Page themeId="home">
      {!isMobile && <Header title={t('Settings')} />}
      <TabbedLayout>
        <TabbedLayout.Route path="general" title={t('General')}>
          <Grid container direction="row" spacing={3}>
            <Grid item xs={12} md={6}>
              <InfoCard title={t('Profile')} variant="gridItem">
                <Grid container spacing={6}>
                  <Grid item>
                    <Avatar
                      sx={{
                        bgcolor: 'gray',
                        width: 96,
                        height: 96,
                        marginBottom: 6,
                      }}
                      src={profile.picture ? profile.picture : ''}
                    >
                      <Typography2 sx={{ fontSize: 36 }}>
                        {initialsForAvatar}
                      </Typography2>
                    </Avatar>
                  </Grid>
                  <Grid item xs={12} sm container>
                    <Grid item xs container direction="column" spacing={2}>
                      <Grid item xs>
                        <Typography variant="subtitle1" gutterBottom>
                          {t(displayName)}
                        </Typography>
                        <Link
                          to={`/catalog/default/user/${formattedEmail}`}
                          variant="inherit"
                        >
                          <Typography variant="body2">
                            {profile.email}
                          </Typography>
                        </Link>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <UserSettingsMenu />
                    </Grid>
                  </Grid>
                </Grid>
              </InfoCard>
            </Grid>
            <Grid item xs={12} md={6}>
              <InfoCard title={t('Appearance')} variant="gridItem">
                <List dense>
                  <ListItem
                    className={classes.list}
                    classes={{ container: classes.container }}
                  >
                    {!isExternal && (
                      <>
                        <ListItemText
                          className={classes.listItemText}
                          primary={t('Language')}
                          secondary={t('Change the language of the UI')}
                        />
                        <ListItemSecondaryAction
                          className={classes.listItemSecondaryAction}
                        >
                          <TranslateWidget />
                        </ListItemSecondaryAction>
                      </>
                    )}
                  </ListItem>
                </List>
              </InfoCard>
            </Grid>
            <Grid item xs={12} md={6}>
              <InfoCard title={t('Backstage Identity')}>
                <Grid container spacing={6}>
                  <Grid item xs={12} sm container>
                    <Grid item xs container direction="column" spacing={2}>
                      <Grid item xs>
                        <Typography variant="subtitle1" gutterBottom>
                          {`${t('User entity')}`}:{' '}
                          <Chip
                            label={backstageIdentity?.userEntityRef}
                            variant="outlined"
                            size="small"
                          />
                        </Typography>
                        <Typography variant="subtitle1">
                          {`${t('Ownership entities')}`}:{' '}
                          {backstageIdentity?.ownershipEntityRefs.map(it => (
                            <Chip
                              label={it}
                              variant="outlined"
                              size="small"
                              key={it}
                            />
                          ))}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </InfoCard>
            </Grid>
            {profile.email && !isGuest && (
              <Grid item xs={12} md={12}>
                <InfoCard title={t('Subscriptions')} variant="gridItem">
                  <List dense className={classes.mySubscriptionsHeaders}>
                    {entitySuscriptions.length > 0 &&
                      entitySuscriptions.map((entitySub, i) => (
                        <ListItem
                          className={classes.list}
                          classes={{ container: classes.container }}
                          key={i}
                        >
                          <ListItemText
                            className={classes.listItemText}
                            primary={
                              isApi(entitySub.entity)
                                ? `${entitySub.entity.metadata.country} / ${entitySub.entity.metadata.typology} / ${entitySub.entity.metadata.title} / ${entitySub.entity.metadata.version}`
                                : `${entitySub.entity.metadata.name}`
                            }
                          />
                          <Dialog open={isDialogSubOpen} onClose={handleClose}>
                            <DialogTitle>{t('Subscription')}</DialogTitle>
                            <Select
                              labelId="demo-simple-select-label"
                              id="select-frequency"
                              value={freq}
                              label="Frequency"
                              onChange={handleChange}
                            >
                              <MenuItem value={1}>Daily</MenuItem>
                              <MenuItem value={7}>Weekly</MenuItem>
                              <MenuItem value={30}>Monthly</MenuItem>
                            </Select>
                          </Dialog>

                          {entitySub.suscription.metadata && (
                            <ListItemText
                              className={classes.listItemSecondaryAction}
                              secondary="METADATA"
                            />
                          )}
                          {entitySub.suscription.metadata &&
                            entitySub.suscription.swagger && (
                              <ListItemText
                                className={classes.listItemSecondaryAction}
                                secondary={' | '}
                              />
                            )}
                          {entitySub.suscription.swagger && (
                            <ListItemText
                              className={classes.listItemSecondaryAction}
                              secondary="INTERFACE"
                            />
                          )}
                          <ListItemSecondaryAction
                            className={classes.listItemSecondaryAction}
                          >
                            <Button
                              title=""
                              value={entitySub.suscription.freq}
                              variant="outlined"
                              disabled
                            >
                              <>
                                {t(
                                  freqs[entitySub.suscription.freq]
                                    ?.period as string,
                                )}
                              </>
                            </Button>
                          </ListItemSecondaryAction>
                          <ListItemSecondaryAction>
                            <Button
                              className={classes.buttonSubscriptions}
                              variant="outlined"
                              onClick={() => {
                                if (isApi(entitySub.entity)) {
                                  navigate(
                                    `/catalog/default/mapfreapi/${entitySub.entity.metadata.name}`,
                                  );
                                } else {
                                  navigate(
                                    `/catalog/default/component/${entitySub.entity.metadata.name}`,
                                  );
                                }
                              }}
                            >
                              {t('Inspect')}
                            </Button>
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    {entitySuscriptions.length === 0 && (
                      <p style={{ textAlign: 'center' }}>
                        You are currently not subscribed to at least one API.
                      </p>
                    )}
                  </List>
                </InfoCard>
              </Grid>
            )}
          </Grid>
        </TabbedLayout.Route>
        <TabbedLayout.Route
          path="auth-providers"
          title={t('Authentication Providers')}
        >
          <UserSettingsAuthProviders />
        </TabbedLayout.Route>
        {groupChecker.isAdmin() && (
          <TabbedLayout.Route path="/tabs" title={t('Tabs')}>
            <Grid container spacing={3}>
              <TabsPage />
            </Grid>
          </TabbedLayout.Route>
        )}
      </TabbedLayout>
    </Page>
  );
};
