import React, { useEffect } from 'react';
import './TranslateWidget.css';

const TranslateWidget = () => {
  useEffect(() => {
    // Load the Google Translate API script
    const script = document.createElement('script');
    script.src =
      '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';

    script.async = true;
    document.head.appendChild(script);
    // @ts-expect-error idk
    window.googleTranslateElementInit = googleTranslateElementInit;
  }, []);

  const googleTranslateElementInit = () => {
    // @ts-expect-error idk
    new window.google.translate.TranslateElement(
      {
        includedLanguages: 'en,es,pt', // include this for selected language
        // @ts-expect-error idk
        layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL,
        autoDisplay: true,
      },
      'google_translate_element',
    );
  };

  return (
    <div>
      <div id="google_translate_element" className="translate-widget" />
    </div>
  );
};

export default TranslateWidget;
