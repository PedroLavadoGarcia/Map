import { Grid, Typography, makeStyles } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { getAllTemplates, postTemplate } from './requests';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Checkbox from '@mui/material/Checkbox';
import { DismissableBanner } from '@backstage/core-components';

interface Template {
  templateName: string;
  descriptionTemplate: string;
  general_data: Record<string, unknown>;
  liable_people: Record<string, unknown>;
  context_data: Record<string, unknown>;
  technical_data: Record<string, unknown>;
  service_availability: Record<string, unknown>;
  execution_permissions: Record<string, unknown>;
  functional_category: Record<string, unknown>;
  relations: string[];
  tabs: string[];
  extTabs: string[];
}

const TABS: Record<string, string> = {
  generalTab: 'General Data',
  interfaceTab: 'Interface',
  interfaceSoapTab: 'Interface SOAP',
  invokedServicesTab: 'Invoked Services',
  functionalInformationTab: 'Functional Information',
  historyLogTab: 'History Log',
  contactTab: 'Contact',
  apisTab: 'APIs',
  logStatisticsTab: 'Statistics',
  gwDeploymentTab: 'GW Deployment',
  instanceTab: 'Instances',
  wsrrTab: 'WSRR',
  documentationTab: 'Documentation',
};

const CONSUMER_TABS: Record<string, string> = {
  overviewTab: 'Overview',
  specificationsTab: 'Specifications',
  documentationTab: 'Documentation',
  changeLogTab: 'Changelog',
  interfaceSoapTab: 'Interface SOAP',
  invokedServicesTab: 'Invoked Services',
  historyLogTab: 'History Log',
  contactTab: 'Contact',
  apisTab: 'APIs',
  logStatisticsTab: 'Statistics',
  gwDeploymentTab: 'GW Deployment',
  instanceTab: 'Instances',
  wsrrTab: 'WSRR',
};

export const TabsPage = () => {
  const { t } = useTranslation();
  const [disabledButton, setDisbledButton] = useState(true);
  const [disabledButtonExt, setDisbledButtonExt] = useState(true);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [initialTemplates, setInitialTemplates] = useState<Template[]>([]);
  const [showBanner, setShowBanner] = useState(false);
  const [bannerType, setBannerType] = useState('');

  const useStyles = makeStyles(() => ({
    fixedColumn: {
      width: 'auto',
      borderRight: '1px solid #ccc',
    },
    button: {
      display: 'flex',
      justifyContent: 'flex-end',
      margin: 10,
      gap: '10px',
    },
    tableContainerWrapper: {
      overflowX: 'auto',
      overflowY: 'auto',
      maxHeight: '600px',
    },
    stickyTableHead: {
      position: 'sticky',
      top: 0,
      zIndex: 1,
      backgroundColor: '#fff',
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
  }));

  const classes = useStyles();

  useEffect(() => {
    getAllTemplates().then(allItems => {
      setTemplates(allItems);
      setInitialTemplates(JSON.parse(JSON.stringify(allItems)));
    });
  }, []);

  const handleCheckboxChange = (templateIndex: number, tab: string) => {
    setDisbledButton(false);
    setTemplates(prevTemplates => {
      const updatedTemplates = [...prevTemplates];
      const templateToUpdate = updatedTemplates[templateIndex];

      if (templateToUpdate.tabs.includes(tab)) {
        templateToUpdate.tabs = templateToUpdate.tabs.filter(t => t !== tab);
      } else {
        templateToUpdate.tabs.push(tab);
      }

      return updatedTemplates;
    });
  };

  const handleCheckboxConsumerChange = (
    templateIndex: number,
    extTab: string,
  ) => {
    setDisbledButtonExt(false);
    setTemplates(prevTemplates => {
      const updatedTemplates = [...prevTemplates];
      const templateToUpdate = updatedTemplates[templateIndex];

      if (templateToUpdate?.extTabs?.includes(extTab)) {
        templateToUpdate.extTabs = templateToUpdate?.extTabs?.filter(
          t => t !== extTab,
        );
      } else {
        templateToUpdate?.extTabs?.push(extTab);
      }

      return updatedTemplates;
    });
  };

  const handleConfirmChanges = async (TabsType: string) => {
    const dismissedBanners = window.localStorage.getItem(
      '/notifications/dismissedBanners',
    );
    if (dismissedBanners) {
      window.localStorage.setItem(
        '/notifications/dismissedBanners',
        JSON.stringify(
          JSON.parse(dismissedBanners)?.filter((e: string) => e !== TabsType),
        ),
      );
    }
    setShowBanner(false);
    const postPromises = templates.map(async template => {
      const data = {
        templateName: template.templateName,
        descriptionTemplate: template.descriptionTemplate
          ? template.descriptionTemplate
          : '',
        general_data: template.general_data ? template.general_data : {},
        liable_people: template.liable_people ? template.liable_people : {},
        context_data: template.context_data ? template.context_data : {},
        technical_data: template.technical_data ? template.technical_data : {},
        service_availability: template.service_availability
          ? template.service_availability
          : {},
        execution_permissions: template.execution_permissions
          ? template.execution_permissions
          : {},
        functional_category: template.functional_category
          ? template.functional_category
          : {},
        relations: template.relations ? template.relations : [],
        tabs: template.tabs ? template.tabs : [],
        extTabs: template.extTabs ? template.extTabs : [],
      };

      return await postTemplate(data);
    });

    try {
      const results = await Promise.all(postPromises);

      const allSuccessful = results.every(result => result === true);

      if (allSuccessful) {
        setBannerType(TabsType);
        setShowBanner(true);
        setDisbledButton(true);
        setDisbledButtonExt(true);
      } else {
        throw new Error(`Ha ocurrido un error`);
      }
    } catch (error) {
      throw new Error(`Ha ocurrido un error: ${error}`);
    }
  };

  const handleDiscardChanges = () => {
    setTemplates(initialTemplates);
    setDisbledButton(true);
  };

  const handleDiscardChangesExt = () => {
    setTemplates(initialTemplates);
    setDisbledButtonExt(true);
  };

  return (
    <>
      <Grid style={{ marginBottom: '3em' }}>
        <Typography variant="h6" gutterBottom>
          Templates Tabs
        </Typography>
        {showBanner && bannerType === 'create-banner' && (
          <DismissableBanner
            message={t('Tabs successfully updated')}
            variant="info"
            fixed={false}
            id="create-banner"
          />
        )}
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 400 }}>
            <Table aria-label="simple table">
              <TableHead className={classes.stickyTableHead}>
                <TableRow>
                  <TableCell className={classes.fixedColumn} align="center">
                    Template
                  </TableCell>
                  {Object.values(TABS).map((tab, index) => (
                    <TableCell key={index}>{tab}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {templates.map((item, index) => (
                  <StyledTableRow key={index}>
                    <TableCell className={classes.fixedColumn}>
                      {item.templateName}
                    </TableCell>
                    {Object.keys(TABS).map((tab, tabIndex) => (
                      <TableCell key={tabIndex} align="center">
                        <Checkbox
                          checked={item.tabs.includes(tab)}
                          onChange={() => handleCheckboxChange(index, tab)}
                          disabled={tab === 'generalTab'}
                          color="error"
                        />
                      </TableCell>
                    ))}
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Grid className={classes.button}>
            <Button
              variant="outlined"
              color="error"
              onClick={handleDiscardChanges}
              disabled={disabledButton}
            >
              {t('Discard changes')}
            </Button>
            <Button
              variant="contained"
              color="error"
              disabled={disabledButton}
              onClick={() => handleConfirmChanges('create-banner')}
            >
              {t('Save')}
            </Button>
          </Grid>
        </Paper>
      </Grid>
      <Grid>
        <Typography variant="h6" gutterBottom>
          Consumer Tabs
        </Typography>
        {showBanner && bannerType === 'create-banner-ext' && (
          <DismissableBanner
            message={t('Tabs successfully updated')}
            variant="info"
            fixed={false}
            id="create-banner-ext"
          />
        )}
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 400 }}>
            <Table aria-label="simple table">
              <TableHead className={classes.stickyTableHead}>
                <TableRow>
                  <TableCell className={classes.fixedColumn} align="center">
                    Template
                  </TableCell>
                  {Object.values(CONSUMER_TABS).map((tab, index) => (
                    <TableCell key={index}>{tab}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {templates.map((item, index) => (
                  <StyledTableRow key={index}>
                    <TableCell className={classes.fixedColumn}>
                      {item.templateName}
                    </TableCell>
                    {Object.keys(CONSUMER_TABS).map((extTab, tabIndex) => (
                      <TableCell key={tabIndex} align="center">
                        <Checkbox
                          checked={item?.extTabs?.includes(extTab)}
                          onChange={() =>
                            handleCheckboxConsumerChange(index, extTab)
                          }
                          disabled={extTab === 'generalTab'}
                          color="error"
                        />
                      </TableCell>
                    ))}
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Grid className={classes.button}>
            <Button
              variant="outlined"
              color="error"
              onClick={handleDiscardChangesExt}
              disabled={disabledButtonExt}
            >
              {t('Discard changes')}
            </Button>
            <Button
              variant="contained"
              color="error"
              disabled={disabledButtonExt}
              onClick={() => handleConfirmChanges('create-banner-ext')}
            >
              {t('Save')}
            </Button>
          </Grid>
        </Paper>
      </Grid>
    </>
  );
};
