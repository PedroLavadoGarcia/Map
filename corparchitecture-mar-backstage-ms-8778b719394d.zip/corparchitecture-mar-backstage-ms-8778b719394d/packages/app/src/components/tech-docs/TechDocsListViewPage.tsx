import React, { createContext, useEffect, useState } from 'react';
import { Content, Header, Progress } from '@backstage/core-components';

import { useAsync } from 'react-use';

import { EntityListProvider } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import axios from 'axios';
import Card from '@mui/material/Card';
import Typography from '@material-ui/core/Typography';
import { NavLink } from 'react-router-dom';

import { makeStyles } from '@material-ui/core/styles';
import i18next, { t } from 'i18next';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import {
  CardActionArea,
  Container,
  Grid,
  IconButton,
  InputAdornment,
  TablePagination,
  TextField,
  Link,
  Chip,
} from '@material-ui/core';
import { Entity } from '@backstage/catalog-model';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useApi } from '@backstage/core-plugin-api';
import FavoriteIcon from '../catalog/FavoriteIcon';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import { useTranslation } from 'react-i18next';
import ViewIcon from '../catalog/ViewIcon';

export const EntityContext = createContext('');

export default function DocumentationListView() {
  const useStyles = makeStyles({
    cardRowStyle: {
      display: 'flex',
      flexDirection: 'row',
      marginBottom: '20px',
      boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
      position: 'relative',
      height: '96px',
      gap: '0px',
      borderColor: '#EAE9E9',
      borderRadius: '8px',
    },
    cardActionAreaStyle: {
      display: 'flex',
      justifyContent: 'flex-start',
      width: '100%',
    },
    containerSearchStyle: {
      display: 'flex',
      marginLeft: '0px',
      marginRight: '0px',
      padding: '24px',
      maxWidth: 'none',
    },
    contentListStyle: {
      display: 'list-item',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '25px',
      listStyle: 'none',
    },
  });
  const imageContainerStyle = {
    width: '108px',
    height: '96px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F6F7',
  };

  const classes = useStyles();
  const [tempSignedUrls, setTempSignedUrls] = useState<string[]>([]);
  const [signedUrls, setSignedUrls] = useState<string[]>([]);
  const [contextEntities, setcontextEntities] = useState<Entity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const catalogApi = useApi(catalogApiRef);
  const [currentPage, setCurrentPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [entities, setEntities] = useState<Entity[]>([]);

  const preloadImage = (url: string) => {
    const img = new Image();
    img.src = url;
  };

  useEffect(() => {
    const signedUrlsArray: string[] = [];
    if (entities.length > 0) {
      const fetchSignedUrls = async () => {
        for (const entity of entities) {
          const kind = entity.kind.toLowerCase();
          const lowerCountry = entity.metadata.country
            ? (entity.metadata.country as string).toLowerCase()
            : 'global';
          try {
            if (entity.metadata.annotations?.header_icon) {
              const baseUrl = new URL(
                `api/s3-images`,
                window.location.origin.replace('3000', '7007'),
              );
              const response = await axios.get(
                `${baseUrl}/${lowerCountry}/${
                  entity.metadata.name
                }/${encodeURIComponent(
                  entity.metadata.annotations?.header_icon as string,
                )}?kind=${kind}`,
              );

              signedUrlsArray.push(response.data.signedUrl);
              preloadImage(response.data.signedUrl);
            } else {
              signedUrlsArray.push('');
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            signedUrlsArray.push('');
          }
        }
        setTempSignedUrls(signedUrlsArray);
        setSignedUrls(signedUrlsArray);
      };

      fetchSignedUrls();
    }
  }, [entities]);

  const { loading } = useAsync(async () => {
    const mapfredocumentEntities = await catalogApi.getEntities({
      filter: [
        {
          kind: 'mapfredocument',
          'spec.type': 'simple',
          'spec.lifecycle': 'Approved',
        },
      ],
      fields: [
        'kind',
        'spec',
        'metadata.name',
        'metadata.title',
        'metadata.description',
        'metadata.country',
        'metadata.annotations',
      ],
    });

    const methodEntities = await catalogApi.getEntities({
      filter: [
        {
          kind: 'component',
          'spec.type': 'method',
        },
      ],
      fields: [
        'kind',
        'spec',
        'metadata.name',
        'metadata.title',
        'metadata.description',
        'metadata.country',
        'metadata.annotations',
      ],
    });

    const entities: Entity[] = [];
    if (mapfredocumentEntities && mapfredocumentEntities.items.length > 0) {
      for (let i = 0; i < mapfredocumentEntities.items.length; i++) {
        entities.push(mapfredocumentEntities.items[i]);
      }
    }

    if (methodEntities && methodEntities.items.length > 0) {
      for (let i = 0; i < methodEntities.items.length; i++) {
        entities.push(methodEntities.items[i]);
      }
    }

    //Sort entities
    entities.sort((a: Entity, b: Entity) => {
      const valueA = a.metadata.title?.toLowerCase() || '';
      const valueB = b.metadata.title?.toLowerCase() || '';

      if (valueA < valueB) {
        return -1;
      }
      if (valueA > valueB) {
        return 1;
      }
      return 0;
    });

    setEntities(entities);
    setcontextEntities(entities);
  });

  const handleSearchChange = (event: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchQuery(event.target.value);
    searchChange(event.target.value as string);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchChange('');
  };

  function searchChange(value: string): void {
    setCurrentPage(0);
    if (entities && entities.length > 0) {
      if (value) {
        const entitiesSearch: Entity[] = [];
        const urls: string[] = [];
        for (let i = 0; i < entities.length; i++) {
          if (
            entities[i] &&
            (entities[i].metadata.title
              ?.toLowerCase()
              .includes(value.toLowerCase()) ||
              entities[i].metadata.description
                ?.toLowerCase()
                .includes(value.toLowerCase()))
          ) {
            entitiesSearch.push(entities[i]);
            urls.push(tempSignedUrls[i]);
          }
        }
        setSignedUrls(urls);
        setcontextEntities(entitiesSearch);
      } else {
        setcontextEntities(entities);
        setSignedUrls(tempSignedUrls);
      }
    }
  }

  const startIndex = currentPage * rowsPerPage;
  const currentEntities = contextEntities.slice(
    startIndex,
    startIndex + rowsPerPage,
  );
  const currentUrls = signedUrls.slice(startIndex, startIndex + rowsPerPage);

  const handleRowsPerPageChange = (event: { target: { value: string } }) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setCurrentPage(0);
  };
  const handlePageChange = (
    _event: unknown,
    value: React.SetStateAction<number>,
  ) => {
    setCurrentPage(value);
  };

  const { t } = useTranslation();

  return (
    <EntityListProvider>
      <Container
        style={{
          maxWidth: 'none',
          paddingLeft: '115px',
          paddingRight: '115px',
        }}
      >
        {loading ? (
          <Progress />
        ) : (
          <>
            <Header
              style={{ paddingTop: '24px', paddingBottom: '0px' }}
              title={t('Documentation')}
            >
              <NavLink
                to="/forms/mapfredocument"
                style={{ color: '#DB271C', marginRight: '10px' }}
              >
                {t('Add documentation')}
              </NavLink>
            </Header>
            <Container className={classes.containerSearchStyle}>
              <Grid item xs={11}>
                <TextField
                  variant="outlined"
                  placeholder={'Search'}
                  value={searchQuery}
                  onChange={handleSearchChange}
                  margin="dense"
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                    //  marginBottom: '5%',
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        {searchQuery && (
                          <IconButton
                            edge="end"
                            onClick={handleClearSearch}
                            size="medium"
                          >
                            <ClearIcon />
                          </IconButton>
                        )}
                        <IconButton edge="end" size="medium">
                          <SearchIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    sx: {
                      borderRadius: '20px',
                    },
                  }}
                />
              </Grid>
              <Grid item xs={1}>
                <ViewIcon
                  GridView={false}
                  UrlArray={['/docs/', '?filters%5Bkind%5D=mapfredocument']}
                />
              </Grid>
            </Container>
            <div>
              {/* DOCUMENTATION CARDS LIST*/}
              {contextEntities.length >= 1 ? (
                <Content className={classes.contentListStyle}>
                  {currentEntities.map((entity, index) => (
                    <Grid item xs={4} key={index} style={{ maxWidth: 'none' }}>
                      <Card className={classes.cardRowStyle} variant="outlined">
                        <Link
                          style={{ display: 'contents' }}
                          href={
                            entity.spec?.type === 'method'
                              ? `/catalog/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                              : `/docs/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                          }
                        >
                          <CardActionArea
                            className={classes.cardActionAreaStyle}
                          >
                            <div style={{ ...imageContainerStyle }}>
                              <img
                                style={{
                                  maxWidth: '100%',
                                  maxHeight: '100%',
                                  objectFit: 'contain',
                                  objectPosition: 'center',
                                }}
                                src={
                                  currentUrls.length > 0
                                    ? currentUrls[index]
                                      ? currentUrls[index]
                                      : '/documentationLogo.png'
                                    : '/documentationLogo.png'
                                }
                                loading="lazy"
                                alt=""
                              />
                            </div>
                            <div>
                              <Typography
                                style={{
                                  color: '#2D373D',
                                  fontWeight: 'bold',
                                  fontSize: '16px',
                                  width: '300px',
                                  lineHeight: '18.23px',
                                  textAlign: 'left',
                                  paddingLeft: '16px',
                                  paddingRight: '8px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  display: '-webkit-box',
                                  WebkitLineClamp: '2',
                                  WebkitBoxOrient: 'vertical',
                                }}
                              >
                                {entity?.metadata?.title}
                              </Typography>
                            </div>
                            <div>
                              <Typography
                                style={{
                                  fontSize: '14px',
                                  color: '#526570',
                                  fontWeight: 'lighter',
                                  lineHeight: '18.23px',
                                  textAlign: 'left',
                                  paddingLeft: '8px',
                                  paddingRight: '8px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  display: '-webkit-box',
                                  WebkitLineClamp: '2',
                                  WebkitBoxOrient: 'vertical',
                                  width: '650px',
                                }}
                              >
                                {entity.metadata?.[
                                  `description_${i18next.resolvedLanguage}`
                                ] ?? entity.metadata?.description}
                              </Typography>
                            </div>
                          </CardActionArea>
                          {/* TAGS (SUBCATALOG) */}
                          {/* <CardActionArea
                            className={classes.cardActionAreaStyle}
                            style={{ justifyContent: 'flex-end' }}
                          >
                            <Typography style={{ marginTop: '15px' }}>
                              {(
                                (entity?.metadata?.subcatalog as string[]) || []
                              ).map((t, index) => (
                                <Chip key={index} size="small" label={t} />
                              ))}
                            </Typography>
                          </CardActionArea> */}
                        </Link>
                        <FavoriteIcon />
                        <Link
                          style={{ display: 'flex' }}
                          href={
                            entity.spec?.type === 'method'
                              ? `/catalog/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                              : `/docs/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                          }
                        >
                          <CardActionArea
                            className={classes.cardActionAreaStyle}
                          >
                            <KeyboardArrowRightOutlinedIcon
                              style={{ color: '#526570', margin: '8px' }}
                            />
                          </CardActionArea>
                        </Link>
                      </Card>
                    </Grid>
                  ))}
                </Content>
              ) : (
                <div className={classes.cardRowStyle}></div>
              )}
            </div>
          </>
        )}
      </Container>

      <TablePagination
        component="div"
        count={contextEntities.length}
        page={currentPage}
        onPageChange={handlePageChange}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleRowsPerPageChange}
        rowsPerPageOptions={[10, 20, 50, 100]}
        labelRowsPerPage={t('Rows per page:')}
      />
    </EntityListProvider>
  );
}
