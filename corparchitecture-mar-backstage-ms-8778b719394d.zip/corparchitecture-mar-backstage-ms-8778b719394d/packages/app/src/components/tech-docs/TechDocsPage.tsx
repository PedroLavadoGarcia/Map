import React, { createContext, useEffect, useState } from 'react';
import {
  Content,
  EmptyState,
  Header,
  Progress,
} from '@backstage/core-components';
import {
  EntityKindPicker,
  EntityTypePicker,
} from '@backstage/plugin-catalog-react';

import { useAsync } from 'react-use';

import { EntityListProvider } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import axios from 'axios';
import Card from '@mui/material/Card';
import Typography from '@material-ui/core/Typography';
import { NavLink } from 'react-router-dom';

import { makeStyles } from '@material-ui/core/styles';
import { t } from 'i18next';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import {
  CardActionArea,
  Container,
  Grid,
  IconButton,
  InputAdornment,
  TablePagination,
  TextField,
  Link,
  Chip,
} from '@material-ui/core';
import { Entity } from '@backstage/catalog-model';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useApi } from '@backstage/core-plugin-api';
import { ContentHeader } from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityOwnerPicker,
  EntityTagPicker,
  UserListPicker,
  EntityListProvider as EntityListProvider1,
} from '@backstage/plugin-catalog-react';
import {
  TechDocsPageWrapper,
  TechDocsPicker,
} from '@backstage/plugin-techdocs';
import { EntityListDocsTable } from '@backstage/plugin-techdocs';
import FavoriteIcon from '../catalog/FavoriteIcon';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import { Pagination, useTheme, useMediaQuery } from '@mui/material';
import { useTranslation } from 'react-i18next';
import ViewIcon from '../catalog/ViewIcon';

export const EntityContext = createContext('');
export const TechDocsHome = () => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const useStyles = makeStyles(theme => ({
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 32%)',

      marginLeft: 1,
      marginTop: 5,
    },
    gridauto: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, 300px)',
      marginLeft: 1,
      marginTop: 5,
    },
    header: {
      color: 'white',
    },
    box: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      display: '-webkit-box',
      '-webkit-line-clamp': 10,
      '-webkit-box-orient': 'vertical',
      paddingBottom: '0.8em',
    },
    label: {
      color: theme.palette.text.secondary,
      textTransform: 'uppercase',
      fontSize: '0.65rem',
      fontWeight: 'bold',
      letterSpacing: 0.5,
      lineHeight: 1,
      paddingBottom: '0.2rem',
    },
    entity: {
      textTransform: 'uppercase',
      padding: 8,
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    containerStyle: { width: '80%', height: '100vh', marginLeft: 20 },
    searchBarRoot: {
      padding: '8px 16px',
      background: theme.palette.background.paper,
      boxShadow: theme.shadows[1],
      borderRadius: '50px',
    },
    searchBarOutline: {
      borderStyle: 'none',
    },

    //
    cardGridStyle: {
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
      position: 'relative',
      height: '500px',
      width: '330px',
      gap: '0px',
      borderColor: '#EAE9E9 !important',
      borderRadius: '8px !important',
    },
    noResultcardGridStyle: {
      flexDirection: 'column',
      position: 'relative',
      height: '500px',
      width: '330px',
      gap: '0px',
    },
    cardActionAreaStyle: {
      justifyContent: 'flex-start',
      width: '100%',
    },
    contentCardStyle: {
      display: 'flex !important',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '18px',
      paddingLeft: '0px',
    },
    containerSearchStyle: {
      display: 'flex',
      marginLeft: '0px',
      marginRight: '0px',
      padding: '24px',
      maxWidth: 'none',
    },
  }));

  const imageContainerStyle = {
    width: '330px',
    height: '220px',
    display: 'flex',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F6F7',
  };
  const classes = useStyles();
  const [tempSignedUrls, setTempSignedUrls] = useState<string[]>([]);
  const [signedUrls, setSignedUrls] = useState<string[]>([]);
  const [contextEntities, setcontextEntities] = useState<Entity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const catalogApi = useApi(catalogApiRef);
  const [currentPage, setCurrentPage] = useState(1);

  const [entities, setEntities] = useState<Entity[]>([]);

  function preloadImage(signedUrl: string) {
    const img = new Image();
    img.src = signedUrl;
  }

  useEffect(() => {
    const signedUrlsArray: string[] = [];
    if (entities.length > 0) {
      const fetchSignedUrls = async () => {
        for (const entity of entities) {
          const kind = entity.kind.toLowerCase();

          const lowerCountry = entity.metadata.country
            ? (entity.metadata.country as string).toLowerCase()
            : 'global';
          try {
            if (entity.metadata.annotations?.header_icon) {
              const baseUrl = new URL(
                `api/s3-images`,
                window.location.origin.replace('3000', '7007'),
              );
              const response = await axios.get(
                `${baseUrl}/${lowerCountry}/${
                  entity.metadata.name
                }/${encodeURIComponent(
                  entity.metadata.annotations?.header_icon as string,
                )}?kind=${kind}`,
              );
              signedUrlsArray.push(response.data.signedUrl);
              preloadImage(response.data.signedUrl);
            } else {
              signedUrlsArray.push('');
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            signedUrlsArray.push('');
          }
        }
        setTempSignedUrls(signedUrlsArray);
        setSignedUrls(signedUrlsArray);
      };

      fetchSignedUrls();
    }
  }, [entities]);

  const { loading } = useAsync(async () => {
    const mapfredocumentEntities = await catalogApi.getEntities({
      filter: [
        {
          kind: 'mapfredocument',
          'spec.type': 'simple',
          'spec.lifecycle': 'Approved',
        },
      ],
      fields: [
        'kind',
        'spec',
        'metadata.name',
        'metadata.title',
        'metadata.description',
        'metadata.country',
        'metadata.annotations',
        'metadata.subcatalog',
      ],
    });

    const methodEntities = await catalogApi.getEntities({
      filter: [
        {
          kind: 'component',
          'spec.type': 'method',
        },
      ],
      fields: [
        'kind',
        'spec',
        'metadata.name',
        'metadata.title',
        'metadata.description',
        'metadata.country',
        'metadata.annotations',
        // 'metadata.subcatalog',
      ],
    });

    const entities: Entity[] = [];
    if (mapfredocumentEntities && mapfredocumentEntities.items.length > 0) {
      for (let i = 0; i < mapfredocumentEntities.items.length; i++) {
        entities.push(mapfredocumentEntities.items[i]);
      }
    }

    if (methodEntities && methodEntities.items.length > 0) {
      for (let i = 0; i < methodEntities.items.length; i++) {
        entities.push(methodEntities.items[i]);
      }
    }

    //Sort entities
    entities.sort((a: Entity, b: Entity) => {
      const valueA = a.metadata.title?.toLowerCase() || '';
      const valueB = b.metadata.title?.toLowerCase() || '';

      if (valueA < valueB) {
        return -1;
      }
      if (valueA > valueB) {
        return 1;
      }
      return 0;
    });

    setEntities(entities);
    setcontextEntities(entities);
  });

  const handleSearchChange = (event: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchQuery(event.target.value);
    searchChange(event.target.value as string);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchChange('');
  };

  function searchChange(value: string): void {
    setCurrentPage(1);
    if (entities && entities.length > 0) {
      if (value) {
        const entitiesSearch: Entity[] = [];
        const urls: string[] = [];
        for (let i = 0; i < entities.length; i++) {
          if (
            entities[i] &&
            (entities[i].metadata.title
              ?.toLowerCase()
              .includes(value.toLowerCase()) ||
              entities[i].metadata.description
                ?.toLowerCase()
                .includes(value.toLowerCase()))
          ) {
            entitiesSearch.push(entities[i]);
            urls.push(tempSignedUrls[i]);
          }
        }
        setSignedUrls(urls);
        setcontextEntities(entitiesSearch);
      } else {
        setcontextEntities(entities);
        setSignedUrls(tempSignedUrls);
      }
    }
  }

  const [itemsPerPage, setItemsPerPage] = useState(8);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentEntities = contextEntities.slice(
    startIndex,
    startIndex + itemsPerPage,
  );
  const currentUrls = signedUrls.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (
    _event: unknown,
    value: React.SetStateAction<number>,
  ) => {
    setCurrentPage(value);
  };

  const { t } = useTranslation();

  const theme = useTheme();
  const isXs = useMediaQuery(theme.breakpoints.down('xs'));
  const isSm = useMediaQuery(theme.breakpoints.between('sm', 'md'));
  const isMd = useMediaQuery(theme.breakpoints.between('md', 'lg'));
  const isLg = useMediaQuery(theme.breakpoints.up('lg'));

  const updateItemsPerPage = () => {
    setCurrentPage(1);

    const pageItems = Math.floor((window.innerWidth - 230) / 348) * 2;
    setItemsPerPage(pageItems);
  };

  useEffect(() => {
    updateItemsPerPage();
    window.addEventListener('resize', updateItemsPerPage);
    return () => {
      window.removeEventListener('resize', updateItemsPerPage);
    };
  }, [isLg, isMd, isSm, isXs]);

  return (
    <EntityListProvider>
      <Container
        style={{
          maxWidth: 'none',
          paddingLeft: '115px',
          paddingRight: '115px',
        }}
      >
        {loading ? (
          <Progress />
        ) : (
          <>
            <Header
              style={{ paddingTop: '24px', paddingBottom: '0px' }}
              title={t('Documentation')}
            >
              <NavLink
                to="/forms/mapfredocument"
                style={{ color: '#DB271C', marginRight: '10px' }}
              >
                {t('Add documentation')}
              </NavLink>
            </Header>
            <Container className={classes.containerSearchStyle}>
              <Grid item xs={11}>
                <TextField
                  variant="outlined"
                  placeholder={'Search'}
                  value={searchQuery}
                  onChange={handleSearchChange}
                  margin="dense"
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        {searchQuery && (
                          <IconButton
                            edge="end"
                            onClick={handleClearSearch}
                            size="medium"
                          >
                            <ClearIcon />
                          </IconButton>
                        )}
                        <IconButton edge="end" size="medium">
                          <SearchIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    sx: {
                      borderRadius: '20px',
                    },
                  }}
                />
              </Grid>
              <Grid item xs={1}>
                <ViewIcon
                  GridView={true}
                  UrlArray={['/docs/', '?filters%5Bkind%5D=mapfredocument']}
                />
              </Grid>
            </Container>

            <div>
              {/* DOCUMENTATION CARDS GRID*/}
              {contextEntities.length >= 1 ? (
                <Content className={classes.contentCardStyle}>
                  {currentEntities.map((entity, index) => (
                    <Grid
                      item
                      xs={8}
                      key={index}
                      style={{
                        maxWidth: 'none',
                        flexBasis: 'calc(10% - 10px)',
                      }}
                    >
                      <Card
                        className={classes.cardGridStyle}
                        variant="outlined"
                      >
                        <Link
                          style={{ display: 'contents' }}
                          href={
                            entity.spec?.type === 'method'
                              ? `/catalog/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                              : `/docs/default/${entity.kind.toLocaleLowerCase()}/${
                                  entity.metadata.name
                                }`
                          }
                        >
                          <CardActionArea
                            className={classes.cardActionAreaStyle}
                          >
                            <div style={{ ...imageContainerStyle }}>
                              <img
                                style={{
                                  maxWidth: '100%',
                                  maxHeight: '100%',
                                  objectFit: 'contain',
                                  objectPosition: 'center',
                                  width: '330px',
                                }}
                                loading="lazy"
                                alt=""
                                src={
                                  currentUrls.length > 0
                                    ? currentUrls[index]
                                      ? currentUrls[index]
                                      : '/documentationLogo.png'
                                    : '/documentationLogo.png'
                                }
                              />
                            </div>
                            <div>
                              <Typography
                                style={{
                                  color: '#2D373D',
                                  fontWeight: 'bold',
                                  fontSize: '20px',
                                  width: '330px',
                                  lineHeight: '28px',
                                  textAlign: 'left',
                                  padding: '16px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  display: '-webkit-box',
                                  WebkitLineClamp: '2',
                                  WebkitBoxOrient: 'vertical',
                                }}
                              >
                                {entity?.metadata?.title}
                              </Typography>
                            </div>
                            <div>
                              <Typography
                                style={{
                                  fontSize: '16px',
                                  color: '#526570',
                                  fontWeight: 'lighter',
                                  lineHeight: '20.83px',
                                  textAlign: 'left',
                                  paddingLeft: '16px',
                                  paddingRight: '16px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  display: '-webkit-box',
                                  WebkitLineClamp: '5',
                                  WebkitBoxOrient: 'vertical',
                                  width: '330px',
                                }}
                              >
                                {entity?.metadata?.description}
                              </Typography>
                            </div>
                          </CardActionArea>
                          {/* TAGS (SUBCATALOG) */}
                          {/* <CardActionArea
                            className={classes.cardActionAreaStyle}
                            style={{ justifyContent: 'flex-end' }}
                          >
                            <Typography
                              style={{ marginTop: '15px', padding: '12px' }}
                            >
                              {(
                                (entity?.metadata?.subcatalog as string[]) || []
                              ).map((t, index) => (
                                <Chip key={index} size="small" label={t} />
                              ))}
                            </Typography>
                          </CardActionArea> */}
                        </Link>
                        <div
                          style={{
                            marginTop: 'auto',
                            paddingBottom: '8px',
                            display: 'flex',
                          }}
                        >
                          <Link
                            style={{ display: 'flex' }}
                            href={
                              entity.spec?.type === 'method'
                                ? `/catalog/default/${entity.kind.toLocaleLowerCase()}/${
                                    entity.metadata.name
                                  }`
                                : `/docs/default/${entity.kind.toLocaleLowerCase()}/${
                                    entity.metadata.name
                                  }`
                            }
                          >
                            <CardActionArea
                              className={classes.cardActionAreaStyle}
                              style={{ display: 'flex' }}
                            >
                              <Typography
                                style={{
                                  color: '#D81E05',
                                  fontSize: '16px',
                                  lineHeight: '24px',
                                  textAlign: 'left',
                                  paddingLeft: '16px',
                                }}
                              >
                                {t('View')}
                              </Typography>
                              <KeyboardArrowRightOutlinedIcon
                                style={{ color: '#D81E05' }}
                              />
                            </CardActionArea>
                          </Link>
                          <FavoriteIcon />
                        </div>
                      </Card>
                    </Grid>
                  ))}
                </Content>
              ) : (
                <div className={classes.noResultcardGridStyle}>
                  <EmptyState missing="data" title={t('No results')} />
                </div>
              )}
            </div>
          </>
        )}
      </Container>

      <Pagination
        count={Math.ceil(contextEntities.length / itemsPerPage)}
        page={currentPage}
        onChange={handlePageChange}
        style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}
      />
    </EntityListProvider>
  );
};

export const TechDocsLegacyHome = () => {
  return (
    <TechDocsPageWrapper>
      <Content>
        <ContentHeader title="" />
        <EntityListProvider1>
          <CatalogFilterLayout>
            <CatalogFilterLayout.Filters>
              <TechDocsPicker />
              <EntityKindPicker
                allowedKinds={[
                  'component',
                  'mapfredocument',
                  'refarch',
                  'resource',
                ]}
              />
              <EntityTypePicker />
              <UserListPicker initialFilter="owned" />
              <EntityOwnerPicker />
              <EntityTagPicker />
            </CatalogFilterLayout.Filters>
            <CatalogFilterLayout.Content>
              <EntityListDocsTable />
            </CatalogFilterLayout.Content>
          </CatalogFilterLayout>
        </EntityListProvider1>
      </Content>
    </TechDocsPageWrapper>
  );
};
