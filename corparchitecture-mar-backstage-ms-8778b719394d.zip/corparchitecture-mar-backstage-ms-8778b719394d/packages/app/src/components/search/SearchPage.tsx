import React, { useState, useRef } from 'react';
import { makeStyles, Theme, Grid, List, Paper } from '@material-ui/core';

import {
  catalogApiRef,
  CATALOG_FILTER_EXISTS,
} from '@backstage/plugin-catalog-react';
import { TechDocsSearchResultListItem } from '@backstage/plugin-techdocs';

import { SearchType } from '@backstage/plugin-search';
import {
  useSearch,
  SearchBar,
  SearchFilter,
  SearchResult,
} from '@backstage/plugin-search-react';
import { Content, DocsIcon, Header, Page } from '@backstage/core-components';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { useTranslation } from 'react-i18next';
import { AnnouncementSearchResultListItem } from '@k-phoen/backstage-plugin-announcements';
import RecordVoiceOverIcon from '@material-ui/icons/RecordVoiceOver';
import { AuditService } from '../../api/audit';
import { useAsync } from 'react-use';
import { Subscription, timer } from 'rxjs';

const useStyles = makeStyles((theme: Theme) => ({
  bar: {
    padding: theme.spacing(1, 0),
  },
  filters: {
    padding: theme.spacing(2),
    marginTop: theme.spacing(2),
  },
  filter: {
    '& + &': {
      marginTop: theme.spacing(2.5),
    },
  },
}));

export const SearchPage = () => {
  const classes = useStyles();
  const { types } = useSearch();
  const catalogApi = useApi(catalogApiRef);
  const identityApi = useApi(identityApiRef);
  const { t } = useTranslation();
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl');
  const audit = new AuditService(backendUrl ?? '');
  const [subscription, setSubscription] = useState<Subscription>();
  const searchRef = useRef<HTMLInputElement>(null);

  const { value: email } = useAsync(async () => {
    const profile = await identityApi.getProfileInfo();
    return profile.email;
  });
  return (
    <Page themeId="home">
      <Header title={t('Search')} />
      <Content>
        <Grid container direction="row">
          <Grid item xs={12}>
            <Paper className={classes.bar}>
              <SearchBar
                placeholder={
                  t('Search in MAPFRE Catalog Marketplace') as
                    | string
                    | undefined
                }
                onChangeCapture={() => {
                  const value = searchRef.current?.value ?? '';
                  if (subscription) {
                    subscription.unsubscribe();
                  }
                  setSubscription(
                    timer(3000).subscribe(() => {
                      if (email) {
                        audit.pushSearchLog(email, value);
                      }
                    }),
                  );
                }}
                ref={searchRef}
              />
            </Paper>
          </Grid>
          <Grid item xs={3}>
            <SearchType.Accordion
              name={t('Result type')}
              types={[
                {
                  value: 'techdocs',
                  name: t('Documentation'),
                  icon: <DocsIcon />,
                },
                {
                  value: 'announcements',
                  name: 'Announcements',
                  icon: <RecordVoiceOverIcon />,
                },
              ]}
            />
            <Paper className={classes.filters}>
              {types.includes('techdocs') && (
                <SearchFilter.Select
                  className={classes.filter}
                  label={t('Entity') as string | undefined}
                  name="name"
                  values={async () => {
                    // Return a list of entities which are documented.
                    const { items } = await catalogApi.getEntities({
                      fields: ['metadata.name'],
                      filter: {
                        'metadata.annotations.backstage.io/techdocs-ref':
                          CATALOG_FILTER_EXISTS,
                      },
                    });

                    const names = items.map(entity => entity.metadata.name);
                    names.sort();
                    return names;
                  }}
                />
              )}
              <SearchFilter.Select
                className={classes.filter}
                label={t('Type') as string | undefined}
                name="kind"
                values={['Component', 'Template']}
              />
              <SearchFilter.Checkbox
                className={classes.filter}
                label={t('Lifecycle') as string | undefined}
                name="lifecycle"
                values={['experimental', 'production']}
              />
            </Paper>
          </Grid>
          <Grid item xs={9}>
            <SearchResult>
              {({ results }) => (
                <List>
                  {results.map(({ type, document, highlight, rank }) => {
                    switch (type) {
                      case 'techdocs':
                        return (
                          <TechDocsSearchResultListItem
                            key={document.location}
                            result={document}
                            highlight={highlight}
                          />
                        );
                      case 'announcements':
                        return (
                          <AnnouncementSearchResultListItem
                            key={document.location}
                            result={document}
                            highlight={highlight}
                            rank={rank}
                          />
                        );
                      default:
                        return (
                          <TechDocsSearchResultListItem
                            key={document.location}
                            result={document}
                            highlight={highlight}
                          />
                        );
                    }
                  })}
                </List>
              )}
            </SearchResult>
          </Grid>
        </Grid>
      </Content>
    </Page>
  );
};
