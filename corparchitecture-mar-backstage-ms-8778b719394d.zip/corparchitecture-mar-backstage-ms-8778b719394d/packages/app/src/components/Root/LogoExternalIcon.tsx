import React from 'react';
import { makeStyles } from '@material-ui/core';

const useStyles = makeStyles({
  svg: {
    width: '80%',
    margin: 'auto',
  },
  path: {
    fill: '#7df3e1',
  },
});

const LogoExternalIcon = (props: { smallLogo: string | undefined }) => {
  const classes = useStyles();

  return (
    <div>
      <img
        className={classes.svg}
        src={props.smallLogo}
        alt="Imagen PNG"
        // width={'300%'}
      />
    </div>
  );
};

export default LogoExternalIcon;
