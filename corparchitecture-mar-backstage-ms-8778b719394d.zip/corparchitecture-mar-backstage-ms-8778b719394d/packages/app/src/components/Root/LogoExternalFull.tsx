import React from 'react';
import { makeStyles } from '@material-ui/core';

const useStyles = makeStyles({
  svg: {
    width: '300%',
    marginLeft: 10,
    objectFit: 'cover',
  },
  image: {
    maxWidth: '100%',
  },
  path: {
    fill: '#7df3e1',
  },
});

const LogoExternalFull = (props: { logo: string | undefined }) => {
  const classes = useStyles();

  return (
    <div>
      <img
        className={classes.svg}
        src={props.logo}
        alt="Imagen PNG"
        // width={'300%'}
      />
    </div>
  );
};

export default LogoExternalFull;
