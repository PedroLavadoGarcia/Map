import React, { PropsWithChildren, useState } from 'react';
import { Divider, MenuItem, styled, makeStyles } from '@material-ui/core';
import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { useAsync } from 'react-use';
import { parseEntityRef } from '@backstage/catalog-model';
import Toolbar from '@mui/material/Toolbar';
import Grid from '@mui/material/Grid/Grid';
import Header from '../header/Header';
import { GridSearchIcon } from '@mui/x-data-grid';

type ToolbarProps = React.ComponentProps<typeof Toolbar>;

export const StyledToolbar: React.ComponentType<ToolbarProps> = styled(Toolbar)(
  ({ theme }) => ({
    display: 'flex',
    paddingTop: theme.spacing(1),
    paddingBottom: theme.spacing(2),
    borderBottom: '2px solid #e8ebed',
    backGround: 'white',
    zIndex: 999,
    color: '#aaa',
    justifyContent: 'space-between',
    // Override media queries injected by theme.mixins.toolbar
    '@media all': {
      minHeight: 128,
    },
  }),
);

export const Root = ({
  children,
}: PropsWithChildren<Record<string, unknown>>) => {
  const { t } = useTranslation();

  const identityApi = useApi(identityApiRef);
  const [isExternal, setIsExternal] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();

  useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();
    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setExtOwnershipEntityRefs(extEntityRefs);
    setIsExternal(Boolean(extEntityRefs.length));
  });

  const overlap: React.CSSProperties = {
    position: 'relative',
    background: 'white',
    zIndex: 999,
  };
  const ExternalSidebar = () => (
    <>
      <div style={overlap}>
        <Header />

        <StyledToolbar>
          <Grid display={'flex'} justifyContent={'space-around'}>
            <MenuItem component={NavLink} to="/">
              {t('Home') as string | undefined}
            </MenuItem>

            <MenuItem component={NavLink} to="api-home">
              {'APIs' as string | undefined}
            </MenuItem>
          </Grid>
        </StyledToolbar>
      </div>

      {children}
    </>
  );

  const MainSideBar = () => {
    const useStyles = makeStyles(() => ({
      divider: {
        width: 2,
        background: '#DB271C',
        margin: '8px 0',
      },
    }));
    const classes = useStyles();

    return (
      <>
        <div style={overlap}>
          <Header />

          <StyledToolbar>
            <Grid display="flex" justifyContent="space-around">
              <MenuItem
                component={NavLink}
                to="/search"
                style={{ background: '#f5f5f5' }}
              >
                <GridSearchIcon />
                {t('Search') as string | undefined}
              </MenuItem>
              <MenuItem component={NavLink} to="/">
                {t('Home') as string | undefined}
              </MenuItem>
              <MenuItem
                component={NavLink}
                to="/solutions/grid?filters%5Bkind%5D=mapfresolution"
              >
                {t('Solutions') as string | undefined}
              </MenuItem>
              <MenuItem
                component={NavLink}
                to="catalog/default/refarch/arqref_general/blueprint"
              >
                {t('Architectures') as string | undefined}
              </MenuItem>

              <MenuItem component={NavLink} to="api-home">
                {'APIs' as string | undefined}
              </MenuItem>

              <MenuItem component={NavLink} to="components">
                {t('Components') as string | undefined}
              </MenuItem>

              <MenuItem
                component={NavLink}
                to="catalog/default/refarch/arqref_catalogo"
              >
                {t('Cloud') as string | undefined}
              </MenuItem>

              <MenuItem
                component={NavLink}
                to="/docs/grid?filters%5Bkind%5D=mapfredocument"
              >
                {t('Documentation') as string | undefined}
              </MenuItem>

              <MenuItem
                onClick={function () {
                  window.open('https://zeus.mapfre.com', '_blank');
                }}
              >
                {t('Zeus') as string | undefined}
              </MenuItem>

              <MenuItem
                onClick={function () {
                  window.open(
                    'https://internos.mapfre.com/marketplace-reef/',
                    '_blank',
                  );
                }}
              >
                {t('Reef') as string | undefined}
              </MenuItem>

              <MenuItem component={NavLink} to="/docs/default/component/FAQ">
                {t('Help') as string | undefined}
              </MenuItem>
              <MenuItem
                component={NavLink}
                to="/docs/default/component/CHANGELOG"
              >
                {t('News') as string | undefined}
              </MenuItem>
            </Grid>

            <Grid display="flex">
              <MenuItem
                component={NavLink}
                style={{ color: '#DB271C' }}
                to="my-entities"
              >
                {t('menu.entities')}
              </MenuItem>

              <Divider
                className={classes.divider}
                orientation="vertical"
                flexItem
              />

              <MenuItem
                component={NavLink}
                style={{ color: '#DB271C' }}
                to="templates_v2"
              >
                {t('menu.add_entity')}
              </MenuItem>
            </Grid>
          </StyledToolbar>
        </div>

        {children}
      </>
    );
  };

  return isExternal ? <ExternalSidebar /> : <MainSideBar />;
};
