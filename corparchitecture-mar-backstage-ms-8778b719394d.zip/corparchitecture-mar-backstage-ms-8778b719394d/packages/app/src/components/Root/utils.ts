export async function getSystemDetails(system: string): Promise<string> {
  const url = new URL(
    `/api/admincatalog/themes/${system}`,
    window.location.origin,
  );
  if (url.hostname === 'localhost' && url.port === '3000') url.port = '7007';

  const method = 'GET';

  const request = new Request(url.toString(), {
    method,
  });

  const res = await fetch(request);

  if (!res.ok) {
    throw Error('Cannot retrieve entity catalog-info.yaml');
  }

  return await res.text();
}

export async function getThemeColors(): Promise<string> {
  const url = new URL(`/api/admincatalog/themescolors`, window.location.origin);
  if (url.hostname === 'localhost' && url.port === '3000') url.port = '7007';

  const method = 'GET';

  const request = new Request(url.toString(), {
    method,
  });

  const res = await fetch(request);

  if (!res.ok) {
    throw Error('Cannot retrieve entity catalog-info.yaml');
  }

  return await res.json();
}
