import React, { createContext, useEffect, useState } from 'react';
import { Content, Header, Progress } from '@backstage/core-components';
import {
  EntityKindFilter,
  EntityKindPicker,
  EntityLifecycleFilter,
  EntityTypeFilter,
  EntityTypePicker,
} from '@backstage/plugin-catalog-react';

import { useAsync } from 'react-use';

import {
  EntityListProvider,
  useEntityList,
} from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import { MAREntityFilters } from '../pickers/EntityCountryPicker';
import axios from 'axios';
import Card from '@mui/material/Card';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import { NavLink } from 'react-router-dom';

import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/core/styles';
import { t } from 'i18next';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import {
  Container,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
} from '@material-ui/core';
import { Entity } from '@backstage/catalog-model';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useApi } from '@backstage/core-plugin-api';
import { ContentHeader } from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityOwnerPicker,
  EntityTagPicker,
  UserListPicker,
  EntityListProvider as EntityListProvider1,
} from '@backstage/plugin-catalog-react';
import {
  TechDocsPageWrapper,
  TechDocsPicker,
} from '@backstage/plugin-techdocs';
import { EntityListDocsTable } from '@backstage/plugin-techdocs';

export const EntityContext = createContext('');
export const SolutionDocsHome = () => {
  const useStyles = makeStyles(theme => ({
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 32%)',

      marginLeft: 1,
      marginTop: 5,
    },
    gridauto: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, 300px)',
      marginLeft: 1,
      marginTop: 5,
    },
    header: {
      color: 'white',
    },
    box: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      display: '-webkit-box',
      '-webkit-line-clamp': 10,
      '-webkit-box-orient': 'vertical',
      paddingBottom: '0.8em',
    },
    label: {
      color: theme.palette.text.secondary,
      textTransform: 'uppercase',
      fontSize: '0.65rem',
      fontWeight: 'bold',
      letterSpacing: 0.5,
      lineHeight: 1,
      paddingBottom: '0.2rem',
    },
    entity: {
      textTransform: 'uppercase',
      padding: 8,
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    containerStyle: { width: '80%', height: '100vh', marginLeft: 20 },
    searchBarRoot: {
      padding: '8px 16px',
      background: theme.palette.background.paper,
      boxShadow: theme.shadows[1],
      borderRadius: '50px',
    },
    searchBarOutline: {
      borderStyle: 'none',
    },
  }));

  const [tempSignedUrls, setTempSignedUrls] = useState<string[]>([]);
  const [signedUrls, setSignedUrls] = useState<string[]>([]);
  const [contextEntities, setcontextEntities] = useState<Entity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const catalogApi = useApi(catalogApiRef);

  const context = useEntityList<MAREntityFilters>();

  useEffect(() => {
    const signedUrlsArray: string[] = [];
    if (context.entities.length > 0) {
      const fetchSignedUrls = async () => {
        for (const entity of context.entities) {
          const kind = entity.kind.toLowerCase();

          try {
            if (entity.metadata.annotations?.header_icon) {
              const baseUrl = new URL(
                `api/s3-images`,
                window.location.origin.replace('3000', '7007'),
              );
              const response = await axios.get(
                `${baseUrl}/${kind}/${entity.metadata.name}/${entity.metadata.annotations?.header_icon}?kind=${kind}`,
              );
              signedUrlsArray.push(response.data.signedUrl);
            } else {
              signedUrlsArray.push('');
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            signedUrlsArray.push('');
          }
        }
        setTempSignedUrls(signedUrlsArray);
        setSignedUrls(signedUrlsArray);
      };

      fetchSignedUrls();

      setcontextEntities(context.entities);
    }
  }, [context.entities]);

  const { loading } = useAsync(async () => {
    context.updateFilters({
      kind: new EntityKindFilter('mapfresolution'),
      lifecycles: undefined,
      type: undefined,
    });
  });

  const handleSearchChange = (event: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchQuery(event.target.value);
    searchChange(event.target.value as string);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchChange('');
  };

  function searchChange(value: string): void {
    if (context.entities && context.entities.length > 0) {
      if (value) {
        const entities: Entity[] = [];
        const urls: string[] = [];
        for (let i = 0; i < context.entities.length; i++) {
          if (
            context.entities[i] &&
            (context.entities[i].metadata.title
              ?.toLowerCase()
              .includes(value.toLowerCase()) ||
              context.entities[i].metadata.description
                ?.toLowerCase()
                .includes(value.toLowerCase()))
          ) {
            entities.push(context.entities[i]);
            urls.push(tempSignedUrls[i]);
          }
        }
        setSignedUrls(urls);
        setcontextEntities(entities);
      } else {
        setcontextEntities(context.entities);
        setSignedUrls(tempSignedUrls);
      }
    }
  }

  return (
    <EntityListProvider>
      {loading ? (
        <Progress />
      ) : (
        <>
          <Header title={t('Solutions')} />

          <Content>
            <Container>
              <TextField
                variant="outlined"
                placeholder={'Search'}
                value={searchQuery}
                onChange={handleSearchChange}
                margin="dense"
                style={{
                  width: '100%',
                  justifyContent: 'center',
                  marginBottom: '5%',
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      {searchQuery && (
                        <IconButton
                          edge="end"
                          onClick={handleClearSearch}
                          size="medium"
                        >
                          <ClearIcon />
                        </IconButton>
                      )}
                      <IconButton edge="end" size="medium">
                        <SearchIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                  // @ts-ignore
                  sx: {
                    borderRadius: '20px', // Adjust the value as per your preference
                  },
                }}
              />
              <Grid container spacing={2}>
                {contextEntities.map((entity, index) => (
                  <Grid item xs={4} key={index}>
                    <Card
                      key={index}
                      style={{
                        maxWidth: 400,
                        height: '100%',
                      }}
                    >
                      <CardMedia
                        key={index}
                        component="img"
                        alt={'image'}
                        height="30%"
                        image={
                          signedUrls[index]
                            ? signedUrls[index]
                            : '/documentationLogo.png'
                        }
                      />

                      <CardContent
                        style={{
                          height: '60%',
                        }}
                      >
                        <Typography
                          gutterBottom
                          variant="h5"
                          component="div"
                          color="textPrimary"
                        >
                          {entity?.metadata?.title}
                        </Typography>
                        <Typography display="initial" color="textSecondary">
                          {entity?.metadata?.description}
                        </Typography>
                      </CardContent>
                      <Box
                        style={{
                          height: '10%',
                        }}
                      >
                        <CardActions>
                          <NavLink
                            to={`/catalog/default/${entity.kind.toLocaleLowerCase()}/${
                              entity.metadata.name
                            }`}
                            style={{ color: 'red' }}
                          >
                            {t('View')} {'>'}
                          </NavLink>
                        </CardActions>
                      </Box>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Container>
          </Content>
        </>
      )}
    </EntityListProvider>
  );
};

export const TechDocsLegacyHome = () => {
  return (
    <TechDocsPageWrapper>
      <Content>
        <ContentHeader title="" />
        <EntityListProvider1>
          <CatalogFilterLayout>
            <CatalogFilterLayout.Filters>
              <TechDocsPicker />
              <EntityKindPicker
                allowedKinds={[
                  'component',
                  'mapfredocument',
                  'refarch',
                  'resource',
                ]}
              />
              <EntityTypePicker />
              <UserListPicker initialFilter="owned" />
              <EntityOwnerPicker />
              <EntityTagPicker />
            </CatalogFilterLayout.Filters>
            <CatalogFilterLayout.Content>
              <EntityListDocsTable />
            </CatalogFilterLayout.Content>
          </CatalogFilterLayout>
        </EntityListProvider1>
      </Content>
    </TechDocsPageWrapper>
  );
};
