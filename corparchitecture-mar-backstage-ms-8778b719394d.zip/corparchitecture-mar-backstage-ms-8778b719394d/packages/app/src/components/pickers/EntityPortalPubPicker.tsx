import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityPortalPubFilter } from '../filters/EntityPortalPubFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isTagAvailable,
} from './nestedFilters';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';

/** @public */
export type CatalogReactEntityPortalPubPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityPortalPubPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntityPortalPubPicker = (props: { initialFilter?: string[] }) => {
  const { initialFilter = [] } = props;
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { portal_pub: portalPubParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamPortalPubs = useMemo(
    () => [portalPubParameter].flat().filter(Boolean) as string[],
    [portalPubParameter],
  );

  const [selectedPortalPubs, setSelectedPortalPubs] = useState(
    queryParamPortalPubs.length
      ? queryParamPortalPubs
      : filters.portal_pub?.values ?? initialFilter,
  );

  const { t } = useTranslation();

  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamPortalPubs.length) {
      setSelectedPortalPubs(queryParamPortalPubs);
    }
  }, [queryParamPortalPubs]);

  const availablePortalPubs = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isOwnerAvailable(filters.owners, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e)
              );
            })
            .flatMap(
              (e: Entity) =>
                (e.metadata?.serviceAvailability as Record<string, string>)?.[
                  'mapfre.com/portal_pub'
                ],
            )
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );

  useEffect(() => {
    updateFilters({
      portal_pub: selectedPortalPubs.length
        ? new EntityPortalPubFilter(selectedPortalPubs)
        : undefined,
    });
  }, [selectedPortalPubs, updateFilters]);

  if (availablePortalPubs.length < 2 && !selectedPortalPubs.length) return null;

  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Publish in portal')}
        <Autocomplete
          multiple
          options={availablePortalPubs}
          value={selectedPortalPubs}
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedPortalPubs(value as string[])
          }
          renderOption={(option: React.ReactNode, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="portal-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
