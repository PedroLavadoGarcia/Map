import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityBusinessLineFilter } from '../filters/EntityBusinessLineFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isTagAvailable,
  isTypologyAvailable,
  isBusinessEntityAvailable,
} from './nestedFilters';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
/** @public */
export type CatalogReactEntityBusinessLinePickerClassKey = 'input';
const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityBusinessLinePicker',
  },
);
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
/** @public */
export const EntityBusinessLinePicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { businessLine: businessLineParameter },
  } = useEntityList<MAREntityFilters>();
  const { t } = useTranslation();
  const refStrings: Record<string, unknown> = {
    Cross: t('Cross'),
    'Health::Health Care': t('Health Care'),
    'Health::Medical Centers': t('Medical Centers'),
    'Health::Other': t('Health - Other'),
    'NoLife::Bicycles and cyclists': t('Bicycles and cyclists'),
    'NoLife::Business': t('Business'),
    'NoLife::Home Insurance': t('Home Insurance'),
    'NoLife::Legal Defense': t('Legal Defense'),
    'NoLife::Pets': t('Pets'),
    'NoLife::Accidents': t('Accidents'),
    'NoLife::Autos': t('Auto'),
    'NoLife::Community': t('Community'),
    'NoLife::Deaths': t('Deaths'),
    'NoLife::Property and Contingency': t('Property and Contingency'),
    'NoLife::Rural': t('Rural'),
    'NoLife::Umbrella': t('Umbrella'),
    'NoLife::Other': t('NoLife - Other'),
    'NoLife::Travel': t('Travel'),
    'Life::Savings': t('Savings'),
    'Life::Risk': t('Risk'),
    'Life::Other': t('Life - Other'),
  };
  const queryParamBusinessLine = useMemo(
    () => [businessLineParameter].flat().filter(Boolean) as string[],
    [businessLineParameter],
  );
  const [selectedBusinessLine, setSelectedBusinessLine] = useState(
    queryParamBusinessLine.length
      ? queryParamBusinessLine
      : filters.businessLine?.values ?? [],
  );
  // Set selected businessLine on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamBusinessLine.length) {
      setSelectedBusinessLine(queryParamBusinessLine);
    }
  }, [queryParamBusinessLine]);
  const availableBusinessLine = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isOwnerAvailable(filters.owners, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isBusinessEntityAvailable(filters.businessEntity, e) &&
                isTagAvailable(filters.tags, e)
              );
            })
            .flatMap(
              (e: Entity) =>
                e.metadata?.['mapfre.com/business_line'] as string[],
            )
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );
  useEffect(() => {
    updateFilters({
      businessLine: selectedBusinessLine.length
        ? new EntityBusinessLineFilter(selectedBusinessLine)
        : undefined,
    });
  }, [selectedBusinessLine, updateFilters]);
  if (availableBusinessLine.length < 2 && !selectedBusinessLine.length)
    return null;
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Business Line')}
        <Autocomplete
          multiple
          options={availableBusinessLine as React.ReactNode[]}
          value={selectedBusinessLine}
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedBusinessLine(value as string[])
          }
          renderOption={(option: React.ReactNode, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={refStrings[option as string] as React.ReactNode}
            />
          )}
          size="small"
          popupIcon={
            <ExpandMoreIcon data-testid="businessLine-picker-expand" />
          }
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
