import { Entity } from '@backstage/catalog-model';
import { EntityTypeFilter } from '@backstage/plugin-catalog-react';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useMemo, useState } from 'react';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isSubTypologyAvailable,
  isTagAvailable,
  isTypologyAvailable,
} from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';
/** @public */
export type CatalogReactEntityTypePickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityTypePicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntityTypePicker = (props: { initialFilter?: string[] }) => {
  const { initialFilter = [] } = props;
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { type: typeParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamType = useMemo(
    () => [typeParameter].flat().filter(Boolean) as string[],
    [typeParameter],
  );

  const [selectedType, setSelectedType] = useState(
    queryParamType.length
      ? queryParamType
      : (filters.type?.value as string[]) ?? [],
  );

  // Set selected types on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamType.length) {
      setSelectedType(queryParamType);
    }
  }, [queryParamType]);

  const availableType = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isOwnerAvailable(filters.owners, e) &&
                isCountryAvailable(filters.country, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isSubTypologyAvailable(filters.country, e) &&
                isLifecycleAvailable(filters.owners, e) &&
                isTagAvailable(filters.tags, e)
              );
            })
            .map((e: Entity) => e.spec?.type)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );

  useEffect(() => {
    updateFilters({
      type: selectedType.length
        ? new EntityTypeFilter(selectedType)
        : undefined,
    });
  }, [selectedType, updateFilters]);

  if (availableType.length < 2 && !selectedType.length) return null;

  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        Type
        <Autocomplete
          multiple
          disableCloseOnSelect
          options={availableType}
          value={selectedType}
          onChange={(_: object, value: string[]) => setSelectedType(value)}
          renderOption={(option, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              onClick={event => event.preventDefault()}
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="type-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
