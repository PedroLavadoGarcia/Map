import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntitySubTypologyFilter } from '../../filters/EntitySubTypologyFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isTagAvailable,
  isTypeAvailable,
  isTypologyAvailable,
} from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';

/** @public */
export type CatalogReactEntitySubTypologyPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntitySubTypologyPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntitySubTypologyPicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { subtypology: subtypologyParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamSubTypologies = useMemo(
    () => [subtypologyParameter].flat().filter(Boolean) as string[],
    [subtypologyParameter],
  );

  const [selectedSubTypologies, setSelectedSubTypologies] = useState(
    queryParamSubTypologies.length
      ? queryParamSubTypologies
      : filters.subtypology?.values ?? [],
  );

  const { t } = useTranslation();

  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamSubTypologies.length) {
      setSelectedSubTypologies(queryParamSubTypologies);
    }
  }, [queryParamSubTypologies]);
  //get entities that are being displayed
  const availableSubTypologies = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isOwnerAvailable(filters.owners, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e) &&
                isTypeAvailable(filters.tags, e)
              );
            })
            .flatMap((e: Entity) => e.metadata.subtypology)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
    // , filters
  );

  useEffect(() => {
    updateFilters({
      subtypology: selectedSubTypologies.length
        ? new EntitySubTypologyFilter(selectedSubTypologies)
        : undefined,
    });
  }, [selectedSubTypologies, updateFilters]);

  if (availableSubTypologies.length < 2 && !selectedSubTypologies.length)
    return null;
  // < 2 && !selectedTypologies.length
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Sub Typology')}
        <Autocomplete
          multiple
          options={availableSubTypologies}
          value={selectedSubTypologies}
          onChange={(_: object, value: string[]) =>
            setSelectedSubTypologies(value)
          }
          renderOption={(option, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="subtypology-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
