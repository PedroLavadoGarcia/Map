import { Select, SelectItem } from '@backstage/core-components';
import { Box } from '@material-ui/core';
import React, { useEffect, useMemo, useState } from 'react';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';
import { EntityKindFilter } from '@backstage/plugin-catalog-react';

function useEntityKindFilter(opts: { initialFilter: string }): {
  allKinds: string[];
  selectedKind: string;
  setSelectedKind: (kind: string) => void;
} {
  const {
    filters,
    queryParameters: { kind: kindParameter },
    updateFilters,
  } = useEntityList();

  const queryParamKind = useMemo(
    () => [kindParameter].flat()[0],
    [kindParameter],
  );

  const [selectedKind, setSelectedKind] = useState(
    queryParamKind ?? filters.kind?.value ?? opts.initialFilter,
  );

  // Set selected kinds on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamKind) {
      setSelectedKind(queryParamKind);
    }
  }, [queryParamKind]);

  // Set selected kind from filters; this happens when the kind filter is
  // updated from another component
  useEffect(() => {
    if (filters.kind?.value) {
      setSelectedKind(filters.kind?.value);
    }
  }, [filters.kind]);

  useEffect(() => {
    updateFilters({
      kind: selectedKind ? new EntityKindFilter(selectedKind) : undefined,
    });
  }, [selectedKind, updateFilters]);

  return {
    allKinds: [],
    selectedKind,
    setSelectedKind,
  };
}

/**
 * Props for {@link EntityKindPicker}.
 *
 * @public
 */
export interface EntityKindPickerProps {
  /**
   * Entity kinds to show in the dropdown; by default all kinds are fetched from the catalog and
   * displayed.
   */
  allowedKinds?: string[];
  initialFilter?: string;
  hidden?: boolean;
}

/** @public */
export const EntityKindPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'component' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['component' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
