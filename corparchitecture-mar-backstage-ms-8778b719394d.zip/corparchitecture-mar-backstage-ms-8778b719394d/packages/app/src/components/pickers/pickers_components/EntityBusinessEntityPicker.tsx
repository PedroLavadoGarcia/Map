import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityBusinessEntityFilter } from '../../filters/EntityBusinessEntityFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import { isTagAvailable } from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';
/** @public */
export type CatalogReactEntityBusinessEntityPickerClassKey = 'input';
const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityBusinessEntityPicker',
  },
);
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
/** @public */
export const EntityBusinessEntityPicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { businessEntity: businessEntityParameter },
  } = useEntityList<MAREntityFilters>();
  const queryParamBusinessEntity = useMemo(
    () => [businessEntityParameter].flat().filter(Boolean) as string[],
    [businessEntityParameter],
  );
  const [selectedBusinessEntity, setSelectedBusinessEntity] = useState(
    queryParamBusinessEntity.length
      ? queryParamBusinessEntity
      : filters.businessEntity?.values ?? [],
  );
  const { t } = useTranslation();
  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamBusinessEntity.length) {
      setSelectedBusinessEntity(queryParamBusinessEntity);
    }
  }, [queryParamBusinessEntity]);
  const availableBusinessEntity = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return isTagAvailable(filters.tags, e);
            })
            .flatMap((e: Entity) => e.metadata.businessEntity)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
    // , filters
  );
  useEffect(() => {
    updateFilters({
      businessEntity: selectedBusinessEntity.length
        ? new EntityBusinessEntityFilter(selectedBusinessEntity)
        : undefined,
    });
  }, [selectedBusinessEntity, updateFilters]);
  if (availableBusinessEntity.length < 2 && !selectedBusinessEntity.length)
    return null;
  const isBusinessEntitySelected = selectedBusinessEntity.length > 0;
  if (availableBusinessEntity.length > 1 && isBusinessEntitySelected)
    return null;
  // < 2 && !selectedBusinessEntity.length
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Business Entity')}
        <Autocomplete
          multiple
          options={availableBusinessEntity}
          value={selectedBusinessEntity}
          onChange={(_: object, value: string[]) =>
            setSelectedBusinessEntity(value)
          }
          renderOption={(option, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={
            <ExpandMoreIcon data-testid="businessEntity-picker-expand" />
          }
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
