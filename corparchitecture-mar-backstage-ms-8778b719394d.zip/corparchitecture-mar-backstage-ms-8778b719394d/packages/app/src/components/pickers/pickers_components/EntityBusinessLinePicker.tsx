import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityBusinessLineFilter } from '../../filters/EntityBusinessLineFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import { isTagAvailable } from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';
/** @public */
export type CatalogReactEntityBusinessLinePickerClassKey = 'input';
const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityBusinessLinePicker',
  },
);
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
/** @public */
export const EntityBusinessLinePicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { businessLine: businessLineParameter },
  } = useEntityList<MAREntityFilters>();
  const queryParamBusinessLine = useMemo(
    () => [businessLineParameter].flat().filter(Boolean) as string[],
    [businessLineParameter],
  );
  const [selectedBusinessLine, setSelectedBusinessLine] = useState(
    queryParamBusinessLine.length
      ? queryParamBusinessLine
      : filters.businessLine?.values ?? [],
  );
  const { t } = useTranslation();
  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamBusinessLine.length) {
      setSelectedBusinessLine(queryParamBusinessLine);
    }
  }, [queryParamBusinessLine]);
  const availableBusinessLine = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return isTagAvailable(filters.tags, e);
            })
            .flatMap((e: Entity) => e.metadata.businessLine)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
    // , filters
  );
  useEffect(() => {
    updateFilters({
      businessLine: selectedBusinessLine.length
        ? new EntityBusinessLineFilter(selectedBusinessLine)
        : undefined,
    });
  }, [selectedBusinessLine, updateFilters]);
  if (availableBusinessLine.length < 2 && !selectedBusinessLine.length)
    return null;
  const isBusinessLineSelected = selectedBusinessLine.length > 0;
  if (availableBusinessLine.length > 1 && isBusinessLineSelected) return null;
  // < 2 && !selectedBusinessLine.length
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Business Line')}
        <Autocomplete
          multiple
          options={availableBusinessLine}
          value={selectedBusinessLine}
          onChange={(_: object, value: string[]) =>
            setSelectedBusinessLine(value)
          }
          renderOption={(option, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={
            <ExpandMoreIcon data-testid="businessLine-picker-expand" />
          }
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
