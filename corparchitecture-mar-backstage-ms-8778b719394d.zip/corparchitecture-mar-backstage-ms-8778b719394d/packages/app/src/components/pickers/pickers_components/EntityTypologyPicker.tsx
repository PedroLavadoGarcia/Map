import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityTypologyFilter } from '../../filters/EntityTypologyFilter';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isSubTypologyAvailable,
  isTagAvailable,
  isTypeAvailable,
} from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';

/** @public */
export type CatalogReactEntityTypologyPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityTypologyPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntityTypologyPicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { typology: typologyParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamTypologies = useMemo(
    () => [typologyParameter].flat().filter(Boolean) as string[],
    [typologyParameter],
  );

  const [selectedTypologies, setSelectedTypologies] = useState(
    queryParamTypologies.length
      ? queryParamTypologies
      : filters.typology?.values ?? [],
  );

  const { t } = useTranslation();

  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamTypologies.length) {
      setSelectedTypologies(queryParamTypologies);
    }
  }, [queryParamTypologies]);

  const availableTypologies = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isOwnerAvailable(filters.owners, e) &&
                isSubTypologyAvailable(filters.subtypology, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e) &&
                isTypeAvailable(filters.tags, e)
              );
            })
            .flatMap((e: Entity) => e.metadata.typology)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
    // , filters
  );

  useEffect(() => {
    updateFilters({
      typology: selectedTypologies.length
        ? new EntityTypologyFilter(selectedTypologies)
        : undefined,
    });
  }, [selectedTypologies, updateFilters]);

  if (availableTypologies.length < 2 && !selectedTypologies.length) return null;

  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Typology')}
        <Autocomplete
          multiple
          options={availableTypologies}
          value={selectedTypologies}
          onChange={(_: object, value: string[]) =>
            setSelectedTypologies(value)
          }
          renderOption={(option, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="typology-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
