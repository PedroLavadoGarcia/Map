import { Entity } from '@backstage/catalog-model';
import {
  DefaultEntityFilters,
  EntityTagFilter,
} from '@backstage/plugin-catalog-react';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityCountryFilter } from '../../filters/EntityCountryFilter';
import { EntitySystemFilter } from '../../filters/EntitySystemFilter';
import { EntityTypologyFilter } from '../../filters/EntityTypologyFilter';
import { EntitySubTypologyFilter } from '../../filters/EntitySubTypologyFilter';
import { EntityOwnerFilter } from '../../filters/EntityOwnerFilter';
import { EntityBusinessLineFilter } from '../../filters/EntityBusinessLineFilter';
import { EntityBusinessEntityFilter } from '../../filters/EntityBusinessEntityFilter';
import {
  isLifecycleAvailable,
  isOwnerAvailable,
  isTagAvailable,
  isTypologyAvailable,
  isSubTypologyAvailable,
  isBusinessLineAvailable,
  isBusinessEntityAvailable,
  isTypeAvailable,
} from './nestedFilters';
import { useEntityList } from '../../catalog/ComponentCatalog/CatalogTable/hooks/useEntityListProvider';

/** @public */
export type CatalogReactEntityCountryPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityCountryPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export interface MAREntityFilters extends DefaultEntityFilters {
  country?: EntityCountryFilter;
  system?: EntitySystemFilter;
  typology?: EntityTypologyFilter;
  subtypology?: EntitySubTypologyFilter;
  owner?: EntityOwnerFilter;
  tags?: EntityTagFilter;
  businessLine?: EntityBusinessLineFilter;
  businessEntity?: EntityBusinessEntityFilter;
}

/** @public */
export const EntityCountryPicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { country: countryParameter },
  } = useEntityList<MAREntityFilters>();
  const { t } = useTranslation();

  const refStrings: Record<string, unknown> = {
    ARG: t('Argentina'),
    BRA: t('Brasil'),
    CHL: t('Chile'),
    COL: t('Colombia'),
    CRI: t('Costa Rica'),
    DEU: t('Germany'),
    DOM: t('Dominican Republic'),
    ECU: t('Ecuador'),
    ESP: t('Spain'),
    ITA: t('Italy'),
    MEX: t('Mexico'),
    MLT: t('Malta'),
    PAN: t('Panama'),
    PER: t('Peru'),
    PRI: t('Puerto Rico'),
    PRY: t('Paraguay'),
    TUR: t('Turkey'),
    URY: t('Uruguay'),
    USA: t('United States of America'),
    VEN: t('Venezuela'),
    ASIS: t('Mawdy'),
    DIG: t('Digital'),
    INV: t('Investment'),
    RE: t('Re'),
    GLOBAL: t('Global'),
    SOL: t('Solunion'),
    TRON: t('Tron'),
    CAN: t('Canada'),
    PHL: t('Philippines'),
    GTM: t('Guatemala'),
    SLV: t('El Salvador'),
    HND: t('Honduras'),
    NIC: t('Nicaragua'),
    SGP: t('Singapore'),
    DZA: t('Algeria'),
    MYS: t('Malaysia'),
    JPN: t('Japan'),
    TUN: t('Tunez'),
    CHN: t('China'),
    BEL: t('Belgium'),
    HUN: t('Hungary'),
    IRL: t('Ireland'),
    GBR: t('United Kingdom'),
  };

  const queryParamCountries = useMemo(
    () => [countryParameter].flat().filter(Boolean) as string[],
    [countryParameter],
  );

  const [selectedCountries, setSelectedCountries] = useState(
    queryParamCountries.length
      ? queryParamCountries
      : filters.country?.values ?? [],
  );

  // Set selected country on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamCountries.length) {
      setSelectedCountries(queryParamCountries);
    }
  }, [queryParamCountries]);

  const availableCountries = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isOwnerAvailable(filters.owners, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isSubTypologyAvailable(filters.subtypology, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e) &&
                isTypeAvailable(filters.tags, e) &&
                isBusinessLineAvailable(filters.businessLine, e) &&
                isBusinessEntityAvailable(filters.businessEntity, e)
              );
            })
            .flatMap((e: Entity) => e.metadata.country)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );

  useEffect(() => {
    updateFilters({
      country: selectedCountries.length
        ? new EntityCountryFilter(selectedCountries)
        : undefined,
    });
  }, [selectedCountries, updateFilters]);

  if (availableCountries.length < 2 && !selectedCountries.length) return null; // < 2 && !selectedCountries.length
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Country')}
        <Autocomplete
          multiple
          options={availableCountries as React.ReactNode[]}
          value={selectedCountries}
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedCountries(value as string[])
          }
          renderOption={(option: React.ReactNode, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={refStrings[option as string] as React.ReactNode}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="country-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
