import { Entity } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isOwnerAvailable,
  isTypologyAvailable,
  isTagAvailable,
} from './nestedFilters';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import { EntitySystemFilter } from '../filters/EntitySystemFilter';

/** @public */
export type CatalogReactEntitySystemPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntitySystemPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntitySystemPicker = (props: { initialFilter?: string[] }) => {
  const { initialFilter = [] } = props;
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { system: systemParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamSystems = useMemo(
    () => [systemParameter].flat().filter(Boolean) as string[],
    [systemParameter],
  );

  const [selectedSystems, setSelectedSystems] = useState(
    queryParamSystems.length
      ? queryParamSystems
      : filters.system?.values ?? initialFilter,
  );

  const { t } = useTranslation();

  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamSystems.length) {
      setSelectedSystems(queryParamSystems);
    }
  }, [queryParamSystems]);

  const availableSystems = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isOwnerAvailable(filters.owners, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e) &&
                isTypologyAvailable(filters.typology, e)
              );
            })
            .flatMap((e: Entity) => e.spec?.system)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );

  useEffect(() => {
    updateFilters({
      system: selectedSystems.length
        ? new EntitySystemFilter(selectedSystems)
        : undefined,
    });
  }, [selectedSystems, updateFilters]);

  if (availableSystems.length < 2 && !selectedSystems.length) return null;

  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Organization')}
        <Autocomplete
          multiple
          options={availableSystems}
          value={selectedSystems}
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedSystems(value as string[])
          }
          renderOption={(option: React.ReactNode, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="system-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
