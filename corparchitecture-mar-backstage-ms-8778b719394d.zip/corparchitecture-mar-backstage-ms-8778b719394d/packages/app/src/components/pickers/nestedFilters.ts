import {
  EntityLifecycleFilter,
  EntityOwnerFilter,
  EntityTagFilter,
} from '@backstage/plugin-catalog-react';
import { MapfreApiEntityV1alpha1 } from '../../interfaces/MapfreApiEntityV1alpha1';
import { EntityCountryFilter } from '../filters/EntityCountryFilter';
import { Entity } from '@backstage/catalog-model';
import { EntityTypologyFilter } from '../filters/EntityTypologyFilter';
import { EntitySystemFilter } from '../filters/EntitySystemFilter';
import { EntityBusinessEntityFilter } from '../filters/EntityBusinessEntityFilter';
import { EntityBusinessLineFilter } from '../filters/EntityBusinessLineFilter';

function isCountryAvailable(
  countryFilter: EntityCountryFilter | undefined,
  e: Entity,
) {
  if (!countryFilter) {
    return true;
  }

  return countryFilter.values.includes(
    (e as MapfreApiEntityV1alpha1).metadata.country,
  );
}

function isOwnerAvailable(
  ownerFilter: EntityOwnerFilter | undefined,
  e: Entity,
) {
  if (!ownerFilter) {
    return true;
  }

  return Array.isArray(e.spec?.owner)
    ? (e.spec?.owner as string[])?.some(owner => {
        return ownerFilter?.values.includes(owner);
      })
    : ownerFilter?.values.includes((e as MapfreApiEntityV1alpha1).spec.owner);
}

function isLifecycleAvailable(
  lifecycleFilter: EntityLifecycleFilter | undefined,
  e: Entity,
) {
  if (!lifecycleFilter) {
    return true;
  }

  return lifecycleFilter.values.includes(
    (e as MapfreApiEntityV1alpha1).spec.lifecycle,
  );
}

function isTypologyAvailable(
  typologyFilter: EntityTypologyFilter | undefined,
  e: Entity,
) {
  if (!typologyFilter) {
    return true;
  }

  return typologyFilter.values.includes(
    (e as MapfreApiEntityV1alpha1).metadata.typology,
  );
}

function isTagAvailable(tagFilter: EntityTagFilter | undefined, e: Entity) {
  if (!tagFilter) {
    return true;
  }

  return e.metadata.tags?.some(tag => {
    return tagFilter?.values.includes(tag);
  });
}

function isSystemAvailable(
  systemFilter: EntitySystemFilter | undefined,
  e: Entity,
) {
  if (!systemFilter) {
    return true;
  }

  return systemFilter.values.includes(
    (e as MapfreApiEntityV1alpha1).spec.system,
  );
}

function isBusinessEntityAvailable(
  businessEntityFilter: EntityBusinessEntityFilter | undefined,
  e: Entity,
) {
  if (!businessEntityFilter) {
    return true;
  }
  return businessEntityFilter.values.includes(
    (e as MapfreApiEntityV1alpha1).metadata?.[
      'mapfre.com/businessEntity'
    ] as string,
  );
}
function isBusinessLineAvailable(
  businessLineFilter: EntityBusinessLineFilter | undefined,
  e: Entity,
) {
  if (!businessLineFilter) {
    return true;
  }
  const businessLine = (e as MapfreApiEntityV1alpha1).metadata?.[
    'mapfre.com/business_line'
  ];
  return Array.isArray(businessLine)
    ? (businessLine as string[])?.some(bLine => {
        return businessLineFilter?.values.includes(bLine);
      })
    : businessLineFilter?.values.includes(businessLine as string);
}

export {
  isCountryAvailable,
  isOwnerAvailable,
  isLifecycleAvailable,
  isTypologyAvailable,
  isTagAvailable,
  isSystemAvailable,
  isBusinessEntityAvailable,
  isBusinessLineAvailable,
};
