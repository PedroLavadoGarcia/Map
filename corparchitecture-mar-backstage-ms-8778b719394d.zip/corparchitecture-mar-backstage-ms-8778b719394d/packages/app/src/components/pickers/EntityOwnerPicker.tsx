import { Entity, RELATION_OWNED_BY } from '@backstage/catalog-model';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  EntityOwnerFilter,
  getEntityRelations,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import { MAREntityFilters } from './EntityCountryPicker';
import {
  isCountryAvailable,
  isLifecycleAvailable,
  isSystemAvailable,
  isTagAvailable,
  isTypologyAvailable,
} from './nestedFilters';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import { isTypeAvailable } from './pickers_components/nestedFilters';

/** @public */
export type CatalogReactEntityOwnerPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityOwnerPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

/** @public */
export const EntityOwnerPicker = () => {
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { owners: ownersParameter },
  } = useEntityList<MAREntityFilters>();

  const queryParamOwners = useMemo(
    () => [ownersParameter].flat().filter(Boolean) as string[],
    [ownersParameter],
  );

  const [selectedOwners, setSelectedOwners] = useState(
    queryParamOwners.length ? queryParamOwners : filters.owners?.values ?? [],
  );

  // Set selected owners on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamOwners.length) {
      setSelectedOwners(queryParamOwners);
    }
  }, [queryParamOwners]);

  const availableOwners = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isCountryAvailable(filters.country, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTypeAvailable(filters.typeDoc, e) &&
                isTagAvailable(filters.tags, e) &&
                isSystemAvailable(filters.system, e)
              );
            })
            .flatMap((e: Entity) =>
              getEntityRelations(e, RELATION_OWNED_BY).map(o =>
                humanizeEntityRef(o, { defaultKind: 'group' }),
              ),
            )
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );
  const { t } = useTranslation();

  useEffect(() => {
    updateFilters({
      owners: selectedOwners.length
        ? new EntityOwnerFilter(selectedOwners)
        : undefined,
    });
  }, [selectedOwners, updateFilters]);

  if (availableOwners.length < 2 && !selectedOwners.length) return null;

  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Owner')}
        <Autocomplete
          multiple
          disableCloseOnSelect
          options={availableOwners}
          value={selectedOwners}
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedOwners(value as string[])
          }
          renderOption={(option: React.ReactNode, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              onClick={event => event.preventDefault()}
              label={option}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="owner-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
