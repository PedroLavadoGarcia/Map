import { Entity } from '@backstage/catalog-model';
import { DefaultEntityFilters } from '@backstage/plugin-catalog-react';
import {
  Box,
  Checkbox,
  FormControlLabel,
  makeStyles,
  TextField,
  Typography,
} from '@material-ui/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Autocomplete } from '@material-ui/lab';
import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityCountryFilter } from '../filters/EntityCountryFilter';
import { EntitySystemFilter } from '../filters/EntitySystemFilter';
import { EntityTypologyFilter } from '../filters/EntityTypologyFilter';
import { EntityPortalPubFilter } from '../filters/EntityPortalPubFilter';
import { EntityBusinessLineFilter } from '../filters/EntityBusinessLineFilter';
import { EntityBusinessEntityFilter } from '../filters/EntityBusinessEntityFilter';
import {
  isLifecycleAvailable,
  isOwnerAvailable,
  isSystemAvailable,
  isTagAvailable,
  isTypologyAvailable,
  isBusinessLineAvailable,
  isBusinessEntityAvailable,
} from './nestedFilters';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';
import { EntityOwnerFilter } from '../filters/EntityOwnerFilter';
import { EntityLiablePeopleFilter } from '../filters/EntityLiablePeopleFilter';
import { EntityTypeDocFilter } from '../filters/EntityTypeDocFilter';

/** @public */
export type CatalogReactEntityCountryPickerClassKey = 'input';

const useStyles = makeStyles(
  {
    input: {},
  },
  {
    name: 'CatalogReactEntityCountryPicker',
  },
);

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export interface MAREntityFilters extends DefaultEntityFilters {
  country?: EntityCountryFilter;
  system?: EntitySystemFilter;
  typology?: EntityTypologyFilter;
  portal_pub?: EntityPortalPubFilter;
  owners?: EntityOwnerFilter;
  liablePeople?: EntityLiablePeopleFilter;
  businessLine?: EntityBusinessLineFilter;
  businessEntity?: EntityBusinessEntityFilter;
  typeDoc?: EntityTypeDocFilter;
}

/** @public */
export const EntityCountryPicker = (props: { initialFilter?: string[] }) => {
  const { initialFilter = [] } = props;
  const classes = useStyles();
  const {
    updateFilters,
    backendEntities,
    filters,
    queryParameters: { country: countryParameter },
  } = useEntityList<MAREntityFilters>();
  const { t } = useTranslation();

  const queryParamCountries = useMemo(
    () => [countryParameter].flat().filter(Boolean) as string[],
    [countryParameter],
  );

  const [selectedCountries, setSelectedCountries] = useState(
    queryParamCountries.length
      ? queryParamCountries
      : filters.country?.values ?? initialFilter,
  );

  // Set selected country on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamCountries.length) {
      setSelectedCountries(queryParamCountries);
    }
  }, [queryParamCountries]);

  const availableCountries = useMemo(
    () =>
      [
        ...new Set(
          backendEntities
            .filter((e: Entity) => {
              return (
                isOwnerAvailable(filters.owners, e) &&
                isTypologyAvailable(filters.typology, e) &&
                isLifecycleAvailable(filters.lifecycles, e) &&
                isTagAvailable(filters.tags, e) &&
                isSystemAvailable(filters.system, e) &&
                isBusinessLineAvailable(filters.businessLine, e) &&
                isBusinessEntityAvailable(filters.businessEntity, e)
              );
            })
            .flatMap((e: Entity) => e.metadata.country)
            .filter(Boolean) as string[],
        ),
      ].sort(),
    [backendEntities, filters],
  );

  useEffect(() => {
    updateFilters({
      country: selectedCountries.length
        ? new EntityCountryFilter(selectedCountries)
        : undefined,
    });
  }, [selectedCountries, updateFilters]);

  if (availableCountries.length < 2 && !selectedCountries.length) return null; // < 2 && !selectedCountries.length
  return (
    <Box pb={1} pt={1}>
      <Typography variant="button" component="label">
        {t('Country')}
        <Autocomplete
          multiple
          options={availableCountries as React.ReactNode[]}
          value={selectedCountries}
          filterOptions={(options, { inputValue }) =>
            options.filter((option: any) =>
              [option, t(option)].some(
                (term: string) =>
                  term
                    .toLowerCase()
                    .includes(inputValue.toLowerCase()) as unknown,
              ),
            )
          }
          onChange={(_: ChangeEvent<object>, value: unknown[]) =>
            value.every(val => typeof val === 'string') &&
            setSelectedCountries(value as string[])
          }
          renderOption={(option: any, { selected }) => (
            <FormControlLabel
              control={
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  checked={selected}
                />
              }
              label={t(option)}
            />
          )}
          size="small"
          popupIcon={<ExpandMoreIcon data-testid="country-picker-expand" />}
          renderInput={params => (
            <TextField
              {...params}
              className={classes.input}
              variant="outlined"
            />
          )}
        />
      </Typography>
    </Box>
  );
};
