import { Select, SelectItem } from '@backstage/core-components';
import { Box } from '@material-ui/core';
import React, { useEffect, useMemo, useState } from 'react';

import { EntityKindFilter } from '@backstage/plugin-catalog-react';
import { useEntityList } from '../catalog/ApiCatalog/CatalogTable/hooks/useEntityListProvider';

function useEntityKindFilter(opts: { initialFilter: string }): {
  allKinds: string[];
  selectedKind: string;
  setSelectedKind: (kind: string) => void;
} {
  const {
    filters,
    queryParameters: { kind: kindParameter },
    updateFilters,
  } = useEntityList();

  const queryParamKind = useMemo(
    () => [kindParameter].flat()[0],
    [kindParameter],
  );

  const [selectedKind, setSelectedKind] = useState(
    queryParamKind ?? filters.kind?.value ?? opts.initialFilter,
  );

  // Set selected kinds on query parameter updates; this happens at initial page load and from
  // external updates to the page location.
  useEffect(() => {
    if (queryParamKind) {
      setSelectedKind(queryParamKind);
    }
  }, [queryParamKind]);

  // Set selected kind from filters; this happens when the kind filter is
  // updated from another component
  useEffect(() => {
    if (filters.kind?.value) {
      setSelectedKind(filters.kind?.value);
    }
  }, [filters.kind]);

  useEffect(() => {
    updateFilters({
      kind: selectedKind ? new EntityKindFilter(selectedKind) : undefined,
    });
  }, [selectedKind, updateFilters]);

  return {
    allKinds: [],
    selectedKind,
    setSelectedKind,
  };
}

/**
 * Props for {@link EntityKindPicker}.
 *
 * @public
 */
export interface EntityKindPickerProps {
  /**
   * Entity kinds to show in the dropdown; by default all kinds are fetched from the catalog and
   * displayed.
   */
  allowedKinds?: string[];
  initialFilter?: string;
  hidden?: boolean;
}

/** @public */
export const EntityKindMapfreApiPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'mapfreapi' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });
  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfreapi' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
export const EntityKindMapfreDocumentPicker = (
  props: EntityKindPickerProps,
) => {
  const { hidden = true, initialFilter = 'mapfredocument' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });
  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfredocument' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
export const EntityKindLegEspPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'mapfreapilegacyesp' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });

  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfreapilegacyesp' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
export const EntityKindLegacyBraPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'mapfreapilegacybra' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });

  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfreapilegacybra' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
export const EntityKindLegacyPerPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'mapfreapilegacyper' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });

  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfreapilegacyper' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
export const EntityKindLegGlobalPicker = (props: EntityKindPickerProps) => {
  const { hidden = true, initialFilter = 'mapfreapilegacyglobal' } = props;

  const { selectedKind, setSelectedKind } = useEntityKindFilter({
    initialFilter: initialFilter,
  });

  const { updateFilters } = useEntityList();
  useEffect(() => {
    updateFilters({
      kind: new EntityKindFilter(initialFilter),
    });
  }, [initialFilter, updateFilters]);

  return hidden ? null : (
    <Box pb={1} pt={1}>
      <Select
        label="Kind"
        items={['mapfreapilegacyglobal' as unknown as SelectItem]}
        selected={selectedKind.toLocaleLowerCase('en-US')}
        onChange={value => setSelectedKind(String(value))}
      />
    </Box>
  );
};
