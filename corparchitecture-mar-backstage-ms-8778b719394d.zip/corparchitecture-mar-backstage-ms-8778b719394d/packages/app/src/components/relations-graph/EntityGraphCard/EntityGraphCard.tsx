import {
  getCompoundEntityRef,
  parseEntityRef,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import { InfoCard, InfoCardVariants } from '@backstage/core-components';
import { useAnalytics, useRouteRef } from '@backstage/core-plugin-api';
import {
  useEntity,
  humanizeEntityRef,
  entityRouteRef,
} from '@backstage/plugin-catalog-react';
import { makeStyles, Theme } from '@material-ui/core';
import qs from 'qs';
import React, { MouseEvent, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { CUSTOM_PAIRS } from '../EntityRelationsGraph';
import {
  Direction,
  EntityNode,
  EntityRelationsGraph,
  RelationPairs,
  catalogGraphRouteRef,
} from '@backstage/plugin-catalog-graph';
import { t } from 'i18next';
import { CustomLabel } from '../EntityRelationsGraph/CustomLabel';

const useStyles = makeStyles<Theme, { height: number | undefined }>(
  {
    card: ({ height }) => ({
      display: 'flex',
      flexDirection: 'column',
      maxHeight: height,
      minHeight: height,
    }),
    graph: {
      flex: 1,
      minHeight: 0,
    },
  },
  { name: 'PluginCatalogGraphCatalogGraphCard' },
);

export const EntityGraphCard = (props: {
  variant?: InfoCardVariants;
  relationPairs?: RelationPairs;
  maxDepth?: number;
  unidirectional?: boolean;
  mergeRelations?: boolean;
  kinds?: string[];
  relations?: string[];
  direction?: Direction;
  height?: number;
  title?: string;
  zoom?: 'enabled' | 'disabled' | 'enable-on-click';
}) => {
  const {
    variant = 'gridItem',
    relationPairs = CUSTOM_PAIRS,
    maxDepth = 1,
    unidirectional = true,
    mergeRelations = false,
    kinds,
    relations,
    direction = Direction.LEFT_RIGHT,
    height,
    title = t('Relations'),
    zoom = 'enable-on-click',
  } = props;

  const { entity } = useEntity();
  const entityName = getCompoundEntityRef(entity);
  const catalogEntityRoute = useRouteRef(entityRouteRef);
  const catalogGraphRoute = useRouteRef(catalogGraphRouteRef);
  const navigate = useNavigate();
  const classes = useStyles({ height });
  const analytics = useAnalytics();

  const onNodeClick = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    (node: EntityNode, _: MouseEvent<unknown>) => {
      const nodeEntityName = parseEntityRef(node.id);
      const path = catalogEntityRoute({
        kind: nodeEntityName.kind.toLocaleLowerCase('en-US'),
        namespace: nodeEntityName.namespace.toLocaleLowerCase('en-US'),
        name: nodeEntityName.name,
      });
      analytics.captureEvent(
        'click',
        node.title ?? humanizeEntityRef(nodeEntityName),
        { attributes: { to: path } },
      );
      navigate(path);
    },
    [catalogEntityRoute, navigate, analytics],
  );
  const catalogGraphParams = qs.stringify(
    { rootEntityRefs: [stringifyEntityRef(entity)] },
    { arrayFormat: 'brackets', addQueryPrefix: true },
  );
  const catalogGraphUrl = `${catalogGraphRoute()}${catalogGraphParams}`;
  return (
    <InfoCard
      title={title}
      cardClassName={classes.card}
      variant={variant}
      noPadding
      deepLink={{
        title: t('View graph'),
        link: catalogGraphUrl,
      }}
    >
      <EntityRelationsGraph
        rootEntityNames={entityName}
        maxDepth={maxDepth}
        unidirectional={unidirectional}
        mergeRelations={mergeRelations}
        kinds={kinds}
        relations={relations}
        direction={direction}
        onNodeClick={onNodeClick}
        className={classes.graph}
        relationPairs={relationPairs}
        zoom={zoom}
        renderLabel={CustomLabel}
      />
    </InfoCard>
  );
};
