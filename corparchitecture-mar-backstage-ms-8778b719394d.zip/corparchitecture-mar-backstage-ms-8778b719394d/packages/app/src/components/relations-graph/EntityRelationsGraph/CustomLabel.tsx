import { DependencyGraphTypes } from '@backstage/core-components';
import { BackstageTheme } from '@backstage/theme';
import makeStyles from '@material-ui/core/styles/makeStyles';
import React from 'react';
import { EntityEdgeData } from './types';
import classNames from 'classnames';
import { t } from 'i18next';

const useStyles = makeStyles((theme: BackstageTheme) => ({
  text: {
    fill: theme.palette.textContrast,
  },
  secondary: {
    fill: theme.palette.textSubtle,
  },
}));

export function CustomLabel({
  edge: { relations },
}: DependencyGraphTypes.RenderLabelProps<EntityEdgeData>) {
  const classes = useStyles();
  return (
    <text className={classes.text} textAnchor="middle">
      {relations.map((r, i) => (
        <tspan key={r} className={classNames(i > 0 && classes.secondary)}>
          {i > 0 && <tspan> / </tspan>}
          {t(r)}
        </tspan>
      ))}
    </text>
  );
}
