import { Entity } from '@backstage/catalog-model';
import { useEffect } from 'react';
import { useEntityStore } from './useEntityStore';

/**
 * Discover the graph of entities connected by relations, starting from a set of
 * root entities. Filters are used to select which relations to includes.
 * Returns all discovered entities once they are loaded.
 */
export function useEntityRelationGraph({
  rootEntityRefs,
  filter: { maxDepth = Number.POSITIVE_INFINITY, relations, kinds } = {},
}: {
  rootEntityRefs: string[];
  filter?: {
    maxDepth?: number;
    relations?: string[];
    kinds?: string[];
  };
}): {
  entities?: { [ref: string]: Entity };
  loading: boolean;
  error?: Error;
} {
  const { entities, loading, error, requestEntities } = useEntityStore();

  useEffect(() => {
    const expectedEntities = new Set([...rootEntityRefs]);
    const processedEntityRefs = new Set<string>();

    let nextDepthRefQueue = [...rootEntityRefs];
    let depth = 0;

    while (
      nextDepthRefQueue.length > 0 &&
      (!isFinite(maxDepth) || depth < maxDepth)
    ) {
      const entityRefQueue = nextDepthRefQueue;
      nextDepthRefQueue = [];

      while (entityRefQueue.length > 0) {
        const entityRef = entityRefQueue?.shift() as string;
        const entity = entities[entityRef];

        processedEntityRefs.add(entityRef);

        if (entity && entity.relations) {
          for (const rel of entity.relations) {
            if (
              (!relations || relations.includes(rel.type)) &&
              (!kinds ||
                kinds.some(kind =>
                  rel.targetRef.startsWith(
                    `${kind.toLocaleLowerCase('en-US')}:`,
                  ),
                ))
            ) {
              if (!processedEntityRefs.has(rel.targetRef)) {
                nextDepthRefQueue.push(rel.targetRef);
                expectedEntities.add(rel.targetRef);
              }
            }
          }
        }
      }

      ++depth;
    }

    requestEntities([...expectedEntities]);
  }, [entities, rootEntityRefs, maxDepth, relations, kinds, requestEntities]);

  return {
    entities,
    loading,
    error,
  };
}
