import { DEFAULT_NAMESPACE } from '@backstage/catalog-model';
import { MouseEvent, useState } from 'react';
import { useDebounce } from 'react-use';
import { CUSTOM_PAIRS } from './relations';
import { EntityEdge, EntityNode } from './types';
import { useEntityRelationGraph } from './useEntityRelationGraph';
import { RelationPairs } from '@backstage/plugin-catalog-graph';
import { t } from 'i18next';
/**
 * Generate nodes and edges to render the entity graph.
 */
export function useEntityRelationNodesAndEdges({
  rootEntityRefs,
  maxDepth = Number.POSITIVE_INFINITY,
  unidirectional = true,
  mergeRelations = true,
  kinds,
  relations,
  onNodeClick,
  relationPairs = CUSTOM_PAIRS,
}: {
  rootEntityRefs: string[];
  maxDepth?: number;
  unidirectional?: boolean;
  mergeRelations?: boolean;
  kinds?: string[];
  relations?: string[];
  onNodeClick?: (value: EntityNode, event: MouseEvent<unknown>) => void;
  relationPairs?: RelationPairs;
}): {
  loading: boolean;
  nodes?: EntityNode[];
  edges?: EntityEdge[];
  error?: Error;
} {
  const [nodesAndEdges, setNodesAndEdges] = useState<{
    nodes?: EntityNode[];
    edges?: EntityEdge[];
  }>({});
  const { entities, loading, error } = useEntityRelationGraph({
    rootEntityRefs,
    filter: {
      maxDepth,
      kinds,
      relations,
    },
  });

  useDebounce(
    () => {
      if (!entities || Object.keys(entities).length === 0) {
        setNodesAndEdges({});
        return;
      }

      const nodes = Object.entries(entities).map(([entityRef, entity]) => {
        const focused = rootEntityRefs.includes(entityRef);
        const node: EntityNode = {
          id: entityRef,
          title: entity.metadata?.title ?? undefined,
          kind: entity.kind,
          name: entity.metadata.name,
          namespace: entity.metadata.namespace ?? DEFAULT_NAMESPACE,
          focused,
          color: focused ? 'secondary' : 'primary',
        };

        if (onNodeClick) {
          node.onClick = event => onNodeClick(node, event);
        }

        return node;
      });

      const edges: EntityEdge[] = [];
      const visitedNodes = new Set<string>();
      const nodeQueue = [...rootEntityRefs];

      while (nodeQueue.length > 0) {
        const entityRef = nodeQueue?.pop() as string;
        const entity = entities[entityRef];
        visitedNodes.add(entityRef);

        if (entity) {
          entity?.relations?.forEach(rel => {
            // Check if the related entity should be displayed, if not, ignore
            // the relation too
            if (!entities[rel.targetRef]) {
              return;
            }

            if (relations && !relations.includes(rel.type)) {
              return;
            }

            if (
              kinds &&
              !kinds.some(kind =>
                rel.targetRef.startsWith(`${kind.toLocaleLowerCase('en-US')}:`),
              )
            ) {
              return;
            }

            if (!unidirectional || !visitedNodes.has(rel.targetRef)) {
              if (mergeRelations) {
                const pair = relationPairs.find(
                  ([l, r]) => l === rel.type || r === rel.type,
                ) ?? [rel.type];
                const [left] = pair;

                edges.push({
                  from: left === rel.type ? entityRef : rel.targetRef,
                  to: left === rel.type ? rel.targetRef : entityRef,
                  relations: [t(pair)],
                  label: 'visible',
                });
              } else {
                edges.push({
                  from: entityRef,
                  to: rel.targetRef,
                  relations: [t(rel.type)],
                  label: 'visible',
                });
              }
            }

            if (!visitedNodes.has(rel.targetRef)) {
              nodeQueue.push(rel.targetRef);
              visitedNodes.add(rel.targetRef);
            }
          });
        }
      }

      setNodesAndEdges({ nodes, edges });
    },
    100,
    [
      entities,
      rootEntityRefs,
      kinds,
      relations,
      unidirectional,
      mergeRelations,
      onNodeClick,
      relationPairs,
    ],
  );

  return {
    loading,
    error,
    ...nodesAndEdges,
  };
}
