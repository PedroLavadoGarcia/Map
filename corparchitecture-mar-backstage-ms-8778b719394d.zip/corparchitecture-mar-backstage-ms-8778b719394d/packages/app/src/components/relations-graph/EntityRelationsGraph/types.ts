import { DependencyGraphTypes } from '@backstage/core-components';
import { MouseEventHandler } from 'react';

/**
 * Additional Data for entities
 */
export type EntityEdgeData = {
  /**
   * Up to two relations that are connecting an entity.
   */
  relations: string[];
  /**
   * Whether the entity is visible or not.
   */
  // Not used, but has to be non empty to draw a label at all!
  label: 'visible';
};

/**
 * Edge between two entities.
 *
 * @public
 */
export type EntityEdge = DependencyGraphTypes.DependencyEdge<EntityEdgeData>;

/**
 * Additional data for Entity Node
 */
export type EntityNodeData = {
  /**
   * Name of the entity.
   */
  name: string;
  /**
   * Optional kind of the entity.
   */
  kind?: string;
  /**
   * Optional title of the entity.
   */
  title?: string;
  /**
   * Namespace of the entity.
   */
  namespace: string;
  /**
   * Whether the entity is focused, optional, defaults to false. Focused
   * entities are highlighted in the graph.
   */
  focused?: boolean;
  /**
   * Optional color of the entity, defaults to 'default'.
   */
  color?: 'primary' | 'secondary' | 'default';
  /**
   * Optional click handler.
   */
  onClick?: MouseEventHandler<unknown>;
};

/**
 * Node representing an entity.
 *
 * @public
 */
export type EntityNode = DependencyGraphTypes.DependencyNode<EntityNodeData>;

/**
 * Render direction of the graph.
 *
 * @public
 */
export enum Direction {
  /**
   * Top to bottom.
   */
  TOP_BOTTOM = 'TB',
  /**
   * Bottom to top.
   */
  BOTTOM_TOP = 'BT',
  /**
   * Left to right.
   */
  LEFT_RIGHT = 'LR',
  /**
   * Right to left.
   */
  RIGHT_LEFT = 'RL',
}
