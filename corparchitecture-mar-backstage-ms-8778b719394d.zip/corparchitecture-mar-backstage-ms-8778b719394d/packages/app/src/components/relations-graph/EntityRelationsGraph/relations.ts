import {
  RelationPairs,
  ALL_RELATION_PAIRS,
} from '@backstage/plugin-catalog-graph';

export const RELATION_AUTHORIZES_API = 'authorizesApis';
export const RELATION_API_AUTHORIZED_BY = 'apiAuthorizedBy';
export const RELATION_INVOKES_API = 'invokesApis';
export const RELATION_API_INVOKED_BY = 'apiInvokedBy';
export const RELATION_NEXT_VERSION_OF = 'nextVersionOf';
export const RELATION_PREVIOUS_VERSION_OF = 'previousVersionOf';

export const CUSTOM_PAIRS: RelationPairs = [
  ...ALL_RELATION_PAIRS,
  [RELATION_AUTHORIZES_API, RELATION_API_AUTHORIZED_BY],
  [RELATION_INVOKES_API, RELATION_API_INVOKED_BY],
  [RELATION_NEXT_VERSION_OF, RELATION_PREVIOUS_VERSION_OF],
];
