import { Container, CardActionArea } from '@material-ui/core';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import GridViewOutlinedIcon from '@mui/icons-material/GridViewOutlined';
import ViewAgendaOutlinedIcon from '@mui/icons-material/ViewAgendaOutlined';

interface ViewIconProps {
  GridView: boolean;
  UrlArray: string[];
}

const ViewIcon: React.FC<ViewIconProps> = ({ GridView, UrlArray }) => {
  const navigate = useNavigate();
  const [isGridViewClicked, setIsGridViewClicked] = useState(GridView);
  const [isListViewClicked, setIsListViewClicked] = useState(!GridView);

  const handleGridView = () => {
    navigate(`${UrlArray[0]}grid${UrlArray[1]}`);
  };

  const handleListView = () => {
    navigate(`${UrlArray[0]}list${UrlArray[1]}`);
  };

  const iconsContainerStyle = {
    display: 'flex',
    maxWidth: 'none',
    paddingRight: '16px',
  };

  const iconStyle = {
    padding: '8px',
    background: 'none',
    border: 'none',
    display: 'flex',
    height: '45px',
    width: '45px',
  };

  return (
    <Container style={{ ...iconsContainerStyle }}>
      {/* GRID ICON */}
      <CardActionArea
        style={{
          ...iconStyle,
          color: isGridViewClicked ? '#2D373D' : '#89969A',
        }}
        onClick={handleGridView}
      >
        <GridViewOutlinedIcon />
      </CardActionArea>

      {/* LIST ICON */}
      <CardActionArea
        style={{
          ...iconStyle,
          color: isListViewClicked ? '#2D373D' : '#89969A',
        }}
        onClick={handleListView}
      >
        <ViewAgendaOutlinedIcon />
      </CardActionArea>
    </Container>
  );
};

export default ViewIcon;
