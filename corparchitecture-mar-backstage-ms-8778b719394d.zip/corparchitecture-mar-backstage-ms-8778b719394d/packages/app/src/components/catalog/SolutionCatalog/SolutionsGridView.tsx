/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  Content,
  EmptyState,
  Header,
  Progress,
} from '@backstage/core-components';
import {
  Card,
  Container,
  Link,
  CardActionArea,
  Chip,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
  Tooltip,
  CardContent,
} from '@material-ui/core';
import { Pagination, useTheme, useMediaQuery } from '@mui/material';
import React, { createContext, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Typography from '@mui/material/Typography';
import { makeStyles } from '@material-ui/core';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import { Entity } from '@backstage/catalog-model';
import {
  CatalogApi,
  EntityListProvider,
  catalogApiRef,
} from '@backstage/plugin-catalog-react';
import axios from 'axios';
import FavoriteIcon from '../FavoriteIcon';
import { useAsync } from 'react-use';
import ViewIcon from '../ViewIcon';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import { NavLink } from 'react-router-dom';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { GroupChecker } from '../../../utils/GroupChecker';
import i18next, { TFunction } from 'i18next';
import DOMPurify from 'dompurify';

export interface FunctionalCatalog {
  [key: string]: any;
}

export const EntityContext = createContext('');
export default function SolutionsGridView({
  t,
}: {
  t: TFunction<'translation', undefined>;
}) {
  const useStyles = makeStyles({
    cardGridStyle: {
      flexDirection: 'column',
      boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
      position: 'relative',
      height: '500px',
      width: '330px',
      gap: '0px',
      borderColor: '#EAE9E9',
      borderRadius: '8px',
    },
    noResultcardGridStyle: {
      flexDirection: 'column',
      position: 'relative',
      height: '500px',
      width: '330px',
      gap: '0px',
    },
    cardActionAreaStyle: {
      justifyContent: 'flex-start',
      width: '100%',
    },
    contentCardStyle: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '18px',
      paddingLeft: '0px',
    },
    containerSearchStyle: {
      display: 'flex',
      marginLeft: '0px',
      marginRight: '0px',
      padding: '24px',
      maxWidth: 'none',
    },
  });
  const imageContainerStyle = {
    width: '330px',
    height: '220px',
    display: 'flex',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F6F7',
  };
  const classes = useStyles();
  const [tempSignedUrls, setTempSignedUrls] = useState<string[]>([]);
  const [signedUrls, setSignedUrls] = useState<string[]>([]);
  const [contextEntities, setcontextEntities] = useState<Entity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const catalogApi = useApi(catalogApiRef);
  const identityApi = useApi(identityApiRef);

  const [entities, setEntities] = useState<Entity[]>([]);

  const preloadImage = (url: string) => {
    const img = new Image();
    img.src = url;
  };

  useEffect(() => {
    const signedUrlsArray: string[] = [];
    if (entities.length > 0) {
      const fetchSignedUrls = async () => {
        for (const entity of entities) {
          const kind = entity.kind.toLowerCase();
          try {
            if (entity.metadata.annotations?.header_icon) {
              const baseUrl = new URL(
                `api/s3-images`,
                window.location.origin.replace('3000', '7007'),
              );
              const response = await axios.get(
                `${baseUrl}/global/${entity.metadata.name}/${encodeURIComponent(
                  entity.metadata.annotations?.header_icon as string,
                )}?kind=${kind}`,
              );
              signedUrlsArray.push(response.data.signedUrl);
              preloadImage(response.data.signedUrl);
            } else {
              signedUrlsArray.push('');
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            signedUrlsArray.push('');
          }
        }
        setTempSignedUrls(signedUrlsArray);
        setSignedUrls(signedUrlsArray);
      };

      fetchSignedUrls();
    }
  }, [entities]);

  const { loading } = useAsync(async () => {
    const entities = await getSolutions(catalogApi);

    setEntities(entities);
    setcontextEntities(entities);
  });

  const { value: groupChecker } = useAsync(async () => {
    return await GroupChecker.init(identityApi);
  });

  const handleSearchChange = (event: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchQuery(event.target.value);
    searchChange(event.target.value as string);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchChange('');
  };

  function searchChange(value: string): void {
    setCurrentPage(1);
    if (entities && entities.length > 0) {
      if (value) {
        const entitiesSearch: Entity[] = [];
        const urls: string[] = [];
        for (let i = 0; i < entities.length; i++) {
          if (
            entities[i] &&
            (entities[i].metadata.title
              ?.toLowerCase()
              .includes(value.toLowerCase()) ||
              entities[i].metadata.description
                ?.toLowerCase()
                .includes(value.toLowerCase()))
          ) {
            entitiesSearch.push(entities[i]);
            urls.push(tempSignedUrls[i]);
          }
        }
        setSignedUrls(urls);
        setcontextEntities(entitiesSearch);
      } else {
        setcontextEntities(entities);
        setSignedUrls(tempSignedUrls);
      }
    }
  }
  const [itemsPerPage, setItemsPerPage] = useState(8);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentEntities = contextEntities.slice(
    startIndex,
    startIndex + itemsPerPage,
  );
  const currentUrls = signedUrls.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (
    _event: unknown,
    value: React.SetStateAction<number>,
  ) => {
    setCurrentPage(value);
  };

  // const { t } = useTranslation();

  const theme = useTheme();
  const isXs = useMediaQuery(theme.breakpoints.down('xs'));
  const isSm = useMediaQuery(theme.breakpoints.between('sm', 'md'));
  const isMd = useMediaQuery(theme.breakpoints.between('md', 'lg'));
  const isLg = useMediaQuery(theme.breakpoints.up('lg'));

  const updateItemsPerPage = () => {
    setCurrentPage(1);

    const pageItems = Math.floor((window.innerWidth - 230) / 348) * 2;
    setItemsPerPage(pageItems);
  };

  useEffect(() => {
    updateItemsPerPage();
    window.addEventListener('resize', updateItemsPerPage);
    return () => {
      window.removeEventListener('resize', updateItemsPerPage);
    };
  }, [isLg, isMd, isSm, isXs]);

  const truncateText = (str: string, num: number) => {
    const cleanText = stripHtml(str);

    if (cleanText.length > num) {
      return cleanText.slice(0, num) + '...';
    } else {
      return cleanText;
    }
  };

  const stripHtml = (html: string) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || '';
  };

  const descriptionByLanguage = (entity: Record<string, any>) => {
    let description;
    if (
      entity.metadata &&
      entity.metadata?.[`description_${i18next.resolvedLanguage}`] &&
      entity.metadata?.[`description_${i18next.resolvedLanguage}`] !== ''
    ) {
      description = entity.metadata[`description_${i18next.resolvedLanguage}`];
    } else {
      switch (i18next.resolvedLanguage) {
        case 'en':
          description =
            entity.metadata?.[`description_es`] &&
            entity.metadata?.[`description_es`] !== ''
              ? entity.metadata?.[`description_es`]
              : entity.metadata?.[`description_pt`];
          break;
        case 'es':
          description =
            entity.metadata?.[`description_en`] &&
            entity.metadata?.[`description_en`] !== ''
              ? entity.metadata?.[`description_en`]
              : entity.metadata?.[`description_pt`];
          break;
        case 'pt':
          description =
            entity.metadata?.[`description_es`] &&
            entity.metadata?.[`description_es`] !== ''
              ? entity.metadata?.[`description_es`]
              : entity.metadata?.[`description_en`];
          break;
        default:
          description = entity.metadata?.description;
          break;
      }
    }
    return description;
  };

  return (
    <EntityListProvider>
      <Container
        style={{
          maxWidth: 'none',
          paddingLeft: '115px',
          paddingRight: '115px',
        }}
      >
        {loading ? (
          <Progress />
        ) : (
          <>
            <Header
              style={{ paddingTop: '24px', paddingBottom: '0px' }}
              title={t('Solutions Catalog')}
            >
              {(groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin()) && (
                <NavLink
                  to="/forms/mapfresolution"
                  style={{ color: '#DB271C', marginRight: '10px' }}
                >
                  {t('Add Solution')}
                </NavLink>
              )}
            </Header>
            <Container className={classes.containerSearchStyle}>
              <Grid item xs={11}>
                <TextField
                  variant="outlined"
                  placeholder={'Search'}
                  value={searchQuery}
                  onChange={handleSearchChange}
                  margin="dense"
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        {searchQuery && (
                          <IconButton
                            edge="end"
                            onClick={handleClearSearch}
                            size="medium"
                          >
                            <ClearIcon />
                          </IconButton>
                        )}
                        <IconButton edge="end" size="medium">
                          <SearchIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    sx: {
                      borderRadius: '20px',
                    },
                  }}
                />
              </Grid>
              <Grid item xs={1}>
                <ViewIcon
                  GridView={true}
                  UrlArray={[
                    '/solutions/',
                    '?filters%5Bkind%5D=mapfresolution',
                  ]}
                />
              </Grid>
            </Container>

            <div>
              {/* SOLUTIONS CARDS GRID*/}
              {contextEntities.length >= 1 ? (
                <Content className={classes.contentCardStyle}>
                  {currentEntities.map((entity, index) => {
                    const rawDescription = descriptionByLanguage(entity);
                    const sanitizedDescription =
                      rawDescription !== undefined
                        ? DOMPurify.sanitize(String(rawDescription))
                        : '';
                    return (
                      <Grid
                        item
                        xs={8}
                        key={index}
                        style={{
                          maxWidth: 'none',
                          flexBasis: 'calc(10% - 10px)',
                        }}
                      >
                        <Card
                          className={classes.cardGridStyle}
                          variant="outlined"
                        >
                          <Link
                            style={{ display: 'contents' }}
                            href={`/catalog/default/mapfresolution/${entity.metadata.name}`}
                          >
                            <CardActionArea
                              className={classes.cardActionAreaStyle}
                            >
                              <div style={{ ...imageContainerStyle }}>
                                <img
                                  style={{
                                    maxWidth: '100%',
                                    maxHeight: '100%',
                                    objectFit: 'contain',
                                    objectPosition: 'center',
                                    width: '330px',
                                  }}
                                  loading="lazy"
                                  alt=""
                                  src={
                                    currentUrls.length > 0
                                      ? currentUrls[index]
                                        ? currentUrls[index]
                                        : '/documentationLogo.png'
                                      : '/documentationLogo.png'
                                  }
                                />
                              </div>
                              <div>
                                <Tooltip title={entity?.metadata?.title || ''}>
                                  <Typography
                                    style={{
                                      color: '#2D373D',
                                      fontWeight: 'bold',
                                      fontSize: '20px',
                                      width: '330px',
                                      lineHeight: '28px',
                                      textAlign: 'left',
                                      padding: '16px',
                                      overflow: 'hidden',
                                      textOverflow: 'ellipsis',
                                      display: '-webkit-box',
                                      WebkitLineClamp: '2',
                                      WebkitBoxOrient: 'vertical',
                                    }}
                                  >
                                    {truncateText(
                                      entity?.metadata?.title || '',
                                      20,
                                    )}
                                  </Typography>
                                </Tooltip>
                              </div>
                              <div style={{ height: '95px' }}>
                                <Tooltip
                                  title={stripHtml(sanitizedDescription)}
                                >
                                  <Typography
                                    style={{
                                      fontSize: '16px',
                                      color: '#526570',
                                      fontWeight: 'lighter',
                                      lineHeight: '20.83px',
                                      textAlign: 'left',
                                      paddingLeft: '16px',
                                      paddingRight: '16px',
                                      overflow: 'hidden',
                                      textOverflow: 'ellipsis',
                                      display: '-webkit-box',
                                      WebkitLineClamp: '5',
                                      WebkitBoxOrient: 'vertical',
                                      width: '330px',
                                    }}
                                  >
                                    {truncateText(
                                      stripHtml(sanitizedDescription),
                                      100,
                                    )}
                                  </Typography>
                                </Tooltip>
                              </div>
                            </CardActionArea>
                            {/* TAGS (SUBCATALOG) */}
                            <CardActionArea
                              className={classes.cardActionAreaStyle}
                              style={{ justifyContent: 'flex-end' }}
                            >
                              <Typography style={{ padding: '12px' }}>
                                {(
                                  (entity?.metadata?.subcatalog as string[]) ||
                                  []
                                ).map((text, index) => (
                                  <Chip
                                    key={index}
                                    size="small"
                                    label={t(
                                      `mapfresolution.subcatalog.${text}`,
                                    )}
                                  />
                                ))}

                                <Chip
                                  key={index}
                                  size="small"
                                  label={t(
                                    `mapfresolution.macroprocess.${
                                      (
                                        entity?.metadata
                                          ?.functional_catalog as FunctionalCatalog
                                      ).macroprocess as string
                                    }`,
                                  )}
                                />
                              </Typography>
                            </CardActionArea>
                          </Link>
                          <div
                            style={{
                              marginTop: 'auto',
                              paddingBottom: '8px',
                              display: 'flex',
                            }}
                          >
                            <Link
                              style={{ display: 'flex' }}
                              href={`/catalog/default/mapfresolution/${entity.metadata.name}`}
                            >
                              <CardActionArea
                                className={classes.cardActionAreaStyle}
                                style={{ display: 'flex' }}
                              >
                                <Typography
                                  style={{
                                    color: '#D81E05',
                                    fontSize: '16px',
                                    lineHeight: '24px',
                                    textAlign: 'left',
                                    paddingLeft: '16px',
                                  }}
                                >
                                  {t('View')}
                                </Typography>
                                <KeyboardArrowRightOutlinedIcon
                                  style={{ color: '#D81E05' }}
                                />
                              </CardActionArea>
                            </Link>
                            <FavoriteIcon />
                          </div>
                        </Card>
                      </Grid>
                    );
                  })}
                </Content>
              ) : (
                <div className={classes.noResultcardGridStyle}>
                  <EmptyState missing="data" title={t('No results')} />
                </div>
              )}
            </div>
          </>
        )}
      </Container>
      <Pagination
        count={Math.ceil(contextEntities.length / itemsPerPage)}
        page={currentPage}
        onChange={handlePageChange}
        style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}
      />
    </EntityListProvider>
  );
}

export async function getSolutions(catalogApi: CatalogApi) {
  const entities = (
    await catalogApi.getEntities({
      filter: [
        {
          kind: 'mapfresolution',
          'spec.lifecycle': ['approved'],
        },
      ],
      fields: [
        'kind',
        'spec',
        'metadata.name',
        'metadata.title',
        'metadata.description_en',
        `metadata.description_es`,
        `metadata.description_pt`,
        'metadata.country',
        'metadata.annotations',
        'metadata.subcatalog',
        'metadata.functional_catalog.macroprocess',
      ],
    })
  ).items;

  entities.sort((a: Entity, b: Entity) => {
    const valueA = a.metadata.title?.toLowerCase() || '';
    const valueB = b.metadata.title?.toLowerCase() || '';

    if (valueA < valueB) {
      return -1;
    }
    if (valueA > valueB) {
      return 1;
    }
    return 0;
  });
  return entities;
}
