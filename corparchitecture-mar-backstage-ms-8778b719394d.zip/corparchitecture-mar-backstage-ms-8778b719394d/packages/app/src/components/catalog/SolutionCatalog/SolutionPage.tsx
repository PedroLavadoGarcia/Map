/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Chip,
  CircularProgress,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  Divider,
  Grid,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  makeStyles,
  styled,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@material-ui/core';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DescriptionIcon from '@mui/icons-material/Description';
import i18next, { TFunction } from 'i18next';
import {
  catalogApiRef,
  EntityRefLink,
  useEntity,
} from '@backstage/plugin-catalog-react';
import {
  alertApiRef,
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import ReactDOM from 'react-dom';
import axios from 'axios';
import ReactPlayer from 'react-player';
import {
  Content,
  ContentHeader,
  DocsIcon,
  EmptyState,
  InfoCard,
  Sidebar,
  SidebarGroup,
  SidebarPage,
  SidebarScrollWrapper,
  SidebarSpace,
} from '@backstage/core-components';
import { useAsync } from 'react-use';
import { GroupChecker } from '../../../utils/GroupChecker';
import { EntityLayout } from '@backstage/plugin-catalog';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
  ChangelogCard,
  MetadataTableCard,
} from '@internal/plugin-custom-cards';
import { Typography as Typography2 } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import { EmailService } from '@backstage/plugin-mapfreapi-editor';
import yaml from 'yaml';
import {
  ANNOTATION_LOCATION,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import { uploadFiles as updateEntity } from '@backstage/plugin-components-catalog-edit/src/lib/uploadFiles';
import {
  copyRepoBucketContent,
  deleteRepoBucket,
  getCatalogInfo,
} from '@backstage/plugin-mapfreapi-editor/src/lib/getCatalogInfo';
import { SolutionChangelogService } from '../../../api/changelog';
import { SolutionState } from '@backstage/plugin-forms/src/models/solution/SolutionFormValue';
import { FunctionalCatalog } from './SolutionsGridView';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import AccountBoxOutlinedIcon from '@mui/icons-material/AccountBoxOutlined';
import { AuditService } from '../../../api/audit';

export function SolutionPage({
  t,
}: {
  t: TFunction<'translation', undefined>;
}) {
  const useStyles = makeStyles({
    cardStyle: {
      // display: 'flex',
      // flexDirection: 'column',
      // height: 'flex',
      // marginBottom: '40px',
      boxShadow: 'none',
      border: 'none',
    },
    cardLogoStyle: {
      display: 'flex',
      flexDirection: 'row',
      height: 'flex',
      marginBottom: '20px',
      boxShadow: 'none',
      position: 'relative',
      alignItems: 'left',
    },
    cardRowStyle: {
      display: 'flex',
      flexDirection: 'row',
      ratio: '1',
      height: 'flex',
      marginTop: '30px',
      marginBottom: '30px',
      boxShadow: 'none',
      position: 'relative',
    },
    textStyle: {
      color: '#394360',
      fontSize: '25px',
    },
    textArea: {
      fontSize: '14px',
    },
    cardRowTextStyle: {
      fontSize: '12px',
      width: '0',
      minWidth: '100%',
    },
    sectionStyle: {
      marginTop: '15px',
    },
    aliasStyle: {
      marginBottom: '15px',
    },
    imageContainer: {
      width: '400px',
      height: '250px',
      marginTop: '25px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      overflow: 'hidden',
    },
    image: {
      //  maxWidth: '100%',
      //  maxHeight: '100%',
      objectFit: 'contain',
      objectPosition: 'center',
    },
    smallScreenContainerStyle: {
      '@media (max-width: 1100px)': {
        flexDirection: 'column',
        display: 'flex',
        alignItems: 'baseline',
      },
    },
    smallScreenTextStyle: {
      '@media (max-width: 1100px)': {
        display: 'contents',
      },
    },
    loading: {
      position: 'absolute',
      bottom: '50%',
      left: '50%',
      transform: 'translateY(-50%) translateX(-50%)',
    },
    containerStyle: {
      margin: '20px 0px 20px 0px',
      width: '100%',
      display: 'flex',
      flexDirection: 'row',
      boxShadow: 'none',
    },
    insideCardStyle: {
      width: '100%',
      boxShadow: 'none',
    },
    icon: {
      cursor: 'pointer',
      color: '#D81E05',
    },
    listItemStyle: {
      display: 'flex',
      justifyContent: 'space-between',
    },
    indicator: {
      backgroundColor: '#DB271C',
    },
    tabRoot: {
      color: 'inherit',
      padding: '10px 10px',
      // transition: 'color 0.3s ease',
      '&:hover': {
        color: 'black',
        backgroundColor: 'inherit',
      },
    },
    contentCardStyle: {
      display: 'flex',
      width: '100%',
      // justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '10px',
      paddingLeft: '0px',
    },
  });
  const classes = useStyles();
  const { entity } = useEntity();
  const navigate = useNavigate();

  const identityApi = useApi(identityApiRef);
  const catalogApi = useApi(catalogApiRef);
  const config = useApi(configApiRef);
  const alertApi = useApi(alertApiRef);

  const backendUrl = config.getOptionalString('backend.baseUrl') ?? '';
  const env = config.getOptionalString('app.env') ?? '';
  const appUrl = config.getOptionalString('app.baseUrl') ?? '';
  const entityUrl = `${appUrl}/catalog/default/mapfresolution/${entity.metadata.name}`;
  const emailService = new EmailService();
  const changelog = new SolutionChangelogService();

  const [potentialUrls, setPotentialUrls] = useState<string[]>([
    '/empty-image.png',
  ]);
  const [integrationUrls, setIntegrationUrls] = useState<string[]>([
    '/empty-image.png',
  ]);
  const [functionalUrls, setFunctionalUrls] = useState<string[]>([
    '/empty-image.png',
  ]);
  const [moreDataUrls, setMoreDataUrls] = useState<string[]>([
    '/empty-image.png',
  ]);
  const [headerIcon, setHeaderIcon] = useState('/empty-icon.png');
  const [isLoading, setIsLoading] = useState(false);
  const [newState, setNewState] = useState<
    SolutionState | 'rejected' | undefined
  >();
  const [comment, setComment] = useState('');
  const audit = new AuditService(backendUrl ?? '');

  useAsync(async () => {
    const { email } = await identityApi.getProfileInfo();
    if (email) {
      audit.pushViewLog(email, entity.metadata.name);
    }
  });

  function addAliasToTitle() {
    const TitleWithAliasComponent = () => (
      <span>
        <span>{entity.metadata.title}</span>
        {entity.metadata.alias &&
          (entity.metadata.alias as string[]).length > 0 && (
            <>
              <span style={{ fontSize: '10px' }}> A.K.A </span>
              <span style={{ fontSize: '16px' }}>
                {(entity.metadata.alias as string[]).join(', ')}
              </span>
            </>
          )}
      </span>
    );
    const headers = document.getElementsByTagName('header');
    if (headers.length >= 2) {
      const header = headers[1];
      if (headers.length >= 2) {
        (header.children[0] as HTMLElement).style.overflow = 'hidden';
        (header.children[0] as HTMLElement).style.paddingRight = '30px';
        (header.children[1] as HTMLElement).style.flexWrap = 'nowrap';
        const spans = header.getElementsByTagName('span');
        if (spans.length >= 1) {
          const title = spans[0];
          ReactDOM.render(<TitleWithAliasComponent />, title);
        }
      }
    }
  }

  const { value: backstageIdentity } = useAsync(async () => {
    return await identityApi.getBackstageIdentity();
  });

  const { value: profile } = useAsync(async () => {
    return await identityApi.getProfileInfo();
  });

  useEffect(() => {
    const fetchSignedUrls = async () => {
      if (entity) {
        const kind = entity.kind.toLowerCase();
        if (entity.metadata.annotations) {
          try {
            const headerMedia = entity.metadata.annotations.header_icon;
            const potentialMedia = entity.metadata.annotations['potential_img1']
              ? entity.metadata.annotations['potential_img1']
              : entity.metadata.annotations['potential_mm'];
            const integrationMedia = entity.metadata.annotations[
              'integration_img1'
            ]
              ? entity.metadata.annotations['integration_img1']
              : entity.metadata.annotations['integration_mm'];
            const moreDataMedia = entity.metadata.annotations['more_data_img1']
              ? entity.metadata.annotations['more_data_img1']
              : entity.metadata.annotations['more_data_mm'];
            const functionalMedia = entity.metadata.annotations[
              'functional_img1'
            ]
              ? entity.metadata.annotations['functional_img1']
              : entity.metadata.annotations['functional_mm'];

            const baseUrl = `${backendUrl}/api/s3-images/global/${entity.metadata.name}`;
            if (potentialMedia) {
              const response = await axios.get(
                `${baseUrl}/${potentialMedia}?kind=${kind}`,
              );
              setPotentialUrls([response.data.signedUrl]);
            }
            if (integrationMedia) {
              const response = await axios.get(
                `${baseUrl}/${integrationMedia}?kind=${kind}`,
              );
              setIntegrationUrls([response.data.signedUrl]);
            }
            if (moreDataMedia) {
              const response = await axios.get(
                `${baseUrl}/${moreDataMedia}?kind=${kind}`,
              );
              setMoreDataUrls([response.data.signedUrl]);
            }
            if (functionalMedia) {
              const response = await axios.get(
                `${baseUrl}/${functionalMedia}?kind=${kind}`,
              );
              setFunctionalUrls([response.data.signedUrl]);
            }
            if (headerMedia) {
              const response = await axios.get(
                `${baseUrl}/${headerMedia}?kind=${kind}`,
              );
              setHeaderIcon(response.data.signedUrl);
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            setPotentialUrls(['']);
            setIntegrationUrls(['']);
            setMoreDataUrls(['']);
            setFunctionalUrls(['']);
          }
        }
      }
    };
    fetchSignedUrls();
    addAliasToTitle();
  }, [entity]);

  const emails =
    useAsync(async () => {
      const govEmails =
        (
          await catalogApi.getEntityByRef(
            `group:gazr-gov-backstage-soluciones-global-${env}`,
          )
        )?.relations
          ?.filter(r => r.type === 'hasMember')
          .map(m => m.targetRef.split('/')[1].replace('_', '@')) ?? [];
      return [
        ...(entity.metadata.liableTeam as any).tech_team.map((u: any) =>
          u.responsible.split(':')[1].replace('_', '@'),
        ),
        ...(entity.metadata.liableTeam as any).func_team.map((u: any) =>
          u.responsible.split(':')[1].replace('_', '@'),
        ),
        ...govEmails,
      ] as string[];
    }).value ?? [];

  const SidebarDivider = styled('hr')(({ theme }) => ({
    height: 1,
    width: '100%',
    background: theme.palette.background.default,
    border: 'none',
    margin: theme.spacing(1.2, 0),
  }));

  const solutionSidebar = (
    <>
      <Sidebar>
        <SidebarScrollWrapper
          style={{
            display: 'flex',
            flexFlow: 'column nowrap',
            minHeight: 500,
            alignItems: 'flex-start',
          }}
        >
          <SidebarSpace />
          <SidebarGroup label={entity.metadata.title} icon={<DocsIcon />}>
            {/* Global nav, not org-specific */}
            {/*<SidebarItem
               icon={HomeIcon}
               to=""
               text={`${entity.metadata.title}` as string | undefined}
             />*/}
            <SidebarDivider />
            {/* <SidebarItem icon={ExtensionIcon} to={'#'} text={'Responsables'} />*/}
          </SidebarGroup>
          <SidebarSpace />
        </SidebarScrollWrapper>
      </Sidebar>
    </>
  );

  const getDeployedComment = () => {
    if (entity?.metadata) {
      const functionalCatalog = ((
        entity.metadata?.functional_catalog as Record<string, string>
      ).deployed || []) as {
        deployed_comment_es?: string;
        deployed_comment_en?: string;
        deployed_comment_pt?: string;
        deployed_comment: string;
      }[];

      if (functionalCatalog) {
        switch (i18next.resolvedLanguage) {
          case 'es':
            return functionalCatalog.map(
              item =>
                item.deployed_comment_es ||
                item.deployed_comment_en ||
                item.deployed_comment_pt ||
                item.deployed_comment,
            );
          case 'en':
            return functionalCatalog.map(
              item =>
                item.deployed_comment_en ||
                item.deployed_comment_es ||
                item.deployed_comment_pt ||
                item.deployed_comment,
            );
          case 'pt':
            return functionalCatalog.map(
              item =>
                item.deployed_comment_pt ||
                item.deployed_comment_es ||
                item.deployed_comment_en ||
                item.deployed_comment,
            );
          default:
            return functionalCatalog.map(item => item.deployed_comment);
        }
      }
    }
    return '';
  };

  const getTranslationForField = (fieldName: string) => {
    const fieldKey = fieldName.toLowerCase();

    switch (i18next.resolvedLanguage) {
      case 'es':
        return (
          entity.metadata?.annotations?.[`${fieldKey}_es`] ||
          entity.metadata?.annotations?.[`${fieldKey}_en`] ||
          entity.metadata?.annotations?.[`${fieldKey}_pt`] ||
          entity.metadata?.[`${fieldKey}_es`] ||
          entity.metadata?.[`${fieldKey}_en`] ||
          entity.metadata?.[`${fieldKey}_pt`] ||
          entity.metadata?.annotations?.[fieldKey] ||
          entity.metadata?.[fieldKey] ||
          undefined
        );
      case 'en':
        return (
          entity.metadata?.annotations?.[`${fieldKey}_en`] ||
          entity.metadata?.annotations?.[`${fieldKey}_es`] ||
          entity.metadata?.annotations?.[`${fieldKey}_pt`] ||
          entity.metadata?.[`${fieldKey}_en`] ||
          entity.metadata?.[`${fieldKey}_es`] ||
          entity.metadata?.[`${fieldKey}_pt`] ||
          entity.metadata?.annotations?.[fieldKey] ||
          entity.metadata?.[fieldKey] ||
          undefined
        );
      case 'pt':
        return (
          entity.metadata?.annotations?.[`${fieldKey}_pt`] ||
          entity.metadata?.annotations?.[`${fieldKey}_es`] ||
          entity.metadata?.annotations?.[`${fieldKey}_en`] ||
          entity.metadata?.[`${fieldKey}_pt`] ||
          entity.metadata?.[`${fieldKey}_es`] ||
          entity.metadata?.[`${fieldKey}_en`] ||
          entity.metadata?.annotations?.[fieldKey] ||
          entity.metadata?.[fieldKey] ||
          undefined
        );
      default:
        return (
          entity.metadata?.annotations?.[fieldKey] ||
          entity.metadata?.[fieldKey] ||
          undefined
        );
    }
  };

  const token =
    useAsync(async () => (await identityApi.getCredentials()).token).value ??
    '';

  const { value: groupChecker } = useAsync(async () => {
    return await GroupChecker.init(identityApi);
  });

  const liableTeam = entity.metadata.liableTeam as any;

  async function downloadFile(file: string) {
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const folder = `${encodeURIComponent(file)}`;

    window
      ?.open(
        `${backendUrl}/api/external-docs/download/${bucket}/${repository}/${folder}`,
        '_blank',
      )
      ?.focus();
  }

  function isResponsible() {
    if (backstageIdentity && entity.metadata.liableTeam) {
      const tech_team = (entity.metadata.liableTeam as any).tech_team;
      const func_team = (entity.metadata.liableTeam as any).func_team;
      return [
        ...(tech_team ? tech_team : []),
        ...(func_team ? func_team : []),
      ].some(
        r =>
          r.responsible ===
          backstageIdentity.userEntityRef.replace('default/', ''),
      );
    }
    return false;
  }

  async function handleDiscarded() {
    setIsLoading(true);
    const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
    const catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));
    const prevCatalogInfo = yaml.stringify(catalogInfo);
    catalogInfo.metadata.state = 'discarded';
    catalogInfo.spec = {
      ...catalogInfo.spec,
      lifecycle: catalogInfo.metadata.state,
    };
    await updateEntity(
      repositoryUrl,
      {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      token,
    );
    await catalogApi.refreshEntity(
      `mapfresolution:default/${entity.metadata.name}`,
    );
    const subject = t('mapfresolution.email.subject', { env });
    const title = t('mapfresolution.email.title', {
      title: entity.metadata.title,
    });
    const subtitle = t('mapfresolution.email.discarded.subtitle');
    const message = t('mapfresolution.email.discarded.message', {
      title: entity.metadata.title,
      state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
      historyLogUrl: `${entityUrl}/history-log`,
    });
    emailService.send({ to: emails, subject, title, subtitle, message });
    changelog.push(entity.metadata.name, prevCatalogInfo, {
      files: {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      desc: 'mapfresolution.historyLog.stateChange',
      descParams: {
        from: `mapfresolution.state.${entity.metadata.state}`,
        to: `mapfresolution.state.${catalogInfo.metadata.state}`,
      },
      modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
      comment,
    });
    setTimeout(() => {
      navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
      window.location.reload();
    }, 3000);
  }

  async function handleRetired() {
    setIsLoading(true);
    const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
    const catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));
    const prevCatalogInfo = yaml.stringify(catalogInfo);
    catalogInfo.metadata.state = 'retired';
    catalogInfo.spec = {
      ...catalogInfo.spec,
      lifecycle: catalogInfo.metadata.state,
    };
    catalogInfo.metadata.changelog.deprecationDate = Date.now();
    if (catalogInfo.metadata.subcatalog.includes('ptc')) {
      catalogInfo.metadata.changelog.deprecationPtcDate = Date.now();
    }
    if (catalogInfo.metadata.subcatalog.includes('reef')) {
      catalogInfo.metadata.changelog.deprecationReefDate = Date.now();
    }
    await updateEntity(
      repositoryUrl,
      {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      token,
    );
    await catalogApi.refreshEntity(
      `mapfresolution:default/${entity.metadata.name}`,
    );
    const subject = t('mapfresolution.email.subject', { env });
    const title = t('mapfresolution.email.title', {
      title: entity.metadata.title,
    });
    const subtitle = t('mapfresolution.email.retired.subtitle');
    const message = t('mapfresolution.email.retired.message', {
      title: entity.metadata.title,
      state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
      historyLogUrl: `${entityUrl}/history-log`,
    });
    emailService.send({ to: emails, subject, title, subtitle, message });
    changelog.push(entity.metadata.name, prevCatalogInfo, {
      files: {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      desc: 'mapfresolution.historyLog.stateChange',
      descParams: {
        from: `mapfresolution.state.${entity.metadata.state}`,
        to: `mapfresolution.state.${catalogInfo.metadata.state}`,
      },
      modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
      comment,
    });
    setTimeout(() => {
      navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
      window.location.reload();
    }, 3000);
  }

  async function handleEdited() {
    setIsLoading(true);
    const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
    const catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));
    const prevCatalogInfo = yaml.stringify(catalogInfo);
    catalogInfo.metadata.state = 'edited';
    catalogInfo.spec = {
      ...catalogInfo.spec,
      lifecycle: catalogInfo.metadata.state,
    };
    await updateEntity(
      repositoryUrl,
      {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      token,
    );
    await catalogApi.refreshEntity(
      `mapfresolution:default/${entity.metadata.name}`,
    );
    const subject = t('mapfresolution.email.subject', { env });
    const title = t('mapfresolution.email.title', {
      title: entity.metadata.title,
    });
    const subtitle = t('mapfresolution.email.edited.subtitle');
    const message = t('mapfresolution.email.edited.message', {
      title: entity.metadata.title,
      state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
      historyLogUrl: `${entityUrl}/history-log`,
    });
    emailService.send({ to: emails, subject, title, subtitle, message });
    changelog.push(entity.metadata.name, prevCatalogInfo, {
      files: {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      desc: 'mapfresolution.historyLog.stateChange',
      descParams: {
        from: `mapfresolution.state.${entity.metadata.state}`,
        to: `mapfresolution.state.${catalogInfo.metadata.state}`,
      },
      modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
      comment,
    });
    setTimeout(() => {
      navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
      window.location.reload();
    }, 3000);
  }

  const handleRejected = async () => {
    setIsLoading(true);
    const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
    const catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));
    const bucket = repositoryUrl.split('/')[2].split('.')[0];
    unRegisterEntity(repositoryUrl);
    await deleteRepoBucket(backendUrl, bucket, entity.metadata.name, token);
    changelog.delete(entity.metadata.name);
    const subject = t('mapfresolution.email.rejected.subject', { env });
    const title = t('mapfresolution.email.rejected.title', {
      title: entity.metadata.title,
    });
    const subtitle = t('mapfresolution.email.rejected.subtitle');
    const message = t('mapfresolution.email.rejected.message', {
      title: entity.metadata.title,
      state: catalogInfo.metadata.state,
      historyLogUrl: `${entityUrl}/history-log`,
    });
    emailService.send({ to: emails, subject, title, subtitle, message });
    setTimeout(() => {
      navigate(
        `/catalog/default/mapfresolution/${entity.metadata.name.replace(
          '_edit',
          '',
        )}`,
      );
      setIsLoading(false);
    }, 3000);
  };

  const handleApproved = async () => {
    if (entity.metadata.annotations) {
      setIsLoading(true);
      const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
      const catalogInfo = yaml.parse(
        await getCatalogInfo(repositoryUrl, token),
      );
      const prevCatalogInfo = yaml.stringify(catalogInfo);
      catalogInfo.metadata.state = 'approved';
      catalogInfo.spec.lifecycle = catalogInfo.metadata.state;
      catalogInfo.metadata.changelog.approvalDate = Date.now();
      if (catalogInfo.metadata.subcatalog.includes('ptc')) {
        catalogInfo.metadata.changelog.approvalPtcDate = Date.now();
      }
      if (catalogInfo.metadata.subcatalog.includes('reef')) {
        catalogInfo.metadata.changelog.approvalReefDate = Date.now();
      }
      await updateEntity(
        repositoryUrl,
        {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        token,
      );
      await catalogApi.refreshEntity(
        `mapfresolution:default/${entity.metadata.name}`,
      );
      const subject = t('mapfresolution.email.subject', { env });
      const title = t('mapfresolution.email.title', {
        title: entity.metadata.title,
      });
      const subtitle = t('mapfresolution.email.approved.subtitle');
      const message = t('mapfresolution.email.approved.message', {
        title: entity.metadata.title,
        state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
        historyLogUrl: `${entityUrl}/history-log`,
      });
      emailService.send({ to: emails, subject, title, subtitle, message });
      changelog.push(entity.metadata.name, prevCatalogInfo, {
        files: {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        desc: 'mapfresolution.historyLog.stateChange',
        descParams: {
          from: `mapfresolution.state.${entity.metadata.state}`,
          to: `mapfresolution.state.${catalogInfo.metadata.state}`,
        },
        modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
        comment,
      });
      setTimeout(async () => {
        navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
        window.location.reload();
      }, 3000);
    }
  };

  async function handleApprovedEdited() {
    if (entity.metadata.annotations) {
      setIsLoading(true);
      const repositoryUrl = entity.metadata.annotations[ANNOTATION_LOCATION];
      const catalogInfo = yaml.parse(
        await getCatalogInfo(repositoryUrl, token),
      );
      const prevCatalogInfo = await getCatalogInfo(
        repositoryUrl.replace('_edit', ''),
        token,
      );
      catalogInfo.metadata.name = entity.metadata.name.replace('_edit', '');
      catalogInfo.metadata.state = 'approved';
      catalogInfo.spec.lifecycle = catalogInfo.metadata.state;
      const ogEntity = (await catalogApi.getEntityByRef({
        kind: 'mapfresolution',
        namespace: 'default',
        name: entity.metadata.name.replace('_edit', '') ?? '',
      })) as any;
      if (ogEntity) {
        if (
          catalogInfo.metadata.subcatalog.includes('ptc') &&
          !ogEntity.metadata.subcatalog.includes('ptc')
        ) {
          catalogInfo.metadata.changelog.approvalPtcDate = Date.now();
          catalogInfo.metadata.changelog.deprecationPtcDate = null;
        }
        if (
          catalogInfo.metadata.subcatalog.includes('reef') &&
          !ogEntity.metadata.subcatalog.includes('reef')
        ) {
          catalogInfo.metadata.changelog.approvalReefDate = Date.now();
          catalogInfo.metadata.changelog.deprecationReefDate = null;
        }
        if (
          !catalogInfo.metadata.subcatalog.includes('ptc') &&
          ogEntity.metadata.subcatalog.includes('ptc')
        ) {
          catalogInfo.metadata.changelog.deprecationPtcDate = Date.now();
        }
        if (
          !catalogInfo.metadata.subcatalog.includes('reef') &&
          ogEntity.metadata.subcatalog.includes('reef')
        ) {
          catalogInfo.metadata.changelog.deprecationReefDate = Date.now();
        }
      }
      await updateEntity(
        repositoryUrl,
        {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        token,
      );
      const bucket = repositoryUrl.split('/')[2].split('.')[0];
      await deleteRepoBucket(
        backendUrl,
        bucket,
        entity.metadata.name.replace('_edit', ''),
        token,
      );
      await copyRepoBucketContent(
        backendUrl,
        bucket,
        entity.metadata.name,
        token,
      );
      await catalogApi.refreshEntity(
        `mapfresolution:default/${catalogInfo.metadata.name}`,
      );
      await deleteRepoBucket(backendUrl, bucket, entity.metadata.name, token);
      unRegisterEntity(repositoryUrl);
      const subject = t('mapfresolution.email.subject', { env });
      const title = t('mapfresolution.email.title', {
        title: entity.metadata.title,
      });
      const subtitle = t('mapfresolution.email.approved.subtitle');
      const message = t('mapfresolution.email.approved.message', {
        title: entity.metadata.title,
        state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
        historyLogUrl: `${entityUrl}/history-log`,
      });
      emailService.send({ to: emails, subject, title, subtitle, message });
      await changelog.push(entity.metadata.name, prevCatalogInfo, {
        files: {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        desc: 'mapfresolution.historyLog.edited',
        descParams: {
          from: `mapfresolution.state.${entity.metadata.state}`,
          to: `mapfresolution.state.${catalogInfo.metadata.state}`,
        },
        modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
        comment,
      });
      changelog.move(
        entity.metadata.name,
        entity.metadata.name.replace('_edit', ''),
      );
      setTimeout(async () => {
        navigate(
          `/catalog/default/mapfresolution/${entity.metadata.name.replace(
            '_edit',
            '',
          )}`,
        );
      }, 3000);
    }
  }

  const handleApprovedRetired = async () => {
    if (entity.metadata.annotations) {
      setIsLoading(true);
      const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
      const catalogInfo = yaml.parse(
        await getCatalogInfo(repositoryUrl, token),
      );
      const prevCatalogInfo = yaml.stringify(catalogInfo);
      catalogInfo.metadata.state = 'approved';
      catalogInfo.spec.lifecycle = catalogInfo.metadata.state;
      catalogInfo.metadata.changelog.approvalDate = Date.now();
      catalogInfo.metadata.changelog.deprecationDate = null;
      catalogInfo.metadata.changelog.deprecationPtcDate = null;
      catalogInfo.metadata.changelog.deprecationReefDate = null;
      if (catalogInfo.metadata.subcatalog.includes('ptc')) {
        catalogInfo.metadata.changelog.approvalPtcDate = Date.now();
      }
      if (catalogInfo.metadata.subcatalog.includes('reef')) {
        catalogInfo.metadata.changelog.approvalReefDate = Date.now();
      }
      await updateEntity(
        repositoryUrl,
        {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        token,
      );
      await catalogApi.refreshEntity(
        `mapfresolution:default/${entity.metadata.name}`,
      );
      const subject = t('mapfresolution.email.subject', { env });
      const title = t('mapfresolution.email.title', {
        title: entity.metadata.title,
      });
      const subtitle = t('mapfresolution.email.retired_approved.subtitle');
      const message = t('mapfresolution.email.retired_approved.message', {
        title: entity.metadata.title,
        state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
        historyLogUrl: `${entityUrl}/history-log`,
      });
      emailService.send({ to: emails, subject, title, subtitle, message });
      changelog.push(entity.metadata.name, prevCatalogInfo, {
        files: {
          'catalog-info.yaml': yaml.stringify(catalogInfo),
        },
        desc: 'mapfresolution.historyLog.stateChange',
        descParams: {
          from: `mapfresolution.state.${entity.metadata.state}`,
          to: `mapfresolution.state.${catalogInfo.metadata.state}`,
        },
        modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
        comment,
      });
      setTimeout(async () => {
        navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
        window.location.reload();
      }, 3000);
    }
  };

  async function handleDraft() {
    setIsLoading(true);
    const repositoryUrl = entity.metadata.annotations![ANNOTATION_LOCATION];
    const catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));
    const prevCatalogInfo = yaml.stringify(catalogInfo);
    catalogInfo.metadata.state = 'draft';
    catalogInfo.spec = {
      ...catalogInfo.spec,
      lifecycle: catalogInfo.metadata.state,
    };
    await updateEntity(
      repositoryUrl,
      {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      token,
    );
    await catalogApi.refreshEntity(
      `${entity.kind.toLowerCase()}:default/${entity.metadata.name}`,
    );
    const subject = t('mapfresolution.email.subject', { env });
    const title = t('mapfresolution.email.title', {
      title: entity.metadata.title,
    });
    const subtitle = t('mapfresolution.email.draft.subtitle');
    const message = t('mapfresolution.email.draft.message', {
      title: entity.metadata.title,
      state: t(`mapfresolution.state.${catalogInfo.metadata.state}`),
      historyLogUrl: `${entityUrl}/history-log`,
    });
    emailService.send({ to: emails, subject, title, subtitle, message });
    changelog.push(entity.metadata.name, prevCatalogInfo, {
      files: {
        'catalog-info.yaml': yaml.stringify(catalogInfo),
      },
      desc: 'mapfresolution.historyLog.stateChange',
      descParams: {
        from: `mapfresolution.state.${entity.metadata.state}`,
        to: `mapfresolution.state.${catalogInfo.metadata.state}`,
      },
      modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
      comment,
    });
    setTimeout(() => {
      navigate(`/catalog/default/mapfresolution/${entity.metadata.name}`);
      window.location.reload();
    }, 3000);
  }

  const headerImage = (signedUrl: string): string => {
    if (signedUrl === '/empty-image.png' || signedUrl === '') {
      if (headerIcon === '/empty-icon.png') {
        return '/empty-image.png';
      }
      return headerIcon;
    }
    return signedUrl;
  };

  const overviewTab = (
    <EntityLayout.Route path={'/'} title={t('mapfresolution.tabs.overview')}>
      <Grid>
        <Dialog open={!!newState} PaperProps={{ style: { width: '500px' } }}>
          <DialogContent>
            <DialogContentText>
              {newState ? t(`mapfresolution.advice.${newState}`) : ''}
            </DialogContentText>
            <TextField
              fullWidth
              autoFocus
              size="small"
              multiline
              minRows={5}
              variant="outlined"
              label={t('mapfresolution.advice.comment')}
              name="comment"
              value={comment}
              onChange={e => {
                setComment(e.target.value);
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setNewState(undefined)} color="primary">
              {t('Cancel')}
            </Button>
            <Button
              onClick={() => {
                switch (newState) {
                  case 'draft':
                    handleDraft();
                    break;
                  case 'approved':
                    switch (entity.metadata.state) {
                      case 'review_edited':
                        handleApprovedEdited();
                        break;
                      case 'retired':
                        handleApprovedRetired();
                        break;
                      case 'review':
                        handleApproved();
                        break;
                    }
                    break;
                  case 'discarded':
                    handleDiscarded();
                    break;
                  case 'retired':
                    handleRetired();
                    break;
                  case 'edited':
                    handleEdited();
                    break;
                  case 'rejected':
                    handleRejected();
                    break;
                }
              }}
              color="secondary"
            >
              {t('Accept')}
            </Button>
          </DialogActions>
        </Dialog>
        {/* PRIMERA BOX CON BOTON*/}

        <Box
          sx={{
            padding: '20px',
            boxSizing: 'border-box',
            display: 'flex',
          }}
        >
          <Box style={{ padding: '20px' }}>
            <img
              style={{
                height: '70px',
                borderRadius: '2px',
              }}
              src={headerIcon}
            ></img>
          </Box>
          <CardContent style={{ width: '30%', paddingLeft: '36px' }}>
            <Typography className={classes.textArea}>
              <span
                dangerouslySetInnerHTML={{
                  __html: getTranslationForField('description') as string,
                }}
              ></span>
            </Typography>
            <Grid className={classes.sectionStyle}>
              <Typography variant="caption">
                {t('mapfresolution.state.label')}
              </Typography>
              <Typography
                variant="caption"
                display="block"
                style={{ fontWeight: 'bold' }}
              >
                {t(`mapfresolution.state.${entity?.spec?.lifecycle as string}`)}
              </Typography>
            </Grid>
            <Typography className={classes.sectionStyle}>
              {(entity?.metadata?.tags || []).map(tag => (
                <Chip key={tag} size="small" label={tag} />
              ))}
              {((entity?.metadata?.subcatalog as string[]) || []).map(
                subcatalog => (
                  <Chip
                    key={subcatalog}
                    size="small"
                    label={t(`mapfresolution.subcatalog.${subcatalog}`)}
                  />
                ),
              )}
              <Chip
                key={'macroprocess'}
                size="small"
                label={t(
                  `mapfresolution.macroprocess.${
                    (entity?.metadata?.functional_catalog as FunctionalCatalog)
                      .macroprocess as string
                  }`,
                )}
              />
            </Typography>
          </CardContent>
          <CardContent>
            <Button
              variant="contained"
              color="primary"
              style={{ marginRight: '20px' }}
            >
              <NavLink to={`${entityUrl.replace(appUrl, '')}/contact`}>
                {t('mapfresolution.contact.title')}
              </NavLink>
            </Button>

            {(((entity.spec?.lifecycle === 'draft' ||
              entity.spec?.lifecycle === 'approved' ||
              entity.spec?.lifecycle === 'edited') &&
              isResponsible()) ||
              groupChecker?.isGlobalGovSolGroup() ||
              groupChecker?.isAdmin()) && (
              <Button
                variant="contained"
                color="primary"
                style={{ marginRight: '20px' }}
                onClick={async () => {
                  const haveEdited = !!(await catalogApi.getEntityByRef(
                    stringifyEntityRef(entity).replace(
                      entity.metadata.name,
                      `${entity.metadata.name}_edit`,
                    ),
                  ));
                  if (haveEdited) {
                    navigate(
                      `/forms/mapfresolution/${entity.metadata.name}_edit`,
                    );
                  } else {
                    navigate(`/forms/mapfresolution/${entity.metadata.name}`);
                  }
                }}
              >
                {t('Edit')}
              </Button>
            )}

            {(entity.spec?.lifecycle === 'review' ||
              entity.spec?.lifecycle === 'review_edited' ||
              entity.spec?.lifecycle === 'retired') &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('approved')}
                  style={{ marginRight: '20px' }}
                >
                  {t('Approve')}
                </Button>
              )}

            {entity.spec?.lifecycle === 'discarded' &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('draft')}
                >
                  {t('Draft')}
                </Button>
              )}

            {(entity.spec?.lifecycle === 'draft' ||
              entity.spec?.lifecycle === 'review') &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin() ||
                isResponsible()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('discarded')}
                >
                  {t('Discard')}
                </Button>
              )}

            {entity.spec?.lifecycle === 'approved' &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin() ||
                isResponsible()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('retired')}
                >
                  {t('Retire')}
                </Button>
              )}

            {entity.spec?.lifecycle === 'review_edited' &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('edited')}
                >
                  {t('Reject')}
                </Button>
              )}

            {entity.spec?.lifecycle === 'edited' &&
              (groupChecker?.isGlobalGovSolGroup() ||
                groupChecker?.isAdmin() ||
                isResponsible()) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setNewState('rejected')}
                >
                  {t('Discard')}
                </Button>
              )}
          </CardContent>
        </Box>

        <Divider></Divider>
        {/* BOX CON IMAGENES SACADAS DE ATRIBUTOS potential_img(1-5)  */}
        <Box
          sx={{
            width: '80%',
            //  margin: 'auto',
            padding: '20px',
            boxSizing: 'border-box',
          }}
        >
          {potentialUrls.length !== 0 ? (
            potentialUrls.map((signedUrl, index) => (
              <Grid
                container
                spacing={2}
                key={index}
                className={classes.smallScreenContainerStyle}
              >
                <Grid item xs={6} style={{ flexBasis: '0%' }}>
                  <Box className={classes.imageContainer}>
                    {signedUrl.includes('.png') ? (
                      <img
                        className={classes.image}
                        style={{
                          width: '100%',
                          height: '100%',
                          // objectFit: 'cover',
                        }}
                        src={headerImage(signedUrl)}
                      ></img>
                    ) : (
                      <ReactPlayer
                        url={signedUrl}
                        controls
                        width="100%"
                        height="auto"
                        key={index}
                      />
                    )}
                  </Box>
                </Grid>
                <Grid item xs={6} className={classes.smallScreenTextStyle}>
                  <Box
                    justifyContent="center"
                    alignItems="center"
                    padding="20px"
                    boxSizing="border-box"
                  >
                    <Typography variant="body1" className={classes.textStyle}>
                      {t('mapfresolution.potential.label')}
                    </Typography>
                    <Typography className={classes.textArea}>
                      <span
                        dangerouslySetInnerHTML={{
                          __html: getTranslationForField('potential') as string,
                        }}
                      ></span>
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            ))
          ) : (
            <Grid item xs={6} className={classes.smallScreenTextStyle}>
              <Box
                justifyContent="center"
                alignItems="center"
                padding="20px"
                boxSizing="border-box"
              >
                <Typography variant="body1" className={classes.textStyle}>
                  {t('mapfresolution.potential.label')}
                </Typography>
                <Typography className={classes.textArea}>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: getTranslationForField('potential') as string,
                    }}
                  ></span>
                </Typography>
              </Box>
            </Grid>
          )}
        </Box>

        {/* Box de campos integration*/}
        <Box
          sx={{
            width: '80%',
            //  margin: 'auto',
            padding: '20px',
            boxSizing: 'border-box',
          }}
        >
          {integrationUrls.length !== 0 ? (
            integrationUrls.map((signedUrl, index) => (
              <Grid
                container
                spacing={2}
                key={index}
                className={classes.smallScreenContainerStyle}
              >
                <Grid item xs={6} style={{ flexBasis: '0%' }}>
                  <Box className={classes.imageContainer}>
                    {signedUrl.includes('.png') ? (
                      <img
                        className={classes.image}
                        style={{
                          width: '100%',
                          height: '100%',
                          // objectFit: 'cover',
                        }}
                        src={headerImage(signedUrl)}
                      ></img>
                    ) : (
                      <ReactPlayer
                        url={signedUrl}
                        controls
                        width="100%"
                        height="auto"
                        key={index}
                      />
                    )}
                  </Box>
                </Grid>
                <Grid item xs={6} className={classes.smallScreenTextStyle}>
                  <Box
                    justifyContent="center"
                    alignItems="center"
                    padding="20px"
                    boxSizing="border-box"
                  >
                    <Typography variant="body1" className={classes.textStyle}>
                      {t('mapfresolution.integration.label')}
                    </Typography>
                    <Typography className={classes.textArea}>
                      <span
                        dangerouslySetInnerHTML={{
                          __html: getTranslationForField(
                            'integration',
                          ) as string,
                        }}
                      ></span>
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            ))
          ) : (
            <Grid item xs={6} className={classes.smallScreenTextStyle}>
              <Box
                justifyContent="center"
                alignItems="center"
                padding="20px"
                boxSizing="border-box"
              >
                <Typography variant="body1" className={classes.textStyle}>
                  {t('mapfresolution.integration.label')}
                </Typography>
                <Typography className={classes.textArea}>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: getTranslationForField('integration') as string,
                    }}
                  ></span>
                </Typography>
              </Box>
            </Grid>
          )}
        </Box>

        {/* CARDS CON ENLACES DE VIDEO SACADAS DE ATRIBUTOS potential_mm_link y integration_mm_link
        {(entity.metadata.annotations as Record<string, string>)
          .potential_mm_link && (
          <Card className={classes.cardLogoStyle}>
            <ReactPlayer
              url={
                (entity.metadata.annotations as Record<string, string>)
                  .potential_mm_link
              }
              controls
              width="100%"
              height="auto"
            />
            <CardContent>
              <Typography variant="body1" className={classes.textStyle}>
                {' '}
                catalog info potential mm link
              </Typography>
              <Typography
                variant="caption"
                style={{ whiteSpace: 'break-spaces' }}
              >
                {
                  (entity.metadata.annotations as Record<string, string>)
                    .potential
                }
              </Typography>
            </CardContent>
          </Card>
        )}
        {(entity.metadata.annotations as Record<string, string>)
          .integration_mm_link && (
          <Card className={classes.cardLogoStyle}>
            <ReactPlayer
              url={
                (entity.metadata.annotations as Record<string, string>)
                  .integration_mm_link as string
              }
              controls
              width="100%"
              height="auto"
            />
            <CardContent>
              <Typography variant="body1" className={classes.textStyle}>
                {' '}
                catalog info integration mm link
              </Typography>
              <Typography
                variant="caption"
                style={{ whiteSpace: 'break-spaces' }}
              >
                {
                  (entity.metadata.annotations as Record<string, string>)
                    .potential
                }
              </Typography>
            </CardContent>
          </Card>
        )} */}
      </Grid>
    </EntityLayout.Route>
  );

  const techTab = (
    <EntityLayout.Route path="/technical" title={t('mapfresolution.tabs.tech')}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <MetadataTableCard
            yamlKey="q_overview"
            title={t('mapfresolution.q_overview')}
            t={t}
          />
        </Grid>
        <Grid item xs={12}>
          <MetadataTableCard
            yamlKey="tech_data"
            title={t('mapfresolution.tech_data')}
            t={t}
          />
        </Grid>
        <Grid item xs={12}>
          <MetadataTableCard
            yamlKey="changelog"
            title={t('mapfresolution.change_log')}
            t={t}
          />
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  const functionalitiesTab = (
    <EntityLayout.Route
      path="/functionalities"
      title={t('mapfresolution.tabs.functionalities')}
    >
      <Grid>
        {/* PRIMERA SECCIÓN CON CATEGORÍAS FUNCIONALES*/}
        <Grid>
          <Box
            sx={{
              width: '80%',
              //  margin: 'auto',
              padding: '20px',
              boxSizing: 'border-box',
              display: 'flex',
            }}
          >
            <Box style={{ padding: '20px' }}>
              <Typography variant="body1" className={classes.textStyle}>
                {t('mapfresolution.functional_cataloging')}
              </Typography>
              <CardContent
                style={{
                  width: '50%',
                  paddingLeft: '36px',
                  display: 'contents',
                }}
              >
                <div style={{ display: 'flex' }}>
                  <div style={{ margin: '8px' }}>
                    <Typography variant="overline">
                      {t('mapfresolution.business_line.label')}
                    </Typography>
                    <Typography variant="caption" display="block">
                      {(
                        (
                          entity?.metadata?.functional_catalog as Record<
                            string,
                            string[]
                          >
                        )?.business_line || []
                      ).map(item => (
                        <div key={item}>
                          <Typography variant="caption">
                            {t(`mapfresolution.business_line.${item}`)}
                          </Typography>
                        </div>
                      ))}
                    </Typography>
                  </div>
                  <div style={{ margin: '8px' }}>
                    <Typography variant="overline">
                      {t('mapfresolution.process.label')}
                    </Typography>
                    <Typography variant="caption" display="block">
                      {(
                        (
                          entity?.metadata?.functional_catalog as Record<
                            string,
                            string[]
                          >
                        )?.process || []
                      ).map(item => (
                        <div key={item}>
                          <Typography variant="caption">
                            {t(`mapfresolution.process.${item}`)}
                          </Typography>
                        </div>
                      ))}
                    </Typography>
                  </div>
                </div>
              </CardContent>
              <div style={{ display: 'flex' }}>
                <div style={{ margin: '8px' }}>
                  <Typography variant="overline">
                    {t('mapfresolution.deployed.label')}
                  </Typography>
                  {/* País */}
                  <Typography variant="caption">
                    {(getDeployedComment() || []).map(
                      (comment: string, index: number) => {
                        const functionalCatalog = (
                          entity?.metadata?.functional_catalog as Record<
                            string,
                            string
                          >
                        ).deployed as unknown as Record<string, string>[];
                        return (
                          <>
                            <div key={index}>
                              <Typography
                                variant="caption"
                                style={{ fontWeight: 'bold' }}
                              >
                                {` ${
                                  ((t(
                                    functionalCatalog[index]?.deployed_country,
                                  ) as string) || '') as string
                                }`}
                              </Typography>
                            </div>
                            <div
                              dangerouslySetInnerHTML={{ __html: comment }}
                            />
                          </>
                        );
                      },
                    )}
                  </Typography>
                </div>
              </div>
            </Box>
          </Box>
        </Grid>

        <Divider></Divider>
        {/* CBOX CON TEXTO E IMAGEN SACADA DE functional_img(1-5)  */}
        <Box
          sx={{
            width: '80%',
            //  margin: 'auto',
            padding: '20px',
            boxSizing: 'border-box',
          }}
        >
          {functionalUrls.length !== 0 ? (
            functionalUrls.map((signedUrl, index) => (
              <Grid
                container
                spacing={2}
                key={index}
                className={classes.smallScreenContainerStyle}
              >
                <Grid item xs={6} style={{ flexBasis: '0%' }}>
                  <Box className={classes.imageContainer}>
                    {signedUrl.includes('.png') ? (
                      <img
                        className={classes.image}
                        style={{
                          width: '100%',
                          height: '100%',
                          // objectFit: 'cover',
                        }}
                        src={headerImage(signedUrl)}
                      ></img>
                    ) : (
                      <ReactPlayer
                        url={signedUrl}
                        controls
                        width="100%"
                        height="auto"
                        key={index}
                      />
                    )}
                  </Box>
                </Grid>
                <Grid item xs={6} className={classes.smallScreenTextStyle}>
                  <Box
                    justifyContent="center"
                    alignItems="center"
                    padding="20px"
                    boxSizing="border-box"
                  >
                    <Typography variant="body1" className={classes.textStyle}>
                      {t('mapfresolution.functional.label')}
                    </Typography>
                    <Typography className={classes.textArea}>
                      <span
                        dangerouslySetInnerHTML={{
                          __html: getTranslationForField(
                            'functional',
                          ) as string,
                        }}
                      ></span>
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            ))
          ) : (
            <Grid item xs={6} className={classes.smallScreenTextStyle}>
              <Box
                justifyContent="center"
                alignItems="center"
                padding="20px"
                boxSizing="border-box"
              >
                <Typography variant="body1" className={classes.textStyle}>
                  {t('mapfresolution.functional.label')}
                </Typography>
                <Typography className={classes.textArea}>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: getTranslationForField('functional') as string,
                    }}
                  ></span>
                </Typography>
              </Box>
            </Grid>
          )}
        </Box>
      </Grid>
    </EntityLayout.Route>
  );

  const dependenciesTab = (
    <EntityLayout.Route
      path="/dependencies"
      title={t('mapfresolution.tabs.dependencies')}
    >
      <Grid>
        <Grid>
          <Box
            sx={{
              width: '80%',
              //  margin: 'auto',
              padding: '20px',
              boxSizing: 'border-box',
              display: 'flex',
            }}
          >
            <Box style={{ padding: '20px' }}>
              <Typography variant="body1" className={classes.textStyle}>
                {t('mapfresolution.dependencies.label')}
              </Typography>
              <Typography className={classes.textArea}>
                <span
                  dangerouslySetInnerHTML={{
                    __html: getTranslationForField('dependencies') as string,
                  }}
                ></span>
              </Typography>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  const billingTab = (
    <EntityLayout.Route
      path="/billing"
      title={t('mapfresolution.tabs.billing')}
    >
      <Grid>
        <Grid>
          <Box
            sx={{
              width: '80%',
              //  margin: 'auto',
              padding: '20px',
              boxSizing: 'border-box',
              display: 'flex',
            }}
          >
            <Box style={{ padding: '20px' }}>
              <Typography variant="body1" className={classes.textStyle}>
                {t('mapfresolution.billing.label')}
              </Typography>
              <Typography className={classes.textArea}>
                <span
                  dangerouslySetInnerHTML={{
                    __html: getTranslationForField('billing') as string,
                  }}
                ></span>
              </Typography>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  const moreDataTab = (
    <EntityLayout.Route
      path="/more_data"
      title={t('mapfresolution.tabs.more_data')}
    >
      <Grid>
        {/* BOX CON IMAGENES SACADAS DE ATRIBUTOS more_data_img(1-5)  */}
        <Box
          sx={{
            width: '80%',
            //  margin: 'auto',
            padding: '20px',
            boxSizing: 'border-box',
          }}
        >
          {moreDataUrls.length !== 0 ? (
            moreDataUrls.map((signedUrl, index) => (
              <Grid
                container
                spacing={2}
                key={index}
                className={classes.smallScreenContainerStyle}
              >
                <Grid item xs={6} style={{ flexBasis: '0%' }}>
                  <Box className={classes.imageContainer}>
                    {signedUrl.includes('.png') ? (
                      <img
                        className={classes.image}
                        style={{
                          width: '100%',
                          height: '100%',
                          // objectFit: 'cover',
                        }}
                        src={headerImage(signedUrl)}
                      ></img>
                    ) : (
                      <ReactPlayer
                        url={signedUrl}
                        controls
                        width="100%"
                        height="auto"
                        key={index}
                      />
                    )}
                  </Box>
                </Grid>
                <Grid item xs={6} className={classes.smallScreenTextStyle}>
                  <Box
                    justifyContent="center"
                    alignItems="center"
                    padding="20px"
                    boxSizing="border-box"
                  >
                    <Typography variant="body1" className={classes.textStyle}>
                      {t('mapfresolution.more_data.label')}
                    </Typography>
                    <Typography className={classes.textArea}>
                      <span
                        dangerouslySetInnerHTML={{
                          __html: getTranslationForField('more_data') as string,
                        }}
                      ></span>
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            ))
          ) : (
            <Grid item xs={6} className={classes.smallScreenTextStyle}>
              <Box
                justifyContent="center"
                alignItems="center"
                padding="20px"
                boxSizing="border-box"
              >
                <Typography variant="body1" className={classes.textStyle}>
                  {t('mapfresolution.more_data.label')}
                </Typography>
                <Typography className={classes.textArea}>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: getTranslationForField('more_data') as string,
                    }}
                  ></span>
                </Typography>
              </Box>
            </Grid>
          )}
        </Box>
      </Grid>
    </EntityLayout.Route>
  );

  const { value: techResponsibles } = useAsync(async () => {
    return (await Promise.all(
      [
        ...liableTeam.tech_team.map((r: any) => ({ ...r, team: 'techTeam' })),
      ].map(async r => {
        const responsibleEntity = await catalogApi.getEntityByRef(
          r.responsible,
        );
        if (responsibleEntity) {
          return {
            ...r,
            entity: responsibleEntity,
          };
        } else {
          return {
            ...r,
            ref: {
              name: r.responsible.split(':')[1]
                ? r.responsible.split(':')[1]
                : '',
              namespace: 'default',
              kind: 'user',
            },
          };
        }
      }),
    )) as any[];
  });

  const { value: funcResponsibles } = useAsync(async () => {
    return (await Promise.all(
      [
        ...liableTeam.func_team.map((r: any) => ({ ...r, team: 'funcTeam' })),
      ].map(async r => {
        const responsibleEntity = await catalogApi.getEntityByRef(
          r.responsible,
        );
        if (responsibleEntity) {
          return {
            ...r,
            entity: responsibleEntity,
          };
        } else {
          return {
            ...r,
            ref: {
              name: r.responsible.split(':')[1]
                ? r.responsible.split(':')[1]
                : '',
              namespace: 'default',
              kind: 'user',
            },
          };
        }
      }),
    )) as any[];
  });

  const [tabIndex, setTabIndex] = useState(0);

  const handleTabChange = (event: any, newValue: any) => {
    const newEvent = event;
    setTabIndex(newValue);
  };

  const responsibleTab = (
    <EntityLayout.Route
      path="/responsible"
      title={t('mapfresolution.tabs.responsible')}
    >
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Tabs
            classes={{ indicator: classes.indicator }}
            value={tabIndex}
            onChange={handleTabChange}
            aria-label="responsible data tabs"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab
              disableRipple
              classes={{ root: classes.tabRoot }}
              key={0}
              label={t('tech_responsibles')}
            ></Tab>
            <Tab
              disableRipple
              classes={{ root: classes.tabRoot }}
              key={1}
              label={t('func_responsibles')}
            ></Tab>
          </Tabs>
        </Grid>
        <Grid item xs={12}>
          <TabPanel value={tabIndex} index={0}>
            <div>
              <Content className={classes.contentCardStyle}>
                {techResponsibles?.map((responsible, index: number) => {
                  let profile = { displayName: '', picture: '', email: '' };
                  let splitName = [' ', ' '];

                  if (
                    responsible.entity &&
                    responsible.entity.spec &&
                    responsible.entity.spec?.profile
                  ) {
                    profile = responsible.entity.spec?.profile;
                    splitName = profile.displayName.split(' ');
                  } else {
                    profile.email = responsible.responsible
                      ?.replace('user:', '')
                      .replace('_', '@');
                  }

                  return (
                    <Grid
                      item
                      xs={8}
                      key={index}
                      style={{
                        maxWidth: 'none',
                        minWidth: '374px',
                        flexBasis: 'calc(10% - 10px)',
                      }}
                    >
                      <Card
                        variant="outlined"
                        style={{
                          boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
                          width: '374px',
                          height: '280px',
                        }}
                      >
                        {/* <CardHeader
                          title={t(
                            `mapfresolution.responsibles.${responsible.team}`,
                          )}
                        /> */}
                        <CardContent>
                          <Grid container spacing={2} alignItems="center">
                            <Grid item xs={4}>
                              <Avatar
                                sx={{
                                  bgcolor: 'gray',
                                  width: 100,
                                  height: 100,
                                }}
                                src={profile.picture}
                              >
                                <Typography2 sx={{ fontSize: 24 }}>{`${
                                  splitName[0][0]
                                }${
                                  splitName.length > 1 && splitName[1][0]
                                }`}</Typography2>
                              </Avatar>
                            </Grid>
                            <Grid item xs={8}>
                              <EntityRefLink
                                entityRef={
                                  responsible.entity ?? responsible.ref ?? ''
                                }
                                defaultKind="user"
                                style={{ fontSize: '18px', color: '#475059' }}
                                title={
                                  responsible.entity
                                    ? profile.displayName
                                    : responsible.responsible?.replace(
                                        'user:',
                                        '',
                                      )
                                }
                              />
                            </Grid>
                          </Grid>
                          <Grid container style={{ marginTop: '20px' }}>
                            <Grid item xs={1}>
                              <MailOutlineIcon />
                            </Grid>
                            <Grid item xs={11}>
                              <Typography
                                style={{
                                  margin: '0 10px 0 10px',
                                  fontSize: '0.8rem',
                                  color: 'grey',
                                }}
                              >
                                {'Email'}
                              </Typography>
                              <Typography style={{ margin: '0 10px 0 10px' }}>
                                {profile.email}
                              </Typography>
                            </Grid>
                          </Grid>
                          <Grid container style={{ marginTop: '10px' }}>
                            <Grid item xs={1}>
                              <AccountBoxOutlinedIcon />
                            </Grid>
                            <Grid item xs={11}>
                              <Typography
                                style={{
                                  margin: '0 10px 0 10px',
                                  fontSize: '0.8rem',
                                  color: 'grey',
                                }}
                              >
                                {t('area')}
                              </Typography>
                              <Typography style={{ margin: '0 10px 0 10px' }}>
                                {responsible.resp_area || '-'}
                              </Typography>
                            </Grid>
                          </Grid>
                        </CardContent>
                      </Card>
                    </Grid>
                  );
                })}
              </Content>
            </div>
          </TabPanel>
          <TabPanel value={tabIndex} index={1}>
            <div>
              <Content className={classes.contentCardStyle}>
                {funcResponsibles?.map((responsible, index: number) => {
                  let profile = { displayName: '', picture: '', email: '' };
                  let splitName = [' ', ' '];

                  if (
                    responsible.entity &&
                    responsible.entity.spec &&
                    responsible.entity.spec?.profile
                  ) {
                    profile = responsible.entity.spec?.profile;
                    splitName = profile.displayName.split(' ');
                  } else {
                    profile.email = responsible.responsible
                      ?.replace('user:', '')
                      .replace('_', '@');
                  }

                  return (
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={4}
                      key={index}
                      style={{
                        maxWidth: 'none',
                        minWidth: '374px',
                        flexBasis: 'calc(10% - 10px)',
                      }}
                    >
                      <Card
                        variant="outlined"
                        style={{
                          boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
                          width: '374px',
                          height: '280px',
                        }}
                      >
                        {/* <CardHeader
                          title={t(
                            `mapfresolution.responsibles.${responsible.team}`,
                          )}
                        /> */}
                        <CardContent>
                          <Grid container spacing={2} alignItems="center">
                            <Grid item xs={4} style={{ paddingRight: '0' }}>
                              <Avatar
                                sx={{
                                  bgcolor: 'gray',
                                  width: 100,
                                  height: 100,
                                }}
                                src={profile.picture}
                              >
                                <Typography2 sx={{ fontSize: 24 }}>{`${
                                  splitName[0][0]
                                }${
                                  splitName.length > 1 && splitName[1][0]
                                }`}</Typography2>
                              </Avatar>
                            </Grid>
                            <Grid item xs={8} style={{ padding: '0' }}>
                              <EntityRefLink
                                entityRef={
                                  responsible.entity ?? responsible.ref ?? ''
                                }
                                defaultKind="user"
                                style={{ fontSize: '18px', color: '#475059' }}
                                title={
                                  responsible.entity
                                    ? profile.displayName
                                    : responsible.responsible?.replace(
                                        'user:',
                                        '',
                                      )
                                }
                              />
                            </Grid>
                          </Grid>
                          <Grid container style={{ marginTop: '20px' }}>
                            <Grid item xs={1}>
                              <MailOutlineIcon />
                            </Grid>
                            <Grid item xs={11}>
                              <Typography
                                style={{
                                  margin: '0 10px 0 10px',
                                  fontSize: '0.8rem',
                                  color: 'grey',
                                }}
                              >
                                {'Email'}
                              </Typography>
                              <Typography style={{ margin: '0 10px 0 10px' }}>
                                {profile.email}
                              </Typography>
                            </Grid>
                          </Grid>
                          <Grid container style={{ marginTop: '10px' }}>
                            <Grid item xs={1}>
                              <AccountBoxOutlinedIcon />
                            </Grid>
                            <Grid item xs={11}>
                              <Typography
                                style={{
                                  margin: '0 10px 0 10px',
                                  fontSize: '0.8rem',
                                  color: 'grey',
                                }}
                              >
                                {t('area')}
                              </Typography>
                              <Typography style={{ margin: '0 10px 0 10px' }}>
                                {responsible.resp_area || '-'}
                              </Typography>
                            </Grid>
                          </Grid>
                        </CardContent>
                      </Card>
                    </Grid>
                  );
                })}
              </Content>
            </div>
          </TabPanel>
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  const documentationTab = (
    <EntityLayout.Route
      path="/documentation"
      title={t('mapfresolution.tabs.documentation')}
    >
      <Grid container spacing={3}>
        <Container
          maxWidth="md"
          style={{ margin: '0px', width: '100%', maxWidth: 'none' }}
        >
          <Card style={{ padding: '20px' }}>
            <Card className={classes.containerStyle}>
              <Box
                style={{
                  height: '100%',
                }}
              >
                <CardContent>
                  <DescriptionIcon />
                </CardContent>
              </Box>
              <Box style={{ width: '100%' }}>
                <CardContent>
                  <ContentHeader
                    title={t('mapfresolution.documentation.label').toString()}
                  />
                </CardContent>
                {(entity.metadata.documentation as string[]).length === 0 && (
                  <Card className={classes.insideCardStyle}>
                    <CardContent>
                      <Typography
                        style={{
                          margin: 0,
                          fontWeight: 400,
                          fontSize: '0.875rem',
                          letterSpacing: '0.01071em',
                          display: 'block',
                        }}
                      >
                        {t('mapfresolution.documentation.empty')}
                      </Typography>
                    </CardContent>
                  </Card>
                )}
                {(entity.metadata.documentation as string[]).length > 0 && (
                  <Card className={classes.insideCardStyle}>
                    <List
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '10px',
                      }}
                    >
                      {(entity.metadata.documentation as string[]).map(
                        (value, i) => {
                          const labelId = `file-list-label-${i}`;
                          return (
                            <>
                              {i > 0 && <Divider />}
                              <ListItem
                                key={i}
                                role={undefined}
                                dense
                                className={classes.listItemStyle}
                              >
                                <ListItemText
                                  id={labelId}
                                  primary={(value as string)?.split('/').pop()}
                                />
                                <div
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    cursor: 'pointer',
                                    color: '#D81E05',
                                  }}
                                  onClick={() => downloadFile(value)}
                                >
                                  <ListItemIcon
                                    style={{
                                      display: 'flex',
                                      justifyContent: 'end',
                                    }}
                                  >
                                    <FileDownloadIcon
                                      className={classes.icon}
                                    />
                                  </ListItemIcon>
                                  <span
                                    style={{
                                      marginLeft: '8px',
                                    }}
                                  >
                                    {t('Download')}
                                  </span>
                                </div>
                              </ListItem>
                            </>
                          );
                        },
                      )}
                    </List>
                  </Card>
                )}
              </Box>
            </Card>
          </Card>
        </Container>
      </Grid>
    </EntityLayout.Route>
  );

  const historyLogTab = (
    <EntityLayout.Route path="/history-log" title={t('History Log')}>
      <ChangelogCard />
    </EntityLayout.Route>
  );

  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const contact = entity.metadata.contact as any;
    setTo(
      [
        ...(contact.contact_mail1 ? [contact.contact_mail1] : []),
        ...(contact.contact_mail2 ? [contact.contact_mail2] : []),
      ].join(', '),
    );
  }, [entity]);

  function validate() {
    const valid =
      to &&
      message &&
      to
        .replaceAll(' ', '')
        .split(',')
        .every(email => {
          console.log(email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/));
          return email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
        });
    return valid;
  }

  const contactTab = (
    <EntityLayout.Route
      path="/contact"
      title={t('mapfresolution.contact.title')}
    >
      <div style={{ maxWidth: '600px', padding: '30px' }}>
        <Typography
          variant="body1"
          className={classes.textStyle}
          style={{ marginBottom: '20px' }}
        >
          {t('mapfresolution.contact.title')}
        </Typography>
        <Typography style={{ marginBottom: '20px' }}>
          {t('mapfresolution.contact.info')}
        </Typography>
        <TextField
          fullWidth
          required
          autoFocus
          size="small"
          helperText={t('mapfresolution.contact.emails.helper')}
          variant="outlined"
          label={t('mapfresolution.contact.emails.label')}
          name="emails"
          value={to}
          onChange={e => {
            setTo(e.target.value);
          }}
          style={{ marginBottom: '20px' }}
        />
        <TextField
          fullWidth
          required
          autoFocus
          size="small"
          multiline
          minRows={6}
          helperText={t('mapfresolution.contact.message.helper')}
          variant="outlined"
          label={t('mapfresolution.contact.message.label')}
          name="message"
          value={message}
          onChange={e => {
            setMessage(e.target.value);
          }}
          style={{ marginBottom: '20px' }}
        />
        <Button
          variant="outlined"
          color="secondary"
          disabled={!validate()}
          onClick={async () => {
            emailService.send({
              message: `${message}<br>${entityUrl}`,
              subject: t('mapfresolution.contact.email.subject', {
                env,
                from: profile?.email,
                title: entity.metadata.title,
              }),
              subtitle: t('mapfresolution.contact.email.subtitle', {
                title: entity.metadata.title,
              }),
              title: t('mapfresolution.contact.email.title'),
              to: to.replaceAll(' ', '').split(','),
            });
            const repositoryUrl =
              entity.metadata.annotations![ANNOTATION_LOCATION];
            const catalogInfo = await getCatalogInfo(repositoryUrl, token);
            changelog.push(entity.metadata.name, catalogInfo, {
              files: {},
              desc: 'mapfresolution.historyLog.contact',
              descParams: {
                to,
              },
              modifiedBy: (await identityApi.getProfileInfo()).email ?? '',
            });
            alertApi.post({
              message: 'email sended',
            });
            setMessage('');
          }}
        >
          {t('mapfresolution.contact.send')}
        </Button>
      </div>
    </EntityLayout.Route>
  );

  if (isLoading) {
    return (
      <div className={classes.loading}>
        <CircularProgress
          style={{ width: '100px', height: '100px' }}
          color="primary"
        />
      </div>
    );
  }

  return (
    <SidebarPage>
      {solutionSidebar}
      <EntityLayout>
        {overviewTab}
        {techTab}
        {functionalitiesTab}
        {dependenciesTab}
        {billingTab}
        {moreDataTab}
        {responsibleTab}
        {documentationTab}
        {historyLogTab}
        {contactTab}
      </EntityLayout>
    </SidebarPage>
  );

  async function unRegisterEntity(repository: string) {
    const location = await catalogApi.getLocationByRef(repository);
    if (location) {
      return catalogApi.removeLocationById(location.id);
    }
    throw Error('Missing MapfreApi entity');
  }
}

function TabPanel(props: any) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 1 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
