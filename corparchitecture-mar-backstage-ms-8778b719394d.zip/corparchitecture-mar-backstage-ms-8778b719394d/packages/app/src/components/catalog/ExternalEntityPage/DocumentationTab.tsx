import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DescriptionIcon from '@mui/icons-material/Description';
import {
  alertApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { useEntity } from '@backstage/plugin-catalog-react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { ContentHeader, EmptyState } from '@backstage/core-components';
import { makeStyles } from '@material-ui/core/styles';
import LinearProgress from '@material-ui/core/LinearProgress';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import { Divider, Typography } from '@material-ui/core';

export function DocumentationTab({
  title,
  path,
}: {
  title: string;
  path: string;
}): JSX.Element {
  const useStyles = makeStyles({
    containerStyle: {
      margin: '20px 0px 20px 0px',
      width: '100%',
      display: 'flex',
      flexDirection: 'row',
      boxShadow: 'none',
    },
    insideCardStyle: {
      width: '100%',
      boxShadow: 'none',
    },
    icon: {
      cursor: 'pointer',
      color: '#D81E05',
    },
    listItemStyle: {
      display: 'flex',
      justifyContent: 'space-between',
    },
  });
  const classes = useStyles();
  //const [fileRecord, setFileRecord] = useState<Record<string, unknown>[]>();
  const [isLoading, setIsLoading] = useState(true);
  const { entity } = useEntity();
  const annotations = entity.metadata.annotations;
  const docs: string[] = [];
  const { t } = useTranslation();
  const identityApi = useApi(identityApiRef);
  const alertApi = useApi(alertApiRef);

  for (const key in annotations) {
    if (key.startsWith(path)) {
      if (annotations[key]) {
        docs.push(annotations[key]);
      }
    }
  }

  useEffect(() => {
    async function fetchData() {
      try {
        //const allItems = await getPublicFileList();
        //setFileRecord(allItems);
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, [entity, identityApi, alertApi, t]);

  async function getPublicFileList() {
    const { token } = await identityApi.getCredentials();
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const url = new URL(
      `/api/external-docs/public-files/${bucket}/${repository}/${encodeURIComponent(
        path,
      )}`,
      window.location.origin.replace('3000', '7007'),
    );
    const headers = new Headers();
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    const request = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    try {
      const response = await fetch(request);
      if (!response.ok) {
        if (response.status !== 404) {
          alertApi.post({
            message: t('Directory does not exist.') as string,
            severity: 'info',
          });
        }
        return;
      }
      const values: Record<string, unknown>[] = await response.json();
      return values;
    } catch (error) {
      console.error(error);
      return;
    }
  }

  async function downloadPublicFile(file: string) {
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const folder = `${encodeURIComponent(file.replace('./', ''))}`;

    const url = new URL(
      `/api/external-docs/download/${bucket}/${repository}/${folder}`,
      window.location.origin.replace('3000', '7007'),
    );
    window?.open(url, '_blank')?.focus();
  }

  return (
    <Card className={classes.containerStyle}>
      <Box
        style={{
          height: '100%',
        }}
      >
        <CardContent>
          <DescriptionIcon />
        </CardContent>
      </Box>
      <Box style={{ width: '100%' }}>
        <CardContent>
          <ContentHeader
            title={t(title) !== null ? (t(title) as string) : undefined}
          />
        </CardContent>
        {isLoading ? (
          <LinearProgress />
        ) : docs && docs?.length > 0 ? (
          <Card className={classes.insideCardStyle}>
            <Box>
              <List>
                {docs?.map((value, i) => {
                  const labelId = `file-list-label-${i}`;
                  return (
                    <>
                      {i > 0 && <Divider />}
                      <ListItem
                        key={i}
                        role={undefined}
                        dense
                        className={classes.listItemStyle}
                      >
                        <ListItemText
                          id={labelId}
                          primary={(value as string)?.split('/').pop()}
                        />
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            cursor: 'pointer',
                            color: '#D81E05',
                          }}
                          onClick={() => downloadPublicFile(value as string)}
                        >
                          <ListItemIcon
                            style={{
                              display: 'flex',
                              justifyContent: 'end',
                            }}
                          >
                            <FileDownloadIcon className={classes.icon} />
                          </ListItemIcon>
                          <span
                            style={{
                              marginLeft: '8px',
                            }}
                          >
                            {t('Download')}
                          </span>
                        </div>
                      </ListItem>
                    </>
                  );
                })}
              </List>
            </Box>
          </Card>
        ) : (
          <Card className={classes.insideCardStyle}>
            {/* <div className={classes.containerStyle}>
              <EmptyState
                missing="info"
                title={t('No documentation is provided')}
              />
            </div> */}
            <CardContent>
              <Typography
                style={{
                  margin: 0,
                  fontWeight: 400,
                  fontSize: '0.875rem',
                  letterSpacing: '0.01071em',
                  display: 'block',
                }}
              >
                {t('mapfresolution.documentation.empty')}
              </Typography>
            </CardContent>
            {/* <div className={classes.containerStyle}>
              <span></span>
            </div> */}
          </Card>
        )}
      </Box>
    </Card>
  );
}
