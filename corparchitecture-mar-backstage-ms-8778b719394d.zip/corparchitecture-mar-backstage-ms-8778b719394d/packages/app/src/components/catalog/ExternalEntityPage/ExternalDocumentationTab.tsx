import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import {
  alertApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { useEntity } from '@backstage/plugin-catalog-react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import {
  ContentHeader,
  EmptyState,
  MarkdownContent,
} from '@backstage/core-components';
import { makeStyles } from '@material-ui/core/styles';
import LinearProgress from '@material-ui/core/LinearProgress';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import { Button, Input } from '@material-ui/core';
import styled from '@emotion/styled';
pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

export function ExternalDocumentationTab() {
  const useStyles = makeStyles({
    containerStyle: { width: '100%', height: '100vh', marginLeft: 20 },
    icon: {
      cursor: 'pointer',
    },
  });
  const classes = useStyles();
  const [fileRecord, setFileRecord] = useState<Record<string, unknown>[]>();
  const [isLoading, setIsLoading] = useState(true);
  const { entity } = useEntity();
  const { t } = useTranslation();
  const identityApi = useApi(identityApiRef);
  const alertApi = useApi(alertApiRef);
  const annotations = entity.metadata.annotations;
  const publicDocs: string[] = [];
  const [, setLoadingPercentage] = useState<number>(0);
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [fileNameExtension, setFileNameExtension] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [title, setTitle] = useState<string | null>('');
  const isFirstPage = pageNumber === 1;
  const isLastPage = pageNumber === numPages;

  for (const key in annotations) {
    if (key.startsWith('public') && key !== 'public1') {
      if (annotations[key]) {
        publicDocs.push(annotations[key]);
      }
    }
  }

  useEffect(() => {
    async function fetchData() {
      try {
        setTitle(t('Documents'));
        const allItems = await getPublicFileList();
        setFileRecord(allItems);

        const fileName = entity.metadata?.annotations?.public1;
        if (fileName) {
          setFileName(fileName);

          const fileNameExtension = fileName.substring(
            fileName.lastIndexOf('.') + 1,
          );
          setFileNameExtension(fileNameExtension);
          const fileContent = await getPublicFile(fileName);

          if (fileNameExtension.includes('md')) {
            setFileContent(fileContent as string);
          } else {
            if (fileNameExtension.includes('pdf') && fileContent) {
              setFileContent('data:application/pdf;base64,' + fileContent);
            }
          }
        }
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, [entity, identityApi, alertApi, t]);

  const PDFDocumentWrapper = styled.div`
    canvas {
      width: 100% !important;
      height: auto !important;
    }
  `;

  const goToPreviousPage = () => {
    if (!isFirstPage) {
      const button = document.getElementById('prevButton') as HTMLButtonElement;
      button.disabled = true;
      setPageNumber(pageNumber - 1);
      setTimeout(() => {
        button.disabled = false;
      }, 500);

      if (pageNumber <= 2) {
        button.disabled = true;
      }
    }
  };
  const goToNextPage = () => {
    if (!isLastPage) {
      const button = document.getElementById('nextButton') as HTMLButtonElement;
      button.disabled = true;
      setPageNumber(pageNumber + 1);
      setTimeout(() => {
        button.disabled = false;
      }, 500);

      if (pageNumber >= numPages) {
        button.disabled = true;
      }
    }
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onPageChange = (e: { target: { value: any } }) => {
    const { value } = e.target;
    setPageNumber(Number(value));
  };

  function download() {
    downloadPublicFile(fileName);
  }

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    setLoadingPercentage(0);
    setNumPages(numPages);
  };

  async function getPublicFileList() {
    const { token } = await identityApi.getCredentials();
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const folder = 'doc%2fpublic';
    const url = new URL(
      `/api/external-docs/public-files/${bucket}/${repository}/${folder}`,
      window.location.origin.replace('3000', '7007'),
    );
    const headers = new Headers();
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    const request = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    try {
      const response = await fetch(request);
      if (!response.ok) {
        if (response.status !== 404) {
          alertApi.post({
            message: t('Directory does not exist.') as string,
            severity: 'info',
          });
        }
        return;
      }
      const values: Record<string, unknown>[] = await response.json();
      return values;
    } catch (error) {
      console.error(error);
      return;
    }
  }

  async function downloadPublicFile(file: string) {
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const folder = `${encodeURIComponent(file.replace('./', ''))}`;
    const url = new URL(
      `/api/external-docs/download/${bucket}/${repository}/${folder}`,
      window.location.origin.replace('3000', '7007'),
    );

    window?.open(url, '_blank')?.focus();
  }

  async function getPublicFile(file: string) {
    const repoUrl = entity.metadata.annotations?.[
      'backstage.io/view-url'
    ] as string;
    const bucket = repoUrl.split('/')[2].split('.')[0];
    const repository = repoUrl.split('/')[3];
    const url = new URL(
      `/api/external-docs/public-files/get-file/${bucket}/${repository}/${encodeURIComponent(
        file,
      )}`,
      window.location.origin.replace('3000', '7007'),
    );

    const method = 'GET';
    const headers = new Headers();
    const request = new Request(url.toString(), {
      method,
      headers,
    });

    const res = await fetch(request);

    return await res.text();
  }

  if (isLoading) {
    return <LinearProgress />;
  }

  return fileRecord || (annotations && annotations?.public1) ? (
    <Card>
      <CardContent>
        {fileNameExtension ? (
          <Card>
            {fileNameExtension.includes('md') ? (
              <MarkdownContent
                content={fileContent as string}
              ></MarkdownContent>
            ) : (
              <section id="pdf-section">
                <div>
                  <Button
                    id="prevButton"
                    variant="contained"
                    size="small"
                    color="default"
                    style={{
                      margin: '5px',
                    }}
                    disabled={pageNumber <= 1}
                    onClick={goToPreviousPage}
                  >
                    Previous
                  </Button>
                  <span>
                    Page{' '}
                    <Input
                      name="pageNumber"
                      inputProps={{
                        size: '1',
                      }}
                      value={pageNumber}
                      onChange={onPageChange}
                    />{' '}
                    of {numPages}
                  </span>
                  <Button
                    id="nextButton"
                    variant="contained"
                    size="small"
                    color="default"
                    style={{
                      margin: '5px',
                    }}
                    disabled={pageNumber >= numPages}
                    onClick={goToNextPage}
                  >
                    Next
                  </Button>
                  <Button
                    variant="contained"
                    color="default"
                    size="small"
                    style={{
                      margin: '5px',
                    }}
                    onClick={download}
                  >
                    Download
                  </Button>
                </div>
                <CardContent>
                  <Card>
                    <PDFDocumentWrapper>
                      <Document
                        externalLinkTarget="_blank"
                        options={{
                          cMapUrl: 'cmaps/',
                          cMapPacked: true,
                        }}
                        file={fileContent || undefined}
                        onLoadSuccess={onDocumentLoadSuccess}
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        onLoadError={(error: any) => console.log(error)}
                        loading="Loading Please Wait..."
                      >
                        <Page
                          pageNumber={pageNumber}
                          renderAnnotationLayer={false}
                          renderTextLayer={false}
                        />
                      </Document>
                    </PDFDocumentWrapper>
                  </Card>
                </CardContent>
              </section>
            )}
          </Card>
        ) : (
          <></>
        )}
      </CardContent>
      <Box>
        <List>
          {publicDocs && publicDocs?.length > 0 && (
            <CardContent>
              <ContentHeader title={title !== null ? title : undefined} />
            </CardContent>
          )}
          {fileRecord
            ?.filter(value => publicDocs.includes(value?.path as string))
            .map((value, i) => {
              const labelId = `file-list-label-${i}`;
              return (
                <ListItem key={i} role={undefined} dense>
                  <ListItemIcon>
                    <FileDownloadIcon
                      onClick={() => downloadPublicFile(value?.path as string)}
                      className={classes.icon}
                    />
                  </ListItemIcon>
                  <ListItemText
                    id={labelId}
                    primary={(value?.path as string)?.split('/').pop()}
                  />
                </ListItem>
              );
            })}
        </List>
      </Box>
    </Card>
  ) : (
    <div className={classes.containerStyle}>
      <EmptyState missing="info" title={t('No documentation is provided')} />
    </div>
  );
}
