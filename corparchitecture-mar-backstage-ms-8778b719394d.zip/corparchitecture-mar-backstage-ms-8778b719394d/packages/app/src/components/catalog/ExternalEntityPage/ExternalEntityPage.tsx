import {
  Header,
  MarkdownContent,
  Page,
  TabbedLayout,
} from '@backstage/core-components';
import { EntityApiDefinitionCard } from '@backstage/plugin-api-docs';
import { useEntity } from '@backstage/plugin-catalog-react';
import { ExternalAboutCustomCard } from '@internal/plugin-custom-cards';
import { Container, Grid, IconButton } from '@material-ui/core';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { ExternalDocumentationTab } from './ExternalDocumentationTab';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';

const refreshPage = () => {
  window.location.reload();
};

export function ExternalEntityPage() {
  const { t } = useTranslation();
  const { entity } = useEntity();
  return (
    <Page themeId={'theme'}>
      <Header
        title={entity?.metadata?.title as string}
        style={{ width: 'fit-content' }}
      >
        <IconButton
          aria-label="Return"
          title="Return to previous view"
          onClick={refreshPage}
          style={{ marginLeft: '3em', marginBottom: '0.5em' }}
        >
          <ExitToAppIcon />
        </IconButton>
      </Header>

      <TabbedLayout>
        <TabbedLayout.Route path="/" title={t('Overview')}>
          <Grid container spacing={3}>
            <Container maxWidth="md">
              <ExternalAboutCustomCard />
            </Container>
          </Grid>
        </TabbedLayout.Route>
        <TabbedLayout.Route path="/specifications" title={t('Specifications')}>
          <Grid container spacing={3}>
            <EntityApiDefinitionCard />
          </Grid>
        </TabbedLayout.Route>
        <TabbedLayout.Route path="/documentation" title={t('Documentation')}>
          <Grid container spacing={3}>
            <Container maxWidth="md">
              <ExternalDocumentationTab />
            </Container>
          </Grid>
        </TabbedLayout.Route>
        <TabbedLayout.Route path="/changelog" title={t('Changelog')}>
          <Grid container spacing={3}>
            <Container maxWidth="md">
              <>
                {entity.metadata?.annotations &&
                entity.metadata?.annotations?.isMigratedFunctional === 'true'
                  ? entity.metadata?.annotations &&
                    entity.metadata?.annotations?.functional && (
                      <div
                        dangerouslySetInnerHTML={{
                          __html: entity.metadata?.annotations?.functional,
                        }}
                      ></div>
                    )
                  : entity.metadata?.annotations &&
                    entity.metadata?.annotations?.functional && (
                      <Card>
                        <CardContent>
                          <MarkdownContent
                            content={entity.metadata?.annotations?.functional}
                          ></MarkdownContent>
                        </CardContent>
                      </Card>
                    )}
              </>
            </Container>
          </Grid>
        </TabbedLayout.Route>
      </TabbedLayout>
    </Page>
  );
}
