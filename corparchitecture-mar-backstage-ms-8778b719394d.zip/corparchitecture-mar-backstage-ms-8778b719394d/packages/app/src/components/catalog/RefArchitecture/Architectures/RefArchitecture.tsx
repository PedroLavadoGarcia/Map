import React, { useEffect } from 'react';
import {
  Content,
  CreateButton,
  TableFilter,
  TableProps,
  Button,
} from '@backstage/core-components';
import { useRouteRef } from '@backstage/core-plugin-api';
import {
  CatalogFilterLayout,
  EntityKindPicker,
  EntityListProvider,
  useEntity,
} from '@backstage/plugin-catalog-react';
import Star from '@material-ui/icons/Star';
import PinchIcon from '@mui/icons-material/Pinch';
import StarBorder from '@material-ui/icons/StarBorder';
import {
  useStarredEntities,
  EntityTypePicker,
} from '@backstage/plugin-catalog-react';
import {
  CatalogTable,
  CatalogTableRow,
  catalogPlugin,
  EntityLayout,
} from '@backstage/plugin-catalog';
import { Box, Card, Grid } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import { refArchColumn } from '../../../columns/archColumns';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { useTranslation } from 'react-i18next';
import { entityRefreshMenuButton } from '../../EntityRefreshMenuButton/entityRefreshMenuButton';
import Timeline from '@mui/lab/Timeline';
import TimelineConnector from '@mui/lab/TimelineConnector';
import TimelineContent from '@mui/lab/TimelineContent';
import TimelineDot from '@mui/lab/TimelineDot';
import TimelineItem from '@mui/lab/TimelineItem';
import TimelineOppositeContent from '@mui/lab/TimelineOppositeContent';
import TimelineSeparator from '@mui/lab/TimelineSeparator';
import ButtonMUI from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Masonry from '@mui/lab/Masonry';
import GridViewIcon from '@mui/icons-material/Add';
import CodeIcon from '@mui/icons-material/Code';
import ScatterPlotIcon from '@mui/icons-material/ScatterPlot';
import AutoFixHighIcon from '@mui/icons-material/AutoFixHigh';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { Scenarios } from './Scenarios';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@material-ui/core';

import { makeStyles } from '@material-ui/core/styles';

const itemData = [
  {
    name: 'Backend Archetype',
    link: '/catalog/default/refarch/arqref_backend/archetype',
    types: 'backend',
    height: 90,
  },
  {
    name: 'BFF Archetype',
    link: '/catalog/default/refarch/arqref_bff/archetype',
    types: 'backend',
    height: 90,
  },
  {
    name: 'SPA Archetype',
    link: '/docs/default/component/SPA',
    types: 'front',
    height: 90,
  },
  {
    name: 'SSR Archetype',
    link: '/docs/default/component/SSR',
    types: 'front',
    height: 90,
  },
  {
    name: 'MFE Archetype',
    link: '/docs/default/component/MFE',
    types: 'front',
    height: 90,
  },
  {
    name: 'LIB Archetype',
    link: '/docs/default/component/LIB',
    types: 'front',
    height: 90,
  },
  {
    name: 'PWA Archetype',
    link: '/docs/default/component/PWA',
    types: 'front',
    height: 90,
  },
];

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(0.5),
  textAlign: 'center',
  justifyContent: 'center',
  display: 'flex',
  alignItems: 'normal',
  verticalAlign: 'middle',
  flexDirection: 'column',
}));
const YellowStar = withStyles({
  root: {
    color: '#f3ba37',
  },
})(Star);

const theme3 = createTheme({
  palette: {
    primary: {
      main: '#DB271C',
    },
  },
});

const useStyles = makeStyles(() => ({
  content: {
    overflowY: 'auto',
  },
}));

export default function BasicMasonry() {
  return (
    <Box>
      <Masonry columns={3} spacing={2}>
        {itemData.map((height, index) =>
          `${height.types}` === 'backend' ? (
            <Item key={index} sx={height}>
              <Button
                variant="text"
                color="secondary"
                to={`${height.link}`}
                align="center"
                style={{ margin: 'auto', fontWeight: 'bold' }}
              >
                {`${height.name}`}
              </Button>
              <Typography variant="caption" color="inherit">
                {'Backend'}
              </Typography>
            </Item>
          ) : (
            <Item key={index} sx={{ height }}>
              <Button
                variant="text"
                color="secondary"
                to={`${height.link}`}
                style={{ margin: 'auto', fontWeight: 'bold' }}
              >
                {`${height.name}`}
              </Button>
              <Typography variant="caption" color="inherit">
                {'Frontend'}
              </Typography>
            </Item>
          ),
        )}
        <Item sx={{ height: 90 }}>
          <Button
            variant="text"
            color="secondary"
            to={
              '/create?filters[kind]=template&filters[user]=all&filters[type]=ref_architecture&filters[type]=front&filters[type]=documentation'
            }
            style={{ margin: 'auto', fontWeight: 'bold' }}
          >
            {`View More`}
          </Button>
          <Typography variant="caption" color="inherit">
            {''}
          </Typography>
        </Item>
      </Masonry>
    </Box>
  );
}

export function ScrollableModal({
  path,
  buttonText,
}: {
  path: string;
  buttonText: string;
}) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const encodedButtonText = encodeURIComponent(buttonText);

  const openDialogIfHashExists = () => {
    // Check if the specific hash exists in the URL
    if (window.location.hash === `#${encodedButtonText}`) {
      setOpen(true);
    }
  };

  useEffect(() => {
    // Call the function when the component mounts
    openDialogIfHashExists();

    // Add a hash change event listener to check for hash changes
    const handleHashChange = () => {
      openDialogIfHashExists();
    };

    window.addEventListener('hashchange', handleHashChange);

    // Clean up the event listener when the component unmounts
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []); // Empty dependency array ensures that the effect runs only once on mount

  const handleClickOpen = () => {
    window.history.pushState(null, '', `#${encodedButtonText}`);
    setOpen(true);
  };
  const handleClose = () => {
    window.history.pushState(null, '', window.location.pathname);
    setOpen(false);
  };
  return (
    <div>
      <ThemeProvider theme={theme3}>
        <ButtonMUI
          id={encodedButtonText}
          variant="contained"
          color="primary"
          onClick={handleClickOpen}
          endIcon={<PinchIcon />}
          href={`#${encodedButtonText}`}
          sx={{
            width: 'auto',
            maxWidth: '50%',
            margin: '2%',
            '&:hover': {
              backgroundColor: '#5DBB63', // Change the background color on hover
            },
            '&:active': {
              backgroundColor: '#5DBB63', // Change the background color on active
            },
            '&:focus': {
              outline: 'none', // Remove the focus outline
              boxShadow: '0 0 0 3px rgba(0, 123, 255, 0.5)', // Add a custom focus style
            },
          }}
        >
          {buttonText}
        </ButtonMUI>
      </ThemeProvider>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        maxWidth="xl"
      >
        <DialogTitle id="scroll-dialog-title">{buttonText}</DialogTitle>
        <DialogContent dividers className={classes.content}>
          <Grid container spacing={2} alignItems="flex-start">
            <Grid item xs={12}>
              <Card>
                <TechDocsCardContent path={path} withTitle={false} />
              </Card>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <ButtonMUI onClick={handleClose} color="primary">
            Close
          </ButtonMUI>
        </DialogActions>
      </Dialog>
    </div>
  );
}

const refArchColumns = [
  CatalogTable.columns.createNameColumn({ defaultKind: 'template' }),
  refArchColumn.createTypeColumn({ hidden: true }),
];
export interface CatalogPageProps {
  actions?: TableProps<CatalogTableRow>['actions'];
  initialKind?: string;
  tableOptions?: TableProps<CatalogTableRow>['options'];
  filters?: TableFilter;
}

export function RefArchitecture({
  actions,
  initialKind = 'RefArch',
  tableOptions = {
    showTitle: false,
    search: false,
    header: true,
    toolbar: false,
    padding: 'dense',
    sorting: true,
    thirdSortClick: false,
  },
}: CatalogPageProps) {
  const createComponentLink = useRouteRef(
    catalogPlugin.externalRoutes.createComponent,
  );
  const { entity } = useEntity();
  const { isStarredEntity, toggleStarredEntity } = useStarredEntities();
  const { t } = useTranslation();
  const general = entity.metadata?.general as Record<string, unknown>;
  const quickstart = general.quickstart as Record<string, string>;

  actions = [
    ({ entity }) => {
      const isStarred = isStarredEntity(entity);
      const title = isStarred ? 'Remove from favorites' : 'Add to favorites';

      return {
        cellStyle: { paddingLeft: '1em' },
        icon: () => (
          <>
            <Typography variant="srOnly">{title}</Typography>
            {isStarred ? <YellowStar /> : <StarBorder />}
          </>
        ),
        tooltip: title,
        onClick: () => toggleStarredEntity(entity),
      };
    },
  ];

  useEffect(() => {
    document
      .querySelector('main > header > div > p[class*=MuiTypography-body1]')
      ?.remove();
    const sortButton = document.querySelector(
      '[class*=MuiTableSortLabel]',
    ) as HTMLInputElement;
    sortButton?.click();
    const columnNames = document.querySelectorAll('[class*=MuiTableSortLabel]');
    let cellText: string | null | undefined = '';
    columnNames.forEach(function (item) {
      if (item) {
        cellText = item.firstChild?.textContent;
        if (item.firstChild) {
          if (cellText === 'Name') {
            item.firstChild.textContent = t(`${'Architectures'}`);
          } else {
            item.firstChild.textContent = t(`${cellText}`);
          }
        }
      }
    });
    const title = document.querySelector(
      'main > header > div > h1 > div > span',
    );
    const text: string | null | undefined = title?.textContent;
    if (text && title) title.textContent = t(`${text}`);
  }, [document]);

  function RefArchsGeneralTabs({
    entityItemName,
  }: {
    entityItemName: string;
  }): JSX.Element {
    return (
      <EntityListProvider>
        <Content>
          <CatalogFilterLayout>
            <EntityKindPicker initialFilter={initialKind} hidden={true} />
            <EntityTypePicker
              initialFilter={'ref_architecture'}
              hidden={true}
            />
            <Grid container spacing={2} alignItems="stretch">
              {entityItemName === 'blueprint' && (
                <Grid item xs={9}>
                  {(general?.blueprint as Record<string, string>)?.title &&
                    (general?.blueprint as Record<string, string>)?.path && (
                      <Card>
                        <TechDocsCardContent path={''} withTitle={false} />
                      </Card>
                    )}
                </Grid>
              )}
              {entityItemName === 'quickstart' && (
                <Grid item xs={9}>
                  {(general?.quickstart as Record<string, string>)?.title &&
                    (general?.quickstart as Record<string, string>)?.path && (
                      <Card>
                        <TechDocsCardContent
                          path={quickstart?.path}
                          withTitle={false}
                        />
                      </Card>
                    )}
                </Grid>
              )}
              <Grid item xs={3}>
                <Box
                  sx={{
                    position: 'sticky',
                    display: 'block',
                    top: '0',
                  }}
                >
                  <CatalogTable
                    columns={refArchColumns}
                    actions={actions}
                    tableOptions={tableOptions}
                  />
                  <Box sx={{ marginTop: '25px' }}>
                    <CreateButton
                      title={t('Create component')}
                      to={createComponentLink && createComponentLink()}
                    />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </CatalogFilterLayout>
        </Content>
      </EntityListProvider>
    );
  }

  return (
    <EntityListProvider>
      <EntityLayout
        UNSTABLE_extraContextMenuItems={[entityRefreshMenuButton()]}
      >
        <EntityLayout.Route path="/blueprint" title="Blueprint">
          <RefArchsGeneralTabs entityItemName="blueprint" />
        </EntityLayout.Route>

        <EntityLayout.Route path="/quickstart" title="Quick start">
          <RefArchsGeneralTabs entityItemName="quickstart" />
        </EntityLayout.Route>

        <EntityLayout.Route path="/scenarios" title={t('Use Cases')}>
          <Scenarios />
        </EntityLayout.Route>
      </EntityLayout>
    </EntityListProvider>
  );
}
