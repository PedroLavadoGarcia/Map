import React, { useEffect } from 'react';
import { useNavigate, useOutlet } from 'react-router';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import {
  makeStyles,
  Card,
  CardActions,
  CardContent,
  Typography,
  Button,
  CardHeader,
  Grid,
  Box,
} from '@material-ui/core';
import { useEntity } from '@backstage/plugin-catalog-react';
import { EntityLayout } from '@backstage/plugin-catalog';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { useTranslation } from 'react-i18next';
import { entityRefreshMenuButton } from '../../EntityRefreshMenuButton/entityRefreshMenuButton';
import { Content } from '@backstage/core-components';
import { RefArchButtons } from '@internal/plugin-custom-cards/src/components/RefArchButtons/RefArchButtons';

const useStyles = makeStyles(() => ({
  container: {
    margin: '0px -24px 8px -24px',
    textAlign: 'justify',
    overflow: 'hidden',
  },
  button: {
    marginLeft: -8,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  icon: {
    filter:
      'invert(100%) sepia(0%) saturate(7440%) hue-rotate(314deg) brightness(110%) contrast(101%)',
    opacity: 0.5,
  },

  card: {
    height: '500px',
  },
  description: {
    margin: '50px 24px 0 24px',
    textAlign: 'justify',
    height: '300px',
    '&:hover': {
      overflowX: 'hidden',
      '&::-webkit-scrollbar': {
        width: '0',
      },
    },
  },
}));

export function Transversal() {
  const { t } = useTranslation();
  const outlet = useOutlet();
  const classes = useStyles();
  const { entity } = useEntity();
  const transversalDocs = entity.metadata?.transversalDocs as Array<
    Record<string, string>
  >;
  const docsButton = entity.metadata?.docsButton as boolean;
  const config = useApi(configApiRef);
  const backendBaseUrl = config.getString('backend.baseUrl');
  const navigate = useNavigate();

  useEffect(() => {
    document.querySelector('[class^="MuiTabs"]')?.remove();
    document
      .querySelector('main > header > div > p[class*=MuiTypography-body1]')
      ?.remove();
  }, [document.body]);
  return (
    outlet || (
      <EntityLayout
        UNSTABLE_extraContextMenuItems={[entityRefreshMenuButton()]}
      >
        <EntityLayout.Route path="" title="">
          <Content>
            <Grid container spacing={3} alignItems="stretch">
              <Grid item xs={12}>
                <RefArchButtons withTechDocsButton={docsButton} />
              </Grid>
              {transversalDocs?.map((e, idx) => {
                return (
                  <Grid item xs={12} sm={6} md={4} lg={3} key={idx}>
                    <Card className={classes.card}>
                      <CardHeader
                        title={
                          <img
                            src={
                              e.imagePath
                                ? `${backendBaseUrl}/api/techdocs/static/docs/default/${entity.kind}/${entity.metadata.name}/${e.imagePath}`
                                : `/icons/transversal/icon/${e.type}.svg`
                            }
                            height={50}
                            className={classes.icon}
                          />
                        }
                        style={{
                          backgroundImage: e.imagePath
                            ? `url(${backendBaseUrl}/api/techdocs/static/docs/default/${entity.kind}/${entity.metadata.name}/${e.imagePath})`
                            : `url(/icons/transversal/background/${e.type}.svg)`,
                          backgroundSize: 'cover',
                          textAlign: 'center',
                        }}
                      ></CardHeader>
                      <CardContent className={`${classes.container}`}>
                        <Box>
                          <Typography
                            variant="h3"
                            color="inherit"
                            align="center"
                            style={{ marginBottom: '-40px' }}
                          >
                            {`${t(e.title)}`}
                          </Typography>
                        </Box>
                        {!e.description && (
                          <TechDocsCardContent
                            path={e.path}
                            withTitle={false}
                            withSubtitle={false}
                            withImage={false}
                            withLineBreak={false}
                          />
                        )}
                        {e.description && (
                          <Box className={classes.description}>
                            <Typography variant="body2">
                              {e.description}
                            </Typography>
                          </Box>
                        )}
                        ;
                      </CardContent>
                      <CardActions>
                        <Button
                          variant="text"
                          color="primary"
                          onClick={() => {
                            navigate(
                              `/catalog/default/${entity.kind}/${entity.metadata.name}/${e.path}`,
                            );
                          }}
                          classes={{ root: classes.button }}
                        >
                          {t(`Access ${e.title}`)}
                        </Button>
                      </CardActions>
                    </Card>
                  </Grid>
                );
              })}
            </Grid>
          </Content>
        </EntityLayout.Route>
      </EntityLayout>
    )
  );
}
