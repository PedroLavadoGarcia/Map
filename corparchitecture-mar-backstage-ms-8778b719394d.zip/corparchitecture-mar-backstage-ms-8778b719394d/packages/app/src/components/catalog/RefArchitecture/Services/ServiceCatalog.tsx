import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  ButtonBase,
  Card,
  Chip,
  Grid,
  makeStyles,
  Typography,
} from '@material-ui/core';
import { useTranslation } from 'react-i18next';
import ArrowRight from '@material-ui/icons/ArrowRight';
import { useEntity } from '@backstage/plugin-catalog-react';
import { IconTechDocsCardsWithTag } from '@internal/plugin-custom-cards';

import { BackstageTheme } from '@backstage/theme';
import StarIcon from '@material-ui/icons/Star';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { configApiRef, useApi } from '@backstage/core-plugin-api';

export function ServiceCatalog() {
  const { entity } = useEntity();
  const catalogDocs = entity.metadata?.catalogDocs as Array<
    Record<string, string>
  >;
  const { t } = useTranslation();

  const [services, setServices] = useState<Array<Record<string, string>>>([]);
  const [selected, setSelected] = useState('0');
  const [CloudStrategy, setCloudStrategy] = useState(false);
  const [serviceTitle, setServiceTitle] = useState(
    catalogDocs[Number(selected)].typology,
  );
  const [cloud, setCloud] = useState('AWS');
  const isCloudActive = (cloudProvider: string) => {
    return cloud === cloudProvider;
  };
  const config = useApi(configApiRef);
  const backendBaseUrl = config.getString('backend.baseUrl');

  useEffect(() => {
    document
      .querySelector('main > header > div > p[class*=MuiTypography-body1]')
      ?.remove();
    const title = document.querySelector(
      'main > header > div > h1 > div > span',
    );
    const text: string | null | undefined = title?.textContent;
    if (text && title) title.textContent = t(`${text}`);
    document.querySelector('main > div')?.remove();
    handleClick(0);
  }, [document]);
  const useStyles = makeStyles<BackstageTheme>(theme => ({
    box: {
      backgroundColor: 'none',
      opacity: '0.5',
      '& img': {
        width: '80px',
        paddingLeft: '20px',
        paddingTop: '15px',
        paddingBottom: '15px',
        paddingRight: '20px',
      },
      '& svg': {
        opacity: '0',
      },
      '&:hover': {
        opacity: '1 !important',
      },
      '& h3': {
        fontSize: '14px',
        color: '#475059',
      },
      '& h6': {
        fontSize: '14px',
        color: '#475059',
      },
    },
    typologyContent: {
      minWidth: '300px',
      backgroundColor: '#f1f4fa',
      borderRadius: '10px',
      paddingTop: '20px',
      paddingBottom: '20px',
      paddingLeft: '20px',
      marginRight: '-20px',
      '& h3': {
        color: '#475059',
      },
    },
    serviceItemContainer: {
      borderRadius: '10%',
      marginBottom: '14px',
      marginLeft: '50px',
      minWidth: '260px',
      maxWidth: '600px',
    },
    serviceTitle: {
      marginTop: '20px',
    },
    boxSelected: {
      backgroundColor: theme.palette.background.default,
      borderRadius: '24px 0 0 24px',
      '& h6': {
        fontSize: '14px',
        color: theme.palette.text.primary,
      },

      '& svg': {
        opacity: '1',
        color: '#DB271C',
      },
    },
    selected: {
      opacity: 1,

      '& img': {
        width: '80px',
        opacity: 1,
        position: 'static',
        paddingLeft: '20px',
        paddingTop: '15px',
        paddingBottom: '15px',
        paddingRight: '20px',
      },
    },
  }));
  const classes = useStyles();

  function handleClick(idx: number) {
    const filteredServices = catalogDocs[idx].service as unknown as Array<
      Record<string, string>
    >;
    setServices(filteredServices);
    setSelected(String(idx));
  }

  function handleClickCloudStrategy(cloudStrategy: boolean) {
    setCloudStrategy(cloudStrategy);
  }

  const general = entity.metadata?.general as Record<string, unknown>;

  return (
    <>
      <Grid
        container
        xs={12}
        spacing={3}
        justifyContent="center"
        alignItems="stretch"
      >
        <Grid item md={4} lg={3} sm={12} xs={12}>
          <div
            className={`${classes.typologyContent}`}
            style={{ marginBottom: '20px' }}
          >
            <Typography variant={'h3'} style={{ paddingLeft: '20px' }}>
              {t('Cloud Strategy')}
            </Typography>
            <Box>
              <Grid
                item
                justifyContent="space-between"
                xs={12}
                sm={12}
                md={12}
                xl={12}
                style={{
                  textAlign: 'left',
                  alignItems: 'center',
                  marginTop: '20px',
                }}
              >
                <Button
                  disableRipple
                  onClick={() => handleClickCloudStrategy(true)}
                  style={{ justifyContent: 'flex-start', marginLeft: '6px' }}
                >
                  <img
                    src={`/icons/serviceIcons/cloud-computing.png`}
                    style={{ width: '20%' }}
                  />
                  <ArrowRight />
                </Button>
              </Grid>
            </Box>
          </div>
          <div className={`${classes.typologyContent}`}>
            <Typography variant={'h3'} style={{ paddingLeft: '20px' }}>
              {t('Service Typology')}
            </Typography>
            {catalogDocs.map((docs, idx) => {
              return (
                <>
                  <Box
                    className={`${
                      CloudStrategy
                        ? ''
                        : selected === String(idx) && classes.boxSelected
                    }`}
                  >
                    <Grid
                      item
                      justifyContent="space-between"
                      xs={12}
                      sm={12}
                      md={12}
                      xl={12}
                      key={idx}
                      style={{
                        textAlign: 'left',
                        alignItems: 'center',
                        marginTop: '20px',
                      }}
                    >
                      <ButtonBase
                        disableRipple
                        onClick={() => {
                          handleClickCloudStrategy(false);
                          handleClick(idx);
                          setServiceTitle(docs.typology);
                        }}
                        className={`${classes.box} ${
                          selected === String(idx) && classes.selected
                        }`}
                        data-typology
                      >
                        <img
                          src={
                            docs.imagePath
                              ? `${backendBaseUrl}/api/techdocs/static/docs/default/${entity.kind}/${entity.metadata.name}/${docs.imagePath}`
                              : `/icons/typologyIcons/${docs.path}.svg`
                          }
                        />
                        <Typography variant="h6">{t(docs.typology)}</Typography>{' '}
                        <ArrowRight />
                      </ButtonBase>
                    </Grid>
                  </Box>
                </>
              );
            })}
          </div>
        </Grid>
        <Grid item xs sm md={8} lg={9}>
          {CloudStrategy ? (
            <Box
              sx={{
                position: 'sticky',
                display: 'block',
                top: '0',
                marginLeft: '5em',
              }}
            >
              <Typography
                variant="h6"
                align="center"
                style={{ margin: '16px 0' }}
              >
                MAPFRE Cloud Strategy
              </Typography>

              <Grid container spacing={2} alignItems="flex-start">
                <Grid item xs={12}>
                  {(general?.strategy as Record<string, string>)?.title &&
                    (general?.strategy as Record<string, string>)?.path && (
                      <Card>
                        <TechDocsCardContent
                          path={
                            (general?.strategy as Record<string, string>)?.path
                          }
                          withTitle={false}
                        />
                      </Card>
                    )}
                </Grid>
              </Grid>
            </Box>
          ) : (
            <Box
              sx={{
                position: 'sticky',
                display: 'block',
                top: '0',
                marginLeft: '5em',
              }}
            >
              {/* Put a filter */}
              <Typography
                variant={'h3'}
                align="left"
                classes={{ root: classes.serviceTitle }}
              >
                {t('Cloud Providers')}
              </Typography>

              <Grid container spacing={2} style={{ alignItems: 'stretch' }}>
                <Grid item xs={4}>
                  <Button
                    variant="contained"
                    style={{
                      width: '100%',
                      marginRight: '20px',
                      height: '100%',
                      backgroundColor: isCloudActive('AWS') ? '#B3D7FF' : '',
                    }}
                    onClick={() => setCloud('AWS')}
                    autoFocus
                  >
                    <img
                      src={`/icons/serviceIcons/AWS-icon.png`}
                      style={{ width: '10%' }}
                    />
                    <StarIcon
                      style={{
                        position: 'absolute',
                        top: '3px',
                        right: '2px',
                        color: 'gold',
                      }}
                    />
                    <Chip
                      label="MAR2.0"
                      color="primary"
                      size="small"
                      variant="outlined"
                      style={{
                        position: 'absolute',
                        top: '5px',
                        right: '20px',
                      }}
                    />
                  </Button>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{ display: 'flex', alignItems: 'center' }}
                >
                  <Button
                    variant="contained"
                    style={{
                      width: '100%',
                      marginRight: '20px',
                      height: '100%',
                      backgroundColor: isCloudActive('AZURE') ? '#B3D7FF' : '',
                    }}
                    onClick={() => setCloud('AZURE')}
                  >
                    <img
                      src={`/icons/serviceIcons/AZURE-icon.png`}
                      style={{ width: '20%' }}
                    />
                  </Button>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{ display: 'flex', alignItems: 'center' }}
                >
                  <Button
                    variant="contained"
                    style={{
                      width: '100%',
                      marginRight: '20px',
                      height: '100%',
                      backgroundColor: isCloudActive('GCP') ? '#B3D7FF' : '',
                    }}
                    onClick={() => setCloud('GCP')}
                  >
                    <img
                      src={`/icons/serviceIcons/GCP-icon.png`}
                      style={{ width: '39%' }}
                    />
                  </Button>
                </Grid>
              </Grid>
              <Grid item container xs={12}>
                <Grid item xs={12} sm={12}>
                  <Typography
                    variant={'h3'}
                    align="left"
                    classes={{ root: classes.serviceTitle }}
                  >
                    {t(serviceTitle)}
                  </Typography>
                </Grid>

                {cloud === 'AWS' ? (
                  <Grid item xs={12} sm={12}>
                    <IconTechDocsCardsWithTag
                      metadataItem={services}
                      type={'service'}
                      cloudProviderType={'AWS'}
                    />
                  </Grid>
                ) : cloud === 'AZURE' ? (
                  <Grid item xs={12} sm={12}>
                    <IconTechDocsCardsWithTag
                      metadataItem={services}
                      type={'service'}
                      cloudProviderType={'AZURE'}
                    />
                  </Grid>
                ) : cloud === 'GCP' ? (
                  <Grid item xs={12} sm={12}>
                    <IconTechDocsCardsWithTag
                      metadataItem={services}
                      type={'service'}
                      cloudProviderType={'GCP'}
                    />
                  </Grid>
                ) : (
                  <Grid item xs={12} sm={12}>
                    <IconTechDocsCardsWithTag
                      metadataItem={services}
                      type={'service'}
                      cloudProviderType={'AWS'}
                    />
                  </Grid>
                )}
              </Grid>
            </Box>
          )}
        </Grid>
      </Grid>
    </>
  );
}
