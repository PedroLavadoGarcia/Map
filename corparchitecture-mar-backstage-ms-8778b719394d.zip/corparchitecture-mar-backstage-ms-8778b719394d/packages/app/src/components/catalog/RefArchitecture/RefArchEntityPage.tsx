import React, { useEffect, useMemo, useState } from 'react';
import { EntityLayout } from '@backstage/plugin-catalog';
import { useEntity } from '@backstage/plugin-catalog-react';
import { JsonObject } from '@backstage/types';
import { Scenarios } from './Architectures/Scenarios';
import { UseCases } from './Architectures/UseCases';
import { TransversalLayout } from './TransversalArchitecture/TransversalLayout';
import { RefArchsTabs } from './Architectures/RefArchsTabs';
import { ServiceCatalog } from './Services/ServiceCatalog';
import { useTranslation } from 'react-i18next';
import { entityRefreshMenuButton } from '../EntityRefreshMenuButton/entityRefreshMenuButton';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import { useUserProfile } from '@backstage/plugin-user-settings';

import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
import NotificationsOffIcon from '@material-ui/icons/NotificationsOff';

import {
  getSubscriptionPutReqMarketplace,
  getSubscriptionsGetReqMarketplace,
  getSubscriptionDeleteReqMarketplace,
} from '../../../api/subscriptions/requests';

import Snackbar from '@material-ui/core/Snackbar';
import SnackbarContent from '@material-ui/core/SnackbarContent';

export function RefArchEntityPage() {
  const { t } = useTranslation();
  const { entity } = useEntity();
  const transversalDocs = entity.metadata?.transversalDocs as Array<
    Record<string, string>
  >;
  const archetype = (entity.metadata?.referenceArchDocs as JsonObject)
    ?.archetype;
  const changelog = (entity.metadata?.referenceArchDocs as JsonObject)
    ?.changelog;
  const pipeline = (entity.metadata?.referenceArchDocs as JsonObject)?.pipeline;
  const useCases = (entity.metadata?.referenceArchDocs as JsonObject)?.useCases;
  const blog = (entity.metadata?.referenceArchDocs as JsonObject)?.blog;
  const generalConfiguration = (
    entity.metadata?.referenceArchDocs as JsonObject
  )?.generalConfiguration;

  const catalogDocs = entity.metadata?.catalogDocs as Array<
    Record<string, string>
  >;

  const [isSubscribed, setIsSubscribed] = useState(false);
  const configApi = useApi(configApiRef);
  const baseUrl = configApi.getString('backend.baseUrl');
  const { profile } = useUserProfile();
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const sourceLocation =
    entity.metadata?.annotations?.['backstage.io/source-location'] ?? '';
  const repoUrl = (entity.metadata.annotations?.[
    'backstage.io/view-url'
  ] as string).match(/https:\/\/([^/]+\/[^/]+\/[^/]+)/)![0] ?? '';
  const componentUrl = sourceLocation.replace('url:', '') ?? '';

  const watchMenuItem = {
    title: t('Subscribe'),
    Icon: NotificationsActiveIcon,
    onClick: subscribe,
  };
  const unwatchMenuItem = {
    title: t('Unsuscribe'),
    Icon: NotificationsOffIcon,
    onClick: unsubscribe,
  };
  const menuItems = !profile.email
    ? undefined
    : isSubscribed
    ? [unwatchMenuItem]
    : [watchMenuItem];

  const extraMenuItems = useMemo(() => {
    const items = [];
    if (menuItems) {
      items.push(...menuItems);
    }
    items.push(entityRefreshMenuButton());
    return items;
  }, [menuItems]);

  async function getIsSubscribedMarketplace() {
    try {
      const response = await fetch(
        getSubscriptionsGetReqMarketplace(baseUrl, profile.email, repoUrl, componentUrl),
      );
      if (response.status === 200) {
        return true;
      } else {
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }
  async function subscribe() {
    try {
      const response = await fetch(
        getSubscriptionPutReqMarketplace(
          baseUrl,
          componentUrl,
          entity.metadata?.name,
          profile.email,
          entity.metadata?.description,
          entity.spec?.owner,
          entity.spec?.type,
        ),
      );
      if (response.status === 200) {
        setIsSubscribed(true);
        setSnackbarMessage('Subscribed successfully!');
        setSnackbarOpen(true);
        return;
      } else {
        setIsSubscribed(false);
        setSnackbarMessage('Failed to subscribe.');
        setSnackbarOpen(true);
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
    }
  }
  async function unsubscribe() {
    try {
      const sourceLocation =
        entity.metadata?.annotations?.['backstage.io/source-location'] ?? '';
      const componentUrl = sourceLocation.replace('url:', '');
      const response = await fetch(
        getSubscriptionDeleteReqMarketplace(
          baseUrl,
          profile.email,
          componentUrl,
        ),
      );
      if (response.status === 200) {
        setIsSubscribed(false);
        setSnackbarMessage('Unsubscribed successfully!');
        setSnackbarOpen(true);
        return;
      } else {
        setIsSubscribed(true);
        setSnackbarMessage('Failed to unsubscribe.');
        setSnackbarOpen(true);
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    (async function () {
      if (profile.email) {
        setIsSubscribed(await getIsSubscribedMarketplace());
      }
    })();
  }, [profile]);

  useEffect(() => {
    const title = document.querySelector(
      'main > header > div > h1 > div > span',
    );
    const text: string | null | undefined = title?.textContent;
    if (text && title) title.textContent = t(`${text}`);
    document
      .querySelector('main > header > div > p[class*=MuiTypography-body1]')
      ?.remove();
    const tabs = document.querySelector('[class^="MuiTabs"]')
      ?.parentElement as HTMLElement | null;

    const transversalTabs = document.querySelector('[class^="MuiTabs"]')
      ?.parentElement as HTMLElement | null;

    if (tabs) {
      tabs.style.position = 'sticky';
      tabs.style.display = 'block';
      tabs.style.top = '0';
      tabs.style.setProperty('z-index', '99');
    }
    if (transversalTabs) {
      transversalTabs.style.position = 'sticky';
      transversalTabs.style.display = 'block';
      transversalTabs.style.top = '0';
      transversalTabs.style.setProperty('z-index', '99');
    }
  }, [document]);

  if (transversalDocs) {
    return <TransversalLayout />;
  } else {
    return (
      <>
        {!catalogDocs && (
          <>
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={3000}
              onClose={() => setSnackbarOpen(false)}
              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
              <SnackbarContent
                message={snackbarMessage}
                style={{
                  backgroundColor: snackbarMessage.includes('Failed')
                    ? 'red'
                    : 'green',
                }}
              />
            </Snackbar>
            <EntityLayout UNSTABLE_extraContextMenuItems={extraMenuItems}>
              <EntityLayout.Route path="/blueprint" title="Blueprint">
                <RefArchsTabs entityItemName="blueprint" />
              </EntityLayout.Route>
              {generalConfiguration && (
                <EntityLayout.Route
                  path="/general-configuration"
                  title="General Configuration"
                >
                  <RefArchsTabs entityItemName="general-configuration" />
                </EntityLayout.Route>
              )}
              <EntityLayout.Route path="/scenarios" title={t('Scenarios')}>
                <Scenarios />
              </EntityLayout.Route>
              {archetype && (
                <EntityLayout.Route path="/archetype" title={t('Archetype')}>
                  <RefArchsTabs entityItemName="archetype" />
                </EntityLayout.Route>
              )}
              {pipeline && (
                <EntityLayout.Route path="/pipeline" title="Pipeline">
                  <RefArchsTabs entityItemName="pipeline" />
                </EntityLayout.Route>
              )}
              {changelog && (
                <EntityLayout.Route path="/changelog" title="Changelog">
                  <RefArchsTabs entityItemName="changelog" />
                </EntityLayout.Route>
              )}
              {blog && (
                <EntityLayout.Route path="/blog" title="Blog">
                  <RefArchsTabs entityItemName="blog" />
                </EntityLayout.Route>
              )}
              {useCases && (
                <EntityLayout.Route path="/useCases" title={t('Use Cases')}>
                  <UseCases />
                </EntityLayout.Route>
              )}
            </EntityLayout>
          </>
        )}
        {catalogDocs && (
          <>
            <EntityLayout UNSTABLE_extraContextMenuItems={extraMenuItems}>
              <EntityLayout.Route path="/blueprint" title="Blueprint">
                <ServiceCatalog />
              </EntityLayout.Route>
            </EntityLayout>
          </>
        )}
      </>
    );
  }
}
