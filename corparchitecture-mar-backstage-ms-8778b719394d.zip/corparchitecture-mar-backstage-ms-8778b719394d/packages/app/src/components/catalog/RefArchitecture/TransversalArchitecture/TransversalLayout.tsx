import { Entity } from '@backstage/catalog-model';
import { ItemCardGrid } from '@backstage/core-components';
import { useEntity } from '@backstage/plugin-catalog-react';
import {
  GridTechDocsCard,
  IconTechDocsCards,
  TechDocsCard,
} from '@internal/plugin-custom-cards';
import { CustomEntityLayout } from '@internal/plugin-custom-entity-layout';
import { Box, Button, Grid, makeStyles, Typography } from '@material-ui/core';
import ArrowBack from '@material-ui/icons/ArrowBack';
import React from 'react';
import { Routes, Route, useNavigate } from 'react-router';
import { Transversal } from './Transversal';
import { useTranslation } from 'react-i18next';
import { t } from 'i18next';
import LibraryBooks from '@material-ui/icons/LibraryBooks';

function TransversalReturnBackBtn({ entity }: { entity: Entity }) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  return (
    <Button
      variant="outlined"
      color="primary"
      onClick={() => {
        navigate(`/catalog/default/${entity.kind}/${entity.metadata.name}`);
      }}
    >
      <ArrowBack style={{ paddingRight: '6px' }} />
      {t(entity.metadata.title as string)}
    </Button>
  );
}
function ViewDocsButton({ docsPath }: { docsPath: string }): JSX.Element {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const useStyles = makeStyles({
    techdocsButton: {
      marginLeft: '10px',
    },
    libraryIcon: {
      paddingRight: '5px',
    },
  });
  const classes = useStyles();
  return (
    <Button
      variant="outlined"
      color="primary"
      onClick={() => navigate(`${docsPath}`)}
      className={classes.techdocsButton}
    >
      <LibraryBooks className={classes.libraryIcon} /> {t('View docs')}
    </Button>
  );
}
const useStyles = makeStyles(theme => ({
  header: {
    color: '#475059',
    backgroundColor: '#f1f4fa !important',
    paddingBottom: '16px',
    '& h4': {
      marginBottom: '0 !important',
    },
    '& h6': {
      marginBottom: '0 !important',
    },
  },
  content: {
    overflow: 'hidden',
    height: '400px',
    backgroundColor: 'white',
  },

  grid: {
    gridGap: '24px',
  },
  icons: {
    color: 'inherit',
    width: '28px',
    height: '28px',
    cursor: 'pointer',
    '&:hover': {
      color: '#DB271C',
    },
  },
  iconImg: {
    width: '28px',
    height: '28px',
    cursor: 'pointer',
    filter:
      'invert(29%) sepia(10%) saturate(658%) hue-rotate(169deg) brightness(95%) contrast(88%)',
    '&:hover': {
      filter:
        'invert(26%) sepia(29%) saturate(6912%) hue-rotate(356deg) brightness(93%) contrast(85%)',
    },
  },
  imageBox: {
    '& img': {
      marginTop: '16px',
      display: 'block',
      width: '100%',
    },
  },

  iconGridContent: {
    padding: '5px',
    textAlign: 'justify',
    flexWrap: 'nowrap',
  },
  cardsActions: {
    padding: '10px 0 10px 0',
    background: theme.palette.background.paper,
  },
  button: {
    fontWeight: 'bold',
    textAlign: 'left',
  },
}));

export function TransversalLayout() {
  const classes = useStyles();
  const { entity } = useEntity();
  const transversalDocs = entity.metadata?.transversalDocs as Array<
    Record<string, string>
  >;
  const docsButton = entity.metadata?.docsButton as boolean;

  return (
    <Box sx={{ textAlign: 'left' }}>
      <Routes>
        <Route path="*" element={<Transversal />} />
        {transversalDocs?.map((e, idx) => {
          return (
            <Route
              key={idx}
              path={`/${e.path}/*`}
              element={
                <CustomEntityLayout title={`${e?.title}`}>
                  {(e.tabs as unknown as Array<Record<string, string>>)?.map(
                    function (tab, tabIdx) {
                      return (
                        <CustomEntityLayout.Route
                          path={`/${tab?.path}`}
                          title={t(`${tab?.title}`)}
                          key={tabIdx}
                        >
                          <Grid
                            container
                            spacing={3}
                            alignItems="stretch"
                            style={{
                              paddingLeft: '3%',
                              paddingRight: '3%',
                              height: 'auto',
                              textAlign: 'left',
                            }}
                          >
                            <Grid item sm={12} style={{ textAlign: 'right' }}>
                              <Box>
                                <TransversalReturnBackBtn entity={entity} />
                                {docsButton && (
                                  <ViewDocsButton
                                    docsPath={`/docs/default/${entity.kind}/${entity.metadata.name}/${e.path}`}
                                  />
                                )}
                              </Box>
                            </Grid>
                            <Grid
                              item
                              container
                              xs={12}
                              style={{ margin: '0px' }}
                              key={idx}
                            >
                              {tab.techdocsPath && (
                                <Grid item xs={12}>
                                  <TechDocsCard path={`${tab.techdocsPath}`} />
                                </Grid>
                              )}
                              {tab.docs && (
                                <>
                                  {tab.docsName && (
                                    <Grid item xs={12}>
                                      <Typography
                                        variant="h2"
                                        align="center"
                                        style={{ padding: '40px' }}
                                        key={idx}
                                      >
                                        {t(`${tab.docsName}`)}
                                      </Typography>
                                    </Grid>
                                  )}
                                  <Grid item xs={12}>
                                    <ItemCardGrid
                                      classes={{ root: classes.grid }}
                                    >
                                      {(
                                        tab.docs as unknown as Array<
                                          Record<string, string>
                                        >
                                      )?.map(function (doc, docIdx) {
                                        return (
                                          <React.Fragment key={docIdx}>
                                            {doc.description ? (
                                              <GridTechDocsCard
                                                title={t(doc.title)}
                                                path={doc.path}
                                                customMessage={doc.description}
                                              />
                                            ) : (
                                              <GridTechDocsCard
                                                title={t(doc.title)}
                                                path={doc.path}
                                              />
                                            )}
                                          </React.Fragment>
                                        );
                                      })}
                                    </ItemCardGrid>
                                  </Grid>
                                </>
                              )}
                              {tab.scenarios && (
                                <Grid item xs={12}>
                                  <IconTechDocsCards
                                    metadataItem={
                                      tab.scenarios as unknown as Array<
                                        Record<string, string>
                                      >
                                    }
                                    type="scenario"
                                  />
                                </Grid>
                              )}
                            </Grid>
                          </Grid>
                        </CustomEntityLayout.Route>
                      );
                    },
                  )}
                </CustomEntityLayout>
              }
            />
          );
        })}
      </Routes>
    </Box>
  );
}
