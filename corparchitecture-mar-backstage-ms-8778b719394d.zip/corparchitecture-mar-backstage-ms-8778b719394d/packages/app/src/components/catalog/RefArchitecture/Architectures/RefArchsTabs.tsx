import { useEntity } from '@backstage/plugin-catalog-react';
import { Card, Grid, makeStyles } from '@material-ui/core';
import React from 'react';
import { JsonObject } from '@backstage/types';
import { RefArchButtons } from '@internal/plugin-custom-cards/src/components/RefArchButtons/RefArchButtons';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs/src/TechDocsCardContent';

export function RefArchsTabs({
  entityItemName,
}: {
  entityItemName: string;
}): JSX.Element {
  const { entity } = useEntity();
  const referenceArchDocs = entity.metadata?.referenceArchDocs as JsonObject;
  const pipeline = referenceArchDocs?.pipeline as Record<string, string>;
  const generalConfiguration =
    referenceArchDocs?.generalConfiguration as Record<string, string>;
  const archetype = referenceArchDocs?.archetype as Record<string, string>;
  const blueprint = referenceArchDocs?.blueprint as Record<string, string>;
  const changelog = referenceArchDocs?.changelog as Record<string, string>;
  const blog = referenceArchDocs?.blog as Record<string, string>;
  const docsButton = referenceArchDocs?.docsButton as boolean;
  const useStyles = makeStyles({
    entityGrid: {
      marginTop: '20px',
      paddingLeft: '3%',
      paddingRight: '3%',
      textAlign: 'left',
    },
  });

  const classes = useStyles();
  return (
    <Grid
      container
      spacing={3}
      alignItems="stretch"
      className={classes.entityGrid}
    >
      <Grid item xs={12}>
        <RefArchButtons withTechDocsButton={docsButton} />
      </Grid>
      {entityItemName === 'pipeline' && (
        <Grid item xs={12}>
          {pipeline && (
            <Card>
              <TechDocsCardContent path={pipeline?.path} withTitle={false} />
            </Card>
          )}
        </Grid>
      )}
      {entityItemName === 'general-configuration' && (
        <Grid item xs={12}>
          {generalConfiguration && (
            <Card>
              <TechDocsCardContent
                path={generalConfiguration?.path}
                withTitle={false}
              />
            </Card>
          )}
        </Grid>
      )}
      {entityItemName === 'archetype' && (
        <Grid item xs={12}>
          {archetype && (
            <Card>
              <TechDocsCardContent path={archetype?.path} withTitle={false} />
            </Card>
          )}
        </Grid>
      )}
      {entityItemName === 'blueprint' && (
        <Grid item xs={12}>
          {blueprint && (
            <Card>
              <TechDocsCardContent
                path={blueprint.path || ''}
                withTitle={false}
              />
            </Card>
          )}
        </Grid>
      )}
      {entityItemName === 'changelog' && (
        <Grid item xs={12}>
          {changelog && (
            <Card>
              <TechDocsCardContent
                path={changelog.path || ''}
                withTitle={false}
              />
            </Card>
          )}
        </Grid>
      )}
      {entityItemName === 'blog' && (
        <Grid item xs={12}>
          {blog && (
            <Card>
              <TechDocsCardContent path={blog.path || ''} withTitle={false} />
            </Card>
          )}
        </Grid>
      )}
    </Grid>
  );
}
