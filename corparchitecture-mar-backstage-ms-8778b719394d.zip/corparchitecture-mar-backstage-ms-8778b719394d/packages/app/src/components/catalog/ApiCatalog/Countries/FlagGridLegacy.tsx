import React from 'react';
import { BackstageTheme } from '@backstage/theme';
import { ButtonBase, makeStyles, Tooltip } from '@material-ui/core';
import { FlagListLegacy } from './FlagListLegacy';
import { useNavigate } from 'react-router';

export const FlagGridLegacy = () => {
  const useStyles = makeStyles<BackstageTheme>(() => ({
    gridImg: {
      width: '48px',
      margin: '-8px -1px -8px 0px',
    },

    boxImage: {
      margin: '0x 50px 0px 0px',
      borderColor: 'black',
      display: 'flex',
      flexDirection: 'row',
      width: '48px',
      height: 'auto',
      '&:hover': {
        boxShadow:
          '0 10px 14px 0 rgba(0,0,0,0.2), 0 17px 50px 0 rgba(0,0,0,0.2)',
      },
    },
  }));

  const classes = useStyles();
  const navigate = useNavigate();
  const countryFilterPathEsp = '/apis?filters%5Bkind%5D=mapfreapilegacyesp';
  const countryFilterPathGlobal =
    '/apis?filters%5Bkind%5D=mapfreapilegacyglobal';

  return (
    <>
      {FlagListLegacy.map(function (flag, idx) {
        return (
          <div key={idx}>
            <Tooltip title={flag.title}>
              <ButtonBase style={{ padding: '10px', textAlign: 'center' }}>
                {}
                <div
                  className={classes.boxImage}
                  onClick={() => {
                    if (flag.filterTag === 'ESP') {
                      navigate(`${countryFilterPathEsp}`);
                    } else if (flag.filterTag === 'GLOB') {
                      navigate(`${countryFilterPathGlobal}`);
                    }
                  }}
                >
                  <img
                    src={flag.image}
                    alt={flag.title}
                    className={classes.gridImg}
                  />
                </div>
              </ButtonBase>
            </Tooltip>
          </div>
        );
      })}
    </>
  );
};
