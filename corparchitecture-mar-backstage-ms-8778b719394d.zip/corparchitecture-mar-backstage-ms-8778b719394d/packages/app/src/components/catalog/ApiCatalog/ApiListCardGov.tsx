import { Content, EmptyState, Progress } from '@backstage/core-components';

import {
  UserListFilterKind,
  EntityKindFilter,
} from '@backstage/plugin-catalog-react';
import React, { createContext, ReactNode } from 'react';
import { Entity } from '@backstage/catalog-model';
import { useTranslation } from 'react-i18next';
import {
  Box,
  CardActions,
  CardMedia,
  Divider,
  Grid,
  makeStyles,
  Typography,
} from '@material-ui/core';

import Card from '@mui/material/Card/Card';
import CardContent from '@mui/material/CardContent';

import useAsync from 'react-use/lib/useAsync';
import { MAREntityFilters } from '../../pickers/EntityCountryPicker';
import {
  EntityListProvider,
  useEntityList,
} from './CatalogTable/hooks/useEntityListProvider';
import { EntityPortalPubFilter } from '../../filters/EntityPortalPubFilter';
import { NavLink } from 'react-router-dom';

export interface EntityProviderProps {
  children: ReactNode;
  entity?: Entity;
}

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  initialKind?: string;
  extOwnershipEntityRefs: string[] | undefined;
}
export interface CatalogCardsProps {
  initialKind?: string;
}

export const EntityContext = createContext('');
export const ApiListCardGov = () => {
  const useStyles = makeStyles(theme => ({
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 300px)',

      marginLeft: 20,
      marginTop: 20,
    },
    gridauto: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, 300px)',
      marginLeft: 20,
      marginTop: 20,
    },
    header: {
      color: 'white',
    },
    box: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      display: '-webkit-box',
      '-webkit-line-clamp': 10,
      '-webkit-box-orient': 'vertical',
      paddingBottom: '0.8em',
    },
    label: {
      color: theme.palette.text.secondary,
      textTransform: 'uppercase',
      fontSize: '0.65rem',
      fontWeight: 'bold',
      letterSpacing: 0.5,
      lineHeight: 1,
      paddingBottom: '0.2rem',
    },
    entity: {
      textTransform: 'uppercase',
      padding: 8,
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    containerStyle: { width: '80%', height: '100vh', marginLeft: 20 },
  }));
  const classes = useStyles();
  const context = useEntityList<MAREntityFilters>();

  const { loading } = useAsync(async () => {
    context.updateFilters({
      kind: new EntityKindFilter('mapfreapi'),
      portal_pub: new EntityPortalPubFilter(['Yes']),
      typology: undefined,
    });
  });

  const { t } = useTranslation();

  return (
    <EntityListProvider>
      {loading ? (
        <Progress />
      ) : (
        <>
          {context.entities.length >= 1 ? (
            <Content>
              <Grid container spacing={2}>
                {context.entities.map((entity, index) => (
                  <Grid item xs={4} key={index}>
                    <Card
                      key={index}
                      style={{
                        maxWidth: 400,
                        height: '100%',
                      }}
                    >
                      <CardMedia
                        key={index}
                        component="img"
                        alt={'image'}
                        height="30%"
                        image={'/documentationLogo.png'}
                      />
                      <CardContent
                        style={{
                          height: '60%',
                        }}
                      >
                        <Typography
                          gutterBottom
                          variant="h5"
                          component="div"
                          color="textPrimary"
                        >
                          {entity?.metadata?.title}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          {entity?.metadata?.typology}
                        </Typography>

                        <Typography variant="body2" color="textSecondary">
                          <br />
                          <Divider />
                          {entity?.metadata?.description}
                        </Typography>
                      </CardContent>
                      <Box
                        style={{
                          height: '10%',
                        }}
                      >
                        <CardActions>
                          <NavLink
                            to={`/catalog/default/${entity.kind}/${entity.metadata.name}`}
                            style={{ color: 'red' }}
                            state={localStorage.setItem(
                              'isExternalGov',
                              true as unknown as string,
                            )}
                          >
                            {t('View')} {'>'}
                          </NavLink>
                        </CardActions>
                      </Box>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Content>
          ) : (
            <div className={classes.containerStyle}>
              <EmptyState
                missing="data"
                title={t('No results')}
                description={
                  t('Please use other filters to see new results') as string
                }
              />
            </div>
          )}
        </>
      )}
    </EntityListProvider>
  );
};
