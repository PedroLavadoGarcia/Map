const FlagList = [
  {
    image: '/icons/flags/Argentina.webp',
    title: 'Argentina',
    filterTag: 'ARG',
  },
  {
    image: '/icons/flags/Brazil.webp',
    title: 'Brazil',
    filterTag: 'BRA',
  },
  {
    image: '/icons/flags/Chile.webp',
    title: 'Chile',
    filterTag: 'CHL',
  },
  {
    image: '/icons/flags/Colombia.webp',
    title: 'Colombia',
    filterTag: 'COL',
  },
  {
    image: '/icons/flags/Costa Rica.webp',
    title: 'Costa Rica',
    filterTag: 'CRI',
  },
  {
    image: '/icons/flags/Germany.webp',
    title: 'Germany',
    filterTag: 'DEU',
  },
  {
    image: '/icons/flags/Dominican Republic.webp',
    title: 'Dominican Republic',
    filterTag: 'DOM',
  },
  {
    image: '/icons/flags/Ecuador.webp',
    title: 'Ecuador',
    filterTag: 'ECU',
  },
  {
    image: '/icons/flags/Spain.webp',
    title: 'Spain',
    filterTag: 'ESP',
  },
  {
    image: '/icons/flags/Italy.webp',
    title: 'Italy',
    filterTag: 'ITA',
  },
  {
    image: '/icons/flags/Mexico.webp',
    title: 'Mexico',
    filterTag: 'MEX',
  },
  {
    image: '/icons/flags/Malta.webp',
    title: 'Malta',
    filterTag: 'MLT',
  },
  {
    image: '/icons/flags/Panama.webp',
    title: 'Panama',
    filterTag: 'PAN',
  },
  {
    image: '/icons/flags/Peru.webp',
    title: 'Peru',
    filterTag: 'PER',
  },
  {
    image: '/icons/flags/Puerto Rico.webp',
    title: 'Puerto Rico',
    filterTag: 'PRI',
  },
  {
    image: '/icons/flags/Paraguay.webp',
    title: 'Paraguay',
    filterTag: 'PRY',
  },
  {
    image: '/icons/flags/Turkey.webp',
    title: 'Turkey',
    filterTag: 'TUR',
  },
  {
    image: '/icons/flags/Uruguay.webp',
    title: 'Uruguay',
    filterTag: 'URY',
  },
  {
    image: '/icons/flags/USA.webp',
    title: 'USA',
    filterTag: 'USA',
  },
  {
    image: '/icons/flags/Venezuela.webp',
    title: 'Venezuela',
    filterTag: 'VEN',
  },
];

export { FlagList };
