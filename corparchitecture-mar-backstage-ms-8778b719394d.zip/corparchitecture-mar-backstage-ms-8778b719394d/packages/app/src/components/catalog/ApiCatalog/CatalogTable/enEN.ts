import { GridLocaleText } from './models/gridLocaleTextApi';
import { Localization, getGridLocalization } from './utils/getGridLocalization';
import { t } from 'i18next';
const esESGrid: Partial<GridLocaleText> = {
  // Root
  noRowsLabel: t('No rows') as string,
  noResultsOverlayLabel: t('Results not found') as string,

  // Density selector toolbar button text
  toolbarDensity: t('Density') as string,
  toolbarDensityLabel: t('Density') as string,
  toolbarDensityCompact: t('Compact') as string,
  toolbarDensityStandard: t('Standard') as string,
  toolbarDensityComfortable: t('Comfortable') as string,

  // Columns selector toolbar button text
  toolbarColumns: t('Columns') as string,
  toolbarColumnsLabel: t('Select columns') as string,

  // Filters toolbar button text
  toolbarFilters: t('Filters') as string,
  toolbarFiltersLabel: t('Show filters') as string,
  toolbarFiltersTooltipHide: t('Hide filters') as string,
  toolbarFiltersTooltipShow: t('Show filters') as string,
  toolbarFiltersTooltipActive: count =>
    count > 1 ? `${count} filtros activos` : `${count} filtro activo`,

  // Quick filter toolbar field
  toolbarQuickFilterPlaceholder: t('Search...') as string,
  toolbarQuickFilterLabel: t('Search') as string,
  toolbarQuickFilterDeleteIconLabel: t('Clean') as string,

  // Export selector toolbar button text
  toolbarExport: t('Export') as string,
  toolbarExportLabel: t('Export') as string,
  toolbarExportCSV: t('Download as CSV') as string,
  toolbarExportPrint: t('Print') as string,
  toolbarExportExcel: 'Descargar como Excel',

  // Columns panel text
  columnsPanelTextFieldLabel: t('Search column') as string,
  columnsPanelTextFieldPlaceholder: t('Title column') as string,
  columnsPanelDragIconLabel: t('Reorder columns') as string,
  columnsPanelShowAllButton: t('Show all') as string,
  columnsPanelHideAllButton: t('Hide all') as string,

  // Filter panel text
  filterPanelAddFilter: t('Add filter') as string,
  filterPanelRemoveAll: t('Remove all') as string,
  filterPanelDeleteIconLabel: t('Delete') as string,
  filterPanelLogicOperator: t('Logic operator') as string,
  filterPanelOperator: t('Operator') as string,
  filterPanelOperatorAnd: t('And') as string,
  filterPanelOperatorOr: t('Or') as string,
  filterPanelColumns: t('Columns') as string,
  filterPanelInputLabel: t('Value') as string,
  filterPanelInputPlaceholder: t('Filter value') as string,

  // Filter operators text
  filterOperatorContains: t('contains') as string,
  filterOperatorEquals: t('equals') as string,
  filterOperatorStartsWith: t('starts with') as string,
  filterOperatorEndsWith: t('ends with') as string,
  filterOperatorIs: t('is') as string,
  filterOperatorNot: t('not') as string,
  filterOperatorAfter: t('after') as string,
  filterOperatorOnOrAfter: t('on or after') as string,
  filterOperatorBefore: t('before') as string,
  filterOperatorOnOrBefore: t('on or before') as string,
  filterOperatorIsEmpty: t('is empty') as string,
  filterOperatorIsNotEmpty: t('is not empty') as string,
  filterOperatorIsAnyOf: t('is any of') as string,
  'filterOperator=': '=',
  'filterOperator!=': '!=',
  'filterOperator>': '>',
  'filterOperator>=': '>=',
  'filterOperator<': '<',
  'filterOperator<=': '<=',

  // Header filter operators text
  headerFilterOperatorContains: 'Contiene',
  headerFilterOperatorEquals: 'Es igual a',
  headerFilterOperatorStartsWith: 'Comienza con',
  headerFilterOperatorEndsWith: 'Termina con',
  headerFilterOperatorIs: 'Es',
  headerFilterOperatorNot: 'No es',
  headerFilterOperatorAfter: 'Esta después de',
  headerFilterOperatorOnOrAfter: 'Esta en o después de',
  headerFilterOperatorBefore: 'Esta antes de',
  headerFilterOperatorOnOrBefore: 'Esta en o antes de',
  headerFilterOperatorIsEmpty: 'Esta vacío',
  headerFilterOperatorIsNotEmpty: 'No esta vacío',
  headerFilterOperatorIsAnyOf: 'Es cualquiera de',
  'headerFilterOperator=': 'Es igual a',
  'headerFilterOperator!=': 'Es diferente a',
  'headerFilterOperator>': 'Es mayor que',
  'headerFilterOperator>=': 'Es mayor o igual que',
  'headerFilterOperator<': 'Es menor que',
  'headerFilterOperator<=': 'Es menor o igual que',

  // Filter values text
  filterValueAny: t('any') as string,
  filterValueTrue: t('true') as string,
  filterValueFalse: t('false') as string,

  // Column menu text
  columnMenuLabel: t('Menu') as string,
  columnMenuShowColumns: t('Show columns') as string,
  columnMenuManageColumns: t('Manage columns') as string,
  columnMenuFilter: t('Filter') as string,
  columnMenuHideColumn: t('Hide column') as string,
  columnMenuUnsort: t('Unsort') as string,
  columnMenuSortAsc: t('Sort ASC') as string,
  columnMenuSortDesc: t('Sort DESC') as string,

  // Column header text
  columnHeaderFiltersTooltipActive: count =>
    count > 1 ? `${count} filtros activos` : `${count} filtro activo`,
  columnHeaderFiltersLabel: 'Mostrar filtros',
  columnHeaderSortIconLabel: 'Ordenar',

  // Rows selected footer text
  footerRowSelected: count =>
    count > 1
      ? t(`${count.toLocaleString()} rows selected`)
      : t(`${count.toLocaleString()} row selected`),

  // Total row amount footer text
  footerTotalRows: t('Total rows: ') as string,

  // Total visible row amount footer text
  footerTotalVisibleRows: (visibleCount, totalCount) =>
    `${visibleCount.toLocaleString()}` +
    t('of') +
    `${totalCount.toLocaleString()}`,

  // Checkbox selection text
  checkboxSelectionHeaderName: 'Seleccionar casilla',
  checkboxSelectionSelectAllRows: 'Seleccionar todas las filas',
  checkboxSelectionUnselectAllRows: 'Deseleccionar todas las filas',
  checkboxSelectionSelectRow: 'Seleccionar fila',
  checkboxSelectionUnselectRow: 'Deseleccionar fila',

  // Boolean cell text
  booleanCellTrueLabel: 'si',
  booleanCellFalseLabel: 'no',

  // Actions cell more text
  actionsCellMore: 'más',

  // Column pinning text
  pinToLeft: 'Anclar a la izquierda',
  pinToRight: 'Anclar a la derecha',
  unpin: 'Desanclar',

  // Tree Data
  treeDataGroupingHeaderName: 'Grupo',
  treeDataExpand: 'mostrar hijos',
  treeDataCollapse: 'ocultar hijos',

  // Grouping columns
  groupingColumnHeaderName: 'Grupo',
  groupColumn: name => `Agrupar por ${name}`,
  unGroupColumn: name => `No agrupar por ${name}`,

  // Master/detail
  detailPanelToggle: 'Alternar detalle',
  expandDetailPanel: 'Expandir',
  collapseDetailPanel: 'Contraer',

  // Row reordering text
  rowReorderingHeaderName: 'Reordenar filas',

  MuiTablePagination: {
    getItemAriaLabel: type => {
      if (type === 'first') {
        return 'Перайсці на першую старонку';
      }
      if (type === 'last') {
        return 'Перайсці на апошнюю старонку';
      }
      if (type === 'next') {
        return t('Go to next page');
      }
      if (type === 'previous') {
        return t('Go to previous page');
      } else {
        return '';
      }
    },
    labelRowsPerPage: t('Rows per page:') as string,
    labelDisplayedRows: ({ from, to, count }) =>
      `${from}–${to}` + t(' of ') + `${count}`,
  },

  // Aggregation
  aggregationMenuItemHeader: 'Agregación',
  aggregationFunctionLabelSum: 'sum',
  aggregationFunctionLabelAvg: 'avg',
  aggregationFunctionLabelMin: 'min',
  aggregationFunctionLabelMax: 'max',
  aggregationFunctionLabelSize: 'tamaño',
};

export const esES: Localization = getGridLocalization(esESGrid);
