import {
  Content,
  EmptyState,
  Header,
  ItemCardGrid,
  ItemCardHeader,
  Page,
  Progress,
} from '@backstage/core-components';
import {
  CatalogFilterLayout,
  UserListFilterKind,
  EntityRefLink,
  EntityKindFilter,
  EntityLifecycleFilter,
} from '@backstage/plugin-catalog-react';
import React, { createContext, ReactNode } from 'react';
import { Entity } from '@backstage/catalog-model';
import { useTranslation } from 'react-i18next';
import {
  Box,
  CardActions,
  CardMedia,
  Divider,
  Grid,
  makeStyles,
  Typography,
} from '@material-ui/core';
import Card from '@mui/material/Card/Card';
import CardContent from '@mui/material/CardContent';

import useAsync from 'react-use/lib/useAsync';
import { EntitySystemFilter } from '../../filters/EntitySystemFilter';
import { MAREntityFilters } from '../../pickers/EntityCountryPicker';
import { EntityCountryFilter } from '../../filters/EntityCountryFilter';
import {
  EntityListProvider,
  useEntityList,
} from './CatalogTable/hooks/useEntityListProvider';
import Container from '@mui/material/Container';

import Tooltip from '@mui/material/Tooltip';
import ToggleButton from '@mui/material/ToggleButton';
import { t } from 'i18next';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { EntityPortalPubFilter } from '../../filters/EntityPortalPubFilter';
import { NavLink } from 'react-router-dom';

export interface EntityProviderProps {
  children: ReactNode;
  entity?: Entity;
}

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  initialKind?: string;
  extOwnershipEntityRefs: string[] | undefined;
}

type TooltipToggleButtonProps = {
  children: JSX.Element;
  title: string;
  value: string;
};
const TooltipToggleButton = ({
  children,
  title,
  value,
  ...props
}: TooltipToggleButtonProps) => (
  <Tooltip placement="top" arrow title={title}>
    <ToggleButton style={{ border: '0px' }} value={value} {...props}>
      {children}
    </ToggleButton>
  </Tooltip>
);

export const EntityContext = createContext('');
export const ApiListCardLayout = () => {
  const useStyles = makeStyles(theme => ({
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(8, 350px)',
      marginLeft: 20,
      marginTop: 20,
    },
    gridauto: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, 300px)',
      marginLeft: 20,
      marginTop: 20,
    },
    header: {
      color: 'white',
    },
    box: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      display: '-webkit-box',
      '-webkit-line-clamp': 10,
      '-webkit-box-orient': 'vertical',
      paddingBottom: '0.8em',
    },
    label: {
      color: theme.palette.text.secondary,
      textTransform: 'uppercase',
      fontSize: '0.65rem',
      fontWeight: 'bold',
      letterSpacing: 0.5,
      lineHeight: 1,
      paddingBottom: '0.2rem',
    },
    entity: {
      textTransform: 'uppercase',
      padding: 8,
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    bar: {
      borderRadius: '25px',
      borderStyle: 'solid',
      borderWidth: '1px',
      opacity: '1',
      padding: '2px 20px 0px 20px',
      width: '100%',
      marginLeft: '3%',
    },
    containerStyle: { width: '80%', height: '100vh', marginLeft: 20 },
  }));
  const classes = useStyles();
  const context = useEntityList<MAREntityFilters>();
  const { t, i18n } = useTranslation();

  const { loading } = useAsync(async () =>
    context.updateFilters({
      kind: new EntityKindFilter('mapfreapi'),
    }),
  );

  return (
    <EntityListProvider>
      <Page themeId={''}>
        <Content>
          <Header title={t('API Catalog')}></Header>
          <CatalogFilterLayout>
            {loading ? (
              <Progress />
            ) : (
              <CatalogFilterLayout.Content>
                <Container>
                  {context.entities.length >= 1 ? (
                    <Content>
                      <Grid container spacing={2}>
                        {context.entities.map((entity, index) => (
                          <Grid item xs={4} key={index}>
                            <Card
                              key={index}
                              style={{
                                maxWidth: 400,
                                height: '100%',
                              }}
                            >
                              <CardMedia
                                key={index}
                                component="img"
                                alt={'image'}
                                height="30%"
                                image={'/documentationLogo.png'}
                              />
                              <CardContent
                                style={{
                                  height: '60%',
                                }}
                              >
                                <Typography
                                  gutterBottom
                                  variant="h5"
                                  component="div"
                                  color="textPrimary"
                                >
                                  {entity?.metadata?.title}
                                </Typography>
                                <Typography
                                  variant="body2"
                                  color="textSecondary"
                                >
                                  {entity?.metadata?.typology}
                                </Typography>

                                <Typography
                                  variant="body2"
                                  color="textSecondary"
                                >
                                  <br />
                                  <Divider />
                                  {entity?.metadata?.description}
                                </Typography>
                              </CardContent>
                              <Box
                                style={{
                                  height: '10%',
                                }}
                              >
                                <CardActions>
                                  <NavLink
                                    to={`/catalog/default/${entity.kind}/${entity.metadata.name}`}
                                    style={{ color: 'red' }}
                                    state={localStorage.setItem(
                                      'isExternalGov',
                                      true as unknown as string,
                                    )}
                                  >
                                    {t('View')} {'>'}
                                  </NavLink>
                                </CardActions>
                              </Box>
                            </Card>
                          </Grid>
                        ))}
                      </Grid>
                    </Content>
                  ) : (
                    <div className={classes.containerStyle}>
                      <EmptyState
                        missing="data"
                        title={t('No results')}
                        description={
                          t(
                            'Please use other filters to see new results',
                          ) as string
                        }
                      />
                    </div>
                  )}
                </Container>
              </CatalogFilterLayout.Content>
            )}
          </CatalogFilterLayout>
        </Content>
      </Page>
    </EntityListProvider>
  );
};
