const BussinessLineList = [
  {
    image: '/icons/bussinessLine/Others.webp',
    title: 'Cross',
    filterTag: 'Cross',
  },
  {
    image: '/icons/bussinessLine/Health.webp',
    title: 'Health Care',
    filterTag: 'Health::Health Care',
  },
  {
    image: '/icons/bussinessLine/Medical.webp',
    title: 'Medical Centers',
    filterTag: 'Health::Medical Centers',
  },
  {
    image: '/icons/bussinessLine/Others.webp',
    title: 'Health - Other',
    filterTag: 'Health::Other',
  },
  {
    image: '/icons/bussinessLine/Bikes.webp',
    title: 'Bicycles & Cyclists',
    filterTag: 'NoLife::Bicycles & cyclists',
  },
  {
    image: '/icons/bussinessLine/Bussiness.webp',
    title: 'Business',
    filterTag: 'NoLife::Business',
  },
  {
    image: '/icons/bussinessLine/Home.webp',
    title: 'Home Insurance',
    filterTag: 'NoLife::Home Insurance',
  },
  {
    image: '/icons/bussinessLine/Legal.webp',
    title: 'Legal Defense',
    filterTag: 'NoLife::Legal Defense',
  },
  {
    image: '/icons/bussinessLine/Pets.webp',
    title: 'Pets',
    filterTag: 'NoLife::Pets',
  },
  {
    image: '/icons/bussinessLine/Accidents.webp',
    title: 'Accidents',
    filterTag: 'NoLife::Accidents',
  },
  {
    image: '/icons/bussinessLine/Car.webp',
    title: 'Auto',
    filterTag: 'NoLife::Autos',
  },
  {
    image: '/icons/bussinessLine/Community.webp',
    title: 'Community',
    filterTag: 'NoLife::Community',
  },
  {
    image: '/icons/bussinessLine/Death.webp',
    title: 'Death',
    filterTag: 'NoLife::Death',
  },
  {
    image: '/icons/bussinessLine/Property.webp',
    title: 'Property & Contingency',
    filterTag: 'NoLife::Property & Contingency',
  },
  {
    image: '/icons/bussinessLine/Rural.webp',
    title: 'Rural',
    filterTag: 'NoLife::Rural',
  },
  {
    image: '/icons/bussinessLine/Umbrella.webp',
    title: 'Umbrella',
    filterTag: 'NoLife::Umbrella',
  },
  {
    image: '/icons/bussinessLine/Others.webp',
    title: 'NoLife - Other',
    filterTag: 'NoLife::Other',
  },
  {
    image: '/icons/bussinessLine/Travel.webp',
    title: 'Travel',
    filterTag: 'NoLife::Travel',
  },
  {
    image: '/icons/bussinessLine/Savings.webp',
    title: 'Savings',
    filterTag: 'Life::Savings',
  },
  {
    image: '/icons/bussinessLine/Risk.webp',
    title: 'Risk',
    filterTag: 'Life::Risk',
  },
  {
    image: '/icons/bussinessLine/Others.webp',
    title: 'Life - Other',
    filterTag: 'Life::Other',
  },
];

export { BussinessLineList };
