import React, {
  Fragment,
  ReactNode,
  useCallback,
  useEffect,
  useReducer,
  useState,
} from 'react';
import {
  Entity,
  RELATION_OWNED_BY,
  RELATION_PART_OF,
} from '@backstage/catalog-model';
import {
  CodeSnippet,
  TableProps,
  WarningPanel,
} from '@backstage/core-components';
import {
  getEntityRelations,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import { CatalogTableRow } from '@backstage/plugin-catalog';
import { useEntityList } from './hooks/useEntityListProvider';
import {
  DataGrid,
  GridColDef,
  GridColumnVisibilityModel,
  GridInitialState,
  GridRowId,
  GridToolbarColumnsButton,
  GridToolbarContainer,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarQuickFilter,
  GridValidRowModel,
  GridToolbarExport,
  useGridApiContext,
  gridClasses,
} from '@mui/x-data-grid';
import { useLocation } from 'react-router-dom';
import Grid from '@mui/material/Grid';
import LinearProgress from '@mui/material/LinearProgress';
import {
  alpha,
  createTheme,
  styled,
  ThemeProvider,
} from '@mui/material/styles';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import Fade from '@mui/material/Fade';
import Popper from '@mui/material/Popper';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import TextField from '@mui/material/TextField';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Paper from '@mui/material/Paper';
import MenuList from '@mui/material/MenuList';
import { makeStyles } from '@material-ui/core';
import { t } from 'i18next';
import { esES } from './enEN';
import { esES as coreEsES } from './enEN';
import { useAsync } from 'react-use';
import { MAREntityFilters } from '../../../pickers/EntityCountryPicker';
import { AuditService } from '../../../../api/audit';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { Subscription, timer } from 'rxjs';

const LOCAL_STORAGE_KEY = 'customViewState';

const ODD_OPACITY = 0.2;

const StripedDataGrid = styled(DataGrid)(({ theme }) => ({
  [`& .${gridClasses.row}.even`]: {
    backgroundColor: '#f1f4fa',
    '&:hover, &.Mui-hovered': {
      backgroundColor: alpha(theme.palette.primary.main, ODD_OPACITY),
      '@media (hover: none)': {
        backgroundColor: 'transparent',
      },
    },
    '&.Mui-selected': {
      backgroundColor: alpha(
        theme.palette.primary.main,
        ODD_OPACITY + theme.palette.action.selectedOpacity,
      ),
      '&:hover, &.Mui-hovered': {
        backgroundColor: alpha(
          theme.palette.primary.main,
          ODD_OPACITY +
            theme.palette.action.selectedOpacity +
            theme.palette.action.hoverOpacity,
        ),
        // Reset on touch devices, it doesn't add specificity
        '@media (hover: none)': {
          backgroundColor: alpha(
            theme.palette.primary.main,
            ODD_OPACITY + theme.palette.action.selectedOpacity,
          ),
        },
      },
    },
  },
}));

const theme = createTheme(
  {
    palette: {
      primary: {
        main: '#DB271C',
      },
      secondary: {
        main: '#FF5630',
      },
    },
  },
  esES,
  coreEsES,
);

const useStyles = makeStyles({
  tableStyle: {
    height: '80vh',
    width: 'auto',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

interface CatalogTableProps {
  columns?: GridColDef<GridValidRowModel>[];
  actions?: GridColDef<GridValidRowModel>[];
  tableOptions?: TableProps<CatalogTableRow>['options'];
  emptyContent?: ReactNode;
  subtitle?: string;
  customTitlePreamble?: string;
}

interface StateView {
  label: string;
  value: GridInitialState;
}

interface DemoState {
  views: { [id: string]: StateView };
  newViewLabel: string;
  activeViewId: string | null;
  isMenuOpened: boolean;
  menuAnchorEl: HTMLElement | null;
}

type DemoActions =
  | { type: 'createInitialView'; value: GridInitialState }
  | { type: 'createView'; value: GridInitialState }
  | { type: 'deleteView'; id: string }
  | { type: 'setNewViewLabel'; label: string }
  | { type: 'setActiveView'; id: string | null }
  | { type: 'togglePopper'; element: HTMLElement }
  | { type: 'closePopper' };

const initialState: DemoState = {
  views: {},
  newViewLabel: '',
  isMenuOpened: false,
  menuAnchorEl: null,
  activeViewId: null,
};

const demoReducer: React.Reducer<DemoState, DemoActions> = (state, action) => {
  const saveStateToLocalStorage = (views: { [id: string]: StateView }) => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(views));
  };

  switch (action.type) {
    case 'createInitialView': {
      const newView = {
        ...state,
        activeViewId: 'initialId',
        newViewLabel: '',
        views: {
          ...state.views,
          ['initialId']: { label: 'Initial view', value: action.value },
        },
      };

      saveStateToLocalStorage(newView?.views);

      return newView;
    }
    case 'createView': {
      const id = Math.random().toString();

      const newView = {
        ...state,
        activeViewId: id,
        newViewLabel: '',
        views: {
          ...state.views,
          [id]: { label: state.newViewLabel, value: action.value },
        },
      };

      saveStateToLocalStorage(newView?.views);

      return newView;
    }
    case 'deleteView': {
      let activeViewId: string | null;
      let views: { [x: string]: StateView } = state.views;

      views = Object.fromEntries(
        Object.entries(state.views).filter(([id]) => id !== action.id),
      );

      if (state.activeViewId !== action.id) {
        activeViewId = state.activeViewId;
      } else {
        const viewIds = Object.keys(state.views);

        if (viewIds.length === 0) {
          activeViewId = null;
        } else {
          activeViewId = 'initialId';
        }
      }

      const updateViews = {
        ...state,
        views,
        activeViewId,
      };

      saveStateToLocalStorage(updateViews?.views);
      return updateViews;
    }

    case 'setActiveView': {
      return {
        ...state,
        activeViewId: action.id,
        isMenuOpened: false,
      };
    }
    case 'setNewViewLabel': {
      return {
        ...state,
        newViewLabel: action.label,
      };
    }
    case 'togglePopper': {
      return {
        ...state,
        isMenuOpened: !state.isMenuOpened,
        menuAnchorEl: action.element,
      };
    }
    case 'closePopper': {
      return {
        ...state,
        isMenuOpened: false,
      };
    }
    default: {
      return state;
    }
  }
};

function ViewListItem(props: {
  view: StateView;
  viewId: string;
  selected: boolean;
  onDelete: (viewId: string) => void;
  onSelect: (viewId: string) => void;
}) {
  const { view, viewId, selected, onDelete, onSelect, ...other } = props;

  return (
    <MenuItem selected={selected} onClick={() => onSelect(viewId)} {...other}>
      {view?.label}

      <IconButton
        edge="end"
        aria-label="delete"
        size="small"
        onClick={event => {
          event.stopPropagation();
          onDelete(viewId);
        }}
      >
        {viewId !== 'initialId' && <DeleteIcon />}
      </IconButton>
    </MenuItem>
  );
}

function NewViewListButton(props: {
  label: string;
  onLabelChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => void;
  onSubmit: () => void;
  isValid: boolean;
}) {
  const { label, onLabelChange, onSubmit, isValid } = props;
  const [isAddingView, setIsAddingView] = React.useState(false);

  const handleSubmitForm: React.FormEventHandler = e => {
    onSubmit();
    setIsAddingView(false);
    e.preventDefault();
  };

  return (
    <Fragment>
      <Button
        endIcon={<AddIcon />}
        size="small"
        onClick={() => setIsAddingView(true)}
      >
        {t('Save current view')}
      </Button>
      <Dialog onClose={() => setIsAddingView(false)} open={isAddingView}>
        <form onSubmit={handleSubmitForm}>
          <DialogTitle>{t('New custom view')}</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              value={label}
              onChange={onLabelChange}
              margin="dense"
              size="small"
              label={t('Name view')}
              variant="standard"
              fullWidth
            />
          </DialogContent>
          <DialogActions>
            <Button type="button" onClick={() => setIsAddingView(false)}>
              {t('Cancel')}
            </Button>
            <Button type="submit" disabled={!isValid}>
              {t('Create view')}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Fragment>
  );
}

function CustomToolbar() {
  const apiRef = useGridApiContext();
  const [state, dispatch] = useReducer(demoReducer, initialState);

  useEffect(() => {
    const savedState = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedState) {
      const parsedState: { [id: string]: StateView } = JSON.parse(savedState);
      if (parsedState) {
        state.views = parsedState;
      }
    } else {
      createInitialView();
    }
  }, []);

  const createInitialView = () => {
    dispatch({
      type: 'createInitialView',
      value: apiRef.current.exportState(),
    });
  };

  const createNewView = () => {
    dispatch({
      type: 'createView',
      value: apiRef.current.exportState(),
    });
  };

  const handleDeleteView = useCallback((viewId: string) => {
    dispatch({ type: 'deleteView', id: viewId });
    apiRef.current.restoreState(state.views['initialId'].value);
  }, []);

  const handleSetActiveView = (viewId: string) => {
    apiRef.current.restoreState(state.views[viewId].value);
    dispatch({ type: 'setActiveView', id: viewId });
  };

  const handlePopperAnchorClick = (event: React.MouseEvent) => {
    dispatch({
      type: 'togglePopper',
      element: event.currentTarget as HTMLElement,
    });
    event.stopPropagation();
  };

  const handleClosePopper = () => {
    dispatch({ type: 'closePopper' });
  };

  const handleNewViewLabelChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    dispatch({ type: 'setNewViewLabel', label: event.target.value });
  };

  const isNewViewLabelValid = React.useMemo(() => {
    if (state.newViewLabel.length === 0) {
      return false;
    }

    return Object.values(state.views).every(
      view => view?.label !== state.newViewLabel,
    );
  }, [state.views, state.newViewLabel]);

  const canBeMenuOpened = state.isMenuOpened && Boolean(state.menuAnchorEl);
  const popperId = canBeMenuOpened ? 'transition-popper' : undefined;

  const handleListKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Tab') {
      event.preventDefault();
      dispatch({ type: 'closePopper' });
    } else if (event.key === 'Escape') {
      dispatch({ type: 'closePopper' });
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <Grid style={{ display: 'flex', justifyContent: 'space-between' }}>
        <GridToolbarContainer>
          <GridToolbarColumnsButton />
          <GridToolbarFilterButton />
          <GridToolbarDensitySelector />
          <GridToolbarExport
            csvOptions={{
              delimiter: ';',
              utf8WithBom: true,
            }}
          />
          <Button
            aria-describedby={popperId}
            type="button"
            size="small"
            id="custom-view-button"
            aria-controls={state.isMenuOpened ? 'custom-view-menu' : undefined}
            aria-expanded={state.isMenuOpened ? 'true' : undefined}
            aria-haspopup="true"
            onClick={handlePopperAnchorClick}
          >
            {t('Views')} ({Object.keys(state.views).length})
          </Button>
          <ClickAwayListener onClickAway={handleClosePopper}>
            <Popper
              id={popperId}
              open={state.isMenuOpened}
              anchorEl={state.menuAnchorEl}
              role={undefined}
              transition
              placement="bottom-start"
              sx={{ zIndex: 'modal' }}
            >
              {({ TransitionProps }) => (
                <Fade {...TransitionProps} timeout={350}>
                  <Paper>
                    <MenuList
                      autoFocusItem={state.isMenuOpened}
                      id="custom-view-menu"
                      aria-labelledby="custom-view-button"
                      onKeyDown={handleListKeyDown}
                    >
                      {Object.entries(state.views).map(([viewId, view]) => (
                        <ViewListItem
                          key={viewId}
                          view={view}
                          viewId={viewId}
                          selected={viewId === state.activeViewId}
                          onDelete={handleDeleteView}
                          onSelect={handleSetActiveView}
                        />
                      ))}
                    </MenuList>
                  </Paper>
                </Fade>
              )}
            </Popper>
          </ClickAwayListener>
          <NewViewListButton
            label={state.newViewLabel}
            onLabelChange={handleNewViewLabelChange}
            onSubmit={createNewView}
            isValid={isNewViewLabelValid}
          />
        </GridToolbarContainer>
        <GridToolbarContainer>
          <GridToolbarQuickFilter />
        </GridToolbarContainer>
      </Grid>
    </ThemeProvider>
  );
}

const refCompare = (a: Entity, b: Entity) => {
  const toRef = (entity: Entity) =>
    entity.metadata.title ||
    humanizeEntityRef(entity, {
      defaultKind: 'Component',
    });

  return toRef(a).localeCompare(toRef(b));
};

export const CatalogTable = (props: CatalogTableProps) => {
  const { columns } = props;
  const { loading, error, entities } = useEntityList();
  const context = useEntityList<MAREntityFilters>();
  const location = useLocation();
  const search = new URLSearchParams(location.search).get('search');
  useAsync(async () => {
    context.updateFilters({
      portal_pub: undefined,
      //country: undefined,
      liablePeople: undefined,
    });
  });

  const CLASSES = useStyles();

  if (error) {
    return (
      <div>
        <WarningPanel
          severity="error"
          title="Could not fetch catalog entities."
        >
          <CodeSnippet language="text" text={error.toString()} />
        </WarningPanel>
      </div>
    );
  }

  const ROWS: readonly GridValidRowModel[] = entities
    .sort(refCompare)
    .map(entity => {
      const partOfSystemRelations = getEntityRelations(
        entity,
        RELATION_PART_OF,
        {
          kind: 'system',
        },
      );
      const id: GridRowId = entity.metadata.name;
      const ownedByRelations = getEntityRelations(entity, RELATION_OWNED_BY);

      return {
        entity,
        id,
        resolved: {
          name: humanizeEntityRef(entity, {
            defaultKind: 'MapfreApi',
          }),
          ownedByRelationsTitle: ownedByRelations
            .map(r => humanizeEntityRef(r, { defaultKind: 'group' }))
            .join(', '),
          ownedByRelations,

          partOfSystemRelationTitle: partOfSystemRelations
            .map(r =>
              humanizeEntityRef(r, {
                defaultKind: 'system',
              }),
            )
            .join(', '),
          partOfSystemRelations,
        },
      };
    });

  const [columnVisibilityModel, setColumnVisibilityModel] =
    useState<GridColumnVisibilityModel>({
      id: false,
      businessEntity: false,
      respFunc: false,
      respTech: false,
      respAlt: false,
      NNII: false,
      NNIICcode: false,
      externalAccess: false,
      servName: false,
      //servUbic: false,
      architecture: false,
      ipFilter: false,
      endpointIc: false,
      endpointDev: false,
      endpointPre: false,
      endpointPro: false,
      portalPub: false,
      authType: false,
      permType: false,
      scopes: false,
      rolServIC: false,
      rolServPre: false,
      rolServPro: false,
      businessLine: false,
      apis: false,
    });

  return (
    <>
      {/* <Typography variant='h4'>
         All: {entities.length}
        </Typography> */}
      <ThemeProvider theme={theme}>
        <div className={CLASSES.tableStyle}>
          <StripedDataGrid
            loading={loading}
            columnVisibilityModel={columnVisibilityModel}
            onColumnVisibilityModelChange={newModel =>
              setColumnVisibilityModel(newModel)
            }
            getRowClassName={params =>
              params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
            }
            getRowHeight={() => 'auto'}
            columns={columns as GridColDef<GridValidRowModel>[]}
            rows={ROWS}
            slots={{
              toolbar: CustomToolbar,
              loadingOverlay: LinearProgress,
            }}
            initialState={{
              pagination: {
                paginationModel: { pageSize: 20 },
              },
              filter: {
                filterModel: {
                  items: [],
                  quickFilterValues: [search],
                },
              },
            }}
            pageSizeOptions={[20, 50, 100]}
            sx={{
              '&.MuiDataGrid-root--densityCompact .MuiDataGrid-cell': {
                py: '0.2em',
              },
              '&.MuiDataGrid-root--densityStandard .MuiDataGrid-cell': {
                py: '0.5em',
              },
              '&.MuiDataGrid-root--densityComfortable .MuiDataGrid-cell': {
                py: '1em',
              },
            }}
          />
        </div>
      </ThemeProvider>
    </>
  );
};
