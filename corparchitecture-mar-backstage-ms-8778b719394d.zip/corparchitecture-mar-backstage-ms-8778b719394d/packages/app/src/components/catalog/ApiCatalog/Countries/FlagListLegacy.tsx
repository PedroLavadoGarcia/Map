const FlagListLegacy = [
  // {
  //   image: '/icons/flags/Brazil.webp',
  //   title: 'Brazil',
  //   filterTag: 'BRA',
  // },
  {
    image: '/icons/flags/Spain.webp',
    title: 'Spain',
    filterTag: 'ESP',
  },
  // {
  //   image: '/icons/flags/Peru.webp',
  //   title: 'Peru',
  //   filterTag: 'PER',
  // },
  {
    image: '/icons/flags/Global.webp',
    title: 'Global',
    filterTag: 'GLOB',
  },
];

export { FlagListLegacy };
