import {
  Content,
  Page,
  Header,
  Progress,
  LinkButton,
} from '@backstage/core-components';
import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Container,
  Grid,
  IconButton,
  InputAdornment,
  Menu,
  MenuItem,
  TextField,
  Typography,
} from '@material-ui/core';
import React, { ChangeEvent, useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
//import { SearchBar } from '@backstage/plugin-search-react';
import { BackstageTheme } from '@backstage/theme';
import { FlagGridInternal } from './Countries/FlagGridInternal';
import { FlagGridExternal } from './Countries/FlagGridExternal';
import { FlagGridLegacy } from './Countries/FlagGridLegacy';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router';
// import { BussinessLineGrid } from './BussinessLine/BussinessLineGrid';
// import { BusinessEntityGrid } from './BusinessEntity/BusinessEntityGrid';

import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { useAsync } from 'react-use';
import { parseEntityRef } from '@backstage/catalog-model';
import { ApiListCardLayout } from './ApiListCardLayout';

import { EntityListProvider } from './CatalogTable/hooks/useEntityListProvider';
import SearchIcon from '@mui/icons-material/Search';
import { AuditService } from '../../../api/audit';
import { NavLink } from 'react-router-dom';
// import ClearIcon from '@mui/icons-material/Clear';

export const ApiHomePage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [search, setSearch] = useState('');

  const identityApi = useApi(identityApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getString('backend.baseUrl');
  const audit = new AuditService(backendUrl);
  const [isExternal, setIsExternal] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const { loading } = useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();
    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setIsExternal(Boolean(extEntityRefs.length));
  });
  const { value: email } = useAsync(async () => {
    const profile = await identityApi.getProfileInfo();
    return profile.email ?? '';
  });
  const useStyles = makeStyles<BackstageTheme>(() => ({
    bar: {
      borderRadius: '25px',
      borderWidth: '1px',
      opacity: '1',
      padding: '2px 20px 0px 20px',
      width: '100%',
      marginLeft: '3%',
    },
    typography: {
      textAlign: 'center',
      marginTop: '30px',
      fontSize: '32px',
    },
    divider: {
      width: 2,
      background: '#DB271C',
      margin: '8px 0',
    },
  }));
  const classes = useStyles();
  const searchAPILink =
    '../apis?filters%5Bkind%5D=mapfreapi&filters%5Buser%5D=all&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=Edge%20API&filters%5Btypology%5D=Login%20API';

  useEffect(() => {
    const supportName = document.querySelector(
      '[aria-label=support]',
    )?.lastChild;
    let supportText: string | null | undefined = '';
    if (supportName) {
      supportText = supportName?.textContent;
      supportName.textContent = t(`${supportText}`);
    }
  }, [document.body]);

  async function handleChange(e: ChangeEvent<HTMLInputElement>) {
    setSearch(e.target.value);
  }
  // async function handleClear() {
  //   setSearch('');
  // }

  function checkGroup(entityRefs: string[]): {
    groups: string[];
    showButton: boolean;
  } {
    const allowedGroups = (entityRefs as string[]).filter(entityRef => {
      const parsedRef = parseEntityRef(entityRef);
      const groupName = parsedRef.name.toLowerCase();
      const isGroup = parsedRef.kind === 'group';
      return (
        isGroup &&
        (groupName.startsWith('gazr-gov-backstage-global') ||
          groupName.startsWith('gazr-gov-backstage'))
      );
    });

    return {
      groups: allowedGroups,
      showButton: allowedGroups.length > 0,
    };
  }
  const isGroup = () => {
    const {
      loading,
      value: showButton,
      error,
    } = useAsync(async () => {
      try {
        const { ownershipEntityRefs: entityRefs } =
          await identityApi.getBackstageIdentity();
        const { showButton } = checkGroup(entityRefs);
        return showButton;
      } catch (error) {
        return false;
      }
    }, []);
    return { loading, showButton, error };
  };

  const { showButton } = isGroup();

  return (
    <>
      {loading ? (
        <Progress />
      ) : isExternal ? (
        <EntityListProvider>
          <ApiListCardLayout />
        </EntityListProvider>
      ) : (
        <Page themeId="">
          <Content>
            <Header title="">
              {showButton && (
                <>
                  <Button
                    className={classes.button}
                    aria-controls="simple-menu"
                    aria-haspopup="true"
                    onClick={handleClick}
                    style={{
                      color: '#DB271C',
                      marginRight: '10px',
                      textTransform: 'none',
                    }}
                  >
                    {t('Add API')}
                  </Button>
                  <Menu
                    id="simple-menu"
                    anchorEl={anchorEl}
                    keepMounted
                    open={Boolean(anchorEl)}
                    onClose={handleClose}
                  >
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=Edge_API"
                    >
                      {t('Edge Services')}
                    </MenuItem>
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=External_Services"
                    >
                      {t('External Services')}
                    </MenuItem>
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=Login_API"
                    >
                      {t('Login Api')}
                    </MenuItem>
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=Mediation_API"
                    >
                      {t('Mediation Services')}
                    </MenuItem>
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=REST_Services"
                    >
                      {t('REST Services')}
                    </MenuItem>
                    <MenuItem
                      onClick={handleClose}
                      component={NavLink}
                      to="/forms/mapfreapi?typology=SOAP_Services"
                    >
                      {t('SOAP Services')}
                    </MenuItem>
                  </Menu>
                </>
              )}
            </Header>
            <Typography variant={'h1'} classes={{ root: classes.typography }}>
              {t('APIs Catalog')}
            </Typography>

            <Container>
              <Grid
                container
                justifyContent="center"
                style={{ textAlign: 'center', marginTop: '20px' }}
                spacing={4}
              >
                <Grid
                  container
                  alignItems="center"
                  style={{ marginBlockEnd: '20px' }}
                  justifyContent="center"
                >
                  <Grid item xs={8}>
                    <TextField
                      onKeyDown={e =>
                        e.key === 'Enter' &&
                        navigate(searchAPILink + '&search=' + search)
                      }
                      placeholder={
                        t('Search in MAPFRE APIs Catalog') as string | undefined
                      }
                      style={{ width: '100%' }}
                      variant="outlined"
                      size="small"
                      value={search}
                      onChange={handleChange}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="Search"
                              onClick={() =>
                                navigate(searchAPILink + '&search=' + search)
                              }
                            >
                              <SearchIcon />
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  <Button
                    variant="contained"
                    color="primary"
                    size="medium"
                    onClick={() => {
                      if (search && email) {
                        audit.pushSearchLog(email, search);
                      }
                      navigate(searchAPILink + '&search=' + search);
                    }}
                    style={{ marginLeft: '8px' }}
                  >
                    {t('Search')}
                  </Button>
                </Grid>
                <Grid
                  container
                  justifyContent="center"
                  style={{ textAlign: 'center', marginTop: '10px' }}
                  spacing={8}
                >
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Componentes.webp'}
                      />
                      <CardContent>
                        <Typography variant="h5" color="inherit" align="center">
                          {t('APIs shared with collaborating companies')}
                        </Typography>
                        <Grid
                          style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            justifyContent: 'center',
                          }}
                        >
                          <FlagGridExternal />
                        </Grid>
                      </CardContent>
                      <CardActions>
                        <LinkButton
                          variant="text"
                          color="primary"
                          to="/apis?filters%5Buser%5D=all&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                          style={{ margin: 'auto', fontWeight: 'bold' }}
                        >
                          {t('View list')}
                        </LinkButton>

                        <LinkButton
                          variant="text"
                          color="primary"
                          to="/apis?filters%5Bkind%5D=mapfreapi"
                          state={{ showCards: true }}
                          style={{ margin: 'auto', fontWeight: 'bold' }}
                        >
                          {t('See consumer view')}
                        </LinkButton>
                      </CardActions>
                    </Card>
                  </Grid>
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Componentes.webp'}
                      />
                      <CardContent>
                        <Typography variant="h5" color="inherit" align="center">
                          {t('Consumption APIs from within MAPFRE')}
                        </Typography>
                        <Grid
                          style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            justifyContent: 'center',
                          }}
                        >
                          <FlagGridInternal />
                        </Grid>
                      </CardContent>
                      <CardActions>
                        <LinkButton
                          variant="text"
                          color="primary"
                          to="/apis?filters%5Buser%5D=all&filters%5Bkind%5D=mapfreapi"
                          style={{ margin: 'auto', fontWeight: 'bold' }}
                        >
                          {t('View list')}
                        </LinkButton>
                      </CardActions>
                    </Card>
                  </Grid>
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Apis.webp'}
                      />
                      <CardContent>
                        <Typography variant="h5" color="inherit" align="center">
                          {t('Business APIs based on TRON')}
                        </Typography>

                        <Typography
                          color="inherit"
                          align="justify"
                          variant="body2"
                        >
                          {`${t(
                            'Query APIs with a pre-built enterprise implementation. This can be used as the basis for building new APIs',
                          )}.`}
                        </Typography>
                        <Typography style={{ visibility: 'hidden' }}>
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a
                        </Typography>
                      </CardContent>
                      <CardActions>
                        <LinkButton
                          variant="text"
                          color="primary"
                          to="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=TRON&filters%5Bkind%5D=mapfreapi&search="
                          style={{ margin: 'auto', fontWeight: 'bold' }}
                        >
                          {t('Access to APIs')}
                        </LinkButton>
                      </CardActions>
                    </Card>
                  </Grid>
                </Grid>
                <Grid
                  container
                  justifyContent="center"
                  style={{ textAlign: 'center', marginTop: '20px' }}
                  spacing={8}
                >
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Apis.webp'}
                      />
                      <CardContent>
                        <Typography variant="h5" color="inherit" align="center">
                          {t('Entity APIs')}
                        </Typography>
                        <Typography
                          color="inherit"
                          align="justify"
                          variant="body2"
                        >
                          <Grid>
                            <strong>{t('MAWDY')}</strong>
                            {`: ${t('Consumption APIs from')}  `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=ASIS&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('outside')}
                            </a>
                            {` ${t('MAPFRE or from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=ASIS&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('within')}
                            </a>
                            {` ${t(' MAPFRE')}.`}
                          </Grid>
                          <Grid>
                            <strong>{t('RE')}</strong>
                            {`: ${t('Consumption APIs from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=RE&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('outside')}
                            </a>
                            {` ${t('MAPFRE or from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=RE&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('within')}
                            </a>
                            {` ${t(' MAPFRE')}.`}
                          </Grid>
                          <Grid>
                            <strong>{t('Investment')}</strong>
                            {`: ${t('Consumption APIs from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=INV&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('outside')}
                            </a>
                            {` ${t('MAPFRE or from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=INV&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('within')}
                            </a>
                            {` ${t(' MAPFRE')}.`}
                          </Grid>
                          <Grid>
                            <strong>{t('Solunion')}</strong>
                            {`: ${t('Consumption APIs from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=SOL&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('outside')}
                            </a>
                            {` ${t('MAPFRE or from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=SOL&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('within')}
                            </a>
                            {` ${t(' MAPFRE')}.`}
                          </Grid>
                          <Grid>
                            <strong>{t('Corporate')}</strong>
                            {`: ${t('Consumption APIs from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=GLOBAL&filters%5Btypology%5D=API%20Consumer&filters%5Btypology%5D=API%20Provider&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=External%20Services&filters%5Btypology%5D=GW%20Services&filters%5Btypology%5D=Login%20API&filters%5Btypology%5D=REST%20Services&filters%5Btypology%5D=SOAP%20Services&filters%5Btypology%5D=BFF%20API&filters%5Btypology%5D=EVENT&filters%5Btypology%5D=Virtual%20Services&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('outside')}
                            </a>
                            {` ${t('MAPFRE or from')} `}
                            <a
                              href="/apis?filters%5Buser%5D=all&filters%5Bcountry%5D=GLOBAL&filters%5Bkind%5D=mapfreapi"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('within')}
                            </a>
                            {` ${t(' MAPFRE')}.`}
                          </Grid>
                        </Typography>
                      </CardContent>
                      <CardActions></CardActions>
                    </Card>
                  </Grid>
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Componentes.webp'}
                      />
                      <CardContent>
                        <Typography variant="h3" color="inherit" align="center">
                          {t('APIs Legacy')}
                        </Typography>
                        <Grid
                          style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            justifyContent: 'center',
                            marginTop: '10px',
                          }}
                        >
                          <FlagGridLegacy />
                        </Grid>
                        <Typography style={{ visibility: 'hidden' }}>
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a
                        </Typography>
                      </CardContent>
                      <CardActions></CardActions>
                    </Card>
                  </Grid>
                  <Grid item sm={12} md={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        alt="green iguana"
                        height="160"
                        image={'/home_img/Apis.webp'}
                      />
                      <CardContent>
                        <Typography variant="h5" color="inherit" align="center">
                          {t('Regulations')}
                        </Typography>
                        <Typography
                          color="inherit"
                          align="justify"
                          variant="body2"
                        >
                          <Grid>
                            <strong>{`${t('API regulations')}: `}</strong>
                            <a
                              href="/docs/default/mapfredocument/48be0c37-1b00-4021-be27-156257ce325e/Normativas/NormativaAPI/introduccion-api-rest.glb_es/"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t('REST standards for APIs design')}
                            </a>
                          </Grid>
                          <Grid>
                            <strong>{`${t(
                              'API publication procedure',
                            )}: `}</strong>
                            <a
                              href="/docs/default/mapfredocument/48be0c37-1b00-4021-be27-156257ce325e/ProcedimientosAPIsServicios/guia-de-peticion.glb_es/"
                              style={{
                                textDecoration: 'underline',
                                color: 'red',
                              }}
                            >
                              {t(
                                'Lifecycle flow of publishing an API in Mapfre in Marketplace and API GW',
                              )}
                            </a>
                          </Grid>
                        </Typography>
                        <Typography style={{ visibility: 'hidden' }}>
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                          a a a a a a a a a a a a a a a a a a a a a a a a a a a
                        </Typography>
                      </CardContent>
                      <CardActions></CardActions>
                    </Card>
                  </Grid>
                </Grid>

                {/*<Grid item xs={12}>
                  <Typography variant="h3">{t('Filter by Country')}</Typography>
                </Grid>
                <Grid
                  item
                  container
                  xs={10}
                  direction={'row'}
                  style={{ textAlign: 'center' }}
                >
                  <FlagGrid />
                  </Grid>*/}

                {/* <Grid item xs={12}>
                  <Typography variant="h3">
                    {t('Filter by Business Line')}
                  </Typography>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <BussinessLineGrid />
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="h3">
                    {t('Filter by Business Entity')}
                  </Typography>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <BusinessEntityGrid />
                </Grid> */}
              </Grid>
            </Container>
          </Content>
        </Page>
      )}
    </>
  );
};
