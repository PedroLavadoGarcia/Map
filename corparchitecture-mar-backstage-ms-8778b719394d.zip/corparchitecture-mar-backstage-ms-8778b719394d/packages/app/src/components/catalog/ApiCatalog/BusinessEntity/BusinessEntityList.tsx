const BusinessEntityList = [
  {
    title: 'Quote And Buy',
    filterTag: 'Quote And Buy',
  },
  {
    title: 'Claim',
    filterTag: 'Claim',
  },
  {
    title: 'Receipt',
    filterTag: 'Receipt',
  },
  {
    title: 'Provider',
    filterTag: 'Provider',
  },
  {
    title: 'Distributor',
    filterTag: 'Distributor',
  },
  {
    title: 'Client',
    filterTag: 'Client',
  },
  {
    title: 'Catalog',
    filterTag: 'Catalog',
  },
  {
    title: 'Document',
    filterTag: 'Document',
  },
  {
    title: 'Application Utilities',
    filterTag: 'Application Utilities',
  },
  {
    title: 'Not applicable',
    filterTag: 'Not applicable',
  },
];

export { BusinessEntityList };
