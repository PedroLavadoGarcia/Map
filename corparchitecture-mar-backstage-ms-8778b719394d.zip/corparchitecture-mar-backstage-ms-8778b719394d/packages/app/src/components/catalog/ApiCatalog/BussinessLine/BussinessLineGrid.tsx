import ArrowRight from '@material-ui/icons/ArrowRight';
import ArrowLeft from '@material-ui/icons/ArrowLeft';

import React, { useRef } from 'react';
import { BackstageTheme } from '@backstage/theme';
import { ButtonBase, makeStyles, Typography } from '@material-ui/core';
import { BussinessLineList } from './BussinessLineList';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router';

export const BussinessLineGrid = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const useStyles = makeStyles<BackstageTheme>(() => ({
    carouselContainer: {
      marginTop: '10px',
      flexWrap: 'nowrap',
      width: '75%',
      display: 'inline-flex',
      flexDirection: 'row',
      textAlign: 'center',
    },
    bussinessIcon: {
      height: '30px',
      width: '100px',
      paddingTop: '8px',
      textAlign: 'center',
      filter:
        'invert(29%) sepia(10%) saturate(658%) hue-rotate(169deg) brightness(95%) contrast(88%)',
    },
    flagContainer: {
      marginTop: '-10px',
      flexWrap: 'nowrap',
      display: 'inline-flex',
      overflow: 'hidden',
      width: '100%',
    },
    boxImage: {
      '&:hover': {
        color: '#DB271C',
        '& img': {
          filter:
            'invert(37%) sepia(80%) saturate(3936%) hue-rotate(342deg) brightness(81%) contrast(114%)',
        },
      },

      display: 'inline-table',
      width: '100px',
      height: '70px',
      cursor: 'pointer',
      padding: '8px 0 8px 0',
    },
  }));
  const scrollRef = useRef(null);
  const handleScroll = (
    element: { scrollLeft: number } | null,
    step: number,
    distance: number,
    speed: number | undefined,
  ) => {
    let scrollAmount = 0;
    const slideTimer = setInterval(() => {
      if (element) element.scrollLeft += step;
      scrollAmount += Math.abs(step);
      if (scrollAmount >= distance) {
        clearInterval(slideTimer);
      }
    }, speed);
  };
  const classes = useStyles();
  const bussinessLineFilterPath =
    '/apis?filters%5Bkind%5D=mapfreapi&filters%5Buser%5D=all&&filters%5Btags%5D=';

  return (
    <div className={classes.carouselContainer}>
      <ButtonBase
        onClick={() => {
          handleScroll(scrollRef.current, -15, 100, 35);
        }}
      >
        <ArrowLeft />
      </ButtonBase>
      <div className={classes.flagContainer} ref={scrollRef}>
        {BussinessLineList.map(function (flag, idx) {
          return (
            <div key={idx}>
              <div
                className={classes.boxImage}
                onClick={() =>
                  navigate(`${bussinessLineFilterPath}${flag.filterTag}`)
                }
              >
                <img
                  src={flag.image}
                  alt={flag.title}
                  className={`bussinessIcon ${classes.bussinessIcon}`}
                />
                <Typography variant="body2"> {t(flag.title)}</Typography>
              </div>
            </div>
          );
        })}
      </div>
      <ButtonBase
        onClick={() => {
          handleScroll(scrollRef.current, 15, 100, 35);
        }}
      >
        <ArrowRight />
      </ButtonBase>
    </div>
  );
};
