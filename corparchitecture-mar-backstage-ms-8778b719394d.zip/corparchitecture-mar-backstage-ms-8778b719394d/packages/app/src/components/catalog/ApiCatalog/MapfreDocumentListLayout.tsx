import {
  Content,
  ContentHeader,
  Page,
  TableFilter,
  TableProps,
} from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityKindFilter,
  UserListFilterKind,
} from '@backstage/plugin-catalog-react';
import React, { useState } from 'react';
import { CatalogTableRow } from '@backstage/plugin-catalog';
import { SearchContextProvider } from '@backstage/plugin-search-react';
import { useLocation, useOutlet } from 'react-router';
import { useTranslation } from 'react-i18next';
import {
  EntityCountryPicker,
  MAREntityFilters,
} from '../../pickers/EntityCountryPicker';

import { UserListPicker } from '../../pickers/UserListPicker';

import { useEntityList } from './CatalogTable/hooks/useEntityListProvider';
import { CatalogTable } from './CatalogTable';
import { GridColDef, GridValidRowModel } from '@mui/x-data-grid';
import { EntityOwnerPicker } from '../../pickers/EntityOwnerPicker';
import { EntityTypeDocPicker } from '../../pickers/EntityTypeDocPicker';

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  columns?: GridColDef<GridValidRowModel>[] | undefined;
  actions?: TableProps<CatalogTableRow>['actions'];
  initialKind?: string;
  tableOptions?: TableProps<CatalogTableRow>['options'];
  filters?: TableFilter;
}

export const MapfreDocumentListLayout = ({
  columns,
  initiallySelectedFilter = 'all',
}: CatalogPageProps) => {
  const location = useLocation();

  const outlet = useOutlet();
  const { t } = useTranslation();
  const kind = new URLSearchParams(location.search);
  const kindParam = kind.get('filters[kind]');

  const context = useEntityList<MAREntityFilters>();

  context.updateFilters({
    kind: new EntityKindFilter(kindParam as string),
  });

  return (
    outlet || (
      <Page themeId="home">
        <Content>
          <ContentHeader title={t('Mapfre Document') as string}></ContentHeader>
          <CatalogFilterLayout>
            <CatalogFilterLayout.Filters>
              <SearchContextProvider>
                <>
                  <UserListPicker initialFilter={initiallySelectedFilter} />
                  <EntityCountryPicker />
                  <EntityOwnerPicker />
                  <EntityTypeDocPicker />
                </>
              </SearchContextProvider>
            </CatalogFilterLayout.Filters>
            <>
              <CatalogFilterLayout.Content>
                <CatalogTable
                  columns={columns as GridColDef<GridValidRowModel>[]}
                />
              </CatalogFilterLayout.Content>
            </>
          </CatalogFilterLayout>
        </Content>
      </Page>
    )
  );
};
