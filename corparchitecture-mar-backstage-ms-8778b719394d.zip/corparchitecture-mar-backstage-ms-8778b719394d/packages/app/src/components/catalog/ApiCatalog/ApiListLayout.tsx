import {
  Content,
  ContentHeader,
  Page,
  TableFilter,
  TableProps,
} from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityKindFilter,
  UserListFilterKind,
} from '@backstage/plugin-catalog-react';
import React, { useState } from 'react';
import { CatalogTableRow } from '@backstage/plugin-catalog';
import { Entity, parseEntityRef } from '@backstage/catalog-model';
import { SearchContextProvider } from '@backstage/plugin-search-react';
import { useLocation, useOutlet } from 'react-router';
import { useTranslation } from 'react-i18next';
import { Button, makeStyles, Menu, MenuItem } from '@material-ui/core';
import { EntityTypologyPicker } from '../../pickers/EntityTypologyPicker';
import {
  EntityCountryPicker,
  MAREntityFilters,
} from '../../pickers/EntityCountryPicker';
import { EntityBusinessEntityPicker } from '../../pickers/EntityBusinessEntityPicker';
import { EntityBusinessLinePicker } from '../../pickers/EntityBusinessLinePicker';
import { exportCSVFile } from '../CreateCSV/exportCSVFile';
import { EntityLifecyclePicker } from '../../pickers/EntityLifecyclePicker';
import { UserListPicker } from '../../pickers/UserListPicker';
import {
  EntityKindLegEspPicker,
  EntityKindLegGlobalPicker,
  EntityKindLegacyBraPicker,
  EntityKindLegacyPerPicker,
  EntityKindMapfreApiPicker,
} from '../../pickers/EntityKindPicker';
import { useEntityList } from './CatalogTable/hooks/useEntityListProvider';
import { CatalogTable } from './CatalogTable';
import { GridColDef, GridValidRowModel } from '@mui/x-data-grid';
import Tooltip from '@mui/material/Tooltip';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import ListIcon from '@mui/icons-material/List';
import { ApiListCardGov } from './ApiListCardGov';
import { EntitySystemPicker } from '../../pickers/EntitySystemPicker';
import { EntityOwnerPicker } from '../../pickers/EntityOwnerPicker';
import { useAsync } from 'react-use';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { NavLink } from 'react-router-dom';

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  columns?: GridColDef<GridValidRowModel>[] | undefined;
  actions?: TableProps<CatalogTableRow>['actions'];
  initialKind?: string;
  tableOptions?: TableProps<CatalogTableRow>['options'];
  filters?: TableFilter;
}

export async function getFilteredMapfreApis(): Promise<
  Record<string, string>[]
> {
  const searchParams = new URLSearchParams(window.location.search);
  const searchString = Array.from(searchParams)
    .map(i =>
      i.map(x =>
        x
          .replace(/filters|\[|\]/g, '')
          .replace(/^owners$/, 'spec.owner')
          .replace(/^country$/, 'metadata.country')
          .replace(/^typology$/, 'metadata.typology')
          .replace(/^lifecycles$/, 'spec.lifecycle')
          .replace(/^businessEntity$/, 'metadata.[mapfre.com/businessEntity]')
          .replace(/^business_line$/, 'metadata.[mapfre.com/business_line]'),
      ),
    )
    .filter(i => i[0] !== 'user' && i[0] !== 'search')
    .map(item => item.join('='))
    .join(',');
  const apiEndpointQuery = new URLSearchParams({ filter: searchString });
  const apiEndpointUrl = new URL(
    '/api/catalog/entities',
    window.location.origin.replace('3000', '7007'),
  );
  apiEndpointUrl.search = apiEndpointQuery.toString();
  const apiRequest = new Request(apiEndpointUrl.toString());

  let entities = await (await fetch(apiRequest)).json();
  if (searchParams.get('search')) {
    const regex = new RegExp(searchParams.get('search') as string, 'i');
    entities = entities.filter(
      (entity: Entity) =>
        entity.metadata.title?.match(regex) ||
        (typeof entity.metadata['mapfre.com/state'] === 'string' &&
          entity.metadata['mapfre.com/state']?.match(regex)) ||
        (typeof entity.metadata.typology === 'string' &&
          entity.metadata.typology?.match(regex)) ||
        (typeof entity.metadata.version === 'string' &&
          entity.metadata.version?.match(regex)) ||
        (typeof entity.metadata.country === 'string' &&
          entity.metadata.country?.match(regex)) ||
        (typeof entity.metadata.description === 'string' &&
          entity.metadata.description?.match(regex)) ||
        (typeof entity.metadata.modDate === 'string' &&
          entity.metadata.modDate?.match(regex)),
    );
  }

  function joinArray(value: string | null | string[]) {
    if (Array.isArray(value)) {
      return `"${value.join(', ')}"`;
    }
    return value;
  }

  function replaceCommas(value: string | null) {
    return value?.replaceAll(',', ' ');
  }

  const entitiesMetas = entities.map?.((entity: Record<string, unknown>) => {
    const metadata = entity.metadata as Record<string, unknown>;
    const spec = entity.spec as Record<string, unknown>;
    return {
      Name: metadata.name,
      Title: metadata.title,
      Version: metadata.version,
      State: metadata['mapfre.com/state'],
      Typology: metadata.typology,
      Country: metadata.country,
      Description: replaceCommas(metadata.description as string),
      repository: (metadata.annotations as Record<string, string>)[
        'backstage.io/view-url'
      ],
      Owners: joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/owners'
        ],
      ),
      'Functional Manager': joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/resp_func'
        ],
      ),
      'Technical Manager': joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/resp_tech'
        ],
      ),
      'Alternative Manager': replaceCommas(
        (metadata?.liablePeople as Record<string, string | null>)?.[
          'mapfre.com/resp_alt'
        ],
      ),
      NNII: joinArray(
        (metadata?.contextData as Record<string, string>)?.['mapfre.com/NNII'],
      ),
      'NNII Code': joinArray(
        (metadata?.contextData as Record<string, string>)?.[
          'mapfre.com/NNII_code'
        ],
      ),
      'External Access': joinArray(
        (metadata?.contextData as Record<string, string>)?.[
          'mapfre.com/externalAccess'
        ],
      ),
      'Service Type': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) =>
                acc.concat((curr['mapfre.com/serv_type'] as string[]) || []),
              [] as string[],
            )
          : [],
      ),
      Architecture: joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const architecture = curr['mapfre.com/architecture'];
                const serviceType = curr['mapfre.com/serv_type'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + architecture;
                } else if (architecture) {
                  result = architecture as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.technicalData as Record<string, string[] | string>)?.[
              'mapfre.com/architecture'
            ],
      ),
      'Interface Type': joinArray((spec as Record<string, string>)?.['type']),
      'Permission Type': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const permissionType = curr['mapfre.com/perm_type'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + permissionType;
                } else if (permissionType) {
                  result = permissionType as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.technicalData as Record<string, string | null>)?.[
              'mapfre.com/perm_type'
            ],
      ),
      /*'Service Location': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceLocation = curr['mapfre.com/serv_ubic'];
                const serviceType = curr['mapfre.com/serv_type'];
                let result = '';
                if (serviceType && serviceType !== '' && serviceLocation) {
                  result = serviceType + ': ' + serviceLocation;
                } else if (serviceLocation) {
                  result = serviceLocation as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.technicalData as Record<string, string[] | string>)?.[
              'mapfre.com/serv_ubic'
            ],
      ),*/
      'IP Filtering': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const ipFiltering = curr['mapfre.com/ip_filter'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + ipFiltering;
                } else if (ipFiltering) {
                  result = ipFiltering as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.technicalData as Record<string, string>)?.[
              'mapfre.com/ip_filter'
            ],
      ),
      'Event Classification': joinArray(
        (metadata?.technicalData as Record<string, string>)?.[
          'mapfre.com/event_classification'
        ],
      ),
      'Compaction Logs': joinArray(
        (metadata?.technicalData as Record<string, string>)?.[
          'mapfre.com/compaction_logs'
        ],
      ),
      'Sorted Message': joinArray(
        (metadata?.technicalData as Record<string, string>)?.[
          'mapfre.com/sorted_message'
        ],
      ),
      'Retention Time': joinArray(
        (metadata?.technicalData as Record<string, string | null>)?.[
          'mapfre.com/retention_time'
        ],
      ),
      'Num Partitions': joinArray(
        (metadata?.technicalData as Record<string, string | null>)?.[
          'mapfre.com/num_partitions'
        ],
      ),
      'IC Endpoint': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const icEndpoint = curr['mapfre.com/endpoint_IC'];
                let result = '';
                const isValidEndpoint = Array.isArray(icEndpoint)
                  ? icEndpoint.length > 0
                  : icEndpoint;
                if (isValidEndpoint) {
                  if (serviceType && serviceType !== '' && icEndpoint) {
                    result = serviceType + ': ' + icEndpoint;
                  } else if (icEndpoint) {
                    result = icEndpoint as string;
                  }
                }
                if (result) {
                  return acc.concat(result);
                }
                return acc;
              },
              [] as string[],
            )
          : (metadata?.serviceAvailability as Record<string, string[]>)?.[
              'mapfre.com/endpoint_IC'
            ],
      ),
      'DEV Endpoint': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const devEndpoint = curr['mapfre.com/endpoint_DEV'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + devEndpoint;
                } else if (devEndpoint) {
                  result = devEndpoint as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.serviceAvailability as Record<string, string[]>)?.[
              'mapfre.com/endpoint_DEV'
            ],
      ),
      'PRE Endpoint': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const preEndpoint = curr['mapfre.com/endpoint_PRE'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + preEndpoint;
                } else if (preEndpoint) {
                  result = preEndpoint as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.serviceAvailability as Record<string, string[]>)?.[
              'mapfre.com/endpoint_PRE'
            ],
      ),
      'PRO Endpoint': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const proEndpoint = curr['mapfre.com/endpoint_PRO'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + proEndpoint;
                } else if (proEndpoint) {
                  result = proEndpoint as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.serviceAvailability as Record<string, string[]>)?.[
              'mapfre.com/endpoint_PRO'
            ],
      ),
      'Publish in Portal': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const publishInPortal = curr['mapfre.com/portal_pub'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + publishInPortal;
                } else if (publishInPortal) {
                  result = publishInPortal as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (metadata?.serviceAvailability as Record<string, string>)?.[
              'mapfre.com/portal_pub'
            ],
      ),

      'Last publication date in WSRR EDIC': isNaN(
        (metadata?.wsrr as Record<string, number>)?.[
          'mapfre.com/wsrr_last_pub_IC'
        ],
      )
        ? 'NaN'
        : (metadata?.wsrr as Record<string, number>)?.[
            'mapfre.com/wsrr_last_pub_IC'
          ] &&
          new Date(
            Number(
              (metadata?.wsrr as Record<string, number>)?.[
                'mapfre.com/wsrr_last_pub_IC'
              ],
            ),
          ).toISOString(),

      'Last publication date in WSRR INTEGRATION': isNaN(
        (metadata?.wsrr as Record<string, number>)?.[
          'mapfre.com/wsrr_last_pub_DEV'
        ],
      )
        ? 'NaN'
        : (metadata?.wsrr as Record<string, number>)?.[
            'mapfre.com/wsrr_last_pub_DEV'
          ] &&
          new Date(
            Number(
              (metadata?.wsrr as Record<string, number>)?.[
                'mapfre.com/wsrr_last_pub_DEV'
              ],
            ),
          ).toISOString(),

      'Last publication date in WSRR PREPRODUCTION': isNaN(
        (metadata?.wsrr as Record<string, number>)?.[
          'mapfre.com/wsrr_last_pub_PRE'
        ],
      )
        ? 'NaN'
        : (metadata?.wsrr as Record<string, number>)?.[
            'mapfre.com/wsrr_last_pub_PRE'
          ] &&
          new Date(
            Number(
              (metadata?.wsrr as Record<string, number>)?.[
                'mapfre.com/wsrr_last_pub_PRE'
              ],
            ),
          ).toISOString(),

      'Last publication date in WSRR PRODUCTION': isNaN(
        (metadata?.wsrr as Record<string, number>)?.[
          'mapfre.com/wsrr_last_pub_PRO'
        ],
      )
        ? 'NaN'
        : (metadata?.wsrr as Record<string, number>)?.[
            'mapfre.com/wsrr_last_pub_PRO'
          ] &&
          new Date(
            Number(
              (metadata?.wsrr as Record<string, number>)?.[
                'mapfre.com/wsrr_last_pub_PRO'
              ],
            ),
          ).toISOString(),

      'Last publication date in WSRR PROBIS': isNaN(
        (metadata?.wsrr as Record<string, number>)?.[
          'mapfre.com/wsrr_last_pub_PROBIS'
        ],
      )
        ? 'NaN'
        : (metadata?.wsrr as Record<string, number>)?.[
            'mapfre.com/wsrr_last_pub_PROBIS'
          ] &&
          new Date(
            Number(
              (metadata?.wsrr as Record<string, number>)?.[
                'mapfre.com/wsrr_last_pub_PROBIS'
              ],
            ),
          ).toISOString(),

      'Authentication Type': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const authenticationType = curr['mapfre.com/auth_type'];
                let result = '';
                if (serviceType && serviceType !== '') {
                  result = serviceType + ': ' + authenticationType;
                } else if (authenticationType) {
                  result = authenticationType as string;
                }
                return acc.concat(result);
              },
              [] as string[],
            )
          : (
              metadata?.executionPermissions as Record<
                string,
                string[] | string
              >
            )?.['mapfre.com/auth_type'],
      ),
      Scopes: joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[]).reduce(
              (acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const scopes = curr['mapfre.com/scopes'];
                let result = '';
                const isValidScope = Array.isArray(scopes)
                  ? scopes.length > 0
                  : scopes;
                if (isValidScope) {
                  if (serviceType && serviceType !== '') {
                    result = serviceType + ': ' + scopes;
                  } else if (scopes) {
                    result = scopes as string;
                  }
                }
                if (result) {
                  return acc.concat(result);
                }
                return acc;
              },
              [] as string[],
            )
          : (
              metadata?.executionPermissions as Record<
                string,
                string[] | string | null
              >
            )?.['mapfre.com/scopes'],
      ),
      'Service role/user in integration': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[])
              .reduce((acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const icRole = curr['mapfre.com/rol_serv_IC'];
                let result = '';
                const isValidICRole = Array.isArray(icRole)
                  ? icRole.length > 0
                  : icRole;
                if (isValidICRole) {
                  if (serviceType && serviceType !== '') {
                    result = serviceType + ': ' + icRole;
                  } else if (icRole) {
                    result = icRole as string;
                  }
                }
                if (result) {
                  return acc.concat(result);
                }
                return acc;
              }, [] as string[])
              .map(item => item.replaceAll(',', ' '))
          : (metadata?.executionPermissions as Record<string, string[]>)?.[
              'mapfre.com/rol_serv_IC'
            ]?.map(item => item.replaceAll(',', ' ')),
      ),
      'Service role/user in preproduction': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[])
              .reduce((acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const preRole = curr['mapfre.com/rol_serv_PRE'];
                let result = '';
                const isValidPRERole = Array.isArray(preRole)
                  ? preRole.length > 0
                  : preRole;
                if (isValidPRERole) {
                  if (serviceType && serviceType !== '') {
                    result = serviceType + ': ' + preRole;
                  } else {
                    result = preRole as string;
                  }
                }
                if (result) {
                  return acc.concat(result);
                }
                return acc;
              }, [] as string[])
              .map(item => item.replaceAll(',', ' '))
          : (metadata?.executionPermissions as Record<string, string[]>)?.[
              'mapfre.com/rol_serv_PRE'
            ]?.map(item => item.replaceAll(',', ' ')),
      ),
      'Service role/user in production': joinArray(
        'instances' in metadata
          ? (metadata.instances as Record<string, unknown>[])
              .reduce((acc, curr) => {
                const serviceType = curr['mapfre.com/serv_type'];
                const proRole = curr['mapfre.com/rol_serv_PRO'];
                let result = '';
                const isValidPRORole = Array.isArray(proRole)
                  ? proRole.length > 0
                  : proRole;
                if (isValidPRORole) {
                  if (serviceType && serviceType !== '') {
                    result = serviceType + ': ' + proRole;
                  } else {
                    result = proRole as string;
                  }
                }
                if (result) {
                  return acc.concat(result);
                }
                return acc;
              }, [] as string[])
              .map(item => item.replaceAll(',', ' '))
          : (metadata?.executionPermissions as Record<string, string[]>)?.[
              'mapfre.com/rol_serv_PRO'
            ]?.map(item => item.replaceAll(',', ' ')),
      ),
      'Creation date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/creationDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/creationDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/creationDate'
              ],
            ),
          ).toISOString(),
      'Creation user': joinArray(
        (metadata?.historyLog as Record<string, string | null>)?.[
          'mapfre.com/creationUser'
        ],
      ),
      'Approval Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/approvalDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/approvalDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/approvalDate'
              ],
            ),
          ).toISOString(),
      'Deprecation Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/deprecationDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/deprecationDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/deprecationDate'
              ],
            ),
          ).toISOString(),
      'Modification Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/modDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/modDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/modDate'
              ],
            ),
          ).toISOString(),
      'User Modification': joinArray(
        (metadata?.historyLog as Record<string, string | null>)?.[
          'mapfre.com/user_mod'
        ],
      ),
      'Business Entity': joinArray(
        metadata?.['mapfre.com/businessEntity'] as string[] | string | null,
      ),
      'Business Line/Life': joinArray(
        (metadata?.['mapfre.com/business_line'] as string[])
          ?.filter(e => e.startsWith('Life::'))
          ?.map(e => e.replace(/^Life::/, '')),
      ),
      'Business Line/No Life': joinArray(
        (metadata?.['mapfre.com/business_line'] as string[])
          ?.filter(e => e.startsWith('NoLife::'))
          ?.map(e => e.replace(/^NoLife::/, '')),
      ),
      'Business Line/Health': joinArray(
        (metadata?.['mapfre.com/business_line'] as string[])
          ?.filter(e => e.startsWith('Health::'))
          ?.map(e => e.replace(/^Health::/, '')),
      ),
      'Business Line/Cross': joinArray(
        (metadata?.['mapfre.com/business_line'] as string[])
          ?.filter(e => e.startsWith('Cross'))
          ?.map(e => e),
      ),
      'ID RAM': joinArray(
        metadata?.['mapfre.com/id_ram'] as string[] | string | null,
      ),

      Consumer_type: joinArray(
        metadata?.['mapfre.com/consumer_type'] as string[] | string | null,
      ),
      Provider_type: joinArray(
        metadata?.['mapfre.com/provider_type'] as string[] | string | null,
      ),
      Organization: joinArray(
        metadata?.['mapfre.com/organization'] as string[] | string | null,
      ),
    };
  });
  return entitiesMetas;
}

export const ApiListLayout = ({
  columns,
  initiallySelectedFilter = 'all',
}: CatalogPageProps) => {
  const useStyles = makeStyles(() => ({
    buttons: {
      textAlign: 'right',
      margin: '0px -20px 0 0px',
    },
    helpIcon: {
      marginRight: '8px',
      fontSize: '20px',
    },
    helpButton: {
      marginLeft: '8px',
    },
  }));
  const location = useLocation();
  const shouldShowCardsDirectly = location.state && location.state.showCards;
  const [icon, setIcon] = useState(
    shouldShowCardsDirectly ? 'ListIcon' : 'ViewModuleIcon',
  );
  const [showCards, setShowCards] = useState(shouldShowCardsDirectly);
  const [showList, setShowList] = useState(!shouldShowCardsDirectly);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const toggleIconView = () => {
    setShowCards((prev: unknown) => !prev);
    setShowList((prev: unknown) => !prev);
    setIcon(prevIcon =>
      prevIcon === 'ViewModuleIcon' ? 'ListIcon' : 'ViewModuleIcon',
    );
  };

  const iconTooltipText =
    icon === 'ViewModuleIcon' ? 'Cards layout' : 'List layout';

  const classes = useStyles();
  const outlet = useOutlet();
  const { t } = useTranslation();
  const identityApi = useApi(identityApiRef);

  const kind = new URLSearchParams(location.search);
  const kindParam = kind.get('filters[kind]');

  const context = useEntityList<MAREntityFilters>();

  context.updateFilters({
    kind: new EntityKindFilter(kindParam as string),
  });

  function checkGroup(entityRefs: string[]): {
    groups: string[];
    showButton: boolean;
  } {
    const allowedGroups = (entityRefs as string[]).filter(entityRef => {
      const parsedRef = parseEntityRef(entityRef);
      const groupName = parsedRef.name.toLowerCase();
      const isGroup = parsedRef.kind === 'group';
      return (
        isGroup &&
        (groupName.startsWith('gazr-gov-backstage-global') ||
          groupName.startsWith('gazr-gov-backstage'))
      );
    });

    return {
      groups: allowedGroups,
      showButton: allowedGroups.length > 0,
    };
  }
  const isGroup = () => {
    const {
      loading,
      value: showButton,
      error,
    } = useAsync(async () => {
      try {
        const { ownershipEntityRefs: entityRefs } =
          await identityApi.getBackstageIdentity();
        const { showButton } = checkGroup(entityRefs);
        return showButton;
      } catch (error) {
        return false;
      }
    }, []);
    return { loading, showButton, error };
  };

  const { showButton } = isGroup();

  const getFilterTypeFromLocation = (location: Location): string => {
    const params = new URLSearchParams(location.search);
    const kindFilter = params.get('filters[kind]') || 'all';

    return kindFilter === 'mapfreapi' || kindFilter === 'all'
      ? 'Mapfre API'
      : 'Mapfre API Legacy';
  };
  const filterType = getFilterTypeFromLocation(location as unknown as Location);

  return (
    outlet || (
      <Page themeId="home">
        <Content>
          <ContentHeader
            title={
              filterType === 'Mapfre API'
                ? (t('APIs Catalog') as string)
                : (t('Legacy APIs Catalog') as string)
            }
          >
            {filterType === 'Mapfre API' && (
              <Tooltip title={iconTooltipText}>
                <Button color="default" onClick={toggleIconView}>
                  {icon === 'ViewModuleIcon' ? (
                    <ViewModuleIcon fontSize="small" />
                  ) : (
                    <ListIcon fontSize="small" />
                  )}
                </Button>
              </Tooltip>
            )}
            {showButton && (
              <>
                <Button
                  aria-controls="simple-menu"
                  aria-haspopup="true"
                  onClick={handleClick}
                  style={{
                    color: '#DB271C',
                    marginRight: '10px',
                    textTransform: 'none',
                  }}
                >
                  {t('Add API')}
                </Button>
                <Menu
                  id="simple-menu"
                  anchorEl={anchorEl}
                  keepMounted
                  open={Boolean(anchorEl)}
                  onClose={handleClose}
                >
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=Edge_API"
                  >
                    {t('Edge Services')}
                  </MenuItem>
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=External_Services"
                  >
                    {t('External Services')}
                  </MenuItem>
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=Login_API"
                  >
                    {t('Login Api')}
                  </MenuItem>
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=Mediation_API"
                  >
                    {t('Mediation Services')}
                  </MenuItem>
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=REST_Services"
                  >
                    {t('REST Services')}
                  </MenuItem>
                  <MenuItem
                    onClick={handleClose}
                    component={NavLink}
                    to="/forms/mapfreapi?typology=SOAP_Services"
                  >
                    {t('SOAP Services')}
                  </MenuItem>
                </Menu>
              </>
            )}
          </ContentHeader>
          <CatalogFilterLayout>
            <CatalogFilterLayout.Filters>
              <SearchContextProvider>
                {showCards && (
                  <>
                    <EntityCountryPicker />
                    <EntitySystemPicker />
                  </>
                )}
                {showList && (
                  <>
                    <UserListPicker initialFilter={initiallySelectedFilter} />
                    {/* <UserListPicker initialFilter={initiallySelectedFilter} /> */}
                    <EntityCountryPicker />
                    <EntityTypologyPicker />
                    <EntityOwnerPicker />
                    <EntityLifecyclePicker />
                    {kindParam === 'mapfreapi' ? (
                      <EntityKindMapfreApiPicker />
                    ) : kindParam === 'mapfreapilegacyesp' ? (
                      <EntityKindLegEspPicker />
                    ) : kindParam === 'mapfreapilegacybra' ? (
                      <EntityKindLegacyBraPicker />
                    ) : kindParam === 'mapfreapilegacyper' ? (
                      <EntityKindLegacyPerPicker />
                    ) : kindParam === 'mapfreapilegacyglobal' ? (
                      <EntityKindLegGlobalPicker />
                    ) : (
                      ''
                    )}

                    <EntityBusinessLinePicker />
                    <EntityBusinessEntityPicker />
                  </>
                )}
              </SearchContextProvider>
            </CatalogFilterLayout.Filters>
            {showCards ? (
              <CatalogFilterLayout.Content>
                <ApiListCardGov />
              </CatalogFilterLayout.Content>
            ) : (
              <>
                <CatalogFilterLayout.Content>
                  <CatalogTable
                    columns={columns as GridColDef<GridValidRowModel>[]}
                  />
                  <Content className={classes.buttons}>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={async () =>
                        exportCSVFile(
                          await getFilteredMapfreApis(),
                          'mapfreapis',
                        )
                      }
                    >
                      {t('Create CSV')}
                    </Button>
                  </Content>
                </CatalogFilterLayout.Content>
              </>
            )}
          </CatalogFilterLayout>
        </Content>
      </Page>
    )
  );
};
