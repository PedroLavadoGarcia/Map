import { parseEntityRef } from '@backstage/catalog-model';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { CircularProgress, makeStyles } from '@material-ui/core';
import React from 'react';
import { useState } from 'react';
import useAsync from 'react-use/lib/useAsync';
import { ApiListCardLayout } from './ApiListCardLayout';
import { apiColumnFactories } from '../../columns/apiColumns';
import { EntityListProvider } from './CatalogTable/hooks/useEntityListProvider';
import { GridColDef, GridValidRowModel } from '@mui/x-data-grid';
import { t, TFunction } from 'i18next';
import { ApiListLayout } from './ApiListLayout';

function apiColumns(t: TFunction<'translation', undefined>) {
  return [
    apiColumnFactories.createTitleColumn(t),
    apiColumnFactories.createIdColumn(t),
    apiColumnFactories.createVersionColumn(t),
    apiColumnFactories.createStateColumn(t),
    apiColumnFactories.createSubTypeColumn(t),
    apiColumnFactories.createCountryColumn(t),
    apiColumnFactories.createShortDescColumn(t),
    apiColumnFactories.createModDateColumn(t),
    apiColumnFactories.createBusinessEntityColumn(t),
    apiColumnFactories.createBusinessLineColumn(t),
    apiColumnFactories.createRespFuncColumn(t),
    apiColumnFactories.createRespTechColumn(t),
    apiColumnFactories.createRespAltColumn(t),
    apiColumnFactories.createNNIIColumn(t),
    apiColumnFactories.createNNIICodeColumn(t),
    apiColumnFactories.createExternalAccessColumn(t),
    apiColumnFactories.createServNameColumn(t),
    //apiColumnFactories.createServUbicColumn(t),
    apiColumnFactories.createArchitectureColumn(t),
    apiColumnFactories.createIpFilterColumn(t),
    apiColumnFactories.createEndpointIcColumn(t),
    apiColumnFactories.createEndpointDevColumn(t),
    apiColumnFactories.createEndpointPreColumn(t),
    apiColumnFactories.createEndpointProColumn(t),
    apiColumnFactories.createPortalPubColumn(t),
    apiColumnFactories.createAuthTypeColumn(t),
    apiColumnFactories.createPermTypeColumn(t),
    apiColumnFactories.createScopesColumn(t),
    apiColumnFactories.createRolServICColumn(t),
    apiColumnFactories.createRolServPreColumn(t),
    apiColumnFactories.createRolServProColumn(t),
    apiColumnFactories.createApisColumn(),
  ];
}
export const ApiListPage = () => {
  const useStyles = makeStyles({
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
  });
  const classes = useStyles();
  const identityApi = useApi(identityApiRef);
  const [isExternal, setIsExternal] = useState(false);
  const { loading } = useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();

    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setIsExternal(Boolean(extEntityRefs.length));
  });

  return (
    <>
      {loading ? (
        <div className={classes.spinner}>
          <CircularProgress />
        </div>
      ) : isExternal ? (
        <EntityListProvider>
          <ApiListCardLayout />
        </EntityListProvider>
      ) : (
        <ApiListLayout
          columns={apiColumns(t) as GridColDef<GridValidRowModel>[]}
        />
      )}
    </>
  );
};
