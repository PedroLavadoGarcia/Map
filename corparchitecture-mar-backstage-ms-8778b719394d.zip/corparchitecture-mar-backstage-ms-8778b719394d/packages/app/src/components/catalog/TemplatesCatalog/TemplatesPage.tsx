/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Entity, parseEntityRef } from '@backstage/catalog-model';
import {
  Content,
  ContentHeader,
  Page,
  TabbedLayout,
} from '@backstage/core-components';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import FavoriteIcon from '../FavoriteIcon';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import CodeIcon from '@mui/icons-material/Code';
import DescriptionIcon from '@mui/icons-material/Description';
import SubjectIcon from '@mui/icons-material/Subject';
import {
  Box,
  Button,
  Card,
  CardActionArea,
  Chip,
  Grid,
  makeStyles,
  MenuItem,
  Tooltip,
  Typography,
} from '@material-ui/core';
import { t } from 'i18next';
import React, { ReactNode, useEffect, useState } from 'react';
import {
  Archive,
  Build,
  Business,
  Category,
  Code,
  Description,
  Apps,
} from '@mui/icons-material';
import { Link, NavLink, To } from 'react-router-dom';
import { getAllCatalogFormInformation } from './requests';
import axios from 'axios';
import apiImage from '../../../images/apis.png';

interface CatalogPage {
  description: string;
  image: string;
  form: string;
  typology: string;
  tags: string[];
  title: string;
}

export default {
  title: 'Layout/ContentHeader',
  component: ContentHeader,
};

export const TemplatesPage = () => {
  const [templateEntities, setTemplateEntities] = useState<Entity[]>([]);
  const [catalogPageProperties, setCatalogPageProperties] = useState<
    CatalogPage[]
  >([]);
  const [loading, setLoading] = useState(true);
  const [mapfresolutionUrls, setMapfresolutionUrls] = useState<string[]>([]);
  const [mapfreapiUrls, setMapfreapiUrls] = useState<string[]>([]);
  const [mapfredocumentUrls, setMapfredocumentUrls] = useState<string[]>([]);
  const catalogApi = useApi(catalogApiRef);
  const identityApi = useApi(identityApiRef);
  const [canRegister, setCanRegister] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();

  const useStyles = makeStyles({
    cardGridStyle: {
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
      position: 'relative',
      height: '500px',
      width: '330px',
      gap: '0px',
      borderColor: '#EAE9E9 !important',
      borderRadius: '8px !important',
    },

    cardActionAreaStyle: {
      justifyContent: 'flex-start',
      width: '100%',
    },
    contentCardStyle: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '18px',
      paddingLeft: '0px',
    },
  });
  const classes = useStyles();
  useEffect(() => {
    async function fetchEntities() {
      try {
        const response = await catalogApi.getEntities({
          filter: [
            {
              kind: 'template',
            },
          ],
          fields: [
            'kind',
            'spec',
            'metadata.name',
            'metadata.title',
            'metadata.description',
            'metadata.country',
            'metadata.annotations',
            'metadata.tags',
            'metadata.links',
          ],
        });
        setTemplateEntities(response.items);

        // Llamada a BBDD
        const catalogPageProps = await getAllCatalogFormInformation();
        setCatalogPageProperties(catalogPageProps);

        // Consulta grupos usuarios
        const { ownershipEntityRefs: entityRefs } =
          await identityApi.getBackstageIdentity();
        const extEntityRefs = entityRefs.filter(
          entityRef =>
            parseEntityRef(entityRef).kind === 'group' &&
            (parseEntityRef(entityRef).name.toLowerCase() ===
              'gaws-backstage-integrators-mar2' ||
              parseEntityRef(entityRef)
                .name.toLowerCase()
                .startsWith('gazr-gov-backstage-admin') ||
              parseEntityRef(entityRef)
                .name.toLowerCase()
                .startsWith('gazr-gov-backstage-global') ||
              parseEntityRef(entityRef)
                .name.toLowerCase()
                .startsWith('gazr-gov-backstage-doc-global')),
        );
        setCanRegister(Boolean(extEntityRefs.length));
      } catch (error) {
        console.error('Error fetching template entities:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchEntities();
  }, []);

  useEffect(() => {
    const signedUrlsArray: string[] = [];
    if (catalogPageProperties.length > 0) {
      const fetchSignedUrls = async () => {
        for (const catalogPageProp of catalogPageProperties) {
          try {
            if (catalogPageProp.image) {
              const baseUrl = new URL(
                `api/s3-images`,
                window.location.origin.replace('3000', '7007'),
              );
              const response = await axios.get(
                `${baseUrl}/global/${catalogPageProp.form}/${encodeURIComponent(
                  catalogPageProp.image as string,
                )}`,
              );
              signedUrlsArray.push(response.data.signedUrl);
            } else {
              signedUrlsArray.push('');
            }
          } catch (error) {
            console.error('Error fetching signed URL:', error);
            signedUrlsArray.push('');
          }
        }

        const mapfresolutionUrls = signedUrlsArray.filter(url =>
          url.includes('mapfresolution'),
        );
        setMapfresolutionUrls(mapfresolutionUrls);

        const mapfreapiUrls = signedUrlsArray.filter(url =>
          url.includes('mapfreapi'),
        );
        setMapfreapiUrls(mapfreapiUrls);

        const mapfredocumentUrls = signedUrlsArray.filter(url =>
          url.includes('mapfredocument'),
        );
        setMapfredocumentUrls(mapfredocumentUrls);
      };

      fetchSignedUrls();
    }
  }, [catalogPageProperties]);

  const mapfredocumentform = catalogPageProperties.filter(
    page => page.form === 'mapfredocumentform',
  );
  const mapfresolutionform = catalogPageProperties.filter(
    page => page.form === 'mapfresolutionform',
  );
  const apisEntities = catalogPageProperties.filter(
    page => page.form === 'mapfreapiform' || page.form === 'template',
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  const mapEntities = (entities: any[]) =>
    entities.map(entity => ({
      type: 'entityTemplate',
      title: entity.metadata?.title || '',
      description: entity.metadata?.description || '',
      url: `/create/templates/default/${entity.metadata?.name}`,
      tags: entity.metadata?.tags || [],
      annotations: entity.metadata?.annotations || {},
      links: entity.metadata?.links || [],
    }));

  const refarchBackendEntities = mapEntities(
    templateEntities.filter(entity =>
      entity.metadata.tags?.includes('backend'),
    ),
  );
  const refarchFrontendEntities = mapEntities(
    templateEntities.filter(entity =>
      entity.metadata.tags?.includes('frontend'),
    ),
  );
  const systemEntity = mapEntities(
    templateEntities.filter(entity => entity.metadata.tags?.includes('system')),
  );

  const buttonsBackend = [
    {
      text: 'Blueprint',
      icon: <Archive />,
      href: '/catalog/default/refarch/arqref_backend/blueprint',
    },
    {
      text: 'General Configuration',
      icon: <Build />,
      href: '/catalog/default/refarch/arqref_backend/general-configuration',
    },
    {
      text: 'Scenarios',
      icon: <Business />,
      href: '/catalog/default/refarch/arqref_backend/scenarios',
    },
    {
      text: 'Archetype',
      icon: <Category />,
      href: '/catalog/default/refarch/arqref_backend/archetype',
    },
    {
      text: 'Pipeline',
      icon: <Code />,
      href: '/catalog/default/refarch/arqref_backend/pipeline',
    },
    {
      text: 'Changelog',
      icon: <Description />,
      href: '/catalog/default/refarch/arqref_backend/changelog',
    },
  ];

  const buttonsFrontend = [
    {
      text: 'Blueprint',
      icon: <Archive />,
      href: '/catalog/default/refarch/arqref_frontend/blueprint',
    },
    {
      text: 'Scenarios',
      icon: <Business />,
      href: '/catalog/default/refarch/arqref_frontend/scenarios',
    },
    {
      text: 'Archetype',
      icon: <Category />,
      href: '/catalog/default/refarch/arqref_frontend/archetype',
    },
    {
      text: 'Pipeline',
      icon: <Code />,
      href: '/catalog/default/refarch/arqref_frontend/pipeline',
    },
    {
      text: 'Changelog',
      icon: <Description />,
      href: '/catalog/default/refarch/arqref_frontend/changelog',
    },
    {
      text: 'Use Cases',
      icon: <Apps />,
      href: '/catalog/default/refarch/arqref_frontend/useCases',
    },
  ];

  const BackendGroup = () => {
    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
          textAlign: 'center',
          gap: '20px',
        }}
      >
        {buttonsBackend.map((button, index) => (
          <Button
            variant="contained"
            color="default"
            component={Link}
            to={button.href}
            style={{
              width: '100%',
              maxWidth: '330px',
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
            }}
            key={index}
          >
            {button.icon}
            <Typography variant="caption" style={{ marginLeft: '1rem' }}>
              {button.text}
            </Typography>
          </Button>
        ))}
      </div>
    );
  };

  const FrontendGroup = () => {
    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
          textAlign: 'center',
          gap: '20px',
        }}
      >
        {buttonsFrontend.map((button, index) => (
          <Button
            variant="contained"
            color="default"
            component={Link}
            to={button.href}
            style={{
              width: '100%',
              height: '100%',
              maxWidth: '330px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
            key={index}
          >
            {button.icon}
            <Typography variant="caption" style={{ marginLeft: '1rem' }}>
              {button.text}
            </Typography>
          </Button>
        ))}
      </div>
    );
  };

  const imageContainerStyle = {
    width: '330px',
    height: '220px',
    display: 'flex',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F6F7',
  };
  const getRedirectPath = (typology: string) => {
    switch (typology) {
      case 'External Services':
      case 'SOAP Services':
      case 'REST Services':
      case 'Edge API':
      case 'Mediation API':
      case 'Login API':
        return `/forms/mapfreapi?typology=${typology.replaceAll(' ', '_')}`;

      default:
        return '/';
    }
  };

  const EntityLinks: React.FC<{ entity: any }> = ({ entity }) => {
    const links = entity?.links || [];

    if (!links || links.length === 0) {
      return null;
    }

    return (
      <div>
        {links.map(
          (
            link: { icon: string; url: To; title: string | undefined },
            index: React.Key | null | undefined,
          ) => {
            let IconComponent;
            if (link.icon === 'docs') {
              IconComponent = DescriptionIcon;
            } else if (link.icon === 'techdocs') {
              IconComponent = SubjectIcon;
            } else {
              return null;
            }

            return (
              <Link key={index} to={link.url} title={link.title}>
                <Tooltip title={link.title || ''}>
                  <IconComponent />
                </Tooltip>
              </Link>
            );
          },
        )}
      </div>
    );
  };

  const transformedMapfreApiForm = apisEntities.map((page, index) => ({
    type: page.form === 'template' ? 'template' : 'mapfreApiForm',
    typology: page.typology,
    title: page.title || '',
    description: page.description || '',
    url:
      page.form === 'template'
        ? `/create/templates/default/${page.title} Template`
        : getRedirectPath(page.typology),
    tags: page.tags || [],
    imageUrl: mapfreapiUrls[index] || apiImage,
    links: [],
  }));

  const finalApiEntities = [...transformedMapfreApiForm, ...systemEntity].sort(
    (a, b) => a.title.localeCompare(b.title),
  );

  const renderEntities = (entities: any[]) => (
    <Content className={classes.contentCardStyle}>
      {entities.map((entity, index) => (
        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          lg={3}
          key={index}
          style={{
            maxWidth: 'none',
            flexBasis: 'calc(10% - 10px)',
          }}
        >
          <Card className={classes.cardGridStyle} variant="outlined">
            <Link style={{ display: 'contents' }} to={entity.url}>
              <CardActionArea className={classes.cardActionAreaStyle}>
                <div style={{ ...imageContainerStyle }}>
                  <img
                    style={{
                      maxWidth: '100%',
                      maxHeight: '100%',
                      objectFit: 'cover',
                      objectPosition: 'center',
                    }}
                    loading="lazy"
                    alt=""
                    src={
                      entity.type === 'template' ||
                      entity.type === 'mapfreApiForm' ||
                      entity.tags.includes('system')
                        ? apiImage
                        : '/documentationLogo.png'
                    }
                  />
                </div>

                <Typography
                  style={{
                    color: '#2D373D',
                    fontWeight: 'bold',
                    fontSize: '20px',
                    width: '100%',
                    lineHeight: '28px',
                    textAlign: 'left',
                    padding: '16px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: '2',
                    WebkitBoxOrient: 'vertical',
                  }}
                >
                  {entity.title}
                </Typography>
                <Typography
                  style={{
                    fontSize: '16px',
                    color: '#526570',
                    fontWeight: 'lighter',
                    lineHeight: '20.83px',
                    textAlign: 'left',
                    padding: '0 16px 16px 16px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: '5',
                    WebkitBoxOrient: 'vertical',
                    width: '100%',
                  }}
                >
                  {entity.description}
                </Typography>

                <Typography
                  style={{ marginTop: '15px', padding: '0 16px 16px 16px' }}
                >
                  {(entity.tags || []).map(
                    (
                      t:
                        | boolean
                        | React.ReactChild
                        | React.ReactFragment
                        | React.ReactPortal
                        | null
                        | undefined,
                      index: React.Key | null | undefined,
                    ) => (
                      <Chip key={index} size="small" label={t} />
                    ),
                  )}
                </Typography>
              </CardActionArea>
            </Link>
            <div
              style={{
                marginTop: 'auto',
                paddingBottom: '8px',
                display: 'flex',
                justifyContent: 'space-between',
                padding: '16px',
              }}
            >
              <Link
                style={{ display: 'flex', alignItems: 'center' }}
                to={entity.url}
              >
                <Typography
                  style={{
                    color: '#D81E05',
                    fontSize: '16px',
                    lineHeight: '24px',
                    textAlign: 'left',
                  }}
                >
                  {t('Choose')}
                </Typography>
                <KeyboardArrowRightOutlinedIcon style={{ color: '#D81E05' }} />
              </Link>
              <div style={{ display: 'flex' }}>
                {entity.type === 'entityTemplate' &&
                entity.annotations?.['backstage.io/view-url'] ? (
                  <Link to={entity.annotations?.['backstage.io/view-url']}>
                    <Tooltip title="bitbucketCloud">
                      <CodeIcon />
                    </Tooltip>
                  </Link>
                ) : null}
                {entity.links && <EntityLinks entity={entity} />}
              </div>
              {/* <FavoriteIcon /> */}
            </div>
          </Card>
        </Grid>
      ))}
    </Content>
  );

  return (
    <>
      <Page themeId="home">
        <Content>
          <ContentHeader title={t('Templates for asset creation') as string}>
            {canRegister && (
              <Box
                display="flex"
                justifyContent="flex-end"
                alignItems="center"
                flexGrow={1}
              >
                <MenuItem
                  component={NavLink}
                  style={{ color: '#DB271C' }}
                  to="/custom-catalog-import"
                >
                  {t('Register existing component')}
                </MenuItem>
              </Box>
            )}
          </ContentHeader>

          <TabbedLayout>
            <TabbedLayout.Route path="refarch" title={t('Architectures')}>
              <>
                <Typography
                  variant="h2"
                  color="textPrimary"
                  style={{ marginTop: '15px' }}
                >
                  MAR Backend
                </Typography>
                <BackendGroup />

                {renderEntities(refarchBackendEntities)}
                <Typography
                  variant="h2"
                  color="textPrimary"
                  style={{ marginTop: '30px' }}
                >
                  MAR Frontend
                </Typography>
                <Content className={classes.contentCardStyle}>
                  <FrontendGroup />
                </Content>

                {renderEntities(refarchFrontendEntities)}
              </>
            </TabbedLayout.Route>
            <TabbedLayout.Route path="apis" title={t('APIS')}>
              {renderEntities(finalApiEntities)}
            </TabbedLayout.Route>

            <TabbedLayout.Route path="documentation" title={t('Documentation')}>
              <Grid container spacing={3}>
                {mapfredocumentform.map((page, index) => (
                  <Grid item xs={12} sm={6} md={4} lg={3} key={page.title}>
                    <Card className={classes.cardGridStyle} variant="outlined">
                      <Link
                        style={{ display: 'contents' }}
                        to={`/forms/mapfredocument`}
                      >
                        <CardActionArea className={classes.cardActionAreaStyle}>
                          <div style={{ ...imageContainerStyle }}>
                            <img
                              style={{
                                maxWidth: '100%',
                                maxHeight: '100%',
                                objectFit: 'cover',
                                objectPosition: 'center',
                              }}
                              loading="lazy"
                              alt=""
                              src={mapfredocumentUrls[index]}
                            />
                          </div>
                          <Typography
                            style={{
                              color: '#2D373D',
                              fontWeight: 'bold',
                              fontSize: '20px',
                              width: '100%',
                              lineHeight: '28px',
                              textAlign: 'left',
                              padding: '16px',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              display: '-webkit-box',
                              WebkitLineClamp: '2',
                              WebkitBoxOrient: 'vertical',
                            }}
                          >
                            {page.title}
                          </Typography>
                          <Typography
                            style={{
                              fontSize: '16px',
                              color: '#526570',
                              fontWeight: 'lighter',
                              lineHeight: '20.83px',
                              textAlign: 'left',
                              padding: '0 16px 16px 16px',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              display: '-webkit-box',
                              WebkitLineClamp: '5',
                              WebkitBoxOrient: 'vertical',
                              width: '100%',
                            }}
                          >
                            {page.description}
                          </Typography>

                          <Typography
                            style={{
                              marginTop: '15px',
                              padding: '0 16px 16px 16px',
                            }}
                          >
                            {((page.tags as string[]) || []).map((t, index) => (
                              <Chip key={index} size="small" label={t} />
                            ))}
                          </Typography>
                        </CardActionArea>
                      </Link>
                      <div
                        style={{
                          marginTop: 'auto',
                          paddingBottom: '8px',
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0 16px',
                        }}
                      >
                        <Link
                          style={{ display: 'flex', alignItems: 'center' }}
                          to={`/forms/mapfredocument`}
                        >
                          <Typography
                            style={{
                              color: '#D81E05',
                              fontSize: '16px',
                              lineHeight: '24px',
                              textAlign: 'left',
                            }}
                          >
                            {t('Choose')}
                          </Typography>
                          <KeyboardArrowRightOutlinedIcon
                            style={{ color: '#D81E05' }}
                          />
                        </Link>
                        <FavoriteIcon />
                      </div>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </TabbedLayout.Route>
          </TabbedLayout>
        </Content>
      </Page>
    </>
  );
};
