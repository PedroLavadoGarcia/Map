const ROUTE = '/api/admincatalog';
const LOCATION = window.location.origin.replace('3000', '7007');

export async function getAllCatalogFormInformation() {
  const url = new URL(`${ROUTE}/catalogforms`, LOCATION);

  const headers = new Headers();

  headers.set('Content-type', 'application/json');

  try {
    const req = new Request(url.toString(), {
      method: 'GET',
      headers,
    });
    const response = await fetch(req);

    if (response.status === 200) {
      const json = await response.json();
      return json;
    } else {
      throw new Error('Something went wrong on API server!');
    }
  } catch (error) {
    if (error instanceof Error) {
      throw Error(`ERROR ${error}`);
    }
    return false;
  }
}
