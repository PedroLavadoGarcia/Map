import React, { useState } from 'react';
import StarBorderOutlinedIcon from '@mui/icons-material/StarBorderOutlined';
import StarOutlinedIcon from '@mui/icons-material/StarOutlined';

const FavoriteIcon = () => {
  const [isFavorite, setIsFavorite] = useState(false);

  const favoriteToggle = () => {
    setIsFavorite(!isFavorite);
  };
  {
    /* Eliminar visibility: 'hidden' cuando se quiera hacer visible el botón */
  }
  return (
    <div style={{ alignContent: 'center', visibility: 'hidden' }}>
      <button
        style={{
          padding: '8px',
          background: 'none',
          border: 'none',
          display: 'flex',
          height: '45px',
        }}
        onClick={favoriteToggle}
      >
        {isFavorite ? (
          <StarOutlinedIcon style={{ color: '#E46B15' }} />
        ) : (
          <StarBorderOutlinedIcon style={{ color: '#89969A' }} />
        )}
      </button>
    </div>
  );

  // TODO: Añadir lógica de favorito
};

export default FavoriteIcon;
