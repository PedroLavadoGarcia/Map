/* eslint-disable @typescript-eslint/no-explicit-any */
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import { ComponentsResponsiblesService } from '@backstage/plugin-mapfreapi-editor';
import React, { createContext, useState } from 'react';
import { useAsync } from 'react-use';

export const ResponsibleContext = createContext({
  responsibleApproval: 'pending',
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  getResponsibleApproval: async () => {},
});

export const ResponsibleProvider = (props: any) => {
  const config = useApi(configApiRef);
  const componentsResponsibles = new ComponentsResponsiblesService(config);

  const [responsibleApproval, setResponsibleApproval] = useState('pending');

  useAsync(async () => {
    await getResponsibleApproval();
  });

  async function getResponsibleApproval() {
    const responsibles = await componentsResponsibles.getAll(props.name);

    let responsibleApproval: 'pending' | 'rejected' | 'approved' = 'approved';
    if (responsibles.some(responsible => responsible.approval === 'rejected')) {
      responsibleApproval = 'rejected';
    } else if (
      responsibles.some(responsible => responsible.approval === 'pending')
    ) {
      responsibleApproval = 'pending';
    }
    setResponsibleApproval(responsibleApproval);
  }

  return (
    <ResponsibleContext.Provider
      value={{ responsibleApproval, getResponsibleApproval }}
    >
      {props.children}
    </ResponsibleContext.Provider>
  );
};
