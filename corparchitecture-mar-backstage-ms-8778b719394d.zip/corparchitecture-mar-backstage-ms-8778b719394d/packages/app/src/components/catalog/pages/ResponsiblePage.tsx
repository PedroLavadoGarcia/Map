import React from 'react';
import { Card, Grid, Typography, makeStyles, styled } from '@material-ui/core';
import {
  Sidebar,
  SidebarGroup,
  SidebarItem,
  SidebarPage,
  SidebarScrollWrapper,
  SidebarSpace,
  TabbedLayout,
  Header,
  Link,
  InfoCard,
} from '@backstage/core-components';
import MenuIcon from '@material-ui/icons/Menu';

import {
  UserSettingsSignInAvatar,
  useUserProfile,
} from '@backstage/plugin-user-settings';
import HomeIcon from '@material-ui/icons/Home';
import ExtensionIcon from '@material-ui/icons/Extension';
import { useTranslation } from 'react-i18next';
function ResponsiblePage() {
  const useStyles = makeStyles({
    cardStyle: {
      display: 'flex',
      flexDirection: 'column',
      height: 'flex',
      marginBottom: '40px',
      boxShadow: 'none',
    },
    cardLogoStyle: {
      display: 'flex',
      flexDirection: 'row',
      height: 'flex',
      marginBottom: '20px',
      boxShadow: 'none',
      position: 'relative',
      alignItems: 'left',
    },
    cardRowStyle: {
      display: 'flex',
      flexDirection: 'row',
      ratio: '1',
      height: 'flex',
      marginTop: '30px',
      marginBottom: '30px',
      boxShadow: 'none',
      position: 'relative',
    },
    textStyle: {
      color: '#394360',
      // fontWeight: 'bold',
      fontSize: '25px',
    },
    cardRowTextStyle: {
      fontSize: '12px',
      width: '0',
      minWidth: '100%',
    },
    sectionStyle: {
      marginTop: '10px',
    },
  });
  const { t } = useTranslation();
  const classes = useStyles();
  const SidebarDivider = styled('hr')(({ theme }) => ({
    height: 1,
    width: '100%',
    background: theme.palette.background.default,
    border: 'none',
    margin: theme.spacing(1.2, 0),
  }));
  const responsibleSidebar = (
    <>
      <Sidebar>
        <SidebarScrollWrapper
          style={{
            display: 'flex',
            flexFlow: 'column nowrap',
            minHeight: 500,
            alignItems: 'flex-start',
          }}
        >
          <SidebarSpace />
          <SidebarGroup label="Orion" icon={<MenuIcon />}>
            {/* Global nav, not org-specific */}
            <SidebarItem icon={HomeIcon} to="" text={t('Orion') as string} />
            <SidebarDivider />
            <SidebarItem
              icon={ExtensionIcon}
              to={'/responsible'}
              text={t('Responsible') as string}
            />
          </SidebarGroup>
          <SidebarSpace />
        </SidebarScrollWrapper>
      </Sidebar>
    </>
  );
  const { displayName, profile } = useUserProfile();
  return (
    <SidebarPage>
      {responsibleSidebar}
      <Header title={t('Responsible') as string}></Header>
      <TabbedLayout>
        <TabbedLayout.Route path={'/'} title={t('Owner')}>
          <Grid>
            <InfoCard title={t('Responsible')} variant="gridItem">
              <Grid container spacing={6}>
                <Grid item>
                  <UserSettingsSignInAvatar size={96} />
                </Grid>
                <Grid item xs={12} sm container>
                  <Grid item xs container direction="column" spacing={2}>
                    <Grid item xs>
                      <Typography variant="subtitle1" gutterBottom>
                        {t(displayName)}
                      </Typography>
                      <Link to={t(displayName)} variant="inherit">
                        <Typography variant="body2">{profile.email}</Typography>
                      </Link>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </InfoCard>
          </Grid>
        </TabbedLayout.Route>
        <TabbedLayout.Route path="/functional" title={t('Functional')}>
          <Card className={classes.cardStyle}>{t('Functional')}</Card>
        </TabbedLayout.Route>
        <TabbedLayout.Route path="/technical" title={t('Technical')}>
          <Card className={classes.cardStyle}>{t('Technical')}</Card>
        </TabbedLayout.Route>
      </TabbedLayout>
    </SidebarPage>
  );
}
export default ResponsiblePage;
