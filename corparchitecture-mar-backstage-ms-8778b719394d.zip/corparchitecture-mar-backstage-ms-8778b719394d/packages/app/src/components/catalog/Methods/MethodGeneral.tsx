import React, { useEffect } from 'react';
import { Content } from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityKindPicker,
  EntityListProvider,
  useEntity,
} from '@backstage/plugin-catalog-react';
import { EntityTypePicker } from '@backstage/plugin-catalog-react';
import { EntityLayout } from '@backstage/plugin-catalog';
import { Card, Grid } from '@material-ui/core';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { useTranslation } from 'react-i18next';
import { entityRefreshMenuButton } from '../EntityRefreshMenuButton/entityRefreshMenuButton';
import { Stages } from './Stages';

export interface CatalogPageProps {
  initialKind?: string;
}

export function MethodGeneral({ initialKind = 'Component' }: CatalogPageProps) {
  const { entity } = useEntity();
  const { t } = useTranslation();
  const general = entity.metadata?.general as Record<string, unknown>;
  const contact = general?.contact as Record<string, string>;

  useEffect(() => {
    document
      .querySelector('main > header > div > p[class*=MuiTypography-body1]')
      ?.remove();
    const sortButton = document.querySelector(
      '[class*=MuiTableSortLabel]',
    ) as HTMLInputElement;
    sortButton?.click();
    const columnNames = document.querySelectorAll('[class*=MuiTableSortLabel]');
    let cellText: string | null | undefined = '';
    columnNames.forEach(function (item) {
      if (item) {
        cellText = item.firstChild?.textContent;
        if (item.firstChild) {
          if (cellText === 'Name') {
            item.firstChild.textContent = t(`${'Architectures'}`);
          } else {
            item.firstChild.textContent = t(`${cellText}`);
          }
        }
      }
    });
    const title = document.querySelector(
      'main > header > div > h1 > div > span',
    );
    const text: string | null | undefined = title?.textContent;
    if (text && title) title.textContent = t(`${text}`);
  }, [document]);

  function MethodsGeneralTabs({
    entityItemName,
  }: {
    entityItemName: string;
  }): JSX.Element {
    return (
      <EntityListProvider>
        <Content>
          <CatalogFilterLayout>
            <EntityKindPicker initialFilter={initialKind} hidden={true} />
            <EntityTypePicker initialFilter={'method'} hidden={true} />
            <Grid container spacing={2} alignItems="stretch">
              {entityItemName === 'landing' && (
                <Grid item xs={12}>
                  {(general?.landing as Record<string, string>)?.title &&
                    (general?.landing as Record<string, string>)?.path && (
                      <Card>
                        <TechDocsCardContent path={''} withTitle={false} />
                      </Card>
                    )}
                </Grid>
              )}
              {entityItemName === 'contact' && (
                <Grid item xs={12}>
                  {(general?.contact as Record<string, string>)?.title &&
                    (general?.contact as Record<string, string>)?.path && (
                      <Card>
                        <TechDocsCardContent
                          path={contact?.path}
                          withTitle={false}
                        />
                      </Card>
                    )}
                </Grid>
              )}
            </Grid>
          </CatalogFilterLayout>
        </Content>
      </EntityListProvider>
    );
  }

  return (
    <EntityListProvider>
      <EntityLayout
        UNSTABLE_extraContextMenuItems={[entityRefreshMenuButton()]}
      >
        <EntityLayout.Route path="/overview" title="Overview">
          <MethodsGeneralTabs entityItemName="landing" />
        </EntityLayout.Route>

        <EntityLayout.Route path="/stages" title="Stages">
          <Stages />
        </EntityLayout.Route>
        <EntityLayout.Route path="/contact" title="Contact Support">
          <MethodsGeneralTabs entityItemName="contact" />
        </EntityLayout.Route>
      </EntityLayout>
    </EntityListProvider>
  );
}
