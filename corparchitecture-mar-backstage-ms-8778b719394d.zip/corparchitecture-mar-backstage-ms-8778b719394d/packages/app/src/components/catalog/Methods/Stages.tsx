import { JsonObject } from '@backstage/types';
import { useEntity } from '@backstage/plugin-catalog-react';
import { Grid } from '@material-ui/core';
import React from 'react';
import { IconTechDocsCards } from '@internal/plugin-custom-cards/src/components/IconTechDocsCards';
import { RefArchButtons } from '@internal/plugin-custom-cards/src/components/RefArchButtons/RefArchButtons';

export function Stages() {
  const { entity } = useEntity();
  const methodDocs = entity.metadata?.methodDocs as JsonObject;
  const scenarios = methodDocs?.stages as Array<Record<string, string>>;
  const docsButton = methodDocs?.docsButton as boolean;

  return (
    <>
      {scenarios && (
        <Grid
          container
          spacing={3}
          alignItems="stretch"
          style={{
            marginTop: '20px',
            paddingLeft: '3%',
            paddingRight: '3%',
            height: 'auto',
          }}
        >
          <Grid item xs={12}>
            <RefArchButtons withTechDocsButton={docsButton} />
          </Grid>
          <Grid item xs={12}>
            <IconTechDocsCards metadataItem={scenarios} type="scenario" />
          </Grid>
        </Grid>
      )}
    </>
  );
}
