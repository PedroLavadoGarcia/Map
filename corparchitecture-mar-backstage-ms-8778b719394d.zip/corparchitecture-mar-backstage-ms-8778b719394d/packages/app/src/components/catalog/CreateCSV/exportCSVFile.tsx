export function convertToCSV(objArray: string | Record<string, unknown>[]) {
  const array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
  let str = '';

  for (let i = 0; i < array.length; i++) {
    let line = '';
    if (i === 0) {
      const firstRow = Object.keys(array[i]).reduce(function (
        accumulator: Record<string, string>,
        currentValue: string,
      ) {
        return { ...accumulator, [currentValue]: currentValue };
      },
      {});
      array.unshift(firstRow);
    }
    for (const index in array[i]) {
      if (line != '') line += ';';
      const value = array[i][index];
      if (
        typeof value === 'string' &&
        value.includes(';') &&
        !value.startsWith('"') &&
        !value.endsWith('"')
      ) {
        line += `"${value}"`;
      } else {
        line += value;
      }
    }

    str += line + '\r\n';
  }

  return str;
}

export async function exportCSVFile(
  objArray: Record<string, string>[],
  filename: string,
) {
  const BOM = '\uFEFF';
  const replacer = (_: string, value: string) =>
    typeof value === 'undefined' ? '' : value;
  const jsonObject = JSON.stringify(objArray, replacer);

  const csv = convertToCSV(jsonObject);

  const exportedFilenmae = `${new Date().toISOString()}_${filename}.csv`;

  const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });

  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', exportedFilenmae);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
