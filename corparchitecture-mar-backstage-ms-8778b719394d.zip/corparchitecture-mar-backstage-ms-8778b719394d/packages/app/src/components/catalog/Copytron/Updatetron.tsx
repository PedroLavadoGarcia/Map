import {
  Button,
  Container,
  Grid,
  Typography,
  TextField,
  makeStyles,
  Box,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogActions,
  CircularProgress,
  DialogTitle,
} from '@material-ui/core';
import React, { ChangeEvent, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { alertApiRef, useApi } from '@backstage/core-plugin-api';
import { useNavigate } from 'react-router-dom';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import { countryCodes } from './isoCodes';
import CryptoJS from 'crypto-js';
import { catalogApiRef } from '@backstage/plugin-catalog-react';

export const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
export const checkedIcon = <CheckBoxIcon fontSize="small" />;
import { JsonArray } from '@backstage/types';

export const Updatetron = () => {
  const useStyles = makeStyles({
    firstInput: {
      width: '200px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    description: {
      width: '760px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    input: {
      width: '250px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    inputFirstLarge: {
      width: '370px',
      marginTop: '20px',
      marginBottom: '5px',
      marginRight: '3px',
    },
    inputLarge: {
      width: '370px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    inputCheckbox: {
      width: '250px',
      paddingLeft: '20px',
      marginTop: '20px',
      marginBottom: '5px',
    },

    flex: {
      display: 'flex',
    },
    helpIcon: {
      marginRight: '8px',
      fontSize: '20px',
    },
    button: {
      paddingTop: '20px',
    },
    section: {
      marginTop: '20px',
    },
    container: {
      margin: '0px 0px 0px 0px',
      padding: '20px 20px 80px 20px',
      // border: '1px solid #ccc',
      // borderRadius: '5px',
    },
    menu: {
      maxHeight: 200,
      marginTop: '50px',
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    helperText: {
      color: 'rgba(0, 0, 0, 0.54)',
    },
    stepper: {
      backgroundColor: '#EAE9E9',
    },
    stepTitle: {
      fontWeight: 'normal',
      marginTop: '0px !important',
      marginBottom: '10px',
    },
  });

  interface FormValues {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [x: string]: any;
  }

  const classes = useStyles();
  const { t } = useTranslation();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const [openDialog, setOpenDialog] = useState(false);
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const [combinedFormInputs, setCombinedFormInputs] = useState<FormValues>({
    country: '',
    domain: '',
    product: '',
    jenkinsUrl: '',
    jenkinsUser: '',
    jenkinsPassword: '',
  });

  const handleConfirm = () => {
    setOpen(false);
    window.location.href = '/';
  };

  const handleConfirmCopy = () => {
    navigate(
      `/apis?filters%5Bkind%5D=mapfreapi&filters%5Buser%5D=all&filters%5Bcountry%5D=${combinedFormInputs.country}&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=Edge%20API&filters%5Btypology%5D=Mediation%20API`,
    );
    window.location.reload();
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleCancel = () => {
    setOpen(true);
  };

  const areRequiredFieldsFilled = () => {
    const requiredFields: (keyof FormValues)[] = [
      'country',
      'domain',
      'product',
      'jenkinsUrl',
      'jenkinsUser',
      'jenkinsPassword',
    ];

    const result = requiredFields.every(field => {
      const value = combinedFormInputs[field];

      if (Array.isArray(value)) {
        return value.length > 0;
      }
      return typeof value === 'string' && value.trim() !== '';
    });

    return result;
  };

  console.log(combinedFormInputs);

  const handleFormInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    if (name === 'country' && value.length >= 3) {
      const country = countryCodes.find(
        c => c.iso3.toLowerCase() === value.toLowerCase(),
      );

      if (country?.iso2 && country?.iso2 !== undefined) {
        setCombinedFormInputs(prevData => ({
          ...prevData,
          [name]: value.toUpperCase(),
        }));
        return;
      } else {
        alertApi.post({
          message: 'Invalid ISO 3 or not in the allowed values',
          severity: 'error',
        });

        setCombinedFormInputs(prevData => ({
          ...prevData,
          [name]: '',
        }));

        return;
      }
    }
    setCombinedFormInputs(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  function encrypt(text: string): string {
    const key = CryptoJS.enc.Utf8.parse('mapfre'.padStart(32, '0'));
    const iv = CryptoJS.enc.Utf8.parse('mapfre'.padStart(16, '0'));

    // Encrypt the text
    const encrypted = CryptoJS.AES.encrypt(text, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    return encrypted.ciphertext.toString(CryptoJS.enc.Hex);
  }

  async function handleCreateConfirmation() {
    setIsLoading(true);

    //Update country data in Dashboards tables
    const url = new URL(
      `api/forms/updateDashboardCountry/${combinedFormInputs.country}`,
      window.location.origin.replace('3000', '7007'),
    );

    const body = {
      domain: combinedFormInputs.domain,
      product: combinedFormInputs.product,
      jenkinsUrl: combinedFormInputs.jenkinsUrl,
      jenkinsUser:
        combinedFormInputs.jenkinsUser.length > 0
          ? encrypt(combinedFormInputs.jenkinsUser)
          : '',
      jenkinsPassword:
        combinedFormInputs.jenkinsPassword.length > 0
          ? encrypt(combinedFormInputs.jenkinsPassword)
          : '',
    };

    const headers = new Headers();
    headers.set('Content-type', 'application/json');

    const req = new Request(url.toString(), {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    await fetch(req);

    //Just execute if domain and product are informed
    if (
      combinedFormInputs.domain.length !== 0 &&
      combinedFormInputs.product.length !== 0
    ) {
      const response = await catalogApi.getEntities({
        filter: {
          kind: 'mapfreapi',
          'metadata.typology': ['Edge API', 'Mediation API'],
          'metadata.country': combinedFormInputs.country,
          'spec.lifecycle': 'Approved',
        },
        fields: [
          'metadata.name',
          'metadata.title',
          'metadata.typology',
          'metadata.country',
          'metadata.instances',
        ],
      });
      if (response.items && Array.isArray(response.items)) {
        const entities = response.items.map(e => {
          const instances =
            e.metadata.instances && Array.isArray(e.metadata.instances)
              ? (e.metadata.instances as JsonArray).map(instance => {
                  if (typeof instance === 'object' && instance !== null) {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const obj = instance as Record<string, any>;
                    return Object.keys(obj)
                      .filter(key => key.startsWith('mapfre.com/endpoint_'))
                      .reduce((result, key) => {
                        result[key] = obj[key];
                        return result;
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                      }, {} as Record<string, any>);
                  }

                  return {};
                })
              : [];

          return `{ "name":"${e.metadata.name}", "title":"${
            e.metadata.title
          }", "typology":"${
            e.metadata.typology
          }", "instances": ${JSON.stringify(instances)}}`;
        });

        const parsedData = entities.map(item => JSON.parse(item));

        //Update domain data in Dashboards tables
        const url = new URL(
          `api/forms/updateDashboardApis/${combinedFormInputs.country}`,
          window.location.origin.replace('3000', '7007'),
        );

        const body = {
          domain: combinedFormInputs.domain,
          product: combinedFormInputs.product,
          data: JSON.stringify(parsedData),
        };

        const headers = new Headers();
        headers.set('Content-type', 'application/json');

        const req = new Request(url.toString(), {
          method: 'POST',
          headers,
          body: JSON.stringify(body),
        });

        await fetch(req);
      }
    }
    setTimeout(() => {
      setIsLoading(false);
      setOpenDialog(true);
    }, 3000);
  }
  return (
    <>
      <Dialog open={isLoading}>
        <DialogContent>
          <CircularProgress
            style={{ width: '100px', height: '100px', margin: '40px' }}
          />
        </DialogContent>
      </Dialog>
      <Dialog
        open={openDialog}
        onClose={handleConfirmCopy}
        aria-labelledby="draft-dialog"
      >
        <DialogTitle id="draft-dialog">{t(`Done`)}</DialogTitle>

        <DialogActions>
          <Button
            onClick={handleConfirmCopy}
            color="primary"
            variant="contained"
          >
            {t('Agree')}
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {t(
              'Are you sure you want to cancel? Unsaved changes will be lost.',
            )}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            {t('Cancel')}
          </Button>
          <Button onClick={handleConfirm} color="secondary">
            {t('Accept')}
          </Button>
        </DialogActions>
      </Dialog>

      <Box sx={{ width: '80%', margin: 'auto' }}>
        <Container className={classes.container}>
          <Typography
            variant="h6"
            className={`${classes.section} ${classes.stepTitle}`}
          >
            {t('Update TRON community data for Dashboard')}
          </Typography>

          <Grid>
            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Country')}
                name="country"
                helperText={t('Indicate ISO 3 Code')}
                onChange={handleFormInputChange}
              />
            </Grid>

            <Typography variant="subtitle1" className={classes.section}>
              {t('Dashboard data')}
            </Typography>

            <TextField
              fullWidth
              required
              className={classes.inputFirstLarge}
              size="small"
              variant="outlined"
              label={t('Zeus Domain')}
              name="domain"
              value={combinedFormInputs.domain}
              onChange={handleFormInputChange}
            />

            <TextField
              fullWidth
              required
              className={classes.inputFirstLarge}
              size="small"
              variant="outlined"
              label={t('Zeus Product')}
              name="product"
              value={combinedFormInputs.product}
              onChange={handleFormInputChange}
            />

            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Url Jenkins Job')}
                name="jenkinsUrl"
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Jenkins User')}
                name="jenkinsUser"
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Jenkins Password')}
                name="jenkinsPassword"
                onChange={handleFormInputChange}
              />
            </Grid>
          </Grid>
        </Container>
      </Box>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          bgcolor: 'background.paper',
          padding: '16px',
          boxShadow: '0px -2px 5px rgba(0, 0, 0, 0.1)',
          zIndex: 1000,
        }}
      >
        <Button color="primary" onClick={handleCancel}>
          {t('Cancel')}
        </Button>
        <Box sx={{ flex: '1 1 auto' }} />
        <Button
          color="primary"
          disabled={!areRequiredFieldsFilled()}
          onClick={handleCreateConfirmation}
        >
          {t('Finish')}
        </Button>
      </Box>
    </>
  );
};
