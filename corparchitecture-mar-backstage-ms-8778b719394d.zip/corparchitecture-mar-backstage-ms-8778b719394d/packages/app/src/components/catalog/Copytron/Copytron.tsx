import {
  Button,
  Container,
  Grid,
  Typography,
  TextField,
  makeStyles,
  Box,
  Checkbox,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogActions,
  CircularProgress,
  DialogTitle,
} from '@material-ui/core';
import React, { ChangeEvent, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  alertApiRef,
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useAsync } from 'react-use';
import { Autocomplete, AutocompleteRenderOptionState } from '@material-ui/lab';
import { v4 as uuidv4 } from 'uuid';
import {
  forkRepository,
  getCatalogInfo,
  uploadFiles,
  ApiChangelogService,
} from '@backstage/plugin-mapfreapi-editor';
import { parse, stringify } from 'yaml';
import sleep from '@backstage/plugin-mapfreapi-editor/src/lib/sleep';
import { Entity, stringifyEntityRef } from '@backstage/catalog-model';
import { AddLocationResponse } from '@backstage/catalog-client';
import { newSubscriptionCatalogApi } from '@backstage/plugin-mapfreapi-editor/src/lib/subscriptionsCatalog';
import { useNavigate } from 'react-router-dom';
import { createBucket } from '@backstage/plugin-mapfreapi-editor/src/lib/updateBitbucketRepo';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import { countryCodes } from './isoCodes';
import MenuItem from '@material-ui/core/MenuItem/MenuItem';
import CryptoJS from 'crypto-js';

export const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
export const checkedIcon = <CheckBoxIcon fontSize="small" />;
import { JsonArray } from '@backstage/types';

export const Copytron = () => {
  const useStyles = makeStyles({
    firstInput: {
      width: '200px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    description: {
      width: '760px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    input: {
      width: '250px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    inputFirstLarge: {
      width: '370px',
      marginTop: '20px',
      marginBottom: '5px',
      marginRight: '3px',
    },
    inputLarge: {
      width: '370px',
      marginLeft: '3px',
      marginTop: '20px',
      marginBottom: '5px',
    },
    inputCheckbox: {
      width: '250px',
      paddingLeft: '20px',
      marginTop: '20px',
      marginBottom: '5px',
    },

    flex: {
      display: 'flex',
    },
    helpIcon: {
      marginRight: '8px',
      fontSize: '20px',
    },
    button: {
      paddingTop: '20px',
    },
    section: {
      marginTop: '20px',
    },
    container: {
      margin: '0px 0px 0px 0px',
      padding: '20px 20px 80px 20px',
      // border: '1px solid #ccc',
      // borderRadius: '5px',
    },
    menu: {
      maxHeight: 200,
      marginTop: '50px',
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    helperText: {
      color: 'rgba(0, 0, 0, 0.54)',
    },
    stepper: {
      backgroundColor: '#EAE9E9',
    },
    stepTitle: {
      fontWeight: 'normal',
      marginTop: '0px !important',
      marginBottom: '10px',
    },
  });

  interface FormValues {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [x: string]: any;
  }

  const classes = useStyles();
  const { t } = useTranslation();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const [owners, setOwners] = useState<string[]>([]);
  const [entities, setEntities] = useState<string[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const identityApi = useApi(identityApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getString('backend.baseUrl');
  const apiChangelog = new ApiChangelogService(backendUrl);
  const env = config.getString('app.env');
  const [entityActual, setEntityActual] = useState(0);
  const navigate = useNavigate();

  const [combinedFormInputs, setCombinedFormInputs] = useState<FormValues>({
    country: '',
    domain: '',
    product: '',
    functionalResponsible: [] as string[],
    technicalResponsible: [] as string[],
    instanceGW: '',
    gwUrlDev: 'https://apisb.mapfre.com.{iso2}',
    gwUrlPre: 'https://apisb.mapfre.com.{iso2}',
    gwUrlPro: 'https://apigw.mapfre.com.{iso2}',
    backendUser: '',
    hostIc: 'https://',
    hostDev: 'https://',
    hostPre: 'https://',
    hostPro: 'https://',
    jenkinsUrl: '',
    jenkinsUser: '',
    jenkinsPassword: '',
    earEdge: '',
    earMediation: '',
  });

  useAsync(async () => {
    try {
      const response = await catalogApi.getEntities({
        filter: { kind: 'User' },
        fields: ['kind', 'metadata.name'],
      });
      if (response.items && Array.isArray(response.items)) {
        setOwners(response.items.map(e => `user:${e.metadata.name}`));
      }
    } catch (error) {
      console.error('Error fetching owners:', error);
    }

    try {
      const response = await catalogApi.getEntities({
        filter: {
          kind: 'mapfreapi',
          'metadata.typology': ['Edge API', 'Mediation API', 'Business API'],
          'metadata.country': 'TRON',
          'spec.lifecycle': 'Approved',
        },
        fields: ['metadata.name', 'metadata.typology'],
      });
      if (response.items && Array.isArray(response.items)) {
        setEntities(
          response.items.map(e => `${e.metadata.name}/${e.metadata.typology}`),
        );
      }
    } catch (error) {
      console.error('Error fetching entities:', error);
    }
  });

  const renderOption = (
    option: string,
    state: AutocompleteRenderOptionState,
  ) => (
    <li {...state}>
      <Checkbox
        color="secondary"
        icon={icon}
        checkedIcon={checkedIcon}
        style={{ marginRight: 8 }}
        checked={state.selected}
      />
      {option}
    </li>
  );

  const handleConfirm = () => {
    setOpen(false);
    window.location.href = '/';
  };

  const handleConfirmCopy = () => {
    navigate(
      `/apis?filters%5Bkind%5D=mapfreapi&filters%5Buser%5D=all&filters%5Bcountry%5D=${combinedFormInputs.country}&filters%5Btypology%5D=Business%20API&filters%5Btypology%5D=Edge%20API&filters%5Btypology%5D=Mediation%20API`,
    );
    window.location.reload();
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleCancel = () => {
    setOpen(true);
  };

  const areRequiredFieldsFilled = () => {
    const requiredFields: (keyof FormValues)[] = [
      'country',
      'functionalResponsible',
      'technicalResponsible',
      'instanceGW',
      'gwUrlDev',
      'gwUrlPre',
      'gwUrlPro',
      'hostIc',
      'hostDev',
      'hostPre',
      'hostPro',
      'earEdge',
      'earMediation',
    ];

    const result = requiredFields.every(field => {
      const value = combinedFormInputs[field];

      if (Array.isArray(value)) {
        return value.length > 0;
      }
      return typeof value === 'string' && value.trim() !== '';
    });

    return result;
  };

  console.log(combinedFormInputs);

  const handleAutocompleteChange =
    (field: string) => (_event: ChangeEvent<object>, value: string[]) => {
      setCombinedFormInputs(prevData => ({
        ...prevData,
        [field]: value,
      }));
    };

  const handleFormInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    if (name === 'country' && value.length >= 3) {
      const country = countryCodes.find(
        c => c.iso3.toLowerCase() === value.toLowerCase(),
      );

      if (country?.iso2 && country?.iso2 !== undefined) {
        const gwUrlDev = (combinedFormInputs.gwUrlDev as string).replace(
          /\.(?!.*\.)[^.]+$/,
          '.' + country?.iso2.toLowerCase(),
        );
        const gwUrlPre = (combinedFormInputs.gwUrlPre as string).replace(
          /\.(?!.*\.)[^.]+$/,
          '.' + country?.iso2.toLowerCase(),
        );
        const gwUrlPro = (combinedFormInputs.gwUrlPro as string).replace(
          /\.(?!.*\.)[^.]+$/,
          '.' + country?.iso2.toLowerCase(),
        );

        const earEdge = (combinedFormInputs.earEdge as string).replace(
          /(.*)/,
          country?.iso2.toLowerCase(),
        );
        const earMediation = (
          combinedFormInputs.earMediation as string
        ).replace(/(.*)/, country?.iso2.toLowerCase());

        setCombinedFormInputs(prevData => ({
          ...prevData,
          [name]: value.toUpperCase(),
          gwUrlDev: gwUrlDev,
          gwUrlPre: gwUrlPre,
          gwUrlPro: gwUrlPro,
          earEdge: earEdge,
          earMediation: earMediation,
        }));
        return;
      } else {
        alertApi.post({
          message: 'Invalid ISO 3 or not in the allowed values',
          severity: 'error',
        });

        setCombinedFormInputs(prevData => ({
          ...prevData,
          [name]: '',
        }));

        return;
      }
    }
    setCombinedFormInputs(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  function encrypt(text: string): string {
    const key = CryptoJS.enc.Utf8.parse('mapfre'.padStart(32, '0'));
    const iv = CryptoJS.enc.Utf8.parse('mapfre'.padStart(16, '0'));

    // Encrypt the text
    const encrypted = CryptoJS.AES.encrypt(text, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    return encrypted.ciphertext.toString(CryptoJS.enc.Hex);
  }

  async function handleCreateConfirmation() {
    setIsLoading(true);
    const { token } = await identityApi.getCredentials();

    const user = (
      await identityApi.getBackstageIdentity()
    ).userEntityRef.replace('default/', '');

    //Update country data in Dashboards tables
    const url = new URL(
      `api/forms/updateDashboardCountry/${combinedFormInputs.country}`,
      window.location.origin.replace('3000', '7007'),
    );

    const body = {
      domain: combinedFormInputs.domain,
      product: combinedFormInputs.product,
      jenkinsUrl: combinedFormInputs.jenkinsUrl,
      jenkinsUser:
        combinedFormInputs.jenkinsUser.length > 0
          ? encrypt(combinedFormInputs.jenkinsUser)
          : '',
      jenkinsPassword:
        combinedFormInputs.jenkinsPassword.length > 0
          ? encrypt(combinedFormInputs.jenkinsPassword)
          : '',
    };

    const headers = new Headers();
    headers.set('Content-type', 'application/json');

    const req = new Request(url.toString(), {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    await fetch(req);

    //Check if target bucket exists, if doesnt exist then create
    const existsBucket = await createBucket(
      `catalog-api-${(
        combinedFormInputs.country as string
      ).toLocaleLowerCase()}-${env}`,
      token,
    );

    if (!existsBucket.includes('Created')) {
      throw new Error(`Bucket can't be created`);
    }

    //Set counter
    let cont = 0;

    for (const entity of entities) {
      cont = cont + 1;
      setEntityActual(cont);

      const uid = uuidv4();
      const now = Date.now();
      const files: Record<string, string> = {};

      const repositoryUrl = await forkRepository(
        `catalog-api-tron-${env}`,
        entity.split('/')[0],
        `catalog-api-${(
          combinedFormInputs.country as string
        ).toLocaleLowerCase()}-${env}`,
        uid,
        'false',
        token,
      );

      const catalogInfo = await getCatalogInfo(repositoryUrl, token);
      const doc = parse(catalogInfo);

      doc.metadata.country = combinedFormInputs.country;
      doc.metadata.liablePeople['mapfre.com/owners'] = [user];
      doc.spec.owner = [user];

      //Update state to Review just for Business API
      if ((doc.metadata.typology as string).includes('Business API')) {
        doc.metadata['mapfre.com/state'] = 'Review';
        doc.spec.lifecycle = 'Review';
      }

      if (doc.spec.consumesApis) {
        doc.spec.consumesApis = [];
      }
      if (doc.spec.apiConsumedBy) {
        doc.spec.apiConsumedBy = [];
      }
      if (doc.spec.authorizesApis) {
        doc.spec.authorizesApis = [];
      }
      if (doc.spec.apiAuthorizedBy) {
        doc.spec.apiAuthorizedBy = [];
      }
      if (doc.spec.invokesApis) {
        doc.spec.invokesApis = [];
      }
      if (doc.spec.apiInvokedBy) {
        doc.spec.apiInvokedBy = [];
      }
      if (doc.spec.simulatesApis) {
        doc.spec.simulatesApis = [];
      }
      if (doc.spec.apiSimulatedBy) {
        doc.spec.apiSimulatedBy = [];
      }
      if (doc.spec.nextVersionOf) {
        doc.spec.nextVersionOf = [];
      }
      if (doc.spec.previousVersionOf) {
        doc.spec.previousVersionOf = [];
      }

      doc.metadata.liablePeople['mapfre.com/resp_func'] =
        combinedFormInputs.functionalResponsible;
      doc.metadata.liablePeople['mapfre.com/resp_tech'] =
        combinedFormInputs.technicalResponsible;
      doc.metadata.liablePeople['mapfre.com/resp_alt'] = '';
      doc.metadata['mapfre.com/id_ram'] = '';
      doc.metadata.modDate = now;
      doc.metadata.historyLog['mapfre.com/approvalDate'] = now;
      doc.metadata.historyLog['mapfre.com/modDate'] = now;
      doc.metadata.historyLog['mapfre.com/user_mod'] = user.replace(
        'user:',
        'user:default/',
      );

      for (
        let i = 0;
        i < (doc.metadata.instances as Record<string, unknown>[]).length;
        i++
      ) {
        const instance = (doc.metadata.instances as Record<string, unknown>[])[
          i
        ];

        //Update serv_type
        if (
          (instance['mapfre.com/serv_type'] as string).includes(
            'External Gateway',
          )
        ) {
          instance['mapfre.com/serv_type'] = combinedFormInputs.instanceGW;
        }

        //Update endpoints
        if ((doc.metadata.typology as string).includes('Edge API')) {
          instance['mapfre.com/endpoint_IC'] = (
            instance['mapfre.com/endpoint_IC'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostIc)
              .replace('_be-web', `_${combinedFormInputs.earEdge}_be-web`),
          );
          instance['mapfre.com/endpoint_DEV'] = (
            instance['mapfre.com/endpoint_DEV'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostDev)
              .replace('_be-web', `_${combinedFormInputs.earEdge}_be-web`),
          );
          instance['mapfre.com/endpoint_PRE'] = (
            instance['mapfre.com/endpoint_PRE'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPre)
              .replace('_be-web', `_${combinedFormInputs.earEdge}_be-web`),
          );

          //If Pro value doesn't exists, use Pre value
          if (
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'No disponible',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes('N/A') ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'Not available',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string) === ''
          ) {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRE'] as string[]
            ).map(str =>
              str.replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPro),
            );
          } else {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRO'] as string[]
            ).map(str =>
              str
                .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPro)
                .replace('_be-web', `_${combinedFormInputs.earEdge}_be-web`),
            );
          }
        }
        if ((doc.metadata.typology as string).includes('Mediation API')) {
          instance['mapfre.com/endpoint_IC'] = (
            instance['mapfre.com/endpoint_IC'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostIc)
              .replace('_be-web', `_${combinedFormInputs.earMediation}_be-web`),
          );
          instance['mapfre.com/endpoint_DEV'] = (
            instance['mapfre.com/endpoint_DEV'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostDev)
              .replace('_be-web', `_${combinedFormInputs.earMediation}_be-web`),
          );
          instance['mapfre.com/endpoint_PRE'] = (
            instance['mapfre.com/endpoint_PRE'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPre)
              .replace('_be-web', `_${combinedFormInputs.earMediation}_be-web`),
          );

          //If Pro value doesn't exists, use Pre value
          if (
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'No disponible',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes('N/A') ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'Not available',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string) === ''
          ) {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRE'] as string[]
            ).map(str =>
              str.replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPro),
            );
          } else {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRO'] as string[]
            ).map(str =>
              str
                .replace(/^https?:\/\/[^/]+/, combinedFormInputs.hostPro)
                .replace(
                  '_be-web',
                  `_${combinedFormInputs.earMediation}_be-web`,
                ),
            );
          }
        }
        if ((doc.metadata.typology as string).includes('Business API')) {
          instance['mapfre.com/endpoint_DEV'] = (
            instance['mapfre.com/endpoint_DEV'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.gwUrlDev)
              .replace('corp/test', combinedFormInputs.country.toLowerCase()),
          );
          instance['mapfre.com/endpoint_PRE'] = (
            instance['mapfre.com/endpoint_PRE'] as string[]
          ).map(str =>
            str
              .replace(/^https?:\/\/[^/]+/, combinedFormInputs.gwUrlPre)
              .replace('corp/test', combinedFormInputs.country.toLowerCase()),
          );

          //If Pro value doesn't exists, use Pre value
          if (
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'No disponible',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes('N/A') ||
            (instance['mapfre.com/endpoint_PRO'] as string).includes(
              'Not available',
            ) ||
            (instance['mapfre.com/endpoint_PRO'] as string) === ''
          ) {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRE'] as string[]
            ).map(str =>
              str
                .replace(/^https?:\/\/[^/]+/, combinedFormInputs.gwUrlPro)
                .replace('corp/test', combinedFormInputs.country.toLowerCase()),
            );
          } else {
            instance['mapfre.com/endpoint_PRO'] = (
              instance['mapfre.com/endpoint_PRO'] as string[]
            ).map(str =>
              str
                .replace(/^https?:\/\/[^/]+/, combinedFormInputs.gwUrlPro)
                .replace('corp/test', combinedFormInputs.country.toLowerCase()),
            );
          }
        }
      }

      files[`catalog-info.yaml`] = stringify(doc);

      const result = await uploadFiles(repositoryUrl, files, token);

      if (result === 'Created') {
        //Remove files deleted
        for (const key in files) {
          if (key.includes('delete_s3_file')) {
            delete files[key];
          }
        }

        //Add history log
        await apiChangelog.pushLogFromEntity(
          '',
          files,
          user.replace('user:', '').replace(/_(?=[^_]*$)/, '@'),
          doc,
          '',
          'Cloned entity. Updated section: metadata',
        );

        //Subscriptions
        const liablePeople: string[] = [user]
          .concat(combinedFormInputs.functionalResponsible)
          .concat(combinedFormInputs.technicalResponsible)
          .map(user => {
            return user.replace('user:', '').replace(/_(?=[^_]*$)/, '@');
          });

        const subscribers: string[] = [...new Set(liablePeople)];
        const uidApi: string = doc.metadata.name;

        for (const subscriber of subscribers) {
          await newSubscriptionCatalogApi(uidApi, subscriber, true, true, '7');
        }

        //Add entities to backstage
        await registerEntity(repositoryUrl);
      }
    }

    //Just execute if domain and product are informed
    if (
      combinedFormInputs.domain.length !== 0 &&
      combinedFormInputs.product.length !== 0
    ) {
      const response = await catalogApi.getEntities({
        filter: {
          kind: 'mapfreapi',
          'metadata.typology': ['Edge API', 'Mediation API'],
          'metadata.country': combinedFormInputs.country,
          'spec.lifecycle': 'Approved',
        },
        fields: [
          'metadata.name',
          'metadata.title',
          'metadata.typology',
          'metadata.country',
          'metadata.instances',
        ],
      });
      if (response.items && Array.isArray(response.items)) {
        const entities = response.items.map(e => {
          const instances =
            e.metadata.instances && Array.isArray(e.metadata.instances)
              ? (e.metadata.instances as JsonArray).map(instance => {
                  if (typeof instance === 'object' && instance !== null) {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const obj = instance as Record<string, any>;
                    return Object.keys(obj)
                      .filter(key => key.startsWith('mapfre.com/endpoint_'))
                      .reduce((result, key) => {
                        result[key] = obj[key];
                        return result;
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                      }, {} as Record<string, any>);
                  }

                  return {};
                })
              : [];

          return `{ "name":"${e.metadata.name}", "title":"${
            e.metadata.title
          }", "typology":"${
            e.metadata.typology
          }", "instances": ${JSON.stringify(instances)}}`;
        });

        const parsedData = entities.map(item => JSON.parse(item));

        //Update domain data in Dashboards tables
        const url = new URL(
          `api/forms/updateDashboardApis/${combinedFormInputs.country}`,
          window.location.origin.replace('3000', '7007'),
        );

        const body = {
          domain: combinedFormInputs.domain,
          product: combinedFormInputs.product,
          data: JSON.stringify(parsedData),
        };

        const headers = new Headers();
        headers.set('Content-type', 'application/json');

        const req = new Request(url.toString(), {
          method: 'POST',
          headers,
          body: JSON.stringify(body),
        });

        await fetch(req);
      }
    }
    setTimeout(() => {
      setIsLoading(false);
      setOpenDialog(true);
    }, 3000);
  }
  return (
    <>
      <Dialog open={isLoading}>
        <DialogContent>
          <CircularProgress
            style={{ width: '100px', height: '100px', margin: '40px' }}
          />

          <DialogContentText>
            <strong>
              Creating {entityActual} of {entities.length} assets
            </strong>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      <Dialog
        open={openDialog}
        onClose={handleConfirmCopy}
        aria-labelledby="draft-dialog"
      >
        <DialogTitle id="draft-dialog">{t(`Copied Community`)}</DialogTitle>

        <DialogActions>
          <Button
            onClick={handleConfirmCopy}
            color="primary"
            variant="contained"
          >
            {t('Agree')}
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {t(
              'Are you sure you want to cancel? Unsaved changes will be lost.',
            )}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            {t('Cancel')}
          </Button>
          <Button onClick={handleConfirm} color="secondary">
            {t('Accept')}
          </Button>
        </DialogActions>
      </Dialog>

      <Box sx={{ width: '80%', margin: 'auto' }}>
        <Container className={classes.container}>
          <Typography
            variant="h6"
            className={`${classes.section} ${classes.stepTitle}`}
          >
            {t('Copy TRON community')}
          </Typography>

          <Grid>
            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Country')}
                name="country"
                helperText={t('Indicate ISO 3 Code')}
                onChange={handleFormInputChange}
              />
            </Grid>
            <Typography variant="subtitle1" className={classes.section}>
              {t('Liable Team')}
            </Typography>
            <Typography variant="subtitle2">
              {t(
                'If you cannot locate the user email address, you should contact the administration team via request in Service Manager',
              )}
            </Typography>
            <Grid style={{ display: 'flex' }}>
              <Autocomplete
                multiple
                className={classes.description}
                size="small"
                id="functionalResponsible"
                options={owners}
                onChange={handleAutocompleteChange('functionalResponsible')}
                disableCloseOnSelect
                getOptionLabel={option => option}
                renderOption={renderOption}
                renderInput={params => (
                  <TextField
                    {...params}
                    required
                    variant="outlined"
                    label={t('Functional Manager')}
                    size="small"
                  />
                )}
              />
              <Autocomplete
                multiple
                className={classes.description}
                size="small"
                id="technicalResponsible"
                options={owners}
                onChange={handleAutocompleteChange('technicalResponsible')}
                disableCloseOnSelect
                getOptionLabel={option => option}
                renderOption={renderOption}
                renderInput={params => (
                  <TextField
                    {...params}
                    required
                    variant="outlined"
                    label={t('Technical Manager')}
                    size="small"
                  />
                )}
              />
            </Grid>

            <Typography variant="subtitle1" className={classes.section}>
              {t('GW Host')}
            </Typography>
            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                size="small"
                className={classes.inputFirstLarge}
                required
                variant="outlined"
                select
                helperText={t('Select the location where exposure is required')}
                label={t('Service location')}
                name="instanceGW"
                value={combinedFormInputs.instanceGW}
                onChange={handleFormInputChange}
                autoComplete="on"
              >
                <MenuItem value="External Gateway (DMZ) Alcalá">
                  {t('External Gateway (DMZ) Alcalá')}
                </MenuItem>
                <MenuItem value="External Gateway (DMZ) Miami">
                  {t('External Gateway (DMZ) Miami')}
                </MenuItem>
                <MenuItem value="External Gateway (DMZ) Sao Paulo">
                  {t('External Gateway (DMZ) Sao Paulo')}
                </MenuItem>
              </TextField>
            </Grid>
            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('GW URL Dev')}
                name="gwUrlDev"
                helperText={t(
                  'It is proposed based on the indicated ISO 3 code',
                )}
                value={combinedFormInputs.gwUrlDev}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('GW URL Pre')}
                name="gwUrlPre"
                helperText={t(
                  'It is proposed based on the indicated ISO 3 code',
                )}
                value={combinedFormInputs.gwUrlPre}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('GW URL Pro')}
                name="gwUrlPro"
                helperText={t(
                  'It is proposed based on the indicated ISO 3 code',
                )}
                value={combinedFormInputs.gwUrlPro}
                onChange={handleFormInputChange}
              />
            </Grid>

            <Typography variant="subtitle1" className={classes.section}>
              {t('Backend Host Environments')}
            </Typography>

            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Backend User')}
                name="backendUser"
                onChange={handleFormInputChange}
              />
            </Grid>
            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Backend Host Ic')}
                name="hostIc"
                value={combinedFormInputs.hostIc}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Backend Host Dev')}
                name="hostDev"
                value={combinedFormInputs.hostDev}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Backend Host Pre')}
                name="hostPre"
                value={combinedFormInputs.hostPre}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Backend Host Pro')}
                name="hostPro"
                value={combinedFormInputs.hostPro}
                onChange={handleFormInputChange}
              />
            </Grid>

            <Typography variant="subtitle1" className={classes.section}>
              {t('Additional data')}
            </Typography>

            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Ear name for the Edge')}
                name="earEdge"
                helperText={
                  t('It is proposed based on the indicated ISO 2 code.') +
                  ` nwt_[api_name]_api_${combinedFormInputs.earEdge}_be-web`
                }
                value={combinedFormInputs.earEdge}
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                required
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Ear name for the Mediation')}
                name="earMediation"
                helperText={
                  t('It is proposed based on the indicated ISO 2 code.') +
                  ` business_api_[api_name]_${combinedFormInputs.earMediation}_be-web`
                }
                value={combinedFormInputs.earMediation}
                onChange={handleFormInputChange}
              />
            </Grid>

            <Typography variant="subtitle1" className={classes.section}>
              {t('Dashboard data')}
            </Typography>

            <TextField
              fullWidth
              className={classes.inputFirstLarge}
              size="small"
              variant="outlined"
              label={t('Zeus Domain')}
              name="domain"
              value={combinedFormInputs.domain}
              onChange={handleFormInputChange}
            />

            <TextField
              fullWidth
              className={classes.inputFirstLarge}
              size="small"
              variant="outlined"
              label={t('Zeus Product')}
              name="product"
              value={combinedFormInputs.product}
              onChange={handleFormInputChange}
            />

            <Grid style={{ display: 'flex' }}>
              <TextField
                fullWidth
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Url Jenkins Job')}
                name="jenkinsUrl"
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Jenkins User')}
                name="jenkinsUser"
                onChange={handleFormInputChange}
              />
              <TextField
                fullWidth
                className={classes.inputFirstLarge}
                size="small"
                variant="outlined"
                label={t('Jenkins Password')}
                name="jenkinsPassword"
                onChange={handleFormInputChange}
              />
            </Grid>
          </Grid>
        </Container>
      </Box>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          bgcolor: 'background.paper',
          padding: '16px',
          boxShadow: '0px -2px 5px rgba(0, 0, 0, 0.1)',
          zIndex: 1000,
        }}
      >
        <Button color="primary" onClick={handleCancel}>
          {t('Cancel')}
        </Button>
        <Box sx={{ flex: '1 1 auto' }} />
        <Button
          color="primary"
          disabled={!areRequiredFieldsFilled()}
          onClick={handleCreateConfirmation}
        >
          {t('Finish')}
        </Button>
      </Box>
    </>
  );

  async function registerEntity(repository: string) {
    const location = await catalogApi.addLocation({
      dryRun: true,
      type: 'url',
      target: `${repository}`,
    });

    if (!location.exists) {
      await catalogApi.addLocation({
        type: 'url',
        target: `${repository}`,
      });
    }

    const entityRefresh = await getEntityRefresh(location);
    // Refreshing entity
    await sleep(3);
    await catalogApi.refreshEntity(stringifyEntityRef(entityRefresh));

    return entityRefresh;
  }

  async function getEntityRefresh(
    location: AddLocationResponse,
  ): Promise<Entity> {
    const { entities } = location;
    let entity: Entity | undefined;
    // prioritise 'Component' type as it is the most central kind of entity
    entity = entities.find(
      e => !e.metadata.name.startsWith('generated-') && e.kind === 'Location',
    );
    if (!entity) {
      entity = entities[0];
    }

    return entity;
  }
};
