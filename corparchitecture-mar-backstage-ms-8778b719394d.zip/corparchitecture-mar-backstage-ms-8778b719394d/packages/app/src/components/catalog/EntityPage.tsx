/* eslint-disable @typescript-eslint/no-explicit-any */
/*
 * Copyright 2020 The Backstage Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import React, { useEffect, useState } from 'react';
import {
  AdaptBitbucketHrefsAddon,
  CustomExpandableAddon,
  CustomBreadcrumbsAddon,
  BrokenLinksAddon,
  HidePrevNextButtonsAddon,
} from '@internal/plugin-custom-addons';
import {
  Button,
  Card,
  CardContent,
  CardHeader,
  Container,
  Divider,
  // UNCOMMENT these lines when Service Manager is connected and available.
  // Dialog,
  // DialogActions,
  // DialogContent,
  // DialogContentText,
  // DialogTitle,
  Grid,
  Typography,
  // UNCOMMENT these lines when Service Manager is connected and available.
  // LinearProgress,
  // TextField,
  // Typography,
  makeStyles,
} from '@material-ui/core';
import {
  EntityApiDefinitionCard,
  EntityConsumedApisCard,
  EntityHasApisCard,
  EntityProvidedApisCard,
} from '@backstage/plugin-api-docs';
import {
  EntityAboutCard,
  EntityDependsOnComponentsCard,
  EntityDependsOnResourcesCard,
  EntityHasSystemsCard,
  EntityLayout,
  EntityLinksCard,
  EntitySwitch,
  EntityOrphanWarning,
  EntityProcessingErrorsPanel,
  isComponentType,
  isKind,
  hasCatalogProcessingErrors,
  isOrphan,
} from '@backstage/plugin-catalog';

import { isRefArchType } from '../conditions/isRefArchType';
import {
  isGithubActionsAvailable,
  EntityGithubActionsContent,
} from '@backstage/plugin-github-actions';
import {
  EntityUserProfileCard,
  EntityGroupProfileCard,
  EntityMembersListCard,
} from '@backstage/plugin-org';
import { EntityTechdocsContent } from '@backstage/plugin-techdocs';
import {
  DocsIcon,
  EmptyState,
  HeaderIconLinkRow,
  IconLinkVerticalProps,
  MarkdownContent,
  Progress,
} from '@backstage/core-components';
import {
  EntityCatalogGraphCard,
  ALL_RELATION_PAIRS,
} from '@backstage/plugin-catalog-graph';
import { getCompoundEntityRef, parseEntityRef } from '@backstage/catalog-model';

import {
  EntityCircleCIContent,
  isCircleCIAvailable,
} from '@backstage/plugin-circleci';

import {
  EntityJenkinsContent,
  isJenkinsAvailable,
} from '@backstage/plugin-jenkins';
import {
  ChangelogCard,
  MetadataTableCard,
  FunctionalCategoryCard,
  AboutCustomCard,
  KeyValueCustomCard,
  MetadataTextCard,
  ExternalAboutCustomCard,
  OwnershipCard,
} from '@internal/plugin-custom-cards';

import { TechDocsAddons } from '@backstage/plugin-techdocs-react';
import { ExpandableNavigation } from '@backstage/plugin-techdocs-module-addons-contrib';

import { Mermaid } from 'backstage-plugin-techdocs-addon-mermaid';
import { TFunction } from 'i18next';
import { isMapfreApiType } from '../conditions/isMapfreApiType';
import { CUSTOM_PAIRS } from '../relations-graph/EntityRelationsGraph';
import { RefArchEntityPage } from './RefArchitecture/RefArchEntityPage';
import { RefArchitecture } from './RefArchitecture/Architectures/RefArchitecture';
import { VERSION_PAIR } from '../version-graph/EntityVersionsGraph';
import { VersionGraphCard } from '../version-graph/VersionGraphCard';
import { ChangelogTableRow } from '@internal/plugin-custom-cards/src/components/ChangelogCard/ChangelogCard';
import Pageview from '@material-ui/icons/Pageview';
import { useEntity } from '@backstage/plugin-catalog-react';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { MethodGeneral } from './Methods/MethodGeneral';
import { WsrrUploadCard } from '@internal/plugin-custom-cards';
import { WsrrPublishCard } from '@internal/plugin-custom-cards';
import { WsrrRequestPublishCard } from '@internal/plugin-custom-cards';
import { EntityGraphCard } from '../relations-graph/EntityGraphCard';
import { usePermission } from '@backstage/plugin-permission-react';
import {
  mapfreapiManagePermission,
  mapfreapiPublishWsrrEdicPermission,
  mapfreapiPublishWsrrPermission,
} from '@backstage/plugin-mapfreapi-editor-common';
import { StatisticsCards } from '@internal/plugin-custom-cards/src/components/StatisticsCards';
import {
  MetadataTableCardEditable,
  ComponentAboutCustomCard,
} from '@internal/plugin-custom-cards';
import { componentsEditPermission } from '@backstage/plugin-components-catalog-edit-common';
import {
  MdEditorComponent,
  HideEditButtonAddon,
  //MdEditorAddon,
} from '@backstage/plugin-components-catalog-edit';
import { grey } from '@mui/material/colors';

import { useAsync } from 'react-use';

import { ExternalDocumentationTab } from './ExternalEntityPage/ExternalDocumentationTab';
import { DocumentationTab } from './ExternalEntityPage/DocumentationTab';
import { getTemplate } from '../settingsPage/requests';
import { AuditService } from '../../api/audit';

import { ResponsibleProvider } from './ResponsibleContext';
import { MembersCard } from '@internal/plugin-custom-cards/src/components/MembersCard';
import { UserDataCard } from '@internal/plugin-custom-cards/src/components/UserDataCard/UserDataCard';
import { SolutionPage } from './SolutionCatalog/SolutionPage';

//import { MdEditorAddon } from '@backstage/plugin-mdeditor';
// UNCOMMENT this line when Service Manager is connected and available.
//import AttachmentIcon from '@mui/icons-material/Attachment';
//import LinkIcon from '@mui/icons-material/Link';

/* const initialEditorState = {
  text: 'foo',
};

const GlobalStateContext = React.createContext(initialEditorState);
const DispatchStateContext = React.createContext(undefined);
// @ts-ignore
const GlobalStateProvider = ({ children }) => {
  const [state, dispatch] = React.useReducer(
    // @ts-ignore
    (state, newValue) => ({ ...state, ...newValue }),
    initialEditorState,
  );
  // @ts-ignore
  return (
    <GlobalStateContext.Provider value={state}>
      <DispatchStateContext.Provider value={dispatch}>
        {children}
      </DispatchStateContext.Provider>
    </GlobalStateContext.Provider>
  );
};

const useGlobalState = () => [
  React.useContext(GlobalStateContext),
  React.useContext(DispatchStateContext),
];

//el addon:

const TextContainer = () => {
  const [state, dispatch] = useGlobalState();
  // @ts-ignore
  const setText = React.useCallback(text => dispatch({ text }), []);
  // @ts-ignore
  return <HideEditButtonAddon text={state.text} setText={setText} />;
};

const EditorContainer = () => {
  const [state] = useGlobalState();
  // @ts-ignore
  return <MdEditorComponent text={state.text} />;
};
 */

const cicdContent = (
  // This is an example of how you can implement your company's logic in entity page.
  // You can for example enforce that all components of type 'service' should use GitHubActions
  <EntitySwitch>
    <EntitySwitch.Case if={isGithubActionsAvailable}>
      <EntityGithubActionsContent />
    </EntitySwitch.Case>
    <EntitySwitch.Case if={isJenkinsAvailable}>
      <EntityJenkinsContent />
    </EntitySwitch.Case>
    <EntitySwitch.Case>
      <EmptyState
        title="No CI/CD available for this entity"
        missing="info"
        description="You need to add an annotation to your component if you want to enable CI/CD for it. You can read more about annotations in Backstage by clicking the button below."
        action={
          <Button
            variant="contained"
            color="primary"
            href="https://backstage.io/docs/features/software-catalog/well-known-annotations"
          >
            Read more
          </Button>
        }
      />
    </EntitySwitch.Case>
    <EntitySwitch.Case if={isCircleCIAvailable}>
      <EntityCircleCIContent />
    </EntitySwitch.Case>
    ;
  </EntitySwitch>
);

const entityWarningContent = (
  <>
    <EntitySwitch>
      <EntitySwitch.Case if={isOrphan}>
        <Grid item xs={12}>
          <EntityOrphanWarning />
        </Grid>
      </EntitySwitch.Case>
    </EntitySwitch>

    <EntitySwitch>
      <EntitySwitch.Case if={hasCatalogProcessingErrors}>
        <Grid item xs={12}>
          <EntityProcessingErrorsPanel />
        </Grid>
      </EntitySwitch.Case>
    </EntitySwitch>
  </>
);

const overviewContent = (
  <Grid container spacing={3} alignItems="stretch">
    {entityWarningContent}
    <Grid item md={6}>
      <EntityAboutCard variant="gridItem" />
    </Grid>

    <Grid item md={6} xs={12}>
      <EntityCatalogGraphCard variant="gridItem" height={400} />
    </Grid>

    <Grid item md={4} xs={12}>
      <EntityLinksCard />
    </Grid>
  </Grid>
);

function serviceEntityPage(t: TFunction<'translation', undefined>) {
  return (
    <>
      <EntityLayout>
        <EntityLayout.Route path="/" title={t('Overview')}>
          {overviewContent}
        </EntityLayout.Route>

        <EntityLayout.Route path="/ci-cd" title="CI/CD">
          {cicdContent}
        </EntityLayout.Route>

        <EntityLayout.Route path="/api" title="API">
          <Grid container spacing={3} alignItems="stretch">
            <Grid item md={6}>
              <EntityProvidedApisCard />
            </Grid>
            <Grid item md={6}>
              <EntityConsumedApisCard />
            </Grid>
          </Grid>
        </EntityLayout.Route>

        <EntityLayout.Route path="/dependencies" title={t('Dependencies')}>
          <Grid container spacing={3} alignItems="stretch">
            <Grid item md={6}>
              <EntityDependsOnComponentsCard variant="gridItem" />
            </Grid>
            <Grid item md={6}>
              <EntityDependsOnResourcesCard variant="gridItem" />
            </Grid>
          </Grid>
        </EntityLayout.Route>

        <EntityLayout.Route path="/docs" title="Docs">
          <EntityTechdocsContent>
            <TechDocsAddons>
              <ExpandableNavigation />
              <CustomBreadcrumbsAddon />
              <BrokenLinksAddon />
              <CustomExpandableAddon />
              <Mermaid />
              <AdaptBitbucketHrefsAddon />
              <HidePrevNextButtonsAddon />
            </TechDocsAddons>
          </EntityTechdocsContent>
        </EntityLayout.Route>
      </EntityLayout>
    </>
  );
}

function ComponentV2EntityPage(t: TFunction<'translation', undefined>) {
  const { entity } = useEntity();

  const canEdit = usePermission({
    permission: componentsEditPermission,
    resourceRef: `component:${entity.metadata.name}`,
  });

  const generalTab2 = (
    <EntityLayout.Route path="/" title={'Overview'}>
      <Grid container spacing={3}>
        {entityWarningContent}
        <Grid item md={6}>
          <ComponentAboutCustomCard variant="gridItem" />
        </Grid>

        {Object.keys(entity.metadata).map(key => {
          const excludedKeys = [
            'uid',
            'etag',
            'description',
            'namespace',
            'name',
            'annotations',
          ];
          if (excludedKeys.includes(key)) {
            return null;
          }
          let title = key; // Default title is the key itself
          const metadataValue = entity.metadata[key];
          if (
            typeof metadataValue === 'object' &&
            metadataValue !== null && // Ensure metadataValue is not null
            'title' in metadataValue &&
            metadataValue['title']
          ) {
            title = metadataValue['title'] as string;

            if (
              typeof metadataValue === 'object' &&
              metadataValue !== null && // Ensure metadataValue is not null
              'dataType' in metadataValue &&
              metadataValue['dataType']
            ) {
              if (metadataValue['dataType'] === 'KeyValue') {
                const dataColor = metadataValue['dataColor'] as string;
                if (metadataValue['dataColor']) {
                  return (
                    <KeyValueCustomCard
                      key={key}
                      title={title}
                      yamlKey={key}
                      dataColor={dataColor}
                    />
                  );
                } else {
                  return (
                    <KeyValueCustomCard
                      key={key}
                      title={title}
                      yamlKey={key}
                      dataColor={'#d9d9d9'}
                    />
                  );
                }
              } else if (metadataValue['dataType'] === 'Text') {
                return (
                  <MetadataTextCard key={key} title={title} yamlKey={key} />
                );
              } else {
                //logica de seleccion si puede editar o no.
                <MetadataTableCardEditable
                  key={key}
                  yamlKey={key}
                  title={title}
                  t={t}
                  isAdmin={canEdit.allowed}
                />;
              }
            }

            return (
              <MetadataTableCardEditable
                key={key}
                yamlKey={key}
                title={title}
                t={t}
                isAdmin={canEdit.allowed}
              />
            );
          }
          return null;
        })}

        <Grid item md={6} xs={12}>
          <EntityCatalogGraphCard variant="gridItem" height={400} />
        </Grid>
        <Grid item md={4} xs={12}>
          <EntityLinksCard />
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  return (
    <>
      <EntityLayout>
        {generalTab2}
        <EntityLayout.Route path="/docs" title="Docs">
          <EntityTechdocsContent>
            <TechDocsAddons>
              <ExpandableNavigation />
              <BrokenLinksAddon />
              <CustomExpandableAddon />
              <Mermaid />
              {canEdit.allowed ? (
                //<MdEditorAddon />
                <>
                  <HideEditButtonAddon />
                  <MdEditorComponent />
                </>
              ) : (
                "You don't have permission to edit this documents. Ask the owner of the component to add you as a contributor."
              )}
            </TechDocsAddons>
          </EntityTechdocsContent>
        </EntityLayout.Route>
      </EntityLayout>
    </>
  );
}

function WebsiteEntityPage({ t }: { t: TFunction<'translation', undefined> }) {
  const useStyles = makeStyles({
    storybook: {
      width: '100%',
      height: '100%',
      border: 'none',
    },
  });
  const classes = useStyles();
  const { entity } = useEntity();
  return (
    <>
      <EntityLayout>
        <EntityLayout.Route path="/" title={t('Overview')}>
          {overviewContent}
        </EntityLayout.Route>

        <EntityLayout.Route path="/docs" title="Docs">
          <EntityTechdocsContent>
            <TechDocsAddons>
              <ExpandableNavigation />
              <CustomExpandableAddon />
              <Mermaid />
              <BrokenLinksAddon />
            </TechDocsAddons>
          </EntityTechdocsContent>
        </EntityLayout.Route>

        <EntityLayout.Route path="/storybook" title="Storybook">
          {entity.metadata.storybook ? (
            <iframe
              className={classes.storybook}
              src={entity.metadata.storybook.toString()}
            ></iframe>
          ) : (
            <EmptyState
              title="No storybook url"
              missing="info"
              description="You need to add a storybook url to your component YAML metadata, if you want to view here your storybook."
              action={
                entity.metadata.annotations &&
                entity.metadata.annotations['backstage.io/edit-url'] ? (
                  <Button
                    variant="contained"
                    color="primary"
                    href={entity.metadata.annotations['backstage.io/edit-url']}
                  >
                    EDIT YAML
                  </Button>
                ) : undefined
              }
            />
          )}
        </EntityLayout.Route>
      </EntityLayout>
    </>
  );
}

/**
 * NOTE: This page is designed to work on small screens such as mobile devices.
 * This is based on Material UI Grid. If breakpoints are used, each grid item must set the `xs` prop to a column size or to `true`,
 * since this does not default. If no breakpoints are used, the items will equitably share the available space.
 * https://material-ui.com/components/grid/#basic-grid.
 */

function defaultEntityPage(t: TFunction<'translation', undefined>) {
  return (
    <>
      <EntityLayout>
        <EntityLayout.Route path="/" title={t('Overview')}>
          {overviewContent}
        </EntityLayout.Route>

        <EntityLayout.Route path="/docs" title="Docs">
          <EntityTechdocsContent>
            <TechDocsAddons>
              <ExpandableNavigation />
              <CustomExpandableAddon />
              <Mermaid />
              <BrokenLinksAddon />
            </TechDocsAddons>
          </EntityTechdocsContent>
        </EntityLayout.Route>
      </EntityLayout>
    </>
  );
}

function DocumentationPageExternal() {
  return (
    <EntityTechdocsContent>
      <TechDocsAddons>
        <ExpandableNavigation />
        <CustomExpandableAddon />
        <Mermaid />
        <BrokenLinksAddon />
      </TechDocsAddons>
    </EntityTechdocsContent>
  );
}

function ComponentPage({ t }: { t: TFunction<'translation', undefined> }) {
  const { entity } = useEntity();
  const identityApi = useApi(identityApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl');
  const audit = new AuditService(backendUrl ?? '');
  const [isExternal, setIsExternal] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();

  useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();
    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setExtOwnershipEntityRefs(extEntityRefs);
    setIsExternal(Boolean(extEntityRefs.length));

    const { email } = await identityApi.getProfileInfo();
    if (email) {
      audit.pushViewLog(email, entity.metadata.name);
    }
  });
  return (
    <EntitySwitch>
      <EntitySwitch.Case if={isComponentType('service')}>
        {serviceEntityPage(t)}
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isComponentType('method')}>
        <MethodGeneral />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isComponentType('website')}>
        <WebsiteEntityPage t={t} />
      </EntitySwitch.Case>
      {isExternal && (
        <EntitySwitch.Case if={isComponentType('documentation')}>
          <DocumentationPageExternal />
        </EntitySwitch.Case>
      )}
      <EntitySwitch.Case>{ComponentV2EntityPage(t)}</EntitySwitch.Case>
    </EntitySwitch>
  );
}

function DocumentationPage({ t }: { t: TFunction<'translation', undefined> }) {
  const { entity } = useEntity();
  const identityApi = useApi(identityApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl');
  const audit = new AuditService(backendUrl ?? '');
  const entityRef = getCompoundEntityRef(entity);
  const entityRefBeta = getCompoundEntityRef(entity);
  entityRefBeta.name = entityRef.name + '_beta';
  const [changelogContent, setChangelogContent] = useState<ChangelogTableRow[]>(
    [],
  );

  useAsync(async () => {
    const { email } = await identityApi.getProfileInfo();
    if (email) {
      audit.pushViewLog(email, entity.metadata.name);
    }
  });

  const generalDataTab = (
    <EntityLayout.Route path="/" title={t('Overview')}>
      {/* <Container maxWidth="md"> */}
      <>
        {setProd()}
        <Grid container spacing={3}>
          <Grid item xs={6}>
            <AboutCustomCard variant="fullHeight" />
          </Grid>
          <MetadataTableCard yamlKey="liableTeam" title="Liable Team" t={t} />
          <MetadataTableCard yamlKey="contextData" title="Context Data" t={t} />
          <MetadataTableCard yamlKey="historyLog" title="History Log" t={t} />
          <Grid item md={6} xs={12}>
            <EntityGraphCard
              variant="gridItem"
              height={400}
              relationPairs={ALL_RELATION_PAIRS}
            />
          </Grid>
        </Grid>
        {/* </Container> */}
      </>
    </EntityLayout.Route>
  );

  const docsMasterTab = (
    <EntityLayout.Route
      path="/docs"
      title={entity.spec?.type === 'Simple' ? 'Prod' : 'Beta'}
    >
      <>
        {setProd()}
        <EntityTechdocsContent>
          <TechDocsAddons>
            <ExpandableNavigation />
            <CustomBreadcrumbsAddon />
            <BrokenLinksAddon />
            <CustomExpandableAddon />
            <Mermaid />
            <AdaptBitbucketHrefsAddon />
            <HidePrevNextButtonsAddon />
          </TechDocsAddons>
        </EntityTechdocsContent>
      </>
    </EntityLayout.Route>
  );

  const docsBetaTab = (
    <EntityLayout.Route path="/docs_beta" title="Beta">
      <>
        {setBeta()}
        <EntityTechdocsContent>
          <TechDocsAddons>
            <ExpandableNavigation />
            <CustomBreadcrumbsAddon />
            <BrokenLinksAddon />
            <CustomExpandableAddon />
            <Mermaid />
            <AdaptBitbucketHrefsAddon />
            <HidePrevNextButtonsAddon />
          </TechDocsAddons>
        </EntityTechdocsContent>
      </>
    </EntityLayout.Route>
  );

  const changeLogDocTab = (
    <EntityLayout.Route path="/history-log" title={t('History Log')}>
      <>
        {setProd()}
        <ChangelogCard />
      </>
    </EntityLayout.Route>
  );
  return (
    <EntityLayout>
      {generalDataTab}

      {(entity.spec?.type === 'Simple' || entity.spec?.type === 'Release') &&
        docsMasterTab}

      {entity.spec?.type === 'Simple' &&
        (entity.spec?.lifecycle === 'Accepted' ||
          entity.spec?.lifecycle === 'Approved' ||
          entity.spec?.lifecycle === 'Pending approval' ||
          entity.spec?.lifecycle === 'Retired candidate' ||
          entity.spec?.lifecycle === 'Discarded' ||
          entity.spec?.lifecycle === 'Retired') &&
        docsBetaTab}
      {entity.spec?.type === 'Simple' && changeLogDocTab}
    </EntityLayout>
  );
}

function ApiPage({ t }: { t: TFunction<'translation', undefined> }) {
  const useStyles = makeStyles({
    containerStyle: { width: '100%', height: '100vh', marginLeft: 20 },
  });
  const classes = useStyles();
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl');
  const audit = new AuditService(backendUrl ?? '');

  const [tabsEntity, setTabsEntity] = useState<string[]>(['generalTab']);
  const [extTabsEntity, setExtTabsEntity] = useState<string[]>(['overviewTab']);
  const identityApi = useApi(identityApiRef);
  const [isExternal, setIsExternal] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();
  const [apiSystem, setApiSystem] = useState(['']);
  const [isGov, setIsGov] = useState(false);
  const { entity } = useEntity();

  const { loading } = useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();
    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setExtOwnershipEntityRefs(extEntityRefs);
    setIsExternal(Boolean(extEntityRefs.length));
    const ownershipSystem = extEntityRefs.map(
      (entityRef: string) =>
        //GAZR-API-BACKSTAGE-EXT split
        entityRef?.split('-')[4].toLowerCase() +
        '-' +
        entityRef?.split('-')[5].toLowerCase(),
    );

    setApiSystem(ownershipSystem);

    const { email } = await identityApi.getProfileInfo();
    if (email) {
      audit.pushViewLog(email, entity.metadata.name);
    }
  });

  // UNCOMMENT this line when Service Manager is connected and available.
  // const [open, setOpen] = useState(false);

  const canPublish = usePermission({
    permission: mapfreapiPublishWsrrPermission,
  });
  const canPublishEdic = usePermission({
    permission: mapfreapiPublishWsrrEdicPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });
  const canManage = usePermission({
    permission: mapfreapiManagePermission,
  });

  const isExternalGov = localStorage.getItem('isExternalGov') === 'true';
  useEffect(() => {
    setIsGov(isExternalGov);
  }, []);

  // UNCOMMENT these lines when Service Manager is connected and available.
  //const gwFile = entity.metadata.annotations?.gwDeployment as string;
  //const wsrrLink = window.location.href;

  const TITLE = isGov ? t('Internal layout') : t('Consumer layout');

  const watchMenuItem = {
    title: TITLE,
    Icon: Pageview,
    onClick: consumerLayoutView,
  };

  async function consumerLayoutView() {
    try {
      setIsGov(prevIsGov => !prevIsGov);
    } catch (error) {
      console.error(error);
    }
  }

  const MENU_ITEMS = !canManage || isExternal ? undefined : [watchMenuItem];

  const WSRR_COUNTRIES = [
    'ESP',
    'GLOBAL',
    'MLT',
    'ITA',
    'DEU',
    'INV',
    'ASIS',
    'RE',
    'SOL',
    'TRON',
  ];
  const COUNTRY = entity?.metadata?.country as string;
  const TYPOLOGY = entity?.metadata?.typology as string;

  function checkGroupWsrr(entityRefs: string[]): {
    groups: string[];
    showWsrrTab: boolean;
  } {
    const allowedGroups = (entityRefs as string[]).filter(entityRef => {
      const parsedRef = parseEntityRef(entityRef);
      const groupName = parsedRef.name.toLowerCase();
      const isGroup = parsedRef.kind === 'group';

      return (
        isGroup &&
        (groupName.startsWith('gazr-api-backstage-wsrr') ||
          groupName.startsWith('gazr-gov-backstage-global') ||
          (groupName.startsWith('gazr-gov-backstage-esp') &&
            COUNTRY === 'ESP') ||
          (groupName.startsWith('gazr-gov-backstage-mlt') &&
            COUNTRY === 'MLT') ||
          (groupName.startsWith('gazr-gov-backstage-ita') &&
            COUNTRY === 'ITA') ||
          (groupName.startsWith('gazr-gov-backstage-deu') &&
            COUNTRY === 'DEU') ||
          (groupName.startsWith('gazr-gov-backstage-inv') &&
            COUNTRY === 'INV') ||
          (groupName.startsWith('gazr-gov-backstage-asis') &&
            COUNTRY === 'ASIS') ||
          (groupName.startsWith('gazr-gov-backstage-re') && COUNTRY === 'RE') ||
          (groupName.startsWith('gazr-gov-backstage-sol') &&
            COUNTRY === 'SOL') ||
          (groupName.startsWith('gazr-gov-backstage-tron') &&
            COUNTRY === 'TRON'))
      );
    });

    return {
      groups: allowedGroups,
      showWsrrTab: allowedGroups.length > 0,
    };
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const isGroupWsrr = () => {
    const {
      loading,
      value: showWsrrTab,
      error,
    } = useAsync(async () => {
      try {
        const { ownershipEntityRefs: entityRefs } =
          await identityApi.getBackstageIdentity();
        const { showWsrrTab } = checkGroupWsrr(entityRefs);
        return showWsrrTab;
      } catch (error) {
        console.log('Error al obtener la entidad:', error);
        return false;
      }
    }, []);

    return { loading, showWsrrTab, error };
  };

  let gwFile = '';

  //async function changeLayoutView() {
  //try {
  //setIsGov(prevIsGov => !prevIsGov);
  //} catch (error) {
  //console.error(error);
  //}
  //}

  async function downloadInterfaceFile(fileContent: string, label: string) {
    let exportedFilename = '';
    try {
      JSON.parse(fileContent);
      exportedFilename = `${new Date().toISOString()}_interface.json`;
    } catch {
      if (label.includes('WSDL')) {
        exportedFilename = `${new Date().toISOString()}_interface.wsdl`;
      } else {
        exportedFilename = `${new Date().toISOString()}_interface.yaml`;
      }
    } finally {
      const blob = new Blob([fileContent], {
        type: 'text/plain;charset=utf-8;',
      });

      const link = document.createElement('a');
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', exportedFilename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  async function downloadGWFile(fileContent: string) {
    const exportedFilename = `gw-deployment-${new Date()
      .toISOString()
      .replace(/:/g, '-')}.json`;

    const blob = new Blob([fileContent], {
      type: 'text/plain;charset=utf-8;',
    });

    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', exportedFilename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }

  useEffect(() => {
    if (TYPOLOGY) {
      getTemplate(TYPOLOGY)
        .then(items => {
          if (Array.isArray(items?.tabs)) {
            setTabsEntity(items?.tabs);
          } else {
            console.log(
              'El resultado de getTemplate no es un array válido: ',
              items.tabs,
            );
          }
          if (Array.isArray(items?.extTabs)) {
            setExtTabsEntity(items?.extTabs);
          } else {
            console.log(
              'El resultado de getTemplate no es un array válido: ',
              items?.extTabs,
            );
          }
        })
        .catch(error => {
          console.log('Error:', error);
        });
    }
  }, []);

  useEffect(() => {
    if (TYPOLOGY) {
      getTemplate(TYPOLOGY)
        .then(items => {
          if (Array.isArray(items?.tabs)) {
            setTabsEntity(items?.tabs);
          } else {
            console.log(
              'El resultado de getTemplate no es un array válido: ',
              items.tabs,
            );
          }
          if (Array.isArray(items?.extTabs)) {
            setExtTabsEntity(items?.extTabs);
          } else {
            console.log(
              'El resultado de getTemplate no es un array válido: ',
              items?.extTabs,
            );
          }
        })
        .catch(error => {
          console.log('Error:', error);
        });
    }
  }, []);

  useEffect(() => {
    const removeElement = () => {
      const items = document.querySelectorAll(
        '#root > div > main > header > div > div[class*="MuiGrid-item"]',
      );
      items.forEach(function (item) {
        item.remove();
      });
    };

    const observer = new MutationObserver(mutationsList => {
      mutationsList.forEach(mutation => {
        if (mutation.addedNodes.length > 0) {
          removeElement();
        }
      });
    });

    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
    };
  }, []);

  // UNCOMMENT these lines when Service Manager is connected and available.
  // function handleClose() {
  //   setOpen(false);
  // }
  // const handleClickOpen = () => {
  //   setOpen(true);
  // };

  // async function handleNewTicketGw() {
  //   const inputComment = (
  //     document.querySelector('#gw-comment') as HTMLInputElement
  //   )?.value;
  //   const inputTitle = (
  //     document.querySelector('#gw-ticket-title') as HTMLInputElement
  //   )?.value;

  //   const url = new URL(
  //     `api/service-manager`,
  //     window.location.origin.replace('3000', '7007'),
  //   );
  //   const headers = new Headers({
  //     'Content-Type': 'application/json',
  //   });

  // const category = 'SERVICIOS DE TECNOLOGIA Y SEGURIDAD > FRONTEND/MIDDLEWARE > APLICACIONES WEB Y J2EE > PETICIONES API – GATEWAY J2EE';

  //   const ticketGwReq = new Request(url.toString(), {
  //     method: 'POST',
  //     headers,
  //     body: JSON.stringify({
  //       file: gwFile,
  //       contact: profile?.email as string,
  //       title: inputTitle,
  //       description: inputComment,
  //       category: category
  //     }),
  //   });
  //   const response = await fetch(ticketGwReq);
  //   if (!response.ok) {
  //     throw new Error(`HTTP error status ${response.status}`);
  //   }
  // }

  // async function handleNewTicketWsrr() {
  //   const inputComment = (
  //     document.querySelector('#wsrr-comment') as HTMLInputElement
  //   )?.value;
  //   const inputTitle = (
  //     document.querySelector('#wsrr-ticket-title') as HTMLInputElement
  //   )?.value;

  //   const url = new URL(
  //     `api/service-manager`,
  //     window.location.origin.replace('3000', '7007'),
  //   );
  //   const headers = new Headers({
  //     'Content-Type': 'application/json',
  //   });

  //   const category = 'SERVICIOS DE TECNOLOGIA Y SEGURIDAD > FRONTEND / MIDDLEWARE > APLICACIONES ARQOS Y NUEVOS COMPONENTES > ARQOS (PUBLICACION DE ACTIVO)';

  //   const ticketWsrrReq = new Request(url.toString(), {
  //     method: 'POST',
  //     headers,
  //     body: JSON.stringify({
  //       file: wsrrLink,
  //       contact: profile?.email as string,
  //       title: inputTitle,
  //       description: inputComment,
  //       category: category
  //     }),
  //   });

  //   const response = await fetch(ticketWsrrReq);
  //   if (!response.ok) {
  //     throw new Error(`HTTP error status ${response.status}`);
  //   }
  // }

  const generalTab = (
    <EntityLayout.Route path="/" title={t('Overview')}>
      <Grid container spacing={3}>
        {entityWarningContent}
        <ResponsibleProvider name={entity.metadata.name}>
          <Grid item md={6}>
            <AboutCustomCard variant="fullHeight" />
          </Grid>
          <MetadataTableCard
            yamlKey="liablePeople"
            title="Liable People"
            t={t}
          />
        </ResponsibleProvider>
        <MetadataTableCard yamlKey="contextData" title="Context Data" t={t} />

        {!isMapfreApiType('GW Services')(entity) && (
          <>
            <MetadataTableCard
              yamlKey="technicalData"
              title="Technical Data"
              t={t}
            />
            <MetadataTableCard
              yamlKey="serviceAvailability"
              title="Service Availability"
              t={t}
            />
            <MetadataTableCard
              yamlKey="executionPermissions"
              title="Execution Permissions"
              t={t}
            />
          </>
        )}

        <MetadataTableCard yamlKey="historyLog" title="History Log" t={t} />
        <MetadataTableCard yamlKey="monitoring" title="Monitoring" t={t} />

        {!isMapfreApiType(['API Consumer', 'API Provider', 'Login API'])(
          entity,
        ) && <FunctionalCategoryCard />}

        <Grid item md={6} xs={12}>
          <EntityGraphCard
            variant="gridItem"
            height={400}
            relationPairs={CUSTOM_PAIRS}
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <VersionGraphCard
            variant="gridItem"
            height={400}
            relationPairs={VERSION_PAIR}
            maxDepth={10}
          />
        </Grid>
      </Grid>
    </EntityLayout.Route>
  );

  let interfaceFile = '';
  let label = '';

  if (
    typeof entity.spec?.['wsdl'] === 'string' &&
    entity.spec.type === 'other'
  ) {
    interfaceFile = entity.spec?.['wsdl'];
    label = t('Download WSDL');
  } else {
    if (typeof entity.spec?.['definition'] === 'string') {
      interfaceFile = entity.spec?.['definition'];
      label = t('Download');
    }
  }

  const iconDownloadInterfaceFile: IconLinkVerticalProps = {
    label: label,
    icon: <DocsIcon />,
    onClick: () => {
      downloadInterfaceFile(interfaceFile, label);
    },
  };

  const interfaceTab = (
    <EntityLayout.Route
      path="/interface"
      title={isExternal || isGov ? t('Specifications') : t('Interface')}
    >
      {entity.spec && entity.spec.definition && entity.spec.type === 'other' ? (
        <span
          dangerouslySetInnerHTML={{
            __html: entity.spec.definition as string,
          }}
        ></span>
      ) : (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            {interfaceFile && (
              <HeaderIconLinkRow links={[iconDownloadInterfaceFile]} />
            )}
            <EntityApiDefinitionCard />
          </Grid>
        </Grid>
      )}
    </EntityLayout.Route>
  );

  const interfaceSoapTab = (
    <EntityLayout.Route path="/interface-soap" title={t('Interface')}>
      <>
        {entity.spec && entity.spec.wsdl ? (
          <>
            <Grid item xs={12}>
              {interfaceFile && (
                <HeaderIconLinkRow links={[iconDownloadInterfaceFile]} />
              )}
            </Grid>
          </>
        ) : (
          <></>
        )}
        {entity.spec?.definition ? (
          <>
            <Typography variant="h2" style={{ marginTop: '30px' }}>
              {t('WSDL Definition') as string}
            </Typography>
            <span
              dangerouslySetInnerHTML={{
                __html: (entity.spec.definition as string)
                  .replaceAll(/html \{[^}]*\}/g, '')
                  .replaceAll(/body \{[^}]*\}/g, '')
                  .replaceAll(/h1, h2, h3 \{[^}]*\}/g, '')
                  .replaceAll(/h1 \{[^}]*\}/g, '')
                  .replaceAll(/h2 \{[^}]*\}/g, '')
                  .replaceAll(/h3 \{[^}]*\}/g, ''),
              }}
            ></span>
          </>
        ) : (
          <></>
        )}
      </>
    </EntityLayout.Route>
  );

  const invokedServicesTab = (
    <EntityLayout.Route path="/invoked-services" title={t('Invoked Services')}>
      <>
        {entity.metadata?.annotations &&
        entity.metadata?.annotations?.isMigratedInvoked === 'true'
          ? entity.metadata?.annotations &&
            entity.metadata?.annotations?.invoked && (
              <span
                dangerouslySetInnerHTML={{
                  __html: entity.metadata?.annotations?.invoked,
                }}
              ></span>
            )
          : entity.metadata?.annotations &&
            entity.metadata?.annotations?.invoked && (
              <Card>
                <CardContent>
                  <MarkdownContent
                    content={entity.metadata?.annotations?.invoked}
                  ></MarkdownContent>
                </CardContent>
              </Card>
            )}
      </>
    </EntityLayout.Route>
  );

  const functionalInformationTab = (
    <EntityLayout.Route
      path="/functional-information"
      title={isExternal || isGov ? t('Changelog') : t('Functional Information')}
    >
      <>
        {entity.metadata?.annotations &&
        entity.metadata?.annotations?.isMigratedFunctional === 'true'
          ? entity.metadata?.annotations &&
            entity.metadata?.annotations?.functional && (
              <span
                dangerouslySetInnerHTML={{
                  __html: entity.metadata?.annotations?.functional,
                }}
              ></span>
            )
          : entity.metadata?.annotations &&
            entity.metadata?.annotations?.functional && (
              <Card>
                <CardContent>
                  <MarkdownContent
                    content={entity.metadata?.annotations?.functional}
                  ></MarkdownContent>
                </CardContent>
              </Card>
            )}
      </>
    </EntityLayout.Route>
  );

  const historyLogTab = (
    <EntityLayout.Route path="/history-log" title={t('History Log')}>
      <ChangelogCard />
    </EntityLayout.Route>
  );

  const contactTab = (
    <EntityLayout.Route path="/contact" title={t('Contact')}>
      <>
        {entity.metadata?.annotations &&
        entity.metadata?.annotations?.isMigratedContact === 'true'
          ? entity.metadata?.annotations &&
            entity.metadata?.annotations?.contact && (
              <span
                dangerouslySetInnerHTML={{
                  __html: entity.metadata?.annotations?.contact,
                }}
              ></span>
            )
          : entity.metadata?.annotations &&
            entity.metadata?.annotations?.contact && (
              <Card>
                <CardContent>
                  <MarkdownContent
                    content={entity.metadata?.annotations?.contact}
                  ></MarkdownContent>
                </CardContent>
              </Card>
            )}
      </>
    </EntityLayout.Route>
  );

  const apisTab = (
    <EntityLayout.Route path="/apis" title={t('APIs')}>
      <>
        {entity.metadata?.annotations &&
        entity.metadata?.annotations?.isMigratedApis === 'true'
          ? entity.metadata?.annotations &&
            entity.metadata?.annotations?.apis && (
              <span
                dangerouslySetInnerHTML={{
                  __html: entity.metadata?.annotations?.apis,
                }}
              ></span>
            )
          : entity.metadata?.annotations &&
            entity.metadata?.annotations?.apis && (
              <Card>
                <CardContent>
                  <MarkdownContent
                    content={entity.metadata?.annotations?.apis}
                  ></MarkdownContent>
                </CardContent>
              </Card>
            )}
      </>
    </EntityLayout.Route>
  );

  const logStatisticsTab = (
    <EntityLayout.Route path="/log-statistics" title={t('Log & Statistics')}>
      <Grid container spacing={3}>
        <StatisticsCards />
      </Grid>
    </EntityLayout.Route>
  );

  const LOGS_COUNTRIES = ['ESP', 'TRON', 'GLOBAL', 'RE', 'SOL', 'INV', 'ASIS'];

  if (typeof entity.metadata.annotations?.['gwDeployment'] === 'string') {
    gwFile = entity.metadata.annotations?.['gwDeployment'];
  }

  const downloadGwFile: IconLinkVerticalProps = {
    label: t('Download'),
    icon: <DocsIcon />,
    onClick: () => {
      downloadGWFile(gwFile);
    },
  };

  const gwDeploymentTab = (
    <EntityLayout.Route path="/gw-deployment" title={t('GW Deployment')}>
      <>
        {/* UNCOMMENT these lines when Service Manager is connected and available. */}
        {/* <Dialog
          onClose={handleClose}
          aria-labelledby="gw-ticket-dialog-title"
          open={open}
        >
          <DialogTitle id="gw-ticket-dialog-title">
            {t(`Create a ticket`)}
          </DialogTitle>
              <DialogContent>
                <DialogContentText>{t('Add a title:')}</DialogContentText>
                <TextField
                  id="gw-ticket-title"
                  style={{ marginTop: 0 }}
                  fullWidth
                  margin="normal"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  variant="outlined"
                  type="text"
                />
                <DialogContentText>{t('Add a comment:')}</DialogContentText>
                <TextField
                  id="gw-comment"
                  style={{ marginTop: 0 }}
                  fullWidth
                  margin="normal"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  variant="outlined"
                  type="text"
                />
                <Typography variant="body2">
                  <AttachmentIcon />
                  {t('GW Deployment JSON added')}
                </Typography>
              </DialogContent>
              <DialogActions>
                <Button autoFocus onClick={handleClose} color="inherit">
                  {t('Discard')}
                </Button>

                <Button
                  color="primary"
                  variant="contained"
                  autoFocus
                  onClick={handleNewTicketGw}
                >
                  {t('Send')}
                </Button>
              </DialogActions>
           
        </Dialog>
        {gwFile && gwFile.length && (
          <Button variant="contained" color="primary" onClick={handleClickOpen}>
            {t('Create a ticket')}
          </Button>
        )} */}
        {entity.metadata.annotations &&
          entity.metadata?.annotations?.gwDeployment && (
            <>
              <CardHeader
                subheader={<HeaderIconLinkRow links={[downloadGwFile]} />}
              />
            </>
          )}
      </>
    </EntityLayout.Route>
  );

  const wsrrTab = (
    <EntityLayout.Route path="/wsrr" title={t('WSRR')}>
      <>
        {/* UNCOMMENT these lines when Service Manager is connected and available. */}
        {/* <Dialog
          onClose={handleClose}
          aria-labelledby="wsrr-ticket-dialog-title"
          open={open}
        >
          <DialogTitle id="wsrr-ticket-dialog-title">
            {t(`Create a ticket`)}
          </DialogTitle>

          <DialogContent>
            <DialogContentText>{t('Add a title:')}</DialogContentText>

            <TextField
              id="wsrr-ticket-title"
              style={{ marginTop: 0 }}
              fullWidth
              margin="normal"
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
            />
            <DialogContentText>{t('Add a comment:')}</DialogContentText>

            <TextField
              id="wsrr-comment"
              style={{ marginTop: 0 }}
              fullWidth
              margin="normal"
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
            />
            <Typography variant="body2">
              <LinkIcon />

              {t('WSRR tab link added')}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button autoFocus onClick={handleClose} color="inherit">
              {t('Discard')}
            </Button>

            <Button
              color="primary"
              variant="contained"
              autoFocus
              onClick={handleNewTicketWsrr}
            >
              {t('Send')}
            </Button>
          </DialogActions>
        </Dialog>

        <Button
          variant="contained"
          color="primary"
          onClick={handleClickOpen}
          style={{ marginBottom: 20 }}
        >
          {t('Create a ticket')}
        </Button> */}

        <Grid container spacing={3}>
          <Grid item xs={6}>
            <WsrrUploadCard />
          </Grid>
          <Grid item xs={6}>
            {!canPublish.loading &&
              !canPublishEdic.loading &&
              (canPublish.allowed || canPublishEdic.allowed) && (
                <WsrrPublishCard />
              )}
          </Grid>
          <Grid item xs={6}>
            {entity.metadata.country !== 'ESP' &&
              !canPublish.loading &&
              !canPublishEdic.loading &&
              (canPublish.allowed || canPublishEdic.allowed) && (
                <WsrrRequestPublishCard />
              )}
          </Grid>
        </Grid>
      </>
    </EntityLayout.Route>
  );

  const instanceTab = (
    <EntityLayout.Route path="/instance" title={t('tech_data')}>
      <>
        <Grid container spacing={3}>
          <MetadataTableCard yamlKey="instances" title="Instance" t={t} />
        </Grid>
      </>
    </EntityLayout.Route>
  );

  const gatewayTab = (
    <EntityLayout.Route path="/gateway" title={t('gateway_exposition')}>
      <>
        <Grid container spacing={3}>
          <MetadataTableCard
            yamlKey="instances"
            title="Instance"
            t={t}
            gateway={true}
            deleteKeys={
              entity.spec?.lifecycle !== 'Approved'
                ? ['mapfre.com/gwDeployment']
                : undefined
            }
          />
        </Grid>
      </>
    </EntityLayout.Route>
  );

  const overviewTab = (
    <EntityLayout.Route path="/" title={t('Overview')}>
      <Grid container spacing={3}>
        <Container maxWidth="md">
          <ExternalAboutCustomCard />
        </Container>
      </Grid>
    </EntityLayout.Route>
  );

  const documentationTab = (
    <EntityLayout.Route path="/documentation" title={t('Documentation')}>
      <Grid container spacing={3}>
        <Container maxWidth="md" style={{ margin: 0, maxWidth: 'none' }}>
          <Card style={{ padding: '20px' }}>
            <DocumentationTab title="Public Docs" path="public" />
            <Divider style={{ backgroundColor: grey[600] }} />
            <DocumentationTab title="Test Cases" path="postman" />
            <Divider style={{ backgroundColor: grey[600] }} />
            <DocumentationTab
              title="Additional Documentation"
              path="additional"
            />
          </Card>
        </Container>
      </Grid>
    </EntityLayout.Route>
  );

  const externalDocumentationTab = (
    <EntityLayout.Route path="/documentation" title={t('Documentation')}>
      <Grid container spacing={3}>
        <Container maxWidth="md">
          <ExternalDocumentationTab />
        </Container>
      </Grid>
    </EntityLayout.Route>
  );

  const system = entity.spec?.system as string[];
  const isSameSystem =
    apiSystem.some(element => system?.includes(element)) && isExternal;

  //const { showWsrrTab } = isGroupWsrr();

  return (
    <>
      {loading ? (
        <Progress />
      ) : isSameSystem || isGov ? (
        <EntityLayout UNSTABLE_extraContextMenuItems={MENU_ITEMS}>
          {extTabsEntity?.includes('overviewTab') && overviewTab}
          {extTabsEntity?.includes('specificationsTab') && interfaceTab}
          {extTabsEntity?.includes('documentationTab') &&
            externalDocumentationTab}
          {extTabsEntity?.includes('changeLogTab') && functionalInformationTab}
          {extTabsEntity?.includes('instanceTab') && instanceTab}
          {extTabsEntity?.includes('gatewayTab') && gatewayTab}
          {extTabsEntity?.includes('interfaceTab') && interfaceTab}
          {extTabsEntity?.includes('interfaceSoapTab') && interfaceSoapTab}
          {extTabsEntity?.includes('invokedServicesTab') && invokedServicesTab}
          {extTabsEntity?.includes('functionalInformationTab') &&
            functionalInformationTab}
          {extTabsEntity?.includes('historyLogTab') && historyLogTab}
          {extTabsEntity?.includes('contactTab') && contactTab}
          {extTabsEntity?.includes('apisTab') && apisTab}
          {extTabsEntity?.includes('logStatisticsTab') &&
            LOGS_COUNTRIES?.includes(COUNTRY) &&
            logStatisticsTab}
          {extTabsEntity?.includes('gwDeploymentTab') && gwDeploymentTab}
          {extTabsEntity?.includes('wsrrTab') &&
            WSRR_COUNTRIES?.includes(COUNTRY) &&
            !canPublish.loading &&
            !canPublishEdic.loading &&
            (canPublish.allowed || canPublishEdic.allowed) &&
            wsrrTab}
        </EntityLayout>
      ) : isExternal ? (
        <div className={classes.containerStyle}>
          <EmptyState
            missing="data"
            title={t('Not authorised')}
            description={t('api_not_authorized') as string}
          />
        </div>
      ) : (
        <EntityLayout UNSTABLE_extraContextMenuItems={MENU_ITEMS}>
          {tabsEntity?.includes('generalTab') && generalTab}
          {tabsEntity?.includes('instanceTab') && instanceTab}
          {tabsEntity?.includes('gatewayTab') && gatewayTab}
          {tabsEntity?.includes('interfaceTab') && interfaceTab}
          {tabsEntity?.includes('interfaceSoapTab') && interfaceSoapTab}
          {tabsEntity?.includes('invokedServicesTab') && invokedServicesTab}
          {tabsEntity?.includes('functionalInformationTab') &&
            functionalInformationTab}
          {tabsEntity?.includes('historyLogTab') && historyLogTab}
          {tabsEntity?.includes('contactTab') && contactTab}
          {tabsEntity?.includes('apisTab') && apisTab}
          {tabsEntity?.includes('logStatisticsTab') &&
            LOGS_COUNTRIES?.includes(COUNTRY) &&
            logStatisticsTab}
          {tabsEntity?.includes('gwDeploymentTab') && gwDeploymentTab}
          {tabsEntity?.includes('wsrrTab') &&
            WSRR_COUNTRIES?.includes(COUNTRY) &&
            !canPublish.loading &&
            !canPublishEdic.loading &&
            (canPublish.allowed || canPublishEdic.allowed) &&
            wsrrTab}
          {extTabsEntity?.includes('documentationTab') && documentationTab}
        </EntityLayout>
      )}
    </>
  );
}

function userPage(t: TFunction<'translation', undefined>) {
  return (
    <EntityLayout>
      <EntityLayout.Route path="/" title={t('Overview')}>
        <Grid container spacing={3}>
          {entityWarningContent}
          <Grid item xs={12} md={6}>
            <EntityUserProfileCard variant="gridItem" />
          </Grid>
          <Grid item xs={12} md={6}>
            <OwnershipCard variant="gridItem" />
          </Grid>
          <Grid item xs={12} md={6}>
            <UserDataCard />
          </Grid>
        </Grid>
      </EntityLayout.Route>
    </EntityLayout>
  );
}

function setProd() {
  const { entity } = useEntity();

  if (
    entity.metadata.name.includes('_beta') &&
    !entity.metadata.title?.toLowerCase().includes('beta') &&
    !window.location.pathname.includes('/docs_beta')
  ) {
    entity.metadata.name = entity.metadata.name
      .toLowerCase()
      .replace('_beta', '');
  }

  return <></>;
}

function setBeta() {
  const { entity } = useEntity();

  if (
    !entity.metadata.name.includes('_beta') &&
    window.location.pathname.includes('/docs_beta')
  ) {
    entity.metadata.name = entity.metadata.name.toLowerCase() + '_beta';
  }

  return <></>;
}

function setOriginal() {
  const { entity } = useEntity();

  if (
    entity.metadata.name.includes('gazr') &&
    !window.location.pathname.includes('/members')
  ) {
    entity.metadata.name =
      entity.metadata.name.toLowerCase().split('-')[4] +
      '-' +
      entity.metadata.name.toLowerCase().split('-')[5];
  }

  return <></>;
}

function groupPage(t: TFunction<'translation', undefined>) {
  return (
    <EntityLayout>
      <EntityLayout.Route path="/" title={t('Overview')}>
        <Grid container spacing={3}>
          {entityWarningContent}
          <Grid item xs={12} md={6}>
            <EntityGroupProfileCard variant="gridItem" />
          </Grid>
          <Grid item xs={12} md={6}>
            <OwnershipCard variant="gridItem" />
          </Grid>
          <Grid item xs={12}>
            <EntityMembersListCard />
          </Grid>
        </Grid>
      </EntityLayout.Route>
    </EntityLayout>
  );
}

function SystemPage({ t }: { t: TFunction<'translation', undefined> }) {
  const { entity } = useEntity();

  return (
    <EntityLayout>
      <EntityLayout.Route path="/" title={t('Overview')}>
        <>
          {setOriginal()}
          <Grid container spacing={3} alignItems="stretch">
            {entityWarningContent}
            <Grid item md={6}>
              <AboutCustomCard variant="fullHeight" />
            </Grid>
            <MetadataTableCard
              yamlKey="liablePeople"
              title="Liable People"
              t={t}
            />
            <Grid item md={6} xs={12}>
              <EntityCatalogGraphCard variant="gridItem" height={400} />
            </Grid>
          </Grid>
        </>
      </EntityLayout.Route>
      <EntityLayout.Route path="/members" title={t('Members')}>
        <Grid>
          <MembersCard />
        </Grid>
      </EntityLayout.Route>
      <EntityLayout.Route path="/apis" title={t('APIs')}>
        <>
          {entity.metadata?.annotations &&
            entity.metadata?.annotations?.apis && (
              <Card>
                <CardContent>
                  <MarkdownContent
                    content={entity.metadata?.annotations?.apis}
                  ></MarkdownContent>
                </CardContent>
              </Card>
            )}
        </>
      </EntityLayout.Route>
      <EntityLayout.Route path="/configuration" title={t('Configuration')}>
        <>
          {setOriginal()}
          <Grid container spacing={3}>
            <></>
          </Grid>
        </>
      </EntityLayout.Route>
    </EntityLayout>
  );
}

function domainPage(t: TFunction<'translation', undefined>) {
  return (
    <EntityLayout>
      <EntityLayout.Route path="/" title={t('Overview')}>
        <Grid container spacing={3} alignItems="stretch">
          {entityWarningContent}
          <Grid item md={6}>
            <EntityAboutCard variant="gridItem" />
          </Grid>
          <Grid item md={6} xs={12}>
            <EntityCatalogGraphCard variant="gridItem" height={400} />
          </Grid>
          <Grid item md={6}>
            <EntityHasSystemsCard variant="gridItem" />
            <EntityHasApisCard variant="gridItem" />
          </Grid>
        </Grid>
      </EntityLayout.Route>
    </EntityLayout>
  );
}

export function entityPage(t: TFunction<'translation', undefined>) {
  return (
    <EntitySwitch>
      <EntitySwitch.Case if={isKind('component')}>
        <ComponentPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfreapi')}>
        <ApiPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfreapilegacyesp')}>
        <ApiPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfreapilegacyper')}>
        <ApiPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfreapilegacybra')}>
        <ApiPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfreapilegacyglobal')}>
        <ApiPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('group')}>{groupPage(t)}</EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('user')}>{userPage(t)}</EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('system')}>
        <SystemPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('domain')}>
        {domainPage(t)}
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfredocument')}>
        <DocumentationPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('mapfresolution')}>
        <SolutionPage t={t} />
      </EntitySwitch.Case>
      <EntitySwitch.Case if={isKind('refarch')}>
        <EntitySwitch>
          <EntitySwitch.Case if={isRefArchType('general')}>
            <RefArchitecture />
          </EntitySwitch.Case>

          <EntitySwitch.Case>
            <RefArchEntityPage />
          </EntitySwitch.Case>
        </EntitySwitch>
      </EntitySwitch.Case>
      <EntitySwitch.Case>{defaultEntityPage(t)}</EntitySwitch.Case>
    </EntitySwitch>
  );
}
