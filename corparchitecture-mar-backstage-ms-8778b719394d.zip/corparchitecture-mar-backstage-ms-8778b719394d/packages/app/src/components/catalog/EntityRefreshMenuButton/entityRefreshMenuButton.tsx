import {
  ANNOTATION_LOCATION,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import { useApi, alertApiRef, errorApiRef } from '@backstage/core-plugin-api';
import { useEntity, catalogApiRef } from '@backstage/plugin-catalog-react';
import { useCallback } from 'react';
import CachedIcon from '@material-ui/icons/Cached';
import Block from '@material-ui/icons/Block';
import { useTranslation } from 'react-i18next';

export const entityRefreshMenuButton = () => {
  const { entity } = useEntity();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const errorApi = useApi(errorApiRef);
  const { t } = useTranslation();

  const entityLocation = entity.metadata.annotations?.[ANNOTATION_LOCATION];
  const allowRefresh =
    entityLocation?.startsWith('url:') || entityLocation?.startsWith('file:');
  const refreshEntity = useCallback(async () => {
    try {
      await catalogApi.refreshEntity(stringifyEntityRef(entity));
      alertApi.post({ message: t('Refresh scheduled'), severity: 'success' });
    } catch (e) {
      if (e instanceof Error) errorApi.post(e);
    }
  }, [catalogApi, alertApi, errorApi, entity]);

  const blockRefresh = () => {
    return errorApi.post({
      message: t('Refresh unavalaible'),
      name: 'Unavailable',
    });
  };

  const refreshItem = {
    title: t('Schedule entity refresh'),
    Icon: CachedIcon,
    onClick: refreshEntity,
  };

  const refreshUnavalaibleItem = {
    title: t('Refresh unavalaible'),
    Icon: Block,
    onClick: blockRefresh,
  };
  if (allowRefresh) return refreshItem;
  else return refreshUnavalaibleItem;
};
