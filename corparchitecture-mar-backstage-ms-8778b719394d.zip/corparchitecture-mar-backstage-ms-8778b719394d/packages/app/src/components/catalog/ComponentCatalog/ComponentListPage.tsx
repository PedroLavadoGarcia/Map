import { parseEntityRef } from '@backstage/catalog-model';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { CatalogTable } from '@backstage/plugin-catalog';
import { CircularProgress, makeStyles } from '@material-ui/core';
import { t, TFunction } from 'i18next';
import React from 'react';
import { useState } from 'react';
import useAsync from 'react-use/lib/useAsync';
import { ComponentListLayout } from './ComponentListLayout';
import { ComponentListCardLayout } from './ComponentListCardLayout';
import { componentColumnFactories } from '../../columns/componentColumns';
import { EntityListProvider } from '@backstage/plugin-catalog-react';

function componentColumns(t: TFunction<'translation', undefined>) {
  return [
    CatalogTable.columns.createNameColumn({ defaultKind: 'Component' }),
    componentColumnFactories.createTitleColumn(),
    componentColumnFactories.createStateColumn(t),
    componentColumnFactories.createSubTypeColumn(t, { hidden: true }),
    componentColumnFactories.createSubSubTypeColumn(t),
    componentColumnFactories.createCountryColumn(t, { hidden: true }),
    componentColumnFactories.createOwnerColumn(t, { hidden: true }),
    componentColumnFactories.createShortDescColumn(t),
    componentColumnFactories.createModDateColumn(t, { hidden: true }),
    componentColumnFactories.createTagsColumn({ hidden: false }),
  ];
}
export const ComponentListPage = () => {
  const useStyles = makeStyles({
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
  });
  const classes = useStyles();
  const identityApi = useApi(identityApiRef);
  const [isExternal, setIsExternal] = useState(false);
  const [extOwnershipEntityRefs, setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();
  const { loading } = useAsync(async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();

    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setExtOwnershipEntityRefs(extEntityRefs);
    setIsExternal(Boolean(extEntityRefs.length));
  });

  return (
    <>
      {loading ? (
        <div className={classes.spinner}>
          <CircularProgress />
        </div>
      ) : isExternal ? (
        <EntityListProvider>
          <ComponentListCardLayout
            extOwnershipEntityRefs={extOwnershipEntityRefs}
          />
        </EntityListProvider>
      ) : (
        <ComponentListLayout columns={componentColumns(t)} />
      )}
    </>
  );
};
