import {
  Content,
  ContentHeader,
  CreateButton,
  Page,
  TableColumn,
  TableFilter,
  TableProps,
} from '@backstage/core-components';
import {
  CatalogFilterLayout,
  UserListFilterKind,
} from '@backstage/plugin-catalog-react';
import React, { useEffect } from 'react';
import { CatalogTableRow } from '@backstage/plugin-catalog';
import { CatalogTable } from './CatalogTable';
import { Entity } from '@backstage/catalog-model';
import { SearchContextProvider } from '@backstage/plugin-search-react';

import { useOutlet } from 'react-router';
import { useTranslation } from 'react-i18next';
import { Button, makeStyles } from '@material-ui/core';
import { EntityTypologyPicker } from '../../pickers/pickers_components/EntityTypologyPicker';
import { EntityCountryPicker } from '../../pickers/pickers_components/EntityCountryPicker';
import { exportCSVFile } from '../CreateCSV/exportCSVFile';
import { EntityOwnerPicker } from '../../pickers/pickers_components/EntityOwnerPicker';
import { EntityTypePicker } from '../../pickers/pickers_components/EntityTypePicker';
import { EntityLifecyclePicker } from '../../pickers/pickers_components/EntityLifecyclePicker';
import { EntityTagPicker } from '../../pickers/pickers_components/EntityTagPicker';
import { EntityListProvider } from './CatalogTable/hooks/useEntityListProvider';
import { UserListPicker } from '../../pickers/pickers_components/UserListPicker';
import { EntityKindPicker } from '../../pickers/pickers_components/EntityKindPicker';
import { EntitySubTypologyPicker } from '../../pickers/pickers_components/EntitySubTypologyPicker';

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  columns?: TableColumn<CatalogTableRow>[];
  actions?: TableProps<CatalogTableRow>['actions'];
  initialKind?: string;
  tableOptions?: TableProps<CatalogTableRow>['options'];
  filters?: TableFilter;
}

export async function getFilteredComponents(): Promise<
  Record<string, string>[]
> {
  const searchParams = new URLSearchParams(window.location.search);
  const searchString = Array.from(searchParams)
    .map(i =>
      i.map(x =>
        x
          .replace(/filters|\[|\]/g, '')
          .replace(/^owners$/, 'spec.owner')
          .replace(/^country$/, 'metadata.country')
          .replace(/^typology$/, 'metadata.typology')
          .replace(/^lifecycles$/, 'spec.lifecycle'),
      ),
    )
    .filter(i => i[0] !== 'user' && i[0] !== 'search')
    .map(item => item.join('='))
    .join(',');
  const apiEndpointQuery = new URLSearchParams({ filter: searchString });
  const apiEndpointUrl = new URL(
    '/api/catalog/entities',
    window.location.origin.replace('3000', '7007'),
  );
  apiEndpointUrl.search = apiEndpointQuery.toString();
  const apiRequest = new Request(apiEndpointUrl.toString());

  let entities = await (await fetch(apiRequest)).json();
  if (searchParams.get('search')) {
    const regex = new RegExp(searchParams.get('search') as string, 'i');
    entities = entities.filter(
      (entity: Entity) =>
        entity.metadata.title?.match(regex) ||
        (typeof entity.metadata['mapfre.com/state'] === 'string' &&
          entity.metadata['mapfre.com/state']?.match(regex)) ||
        (typeof entity.metadata.typology === 'string' &&
          entity.metadata.typology?.match(regex)) ||
        (typeof entity.metadata.country === 'string' &&
          entity.metadata.country?.match(regex)) ||
        (typeof entity.metadata.description === 'string' &&
          entity.metadata.description?.match(regex)) ||
        (typeof entity.spec?.lifecycle === 'string' &&
          entity.spec?.lifecycle.match(regex)) ||
        (typeof entity.metadata.modDate === 'string' &&
          entity.metadata.modDate?.match(regex)),
    );
  }

  function joinArray(value: string | null | string[]) {
    if (Array.isArray(value)) {
      return value.join('|');
    }
    return value;
  }

  function replaceCommas(value: string | null) {
    return value?.replaceAll(',', ' ');
  }

  const entitiesMetas = entities.map?.((entity: Record<string, unknown>) => {
    const metadata = entity.metadata as Record<string, unknown>;
    const spec = entity.spec as Record<string, unknown>;
    return {
      Name: metadata.name,
      Title: metadata.title,
      Version: metadata.version,
      State: spec.lifecycle,
      Typology: metadata.typology,
      Country: metadata.country,
      Description: replaceCommas(metadata.description as string),
      repository: (metadata.annotations as Record<string, string>)[
        'backstage.io/view-url'
      ],
      Owners: joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/owners'
        ],
      ),
      'Functional Manager': joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/resp_func'
        ],
      ),
      'Technical Manager': joinArray(
        (metadata?.liablePeople as Record<string, string[] | string>)?.[
          'mapfre.com/resp_tech'
        ],
      ),
      'Approval Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/approvalDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/approvalDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/approvalDate'
              ],
            ),
          ).toISOString(),
      'Deprecation Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/deprecationDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/deprecationDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/deprecationDate'
              ],
            ),
          ).toISOString(),
      'Modification Date': isNaN(
        (metadata?.historyLog as Record<string, number>)?.[
          'mapfre.com/modDate'
        ],
      )
        ? 'NaN'
        : (metadata?.historyLog as Record<string, number>)?.[
            'mapfre.com/modDate'
          ] &&
          new Date(
            Number(
              (metadata?.historyLog as Record<string, number>)?.[
                'mapfre.com/modDate'
              ],
            ),
          ).toISOString(),
      'User Modification': joinArray(
        (metadata?.historyLog as Record<string, string | null>)?.[
          'mapfre.com/user_mod'
        ],
      ),
    };
  });
  return entitiesMetas;
}

export const ComponentListLayout = ({
  columns,
  actions,
  initiallySelectedFilter,
  tableOptions = {
    tableLayout: 'auto',
    padding: 'dense',
    columnResizable: true,
    columnsButton: true,
    toolbarButtonAlignment: 'right',
    emptyRowsWhenPaging: false,
    paging: true,
    pageSizeOptions: [20, 50, 100],
    paginationType: 'normal',
    showSelectAllCheckbox: true,
  },
}: CatalogPageProps) => {
  const useStyles = makeStyles(() => ({
    buttons: {
      textAlign: 'right',
      margin: '0px -20px 0 0px',
    },
    helpIcon: {
      marginRight: '8px',
      fontSize: '20px',
    },
    helpButton: {
      marginLeft: '8px',
    },
  }));
  const classes = useStyles();

  const searchTemplateAPILink =
    '../create?filters%5Bkind%5D=template&filters%5Buser%5D=all&filters%5Btags%5D=api';
  const outlet = useOutlet();
  const { t } = useTranslation();

  useEffect(() => {
    const name = document.querySelector(
      'table > thead > tr > th:nth-child(1) > span',
    )?.parentElement;

    if (name) {
      name.style.width = '40%';
    }

    const columnNames = document.querySelectorAll('[class*=MuiTableSortLabel]');
    let cellText: string | null | undefined = '';
    columnNames.forEach(function (item) {
      if (item) {
        cellText = item.firstChild?.textContent;
        if (item.firstChild) item.firstChild.textContent = t(`${cellText}`);
      }

      const supportName = document.querySelector(
        '[aria-label=support]',
      )?.lastChild;
      let supportText: string | null | undefined = '';
      if (supportName) {
        supportText = supportName?.textContent;
        supportName.textContent = t(`${supportText}`);
      }
    });
    const searchInput: HTMLInputElement | null = document.querySelector(
      'input[aria-label=Search]',
    );
    const searchInitialState = new URLSearchParams(window.location.search).get(
      'search',
    );

    if (searchInput && searchInitialState) {
      const valueSetter = Object.getOwnPropertyDescriptor(
        searchInput,
        'value',
      )?.set;
      const prototype = Object.getPrototypeOf(searchInput);
      const prototypeValueSetter = Object.getOwnPropertyDescriptor(
        prototype,
        'value',
      )?.set;
      if (valueSetter && valueSetter !== prototypeValueSetter) {
        prototypeValueSetter?.call(searchInput, searchInitialState);
      } else {
        valueSetter?.call(searchInput, searchInitialState);
      }
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }, [document.body]);

  return (
    outlet || (
      <Page themeId="home">
        <EntityListProvider>
          <Content>
            <ContentHeader title={'Catalog'}>
              <CreateButton
                title={t('Catalog Component')}
                to={searchTemplateAPILink}
              />
            </ContentHeader>
            <CatalogFilterLayout>
              <CatalogFilterLayout.Filters>
                <SearchContextProvider>
                  <UserListPicker initialFilter={initiallySelectedFilter} />
                  <EntityTypologyPicker />
                  <EntitySubTypologyPicker />
                  <EntityCountryPicker />
                  <EntityOwnerPicker />
                  <EntityLifecyclePicker />
                  <EntityTypePicker />
                  <EntityTagPicker />
                  <EntityKindPicker initialFilter="component" />
                </SearchContextProvider>
              </CatalogFilterLayout.Filters>
              <CatalogFilterLayout.Content>
                <CatalogTable
                  columns={columns}
                  actions={actions}
                  tableOptions={tableOptions}
                />
                <Content className={classes.buttons}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={async () =>
                      exportCSVFile(await getFilteredComponents(), 'components')
                    }
                  >
                    {t('Create CSV')}
                  </Button>
                </Content>
              </CatalogFilterLayout.Content>
            </CatalogFilterLayout>
          </Content>
        </EntityListProvider>
      </Page>
    )
  );
};
