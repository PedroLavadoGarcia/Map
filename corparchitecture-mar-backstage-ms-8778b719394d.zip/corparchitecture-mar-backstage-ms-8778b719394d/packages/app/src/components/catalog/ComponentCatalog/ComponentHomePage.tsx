import {
  Content,
  Page,
  Header,
  ContentHeader,
} from '@backstage/core-components';
import {
  Button,
  Container,
  Grid,
  Typography,
  TextField,
  Divider,
  makeStyles,
  Link,
  CardActionArea,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EntityListProvider } from './CatalogTable/hooks/useEntityListProvider';
import { useApi } from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import {
  InputAdornment,
  IconButton,
  Card,
  CardContent,
  CardActions,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import WidgetsIcon from '@mui/icons-material/Widgets';
import WidgetsIconOutlined from '@mui/icons-material/WidgetsOutlined';
import ViewInArIcon from '@mui/icons-material/ViewInArOutlined';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import { useTheme, useMediaQuery } from '@mui/material';

// import { usePermission } from '@backstage/plugin-permission-react';
import { marketplaceAdminView } from '../../../permissions';
import { RequirePermission } from '@backstage/plugin-permission-react';
import { Add } from '@material-ui/icons';
import FavoriteIcon from '../FavoriteIcon';

export const ComponentHomePage = () => {
  const useStyles = makeStyles({
    containerSearchStyle: {
      display: 'flex',
      marginLeft: '0px',
      marginRight: '0px',
      padding: '24px',
      maxWidth: 'none',
    },
  });
  const classes = useStyles();
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (event: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearchQuery(event.target.value);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
  };

  return (
    <Page themeId="componentHome">
      <EntityListProvider>
        <Container
          style={{
            maxWidth: 'none',
            paddingLeft: '115px',
            paddingRight: '115px',
          }}
        >
          <Header
            style={{ paddingTop: '24px', paddingBottom: '0px' }}
            title={t('Our Catalogs')}
          >
            <Button
              color="primary"
              variant="contained"
              style={{
                margin: '0 1rem',
              }}
              onClick={() => {
                window.location.href =
                  '/create?filters[kind]=template&filters[user]=all';
              }}
              endIcon={<Add />}
            >
              Create Components
            </Button>
          </Header>
          <div
            style={{
              padding: '24px',
              paddingTop: '24px',
              paddingBottom: '0px',
              display: 'flex',
              justifyContent: 'end',
              gap: '1rem',
            }}
            title=""
          >
            <Button
              color="primary"
              variant="outlined"
              onClick={() => {
                window.location.href = '/components_v2';
              }}
              endIcon={<WidgetsIcon />}
            >
              View All Components
            </Button>
            <RequirePermission
              permission={marketplaceAdminView}
              errorPage={<></>}
            >
              <Button
                color="primary"
                variant="outlined"
                onClick={() => {
                  window.location.href = '/components_old';
                }}
                endIcon={<WidgetsIconOutlined />}
              >
                View All Components (Admin page)
              </Button>
            </RequirePermission>
          </div>
          <Container className={classes.containerSearchStyle}>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                placeholder={'Search'}
                value={searchQuery}
                onChange={handleSearchChange}
                margin="dense"
                style={{
                  width: '100%',
                  justifyContent: 'center',
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      {searchQuery && (
                        <IconButton
                          edge="end"
                          onClick={handleClearSearch}
                          size="large"
                        >
                          <ClearIcon />
                        </IconButton>
                      )}
                      <IconButton edge="end" size="large">
                        <SearchIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                  // @ts-ignore
                  sx: {
                    borderRadius: '20px', // Adjust the value as per your preference
                  },
                }}
              />
            </Grid>
            {/* <Divider style={{ marginTop: '1rem' }} /> */}
          </Container>
          <CatalogGrid searchQuery={searchQuery} />
        </Container>
      </EntityListProvider>
    </Page>
  );
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const CatalogGrid = ({ searchQuery }: any) => {
  const useStyles = makeStyles({
    cardGridStyle: {
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0.8px 0.8px 0.8px 0.8px #EAE9E9',
      position: 'relative',
      height: '400px',
      width: '330px',
      gap: '0px',
      borderColor: '#EAE9E9',
      borderRadius: '8px',
    },
    cardActionAreaStyle: {
      justifyContent: 'flex-start',
      width: '100%',
    },
    contentCardStyle: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      gridGap: '18px',
      paddingLeft: '0px',
    },
  });
  const imageContainerStyle = {
    width: '330px',
    height: '220px',
    display: 'flex',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F6F7',
  };
  const classes = useStyles();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [filteredFacets, setFilteredFacets] = useState([] as any[]);
  const catalogApi = useApi(catalogApiRef);
  const { t } = useTranslation();

  useEffect(() => {
    const fetchData = async () => {
      const newFacets = [];

      const availableTypologies = await catalogApi.getEntityFacets({
        facets: ['metadata.typology'],
        filter: {
          kind: 'component',
        },
      });

      const availableDocs = await catalogApi.getEntityFacets({
        facets: ['kind'],
        filter: {
          kind: 'mapfredocument',
        },
      });

      const availableSolutions = await catalogApi.getEntityFacets({
        facets: ['kind'],
        filter: {
          kind: 'mapfresolution',
        },
      });

      const fetchedFacetsTypology =
        availableTypologies.facets['metadata.typology'];

      for (let i = 0; i < fetchedFacetsTypology.length; i++) {
        newFacets.push({ type: 'typology', facet: fetchedFacetsTypology[i] });
      }

      //Se añade documentacion directamente
      newFacets.push({
        type: 'component',
        facet: { value: 'documentation', number: 1 },
      });

      const fetchedFacetsMapfredocument = availableDocs.facets['kind'];

      for (let i = 0; i < fetchedFacetsMapfredocument.length; i++) {
        newFacets.push({
          type: 'mapfredocument',
          facet: fetchedFacetsMapfredocument[i],
        });
      }

      const fetchedFacetsMapfresolution = availableSolutions.facets['kind'];

      for (let i = 0; i < fetchedFacetsMapfresolution.length; i++) {
        newFacets.push({
          type: 'mapfresolution',
          facet: fetchedFacetsMapfresolution[i],
        });
      }

      // Filter the facets based on the search query
      const filteredFacets = newFacets.filter(facets =>
        facets.facet.value.toLowerCase().includes(searchQuery.toLowerCase()),
      );
      console.log(newFacets);
      console.log(filteredFacets);

      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      setFilteredFacets(filteredFacets);
    };

    fetchData();
  }, [catalogApi, searchQuery]);

  const handleClick = (type: string, value: string) => {
    let url = '';
    if (type.includes('component')) {
      //window.location.href
      url = `/documentation?filters[user]=all&filters[kind]=component`;
    }

    if (type.includes('mapfredocument')) {
      url = `/mapfredocument?filters%5Bkind%5D=mapfredocument&filters%5Buser%5D=all&filters%5BtypeDoc%5D=Simple`;
    }

    if (type.includes('mapfresolution')) {
      url = `/mapfresolution?filters%5Bkind%5D=mapfresolution&filters%5Buser%5D=all`;
    }

    if (type.includes('typology')) {
      url = `/components_v2?filters[user]=all&filters[typology]=${value}&filters[kind]=component`;
    }

    return url;
  };

  return (
    <div>
      <Content className={classes.contentCardStyle}>
        {filteredFacets.map((facet, index) => (
          <Grid
            item
            xs={8}
            key={index}
            style={{
              maxWidth: 'none',
              flexBasis: 'calc(10% - 10px)',
            }}
          >
            <Card className={classes.cardGridStyle} variant="outlined">
              <Link
                style={{ display: 'contents' }}
                href={handleClick(facet.type, facet.facet.value)}
              >
                <CardActionArea className={classes.cardActionAreaStyle}>
                  <div style={{ ...imageContainerStyle }}>
                    <img
                      style={{
                        maxWidth: '100%',
                        maxHeight: '100%',
                        objectFit: 'contain',
                        objectPosition: 'center',
                        width: '330px',
                      }}
                      loading="lazy"
                      alt=""
                      src={'/documentationLogo.png'}
                    />
                  </div>
                  <div>
                    <Typography
                      style={{
                        color: '#2D373D',
                        fontWeight: 'bold',
                        fontSize: '20px',
                        width: '330px',
                        lineHeight: '28px',
                        textAlign: 'left',
                        padding: '16px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: '-webkit-box',
                        WebkitLineClamp: '2',
                        WebkitBoxOrient: 'vertical',
                      }}
                    >
                      {(facet.facet.value as string).includes('documentation')
                        ? (facet.facet.value as string).replace(
                            'documentation',
                            'Legacy document',
                          )
                        : (facet.facet.value as string).includes(
                            'MapfreDocument',
                          )
                        ? (facet.facet.value as string).replace(
                            'MapfreDocument',
                            'Document',
                          )
                        : (facet.facet.value as string).includes(
                            'MapfreSolution',
                          )
                        ? (facet.facet.value as string).replace(
                            'MapfreSolution',
                            'Solution',
                          )
                        : facet.facet.value}{' '}
                      catalog
                      <CatalogIcon />
                    </Typography>
                  </div>
                </CardActionArea>
              </Link>
              <div
                style={{
                  marginTop: 'auto',
                  paddingBottom: '8px',
                  display: 'flex',
                }}
              >
                <Link
                  style={{ display: 'flex' }}
                  href={handleClick(facet.type, facet.facet.value)}
                >
                  <CardActionArea
                    className={classes.cardActionAreaStyle}
                    style={{ display: 'flex' }}
                  >
                    <Typography
                      style={{
                        color: '#D81E05',
                        fontSize: '16px',
                        lineHeight: '24px',
                        textAlign: 'left',
                        paddingLeft: '16px',
                      }}
                    >
                      {t('View')}
                    </Typography>
                    <KeyboardArrowRightOutlinedIcon
                      style={{ color: '#D81E05' }}
                    />
                  </CardActionArea>
                </Link>
                <FavoriteIcon />
              </div>
            </Card>
          </Grid>
        ))}
        <Grid item xs={12}>
          <Typography variant="h5" align="center" style={{ marginTop: '20px' }}>
            Total catalogs: {filteredFacets.length}
          </Typography>
        </Grid>
      </Content>
    </div>
  );
};

export const CatalogIcon = () => {
  const getRandomColor = () => {
    // Generate a random color between red and black
    const getRandomValue = () => Math.floor(Math.random() * 100) + 100; // Generate random value between 100 and 255
    const red = getRandomValue();
    const blue = getRandomValue();
    const black = getRandomValue();
    const color = `rgb(${red}, ${blue}, ${black})`;
    return color;
  };

  const iconStyle = {
    color: getRandomColor(),
    fontSize: '30px',
    marginLeft: '15px',
    // Add any other styles you want for the icon
  };

  return <ViewInArIcon style={iconStyle} />;
};
