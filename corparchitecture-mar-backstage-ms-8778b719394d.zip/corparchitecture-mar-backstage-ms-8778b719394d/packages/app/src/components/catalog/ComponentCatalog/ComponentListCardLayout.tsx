import {
  Content,
  ContentHeader,
  CreateButton,
  HorizontalScrollGrid,
  ItemCardGrid,
  ItemCardHeader,
  Page,
} from '@backstage/core-components';
import {
  CatalogFilterLayout,
  EntityLifecyclePicker,
  EntityProcessingStatusPicker,
  EntityOwnerPicker,
  EntityTagPicker,
  UserListFilterKind,
  UserListPicker,
  useEntityList,
  EntityRefLink,
} from '@backstage/plugin-catalog-react';
import React, { createContext, ReactNode } from 'react';

import { Entity } from '@backstage/catalog-model';
import { SearchContextProvider } from '@backstage/plugin-search-react';
import { EntityTypologyPicker } from '../../pickers/EntityTypologyPicker';

import { useTranslation } from 'react-i18next';
import {
  Box,
  CardActions,
  CircularProgress,
  makeStyles,
  Typography,
} from '@material-ui/core';

import Card from '@mui/material/Card/Card';
import CardContent from '@mui/material/CardContent';
import { CatalogKindHeader } from '@backstage/plugin-catalog';
import useAsync from 'react-use/lib/useAsync';
import { EntitySystemFilter } from '../../filters/EntitySystemFilter';
import { MAREntityFilters } from '../../pickers/EntityCountryPicker';
import { EntityCountryFilter } from '../../filters/EntityCountryFilter';

export interface EntityProviderProps {
  children: ReactNode;
  entity?: Entity;
}

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  initialKind?: string;
  extOwnershipEntityRefs: string[] | undefined;
}

export const EntityContext = createContext('');
export const ComponentListCardLayout = ({
  initiallySelectedFilter = 'all',
  initialKind = 'component',
  extOwnershipEntityRefs,
}: CatalogPageProps) => {
  const useStyles = makeStyles(theme => ({
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(10, 250px)',
      marginLeft: 20,
      marginTop: 20,
    },
    gridauto: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, 250px)',
      marginLeft: 20,
      marginTop: 20,
    },
    header: {
      color: 'white',
    },
    box: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      display: '-webkit-box',
      '-webkit-line-clamp': 10,
      '-webkit-box-orient': 'vertical',
      paddingBottom: '0.8em',
    },
    label: {
      color: theme.palette.text.secondary,
      textTransform: 'uppercase',
      fontSize: '0.65rem',
      fontWeight: 'bold',
      letterSpacing: 0.5,
      lineHeight: 1,
      paddingBottom: '0.2rem',
    },
    entity: {
      textTransform: 'uppercase',
      padding: 8,
    },
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
  }));
  const classes = useStyles();
  const context = useEntityList<MAREntityFilters>();

  const { t } = useTranslation();

  const searchTemplateAPILink =
    '../create?filters%5Bkind%5D=template&filters%5Buser%5D=all&filters%5Btags%5D=api';
  const { loading } = useAsync(async () =>
    context.updateFilters({
      system: new EntitySystemFilter(
        (extOwnershipEntityRefs as string[])?.map(
          entityRef => entityRef?.split('-')?.pop()?.toLowerCase() as string,
        ),
      ),
      country: new EntityCountryFilter(
        (extOwnershipEntityRefs as string[])?.map(
          entityRef =>
            entityRef?.split('-')?.slice(-2).shift()?.toUpperCase() as string,
        ),
      ),
    }),
  );
  return (
    <Page themeId={'home'}>
      <Content>
        <ContentHeader
          titleComponent={
            <CatalogKindHeader
              initialFilter={initialKind}
              allowedKinds={[initialKind]}
            />
          }
        >
          <CreateButton
            title={t('Catalog Component')}
            to={searchTemplateAPILink}
          />
        </ContentHeader>
        <CatalogFilterLayout>
          <CatalogFilterLayout.Filters>
            <SearchContextProvider>
              {/* <EntityKindPicker initialFilter={'mapfreapi'} allowedKinds={['mapfreapi']} /> */}
              <UserListPicker initialFilter={initiallySelectedFilter} />
              <EntityTypologyPicker />
              <EntityOwnerPicker />
              <EntityLifecyclePicker />
              <EntityTagPicker />
              <EntityProcessingStatusPicker />
            </SearchContextProvider>
          </CatalogFilterLayout.Filters>
          {loading ? (
            <div className={classes.spinner}>
              <CircularProgress />
            </div>
          ) : (
            <CatalogFilterLayout.Content>
              {context.entities.length <= 3 || context.entities.length > 10 ? (
                <ItemCardGrid classes={{ root: classes.gridauto }}>
                  {context.entities.map((entity, index) => (
                    <Card key={index}>
                      <ItemCardHeader
                        title={entity.metadata.title}
                        classes={{ root: classes.header }}
                      />
                      <CardContent>
                        <Box className={classes.box}>
                          <Typography variant="body2" className={classes.label}>
                            {t('Description')}
                          </Typography>
                          {entity?.metadata?.description}
                        </Box>
                        <Box className={classes.box}>
                          <Typography variant="body2" className={classes.label}>
                            {t('Typology')}
                          </Typography>
                          {entity?.metadata?.typology}
                        </Box>
                      </CardContent>
                      <Box>
                        <CardActions>
                          <EntityRefLink
                            className={classes.entity}
                            entityRef={entity}
                            defaultKind={'component'}
                          >
                            {t('View')}
                          </EntityRefLink>
                        </CardActions>
                      </Box>
                    </Card>
                  ))}
                </ItemCardGrid>
              ) : (
                <HorizontalScrollGrid>
                  <ItemCardGrid classes={{ root: classes.grid }}>
                    {context.entities.map((entity, index) => (
                      <Card key={index}>
                        <ItemCardHeader
                          title={entity.metadata.title}
                          classes={{ root: classes.header }}
                        />
                        <CardContent>
                          <Box className={classes.box}>
                            <Typography
                              variant="body2"
                              className={classes.label}
                            >
                              {t('Description')}
                            </Typography>
                            {entity?.metadata?.description}
                          </Box>
                          <Box className={classes.box}>
                            <Typography
                              variant="body2"
                              className={classes.label}
                            >
                              {t('Typology')}
                            </Typography>
                            {entity?.metadata?.typology}
                          </Box>
                        </CardContent>
                        <Box>
                          <CardActions>
                            <EntityRefLink
                              className={classes.entity}
                              entityRef={entity}
                              defaultKind={'component'}
                            >
                              {t('View')}
                            </EntityRefLink>
                          </CardActions>
                        </Box>
                      </Card>
                    ))}
                  </ItemCardGrid>
                </HorizontalScrollGrid>
              )}
            </CatalogFilterLayout.Content>
          )}
        </CatalogFilterLayout>
      </Content>
    </Page>
  );
};
