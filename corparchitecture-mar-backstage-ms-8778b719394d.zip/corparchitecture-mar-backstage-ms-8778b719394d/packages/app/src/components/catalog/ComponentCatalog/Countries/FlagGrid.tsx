import React from 'react';
import { BackstageTheme } from '@backstage/theme';
import { ButtonBase, makeStyles, Tooltip } from '@material-ui/core';
import { FlagList } from './FlagList';
import { useNavigate } from 'react-router';

export const FlagGrid = () => {
  const useStyles = makeStyles<BackstageTheme>(() => ({
    gridImg: {
      width: '48px',
      margin: '-8px -1px -8px 0px',
    },

    boxImage: {
      borderColor: 'black',
      display: 'flex',
      flexDirection: 'row',
      width: '48px',
      height: 'auto',
      '&:hover': {
        boxShadow:
          '0 10px 14px 0 rgba(0,0,0,0.2), 0 17px 50px 0 rgba(0,0,0,0.2)',
      },
    },
  }));

  const classes = useStyles();
  const navigate = useNavigate();
  const countryFilterPath =
    '/apis?filters%5Bkind%5D=mapfreapi&filters%5Buser%5D=all&filters%5Bcountry%5D=';

  return (
    <>
      {FlagList.map(function (flag, idx) {
        return (
          <div key={idx}>
            <Tooltip title={flag.title}>
              <ButtonBase style={{ padding: '10px', textAlign: 'center' }}>
                <div
                  className={classes.boxImage}
                  onClick={() =>
                    navigate(`${countryFilterPath}${flag.filterTag}`)
                  }
                >
                  <img
                    src={flag.image}
                    alt={flag.title}
                    className={classes.gridImg}
                  />
                </div>
              </ButtonBase>
            </Tooltip>
          </div>
        );
      })}
    </>
  );
};
