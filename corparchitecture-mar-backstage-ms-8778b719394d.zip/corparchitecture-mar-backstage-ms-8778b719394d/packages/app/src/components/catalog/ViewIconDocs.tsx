import { Container, CardActionArea } from '@material-ui/core';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import GridViewOutlinedIcon from '@mui/icons-material/GridViewOutlined';
import ViewAgendaOutlinedIcon from '@mui/icons-material/ViewAgendaOutlined';

const ViewIcon = () => {
  const navigate = useNavigate();
  const [isGridViewClicked, setIsGridViewClicked] = useState(true);
  const [isListViewClicked, setIsListViewClicked] = useState(false);

  const handleGridView = () => {
    setIsGridViewClicked(true);
    setIsListViewClicked(false);
    navigate('/docs/grid?filters%5Bkind%5D=mapfredocument');
  };

  const handleListView = () => {
    setIsGridViewClicked(false);
    setIsListViewClicked(true);
    navigate('/docs/list?filters%5Bkind%5D=mapfredocument');
  };

  const iconsContainerStyle = {
    display: 'flex',
    maxWidth: 'none',
    paddingRight: '16px',
  };

  const iconStyle = {
    padding: '8px',
    background: 'none',
    border: 'none',
    display: 'flex',
    height: '45px',
    width: '45px',
  };

  return (
    <Container style={{ ...iconsContainerStyle }}>
      {/* GRID ICON */}
      <CardActionArea
        style={{
          ...iconStyle,
          color: isGridViewClicked ? '#2D373D' : '#89969A',
        }}
        onClick={handleGridView}
      >
        <GridViewOutlinedIcon />
      </CardActionArea>

      {/* LIST ICON */}
      <CardActionArea
        style={{
          ...iconStyle,
          color: isListViewClicked ? '#2D373D' : '#89969A',
          // visibility: 'hidden', // Eliminar cuando se quiera mostrar el icono de list view
        }}
        onClick={handleListView}
      >
        <ViewAgendaOutlinedIcon />
      </CardActionArea>
    </Container>
  );
};

export default ViewIcon;
