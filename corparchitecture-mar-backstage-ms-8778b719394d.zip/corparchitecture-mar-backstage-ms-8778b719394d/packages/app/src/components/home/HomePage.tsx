import {
  Content,
  Page,
  InfoCard,
  Button,
  Header,
} from '@backstage/core-components';
import {
  Box,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Chip,
  Container,
  Grid,
  makeStyles,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import Typography from '@material-ui/core/Typography';
import { useTranslation } from 'react-i18next';
import Timeline from '@mui/lab/Timeline';
import TimelineItem from '@mui/lab/TimelineItem';
import TimelineSeparator from '@mui/lab/TimelineSeparator';
import TimelineConnector from '@mui/lab/TimelineConnector';
import TimelineContent from '@mui/lab/TimelineContent';
import TimelineOppositeContent from '@mui/lab/TimelineOppositeContent';
import TimelineDot from '@mui/lab/TimelineDot';
import EmojiObjectsIcon from '@mui/icons-material/EmojiObjectsSharp';
import GroupsIcon from '@mui/icons-material/Groups';
import SpeedIcon from '@mui/icons-material/Speed';
import { NewAnnouncementBanner } from '@k-phoen/backstage-plugin-announcements';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { parseEntityRef } from '@backstage/catalog-model';
import CircularProgress from '@mui/material/CircularProgress';
import { getSystemDetails } from '../Root/utils';
import { useNavigate } from 'react-router-dom';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { type EntityFilterQuery } from '@backstage/catalog-client';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export const HomePage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const useStyles = makeStyles({
    spinner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: 'calc(100%)',
    },
    typography: {
      textAlign: 'center',
      marginTop: '30px',
      fontSize: '32px',
    },
    markdown: {
      marginLeft: '30px',
    },
  });

  const classes = useStyles();
  const identityApi = useApi(identityApiRef);
  const catalogApi = useApi(catalogApiRef);
  const [isExternal, setIsExternal] = useState(false);
  const [, /* eslint-disable-line */ setExtOwnershipEntityRefs] = useState<
    string[] | undefined
  >();
  const [loading, setLoading] = useState(true);
  const [documentationName, setDocumentationName] = useState('');

  const fetchIdentityData = async () => {
    const { ownershipEntityRefs: entityRefs } =
      await identityApi.getBackstageIdentity();
    const extEntityRefs = entityRefs.filter(
      entityRef =>
        parseEntityRef(entityRef).kind === 'group' &&
        parseEntityRef(entityRef)
          .name.toLowerCase()
          .startsWith('gazr-api-backstage-ext'),
    );
    setExtOwnershipEntityRefs(extEntityRefs);
    setIsExternal(Boolean(extEntityRefs.length));
    const mappedApiSystem = extEntityRefs?.map(
      (entityRef: string) =>
        //GAZR-API-BACKSTAGE-EXT split
        entityRef?.split('-')[4].toLowerCase() +
        '-' +
        entityRef?.split('-')[5].toLowerCase(),
    );

    if (mappedApiSystem && mappedApiSystem.length > 0) {
      const catalogFilter: EntityFilterQuery | undefined = {
        kind: 'system',
        'metadata.name': mappedApiSystem[0],
      };

      const entities = await catalogApi.getEntities({
        filter: catalogFilter,
        fields: ['kind', 'metadata.name', 'metadata.annotations.documentation'],
      });

      if (
        entities &&
        entities.items.length > 0 &&
        entities.items[0].metadata &&
        entities.items[0].metadata.annotations &&
        entities.items[0].metadata.annotations.documentation
      ) {
        setDocumentationName(
          entities.items[0].metadata?.annotations?.documentation as string,
        );
      } else {
        setDocumentationName('APIPortalDefault');
      }
    }

    setLoading(false);
  };

  useEffect(() => {
    const fetchDataAndSystemDetails = async () => {
      await fetchIdentityData();
    };
    fetchDataAndSystemDetails();
  }, []);

  return (
    <>
      {loading ? (
        <div className={classes.spinner}>
          <CircularProgress />
        </div>
      ) : isExternal ? (
        navigate(`/catalog/default/component/${documentationName}`)
      ) : (
        !isExternal && (
          <Page themeId="home">
            <Header
              style={{ textAlign: 'center' }}
              title={t('Marketplace')}
              pageTitleOverride={t('Home') as string | undefined}
            />
            <Content>
              <Container>
                <Grid item md={12}>
                  <NewAnnouncementBanner />
                </Grid>
                <Grid
                  container
                  direction="row"
                  spacing={10}
                  justifyContent="space-between"
                >
                  <Grid item sm={12} md={8}>
                    <Timeline
                      position="alternate"
                      nonce={undefined}
                      onReset={undefined}
                      onResetCapture={undefined}
                    >
                      <TimelineItem>
                        <TimelineOppositeContent
                          sx={{ m: 'auto 0' }}
                          align="right"
                          variant="body2"
                        >
                          <Typography variant="h6" color="inherit">
                            {`${t('Concept')}`}
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineConnector />
                          <TimelineDot color="error">
                            <EmojiObjectsIcon />
                          </TimelineDot>
                          <TimelineConnector />
                        </TimelineSeparator>
                        <TimelineContent sx={{ py: '12px', px: 2 }}>
                          <Typography
                            color="inherit"
                            align="justify"
                            variant="body1"
                          >
                            {`${t(
                              'The Marketplace forms the space where the development of MAPFRE projects.',
                            )}`}
                          </Typography>
                        </TimelineContent>
                      </TimelineItem>
                      <TimelineItem>
                        <TimelineOppositeContent
                          sx={{ m: 'auto 0' }}
                          variant="body2"
                        >
                          <Typography
                            variant="h6"
                            component="span"
                            color="inherit"
                          >
                            {`${t('Reference architectures')}`}
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineConnector />
                          <TimelineDot color="error">
                            <SpeedIcon />
                          </TimelineDot>
                          <TimelineConnector />
                        </TimelineSeparator>
                        <TimelineContent sx={{ py: '12px', px: 2 }}>
                          <Typography
                            color="inherit"
                            align="justify"
                            variant="body1"
                          >
                            {`${t(
                              'The developer will have at his disposal a set of reference architectures as blueprints.',
                            )}`}
                          </Typography>
                        </TimelineContent>
                      </TimelineItem>
                      <TimelineItem>
                        <TimelineOppositeContent
                          sx={{ m: 'auto 0' }}
                          align="right"
                          variant="body2"
                        >
                          <Typography color="inherit" variant="h6">
                            {`${t('Components')}`}
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineConnector />
                          <TimelineDot color="error">
                            <GroupsIcon />
                          </TimelineDot>
                          <TimelineConnector />
                        </TimelineSeparator>
                        <TimelineContent sx={{ py: '12px', px: 2 }}>
                          <Typography
                            color="inherit"
                            align="justify"
                            variant="body1"
                          >
                            {`${t(
                              'The component catalog is where the base resources of our products and services are defined. Each developer or dev team will have their own components adjusting them to the needs of their projects.',
                            )}`}
                          </Typography>
                        </TimelineContent>
                      </TimelineItem>

                      <TimelineItem>
                        <TimelineOppositeContent
                          sx={{ m: 'auto 0' }}
                          align="right"
                          variant="body2"
                        >
                          <Typography variant="h6" color="inherit">
                            APIs
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineConnector />
                          <TimelineDot color="error">
                            <GroupsIcon />
                          </TimelineDot>
                          <TimelineConnector />
                        </TimelineSeparator>
                        <TimelineContent sx={{ py: '12px', px: 2 }}>
                          <Typography
                            color="inherit"
                            align="justify"
                            variant="body1"
                          >
                            {`${t(
                              'The API catalog allows you to view, use, share, consume and provide APIs between developers and services from multiple countries and projects. In this catalog you can make use of the different types of APIs according to your needs.',
                            )}`}
                          </Typography>
                        </TimelineContent>
                      </TimelineItem>

                      <TimelineItem>
                        <TimelineOppositeContent
                          sx={{ m: 'auto 0' }}
                          align="right"
                          variant="body2"
                        >
                          <Typography color="inherit" variant="h6">
                            {`${t('Documentation')}`}
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineConnector />
                          <TimelineDot color="error">
                            <GroupsIcon />
                          </TimelineDot>
                          <TimelineConnector />
                        </TimelineSeparator>
                        <TimelineContent sx={{ py: '12px', px: 2 }}>
                          <Typography
                            color="inherit"
                            align="justify"
                            variant="body1"
                          >
                            {`${t('The Global Documentation catalogue.')}`}
                          </Typography>
                        </TimelineContent>
                      </TimelineItem>
                    </Timeline>
                  </Grid>
                  <Grid item sm={12} md={4}>
                    <img
                      src={'/home_img/cubes.webp'}
                      alt="Marketplace"
                      width="90%"
                      height="auto"
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: '50px', mb: 4 }}></Box>

                <Box sx={{ mt: '24px', mb: 4 }}>
                  <Typography variant="h2" color="inherit" align="left">
                    <Chip
                      label="Recommended"
                      variant="outlined"
                      color="primary"
                    />
                    {t('First steps: Reference Architectures')}
                  </Typography>
                </Box>

                <Grid item sm={12} md={12}>
                  <Card>
                    <CardContent>
                      <Typography
                        variant="body1"
                        color="inherit"
                        align="justify"
                      >
                        {`${t(
                          'Follow this guide to start exploring the reference architectures that MAPFRE architecture team provides and use them as part of your projects!',
                        )}`}
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button
                        variant="text"
                        color="primary"
                        to="catalog/default/refarch/arqref_general/quickstart?filters[kind]=RefArch&filters[type]=ref_architecture"
                        style={{ margin: 'auto', fontWeight: 'bold' }}
                      >
                        {t('The QUICKSTART')}
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
                <Box sx={{ mt: '24px', mb: 4 }}>
                  <Typography variant="h2" color="inherit" align="left">
                    {t('How to...?')}
                  </Typography>
                </Box>
                <Grid container spacing={8}>
                  <Grid item sm={12}>
                    <Grid container spacing={9}>
                      <Grid item xs>
                        <Item>
                          <Button
                            to={'docs/default/component/FAQ/cre/'}
                            variant="text"
                            color="secondary"
                            style={{ fontWeight: 'bold' }}
                          >
                            {t('Create a component')}
                          </Button>
                        </Item>
                      </Grid>
                      <Grid item xs>
                        <Item>
                          <Button
                            to={'docs/default/component/FAQ/reg/'}
                            variant="text"
                            color="secondary"
                            style={{ fontWeight: 'bold' }}
                          >
                            {t('Publish components')}
                          </Button>
                        </Item>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Box sx={{ mt: '50px', mb: 4 }}></Box>
              </Container>
            </Content>
          </Page>
        )
      )}
    </>
  );
};
