import { parseEntityRef } from '@backstage/catalog-model';
import { IdentityApi } from '@backstage/core-plugin-api';

export class GroupChecker {
  groups: string[] = [];

  private constructor(groups: string[]) {
    this.groups = groups;
  }

  static async init(identityApi: IdentityApi) {
    let groups: string[] = [];
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();
      groups = entityRefs
        .map(entityRef => parseEntityRef(entityRef))
        .filter(parsedEntityRef => parsedEntityRef.kind === 'group')
        .map(parsedEntityRef => parsedEntityRef.name.toLowerCase());
    } catch (error) {
      console.error('Error getting entityRefs:', error);
    }
    return new GroupChecker(groups);
  }

  isAdmin(): boolean {
    const foundGroupRef = this.groups.find(group =>
      group.includes('gazr-gov-backstage-admin'),
    );

    if (foundGroupRef) {
      return true;
    }

    return false;
  }

  isGlobalGovGroup(): boolean {
    const foundGroupRef = this.groups.find(group =>
      group.includes('gazr-gov-backstage-global'),
    );

    if (foundGroupRef) {
      return true;
    }

    return false;
  }

  isGlobalGovDocGroup(): boolean {
    const foundGroupRef = this.groups.find(group =>
      group.includes('gazr-gov-backstage-doc-global'),
    );

    if (foundGroupRef) {
      return true;
    }

    return false;
  }

  isGlobalGovSolGroup(): boolean {
    const foundGroupRef = this.groups.find(group =>
      group.includes('gazr-gov-backstage-soluciones-global'),
    );

    if (foundGroupRef) {
      return true;
    }

    return false;
  }

  isCountryGroup(): string[] | undefined {
    const countryGroups = this.groups.filter(group =>
      group.includes('gazr-gov-backstage-'),
    );
    return countryGroups.length > 0 ? countryGroups : undefined;
  }

  isExternal(): boolean {
    return this.groups.some(group => group.includes('gazr-api-backstage-ext'));
  }

  isDisma(): boolean {
    return this.groups.some(group =>
      group.includes('gazr-gov-backstage-disma'),
    );
  }
}
