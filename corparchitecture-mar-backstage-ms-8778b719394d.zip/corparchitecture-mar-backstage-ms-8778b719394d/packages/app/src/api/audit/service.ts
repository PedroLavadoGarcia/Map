import axios from 'axios';

const route = 'api/audit';

export class AuditService {
  baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  async pushLoginLog(user: string) {
    try {
      await axios.post(`${this.baseUrl}/${route}/login`, {
        user,
      });
    } catch (error) {
      console.error(error);
    }
  }

  async pushSearchLog(user: string, text: string) {
    try {
      await axios.post(`${this.baseUrl}/${route}/search`, {
        user,
        text,
      });
    } catch (error) {
      console.error(error);
    }
  }

  pushViewLog(user: string, entity: string) {
    return axios.post(`${this.baseUrl}/${route}/view`, {
      user,
      entity,
    });
  }

  pushViewDocLog(user: string, entity: string) {
    return axios.post(`${this.baseUrl}/${route}/viewDoc`, {
      user,
      entity,
    });
  }
}
