import { Entity } from '@backstage/catalog-model';
import * as Diff from 'diff';
import moment from 'moment';
import yaml from 'js-yaml';
import axios from 'axios';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import { getCatalogInfo } from '@backstage/plugin-mapfreapi-editor';

const route = 'api/changelog/solution';

export interface Log {
  id: string;
  date: string;
  diff: string;
  file: string;
  modifiedBy: string;
  desc: string;
  comment?: string;
  descParams?: { [key: string]: string };
}

export class SolutionChangelogService {
  protected baseUrl: string;
  protected env: string;

  constructor() {
    const config = useApi(configApiRef);
    this.baseUrl = config.getOptionalString('backend.baseUrl') ?? '';
    this.env = config.getOptionalString('app.env') ?? '';
  }

  async push(
    name: string,
    prevCatalogInfo: string,
    changes: {
      files: { [key: string]: string };
      modifiedBy: string;
      desc: string;
      descParams?: { [key: string]: string };
      comment?: string;
    },
  ) {
    const url = `${this.baseUrl}/${route}/log/${name}`;
    const { files, comment, desc, descParams, modifiedBy } = changes;
    const date = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');

    if (Object.keys(files).length === 0) {
      await axios.post(url, {
        date,
        diff: `[{"value":"${prevCatalogInfo}","count":1}]`,
        file: '',
        modifiedBy,
        comment,
        desc,
        descParams,
      });
    }

    let diff;

    if (files['catalog-info.yaml']) {
      diff = JSON.stringify(
        await this.compareYamlFiles(
          prevCatalogInfo,
          files['catalog-info.yaml'],
        ),
      );

      await axios.post(url, {
        date,
        diff,
        file: 'catalog-info.yaml',
        modifiedBy,
        comment,
        desc,
        descParams,
      });

      delete files['catalog-info.yaml'];
    }

    for (const path in files) {
      diff = this.isBinary(path)
        ? JSON.stringify(Diff.diffLines('Binary content', 'Binary content'))
        : JSON.stringify(
            Diff.diffLines('', atob((files[path] as string).split(',')[1])),
          );

      await axios.put(url, {
        date,
        diff,
        file: path,
        modifiedBy,
        comment,
        desc: 'mapfresolution.historyLog.file',
      });
    }
  }

  async getAll(name: string) {
    return (await axios.get<Log[]>(`${this.baseUrl}/${route}/log/${name}`))
      .data;
  }

  async move(from: string, to: string) {
    await axios.put(`${this.baseUrl}/${route}/log/${from}/${to}`);
  }

  async delete(name: string) {
    await axios.delete(`${this.baseUrl}/${route}/log/${name}`);
  }

  private isBinary(filename: string) {
    const binaryExtensions = [
      'pdf',
      'docx',
      'doc',
      'xlsx',
      'xlsm',
      'xls',
      'abw',
      'bin',
      'bmp',
      'bz',
      'bz2',
      'gz',
      'gif',
      'ico',
      'jar',
      'jpeg',
      'jpg',
      'mjs',
      'odp',
      'ods',
      'odt',
      'otf',
      'ppt',
      'pptx',
      'rar',
      'rtf',
      'tar',
      'tif',
      'tiff',
      'vsd',
      'zip',
      '7z',
    ];
    const extension = filename.match(/\.([A-Za-z0-9]+$)/);

    return binaryExtensions.includes(extension?.[1] ?? '');
  }

  private async compareYamlFiles(
    file1: string,
    file2: string,
  ): Promise<Diff.Change[]> {
    const doc1 = yaml.load(file1);
    const doc2 = yaml.load(file2);

    const yaml1 = yaml.dump(doc1);
    const yaml2 = yaml.dump(doc2);

    const differences = Diff.diffLines(yaml1, yaml2);
    const filteredDifferences = differences.filter(
      d => d.added || d.removed || d.value,
    );

    return filteredDifferences;
  }
}
