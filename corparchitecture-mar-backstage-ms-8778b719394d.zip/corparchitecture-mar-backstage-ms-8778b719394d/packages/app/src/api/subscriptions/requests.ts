import { JsonValue } from '@backstage/types';

const route = '/api/subscriptions';

function getSubscriptionsGetReq(baseUrl: string, email = '') {
  const url = new URL(`${route}/catalog/${email}`, baseUrl);
  return new Request(url.toString(), {
    method: 'GET',
  });
}

function getSubscriptionsGetReqMarketplace(
  baseUrl: string,
  email = '',
  repoUrl: string,
  componentUrl: string,
) {
  const url = new URL(`${route}/marketplace`, baseUrl);
  console.log('[DEBUG]: subscription get:' + url.toString());
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'PUT',
    headers,
    body: JSON.stringify({
      uid: email,
      repoUrl,
      componentUrl,
    }),
  });
}

function getSubscriptionPutReq(
  baseUrl: string,
  email = '',
  entityName: string,
) {
  const url = new URL(`${route}/sub`, baseUrl);
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'PUT',
    headers,
    body: JSON.stringify({
      uid: email,
      sub: entityName,
    }),
  });
}

function newCatalogSubscription(
  entity: string,
  subscriber: string,
  freq: string,
  metadata?: boolean,
  swagger?: boolean,
  sourceLocation?: string,
) {
  const url = new URL(
    `${route}/newsubscription`,
    window.location.origin.replace('3000', '7007'),
  );
  const headers = new Headers({
    'Content-Type': 'application/json',
  });

  return new Request(url.toString(), {
    method: 'POST',
    headers,
    body: JSON.stringify({
      entity,
      subscriber,
      freq,
      metadata,
      swagger,
      sourceLocation,
    }),
  });
}

function catalogUnsubscription(entity: string, subscriber: string) {
  const url = new URL(
    `${route}/unsubscribe`,
    window.location.origin.replace('3000', '7007'),
  );
  const headers = new Headers({
    'Content-Type': 'application/json',
  });

  return new Request(url.toString(), {
    method: 'DELETE',
    headers,
    body: JSON.stringify({
      entity: entity,
      subscriber: subscriber,
    }),
  });
}

function getSubscriptionPutReqMarketplace(
  baseUrl: string,
  componentUrl: string,
  componentName: string,
  email = '',
  entityDescription: string | undefined,
  entityOwner: JsonValue | undefined,
  entityType: JsonValue | undefined,
) {
  const url = new URL(`${route}/sub/marketplace`, baseUrl);
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'PUT',
    headers,
    body: JSON.stringify({
      componentUrl,
      componentName,
      uid: email,
      entityDescription,
      entityOwner,
      entityType,
    }),
  });
}
function getSubscriptionDeleteReq(
  baseUrl: string,
  email = '',
  entityName: string,
) {
  const url = new URL(`${route}/unsub`, baseUrl);
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'DELETE',
    headers,
    body: JSON.stringify({
      uid: email,
      sub: entityName,
    }),
  });
}

function getSubscriptionDeleteReqMarketplace(
  baseUrl: string,
  email = '',
  componentUrl: string,
) {
  const url = new URL(`${route}/unsub/marketplace`, baseUrl);
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'DELETE',
    headers,
    body: JSON.stringify({
      componentUrl,
      uid: email,
    }),
  });
}

function getSubscriptionFreqPutReq(baseUrl: string, email = '', freq: string) {
  const url = new URL(`${route}/freq`, baseUrl);
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  return new Request(url.toString(), {
    method: 'PUT',
    headers,
    body: JSON.stringify({
      uid: email,
      freq,
    }),
  });
}
function getUserSubscriptions(baseUrl: string, email = '') {
  const url = new URL(`${route}/catalog/${email}`, baseUrl);

  const method = 'GET';

  return new Request(url.toString(), { method });
}

export {
  getSubscriptionsGetReq,
  getSubscriptionPutReq,
  getSubscriptionDeleteReq,
  getSubscriptionFreqPutReq,
  getUserSubscriptions,
  getSubscriptionPutReqMarketplace,
  getSubscriptionsGetReqMarketplace,
  getSubscriptionDeleteReqMarketplace,
  newCatalogSubscription,
  catalogUnsubscription,
};
