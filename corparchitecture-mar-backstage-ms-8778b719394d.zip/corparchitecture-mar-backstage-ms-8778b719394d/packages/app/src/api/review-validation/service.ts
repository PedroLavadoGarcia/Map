import axios from 'axios';
import i18next from 'i18next';

const route = 'api/review-validation';

export interface MetadataValidationResult {
  errors: {
    key: string;
    severity: 'error' | 'warn' | 'review' | 'info';
    path?: string;
  }[];
}

export interface ApiValidationResult {
  errors: {
    key: string;
    severity: 'error' | 'warn' | 'review' | 'info';
    path?: string;
  }[];
}

interface ReportError {
  key: string;
  paths: { path: string }[];
}

type Severity = 'error' | 'review' | 'security review' | 'warn' | 'info';

export const severities: Severity[] = [
  'error',
  'review',
  'security review',
  'warn',
  'info',
];

export class ReviewValidationService {
  baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  async validateMetadata(bucket: string, repo: string) {
    const response = await axios.post<MetadataValidationResult>(
      `${this.baseUrl}/${route}/validate-metadata`,
      {
        bucket,
        repo,
      },
    );
    return response.data;
  }

  async validateApi(bucket: string, repo: string) {
    const response = await axios.post<ApiValidationResult>(
      `${this.baseUrl}/${route}/validate-api`,
      {
        bucket,
        repo,
      },
    );
    return response.data;
  }

  async generateReport(
    title: string,
    metadataValidationResult: MetadataValidationResult,
    apiValidationResult: ApiValidationResult,
    state: string,
    bucket: string,
    repo: string,
    to: string[],
  ) {
    const categorizeErrors = (severity: Severity): ReportError[] => {
      const result: ReportError[] = [];
      const errors = [
        ...metadataValidationResult.errors.filter(e => e.severity === severity),
        ...apiValidationResult.errors.filter(e => e.severity === severity),
      ];

      errors.forEach(error => {
        const existingError = result.find(e => e.key === error.key);
        if (existingError) {
          if (error.path) {
            existingError.paths.push({ path: error.path });
          }
        } else {
          const newError: ReportError = {
            key: error.key,
            paths: [],
          };
          if (error.path) {
            newError.paths.push({ path: error.path });
          }
          result.push(newError);
        }
      });

      return result;
    };

    const response = await axios.post(
      `${this.baseUrl}/${route}/generate-report`,
      {
        bucket,
        repo,
        title,
        errors: categorizeErrors('error'),
        reviews: [
          ...categorizeErrors('review'),
          ...categorizeErrors('security review'),
        ],
        warns: categorizeErrors('warn'),
        infos: categorizeErrors('info'),
        state,
        to,
        language: i18next.resolvedLanguage,
      },
    );
    return response.data;
  }
}
