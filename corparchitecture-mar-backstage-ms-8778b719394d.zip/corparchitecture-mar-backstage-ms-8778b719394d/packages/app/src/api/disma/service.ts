import { Entity } from '@backstage/catalog-model';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import axios from 'axios';

const route = 'api/disma';

export class DismaService {
  protected baseUrl: string;
  protected env: string;

  constructor() {
    const config = useApi(configApiRef);
    this.baseUrl = config.getOptionalString('backend.baseUrl') ?? '';
    this.env = config.getOptionalString('app.env') ?? '';
  }

  async haveChanges(entity: Entity) {
    const country = (entity.metadata.country as string).toLowerCase();
    const bucket = `catalog-api-${country}-${this.env}`;
    const repoOg = entity.metadata.name.replace('_edit', '');
    const response = await axios.get(
      `${this.baseUrl}/${route}/changes/${bucket}/${repoOg}`,
    );
    return response.data;
  }
}
