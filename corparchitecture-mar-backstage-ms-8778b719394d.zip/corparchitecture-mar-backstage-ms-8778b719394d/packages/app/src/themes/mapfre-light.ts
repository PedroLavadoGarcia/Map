import { BackstageOverrides } from '@backstage/core-components';
import { BackstageOverrides as CatalogReactOverrides } from '@backstage/plugin-catalog-react';
import { BackstageTheme, createTheme, lightTheme } from '@backstage/theme';

const baseTheme = createTheme({
  palette: {
    ...lightTheme.palette,
    primary: {
      main: '#DB271C',
    },
    secondary: {
      main: '#FF5630',
    },
    grey: {
      300: '#f1f4fa',
    },

    error: {
      main: '#8c4351',
    },
    warning: {
      main: '#8f5e15',
    },
    info: {
      main: '#34548a',
    },
    success: {
      main: '#485e30',
    },
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    navigation: {
      ...lightTheme.palette.navigation,
      //  background: '#ddd',
      background: '#FFFFFF',
      color: '#475059',
      indicator: '#475059',
      navItem: {
        hoverBackground: '#aaaaaa',
      },
    },
    text: {
      primary: '#475059',
    },
    background: {
      default: '#FFFFFF',
    },
  },
  fontFamily: 'Roboto, sans-serif',
  defaultPageTheme: 'home',
});

const createCustomThemeOverrides = (): BackstageOverrides &
  CatalogReactOverrides => {
  return {
    BackstageHeader: {
      header: {
        backgroundImage: 'none',
        boxShadow: 'none',
        paddingTop: '10px',
      },
      breadcrumb: {
        color: '#475059',
      },
      title: {
        color: '#475059',
        fontWeight: 900,
        marginTop: '10px',
      },
      subtitle: {
        display: 'none',
      },
      type: {
        color: '#475059',
      },
      rightItemsBox: {
        marginTop: '10px',

        '& div[class*=MuiGrid-item]': {
          color: '#475059',
        },
        '& a:hover': {
          color: '#475059',
        },
      },
    },

    BackstageItemCardHeader: {
      root: {
        '& a': {
          color: 'white !important',
        },
        backgroundColor: '#DB271C',
        backgroundImage: 'none !important',
      },
    },

    BackstageSidebarPage: {
      root: {
        '& nav > div > div > div::-webkit-scrollbar': {
          backgroundColor: '#ffffff !important',
        },
        '& nav > div > div > div::-webkit-scrollbar-thumb': {
          backgroundColor: '#ffffff !important',
        },
        '& [data-testid=item-with-submenu] > div:last-child': {
          left: '-10px !important',
        },
      },
    },

    BackstageTabbedCard: {
      indicator: {
        backgroundColor: 'none',
      },
    },

    BackstageSidebarItem: {
      root: {
        '&[aria-label="Arq. de Referencia"] div:last-child': {
          width: '0 !important',
        },
        flexShrink: 0,
      },
      expandButton: {
        flexShrink: 0,
      },
    },

    BackstagePage: {
      root: {
        'overflow-y': 'visible',
      },
    },

    MuiCardActions: {
      root: {
        '& img[class~="iconImg"]': {
          filter:
            'invert(27%) sepia(10%) saturate(621%) hue-rotate(169deg) brightness(102%) contrast(89%)',
        },
        '& img[class~="iconImg"]:hover': {
          filter:
            'invert(37%) sepia(80%) saturate(3936%) hue-rotate(342deg) brightness(81%) contrast(114%)',
        },
      },
    },
    CatalogReactUserListPicker: {
      root: {
        backgroundColor: '#f1f4fa',
      },
      menuItem: {
        '&:hover': {
          backgroundColor: '#ecf2ff',
        },
        '&.Mui-selected:hover': {
          backgroundColor: '#ecf2ff',
        },
        '&.Mui-selected': {
          backgroundColor: '#d6dbe5',
        },
      },
    },

    BackstageTable: {
      root: {
        '& tr:hover td': {
          backgroundColor: '#eae9e9',
        },
        '& tr': {
          borderBottom: '1px solid #b0b8bb',
        },
        '& td:first-child': {
          backgroundColor: '#eae9e9',
        },

        '&> :first-child': {
          borderBottom: '1px solid #D5D5D5',
        },
        '& th': {
          borderTop: 'none',
          textTransform: 'none !important',
        },
      },
    },
    MuiTable: {
      root: {
        '& td:first-child': {
          backgroundColor: '#eae9e9',
        },
        '&> :first-child': {
          borderBottom: '1px solid #D5D5D5',
        },
        '& th': {
          borderTop: 'none',
          textTransform: 'none !important',
        },
      },
    },

    BackstageHeaderLabel: {
      label: {
        color: '#475059',
      },
      value: {
        color: '#475059',
      },
    },

    MuiIconButton: {
      label: {
        color: '#475059',
      },
    },
    MuiCardMedia: {
      root: {
        '& h6': {
          color: '#475059',
        },
      },
    },
    MuiFab: {
      root: {
        backgroundColor: '#DB271C',
        color: 'white !important',
        '&:hover': {
          color: 'black !important',
        },
      },
    },
    MuiButton: {
      textSecondary: {
        color: '#DB271C',
      },
      contained: {
        '&.md-content__button': {
          visibility: 'hidden',
        },
      },
    },

    MuiBottomNavigation: {
      root: {
        width: '100% !important',
      },
    },

    MuiTypography: {
      h1: {
        fontSize: '42px',
        fontWeight: 800,
      },
      h2: {
        fontSize: '32px',
      },
      h3: {
        fontSize: '24px',
      },
      body1: {
        fontSize: '18px',
      },
      body2: {
        fontSize: '16px',
      },
    },
  };
};

export const mapfreLightTheme: BackstageTheme = {
  ...baseTheme,
  overrides: {
    ...baseTheme.overrides,
    ...createCustomThemeOverrides(),
  },
};
