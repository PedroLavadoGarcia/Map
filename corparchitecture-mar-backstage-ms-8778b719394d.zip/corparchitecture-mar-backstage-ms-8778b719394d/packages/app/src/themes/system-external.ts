import { BackstageOverrides } from '@backstage/core-components';
import { BackstageOverrides as CatalogReactOverrides } from '@backstage/plugin-catalog-react';
import { BackstageTheme, createTheme, lightTheme } from '@backstage/theme';

const baseTheme = (color: string) =>
  createTheme({
    palette: {
      ...lightTheme.palette,
      primary: {
        main: color,
      },
      secondary: {
        main: color,
      },
      grey: {
        300: '#7D7F7D',
      },

      error: {
        main: '#7D7F7D',
      },
      warning: {
        main: '#7D7F7D',
      },
      info: {
        main: '#7D7F7D',
      },
      success: {
        main: color,
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      navigation: {
        ...lightTheme.palette.navigation,
        background: color,
        color: '#FFFFFF',
        indicator: '#FFFFFF',
      },
      text: {
        primary: '#475059',
      },
      background: {
        default: '#FFFFFF',
      },
    },
    fontFamily: 'Roboto, sans-serif',
    defaultPageTheme: 'home',
  });

const createCustomThemeOverrides = (
  color: string,
): BackstageOverrides & CatalogReactOverrides => {
  return {
    BackstageHeader: {
      header: {
        backgroundImage: 'none',
        boxShadow: 'none',
        paddingTop: '10px',
      },
      breadcrumb: {
        color: '#475059',
      },
      title: {
        color: '#475059',
        fontWeight: 900,
        marginTop: '10px',
      },
      subtitle: {
        display: 'none',
      },
      type: {
        color: '#475059',
      },
      rightItemsBox: {
        marginTop: '10px',
        '& div[class*=MuiGrid-item]': {
          color: '#475059',
        },
        '& a:hover': {
          color: '#475059',
        },
      },
    },
    BackstageItemCardHeader: {
      root: {
        '& a': {
          color: 'white !important',
        },
        backgroundColor: color,
        backgroundImage: 'none !important',
      },
    },

    BackstageSidebarPage: {
      root: {
        '& nav > div > div > div::-webkit-scrollbar': {
          backgroundColor: `${color} !important`,
        },
        '& nav > div > div > div::-webkit-scrollbar-thumb': {
          backgroundColor: '#FAFAFA !important',
        },
        '& [data-testid=item-with-submenu] > div:last-child': {
          left: '-10px !important',
        },
      },
    },
    BackstageTabbedCard: {
      indicator: {
        backgroundColor: 'none',
      },
    },
    BackstageSidebarItem: {
      root: {
        '&[aria-label="Arq. de Referencia"] div:last-child': {
          width: '0 !important',
        },
        flexShrink: 0,
      },
      expandButton: {
        flexShrink: 0,
      },
    },
    MuiCardActions: {
      root: {
        '& img[class~="iconImg"]': {
          filter:
            'invert(27%) sepia(10%) saturate(621%) hue-rotate(169deg) brightness(102%) contrast(89%)',
        },
        '& img[class~="iconImg"]:hover': {
          filter:
            'invert(37%) sepia(80%) saturate(3936%) hue-rotate(342deg) brightness(81%) contrast(114%)',
        },
      },
    },
    CatalogReactUserListPicker: {
      root: {
        backgroundColor: '#f1f4fa',
      },
      menuItem: {
        '&:hover': {
          backgroundColor: '#ecf2ff',
        },
        '&.Mui-selected:hover': {
          backgroundColor: '#ecf2ff',
        },
        '&.Mui-selected': {
          backgroundColor: '#d6dbe5',
        },
      },
    },
    BackstageTable: {
      root: {
        '& tr:nth-of-type(odd)': {
          backgroundColor: '#f1f4fa',
        },
        '&> :first-child': {
          borderBottom: '1px solid #D5D5D5',
        },
        '& th': {
          borderTop: 'none',
          textTransform: 'none !important',
        },
      },
    },
    MuiTable: {
      root: {
        '& tr:nth-of-type(odd)': {
          backgroundColor: '#f1f4fa',
        },
        '&> :first-child': {
          borderBottom: '1px solid #D5D5D5',
        },
        '& th': {
          borderTop: 'none',
          textTransform: 'none !important',
        },
      },
    },
    BackstageHeaderLabel: {
      label: {
        color: '#475059',
      },
      value: {
        color: '#475059',
      },
    },
    MuiIconButton: {
      label: {
        color: '#475059',
      },
    },
    MuiCardMedia: {
      root: {
        '& h6': {
          color: '#475059',
        },
      },
    },
    MuiFab: {
      root: {
        backgroundColor: color,
        color: 'white !important',
        '&:hover': {
          color: 'black !important',
        },
      },
    },
    MuiButton: {
      textSecondary: {
        color: color,
      },
      contained: {
        '&.md-content__button': {
          visibility: 'hidden',
        },
      },
    },

    MuiBottomNavigation: {
      root: {
        width: '100% !important',
      },
    },
    MuiTypography: {
      h1: {
        fontSize: '42px',
        fontWeight: 800,
      },
      h2: {
        fontSize: '32px',
      },
      h3: {
        fontSize: '24px',
      },
      body1: {
        fontSize: '18px',
      },
      body2: {
        fontSize: '16px',
      },
    },
  };
};
export const systemExternalTheme = (color: string): BackstageTheme => {
  return {
    ...baseTheme(color),
    overrides: {
      ...baseTheme(color).overrides,
      ...createCustomThemeOverrides(color),
    },
  };
};
