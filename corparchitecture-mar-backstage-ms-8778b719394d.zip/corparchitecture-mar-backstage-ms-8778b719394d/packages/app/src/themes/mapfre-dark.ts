import { BackstageOverrides } from '@backstage/core-components';
import { BackstageOverrides as CatalogReactOverrides } from '@backstage/plugin-catalog-react';
import { BackstageTheme, createTheme, darkTheme } from '@backstage/theme';

const baseTheme = createTheme({
  palette: {
    ...darkTheme.palette,
    primary: {
      dark: '#FAB9B6',
      main: '#ffcecb',
    },
    secondary: {
      main: '#ffcecb',
    },
    grey: {
      300: '#DB271C',
    },

    error: {
      main: '#ffcecb',
    },
    warning: {
      main: '#8f5e15',
    },
    info: {
      main: '#34548a',
    },
    success: {
      main: '#485e30',
    },
    // @ts-ignore
    navigation: {
      ...darkTheme.palette.navigation,
      indicator: '#DB271C',

      navItem: {
        hoverBackground: 'rgba(219, 39, 28, 1)',
      },
    },
    link: '#ffcecb',
    linkHover: '#FAB9B6',
    textSubtle: '#ffffff',
  },
  fontFamily: 'Roboto, sans-serif',
  defaultPageTheme: 'home',
});

const createCustomThemeOverrides = (): BackstageOverrides &
  CatalogReactOverrides => {
  return {
    MuiCardActions: {
      root: {
        '& img[class~="iconImg"]': {
          filter: 'invert(100%) brightness(100%) contrast(100%)',
        },
        '& img[class~="iconImg"]:hover': {
          filter:
            'invert(37%) sepia(80%) saturate(3936%) hue-rotate(342deg) brightness(81%) contrast(114%)',
        },
      },
    },
    MuiGrid: {
      root: {
        '& img[class~="bussinessIcon"]': {
          filter: 'invert(100%) brightness(100%) contrast(100%)',
        },
      },
    },

    BackstageTabbedCard: {
      indicator: {
        backgroundColor: 'none',
      },
    },

    BackstageHeader: {
      header: {
        backgroundImage: 'none',
        boxShadow: 'none',
        paddingTop: '10px',
      },
      title: {
        marginTop: '10px',
      },
      subtitle: {
        display: 'none',
      },
    },

    BackstageItemCardHeader: {
      root: {
        backgroundColor: '#DB271C',
        backgroundImage: 'none !important',
      },
    },

    BackstageSidebarItem: {
      highlightable: {
        '&:hover': { color: 'white' },
      },

      root: {
        '&[aria-label="Arq. de Referencia"] div:last-child': {
          width: '0 !important',
        },
        flexShrink: 0,
      },

      expandButton: {
        flexShrink: 0,
      },
    },
    BackstageDependencyGraphEdge: {
      path: {
        stroke: '#FFFFFF',
      },
    },

    BackstageSidebarPage: {
      root: {
        '& nav > div > div > div::-webkit-scrollbar': {
          backgroundColor: `${darkTheme.palette.grey[800]} !important`,
        },
        '& nav > div > div > div::-webkit-scrollbar-thumb': {
          backgroundColor: 'rgba(255,255,255,0.3) !important',
        },
        '& [data-testid=item-with-submenu] > div:last-child': {
          left: '-10px !important',
        },
      },
    },

    BackstageDependencyGraphNode: {
      node: {
        '& rect[class~="primary"] ': {
          fill: '#9cc9ff',
          stroke: '#9cc9ff ',
        },
        '& rect[class~="secondary"] ': {
          fill: '#ffcecb',
          stroke: '#ffcecb',
        },
      },
    },

    MuiFab: {
      root: {
        '&:hover': {
          color: 'black',
        },
      },
    },

    MuiOutlinedInput: {
      input: {
        '&:-webkit-autofill': {
          '-webkit-box-shadow': '0 0 0 100px #754542 inset !important',
        },
      },
    },
    MuiButton: {
      containedPrimary: {
        backgroundColor: '#DB271C',
        color: '#FFFFFF',
      },
      textPrimary: {
        color: 'white',
      },
      textSecondary: {
        color: '#DB271C',
      },
      text: {
        padding: void 0,
      },
    },

    MuiBottomNavigationAction: {
      selected: {
        color: 'white',
        '& svg': {
          fill: 'white',
        },
      },
    },
    MuiTypography: {
      h1: {
        fontSize: '42px',
        fontWeight: 800,
      },
      h2: {
        fontSize: '32px',
      },
      h3: {
        fontSize: '24px',
      },
      body1: {
        fontSize: '18px',
      },
      body2: {
        fontSize: '16px',
      },
    },

    BackstageTable: {
      root: {
        '&> :first-child': {
          borderBottom: '1px solid #D5D5D5',
        },
        '& th': {
          borderTop: 'none',
          textTransform: 'none !important',
        },
      },
    },
  };
};

export const mapfreDarkTheme: BackstageTheme = {
  ...baseTheme,
  overrides: {
    ...baseTheme.overrides,
    ...createCustomThemeOverrides(),
  },
};
