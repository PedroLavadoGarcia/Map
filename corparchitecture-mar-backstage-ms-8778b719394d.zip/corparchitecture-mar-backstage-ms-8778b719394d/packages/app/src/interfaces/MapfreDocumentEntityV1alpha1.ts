import { Entity, EntityMeta } from '@backstage/catalog-model';
import Countries from '../enums/Countries';

export interface MapfreDocumentEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'MapfreDocument';
  metadata: EntityMeta & {
    country: Countries;
    global_business_areas: boolean;
    state: string;
    name_beta: string;

    header_icon: string;
    liableTeam?: {
      'mapfre.com/responsible': string;
      'mapfre.com/writers': string;
      'mapfre.com/reviewers': string;
    };
    contextData: {
      pro_doc_repo_url: string;
      beta_doc_repo_url: string;
    };
    historyLog: {
      creation_date: string;
      acceptance_date: string;
      publication_date: string;
      last_update_date: string;
      retired_date: string;
      creation_user: string;
      last_update_user: string;
      retired_user: string;
    };
  };
  spec: {
    type: string;
    lifecycle: string;
    owner: string;
  };
}
