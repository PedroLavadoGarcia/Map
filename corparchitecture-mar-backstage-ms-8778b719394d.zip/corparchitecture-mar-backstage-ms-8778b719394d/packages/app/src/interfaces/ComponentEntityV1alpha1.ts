import { Entity, EntityMeta } from '@backstage/catalog-model';
import Architecture from '../enums/Architecture';
import AuthType from '../enums/AuthType';
import BusinessEntity from '../enums/BusinessEntity';
import Countries from '../enums/Countries';
import Life from '../enums/Life';
//import ServUbic from '../enums/ServUbic';
import Types from '../enums/Types';

export interface ComponentEntityV1alpha1 extends Entity {
  apiVersion: 'backstage.io/v1alpha1' | 'backstage.io/v1beta1';
  kind: 'MapfreApi';
  metadata: EntityMeta & {
    typology: Types;
    subtypology: string;
    country: Countries;
    version: string;
    modDate?: string;
    liablePeople?: {
      'mapfre.com/owners': string;
      'mapfre.com/resp_func': string;
      'mapfre.com/resp_tech': string;
      'mapfre.com/resp_alt': string;
    };
    contextData?: {
      'mapfre.com/NNII': boolean;
      'mapfre.com/NNII_code': string[];
      'mapfre.com/externalAccess': boolean;
    };
    technicalData?: {
      //'mapfre.com/serv_ubic': ServUbic;
      'mapfre.com/architecture': Architecture;
      'mapfre.com/perm_type':
        | 'All authenticated users'
        | 'Roles'
        | 'Scopes'
        | 'Users'
        | 'Other'
        | '';
      'mapfre.com/ip_filter': boolean;
      'mapfre.com/scope_of_use': 'Public' | 'Private';
      'mapfre.com/event_classification': 'fct' | 'cdc' | 'sys';
      'mapfre.com/compaction_logs': boolean;
      'mapfre.com/sorted_message':
        | 'There is no sorted message'
        | 'By Partition'
        | 'Global';
      'mapfre.com/retention_time': string;
      'mapfre.com/num_partitions': string;
    };
    serviceAvailability?: {
      'mapfre.com/endpoint_DEV': string;
      'mapfre.com/endpoint_PRE': string;
      'mapfre.com/endpoint_PRO': string;
      'mapfre.com/portal_pub': boolean;
    };
    wsrr?: {
      'mapfre.com/wsrr_last_pub_DEV': string;
      'mapfre.com/wsrr_last_pub_IC': string;
      'mapfre.com/wsrr_last_pub_PRE': string;
      'mapfre.com/wsrr_last_pub_PRO': string;
      'mapfre.com/wsrr_last_pub_PROBIS': string;
    };
    executionPermissions?: {
      'mapfre.com/auth_type': AuthType;
      'mapfre.com/scopes': string;
      'mapfre.com/rol_serv_IC': string;
      'mapfre.com/rol_serv_PRE': string;
      'mapfre.com/rol_serv_PRO': string;
    };
    historyLog?: {
      'mapfre.com/approvalDate': string;
      'mapfre.com/deprecationDate': string;
      'mapfre.com/modDate': string;
      'mapfre.com/user_mod': string;
    };

    'mapfre.com/businessEntity'?: BusinessEntity;
    'mapfre.com/business_line'?:
      | 'Cross'
      | 'Health::Health Care'
      | 'Health::Medical Centers'
      | 'Health::Other'
      | 'NoLife::Bicycles and cyclists'
      | 'NoLife::Business'
      | 'NoLife::Home Insurance'
      | 'NoLife::Legal Defense'
      | 'NoLife::Pets'
      | 'NoLife::Accidents'
      | 'NoLife::Autos'
      | 'NoLife::Community'
      | 'NoLife::Death'
      | 'NoLife::Property and Contingency'
      | 'NoLife::Rural'
      | 'NoLife::Umbrella'
      | 'NoLife::Other'
      | 'NoLife::Travel'
      | 'Life::Savings'
      | 'Life::Risk'
      | 'Life::Other';

    'mapfre.com/state': string;
    'mapfre.com/consumer_type'?: 'Internal' | 'External' | '';
    'mapfre.com/provider_type'?: 'Internal' | 'External' | '';
    'mapfre.com/organization'?: string;
    'mapfre.com/id_ram'?: string;
  };
  spec: {
    type: string;
    lifecycle: string;
    owner: string;
    system: string;
    consumesApis: string;
    authorizesApis: string;
    invokesApis: string;
    simulatesApis: string;
    nextVersionOf: string;
  };
}
