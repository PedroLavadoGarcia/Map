import { IconComponent } from '@backstage/core-plugin-api';

interface ExtraContextMenuItem {
  title: string;
  Icon: IconComponent;
  onClick: () => void;
}

export default ExtraContextMenuItem;
