import React, { useEffect, useState } from 'react';
import {
  FormControl,
  Button,
  CardContent,
  Card,
  Select,
  MenuItem,
  Typography,
  makeStyles,
  FormHelperText,
  InputLabel,
  Input,
  Tooltip,
  IconButton,
  Grid,
  CircularProgress,
} from '@material-ui/core';
import {
  SessionState,
  bitbucketAuthApiRef,
  useApi,
  errorApiRef,
} from '@backstage/core-plugin-api';
import InfoIcon from '@mui/icons-material/Info';
import axios, { AxiosRequestConfig } from 'axios';
import { BackstageTheme } from '@backstage/theme';
import {
  FieldExtensionComponentProps,
  useTemplateSecrets,
} from '@backstage/plugin-scaffolder-react';
import { Subscription, timer } from 'rxjs';

const BITBUCKET_BASE_URL = 'https://api.bitbucket.org/2.0';

const useStyles = makeStyles<BackstageTheme>(() => ({
  loading: {
    border: '16px solid #f3f3f3',
    'border-top': '16px solid #3498db',
    'border-radius': '50%',
    width: '100px',
    height: '100px',
    animation: '$spin 2s linear infinite',
  },
  '@keyframes spin': {
    '0%': {
      transform: 'rotate(0deg)',
    },
    '100%': {
      transform: 'rotate(360deg)',
    },
  },
}));

async function getBitbucketConfig(): Promise<string> {
  const url = new URL(
    `/api/components-editor/get-bitbucket-config`,
    window.location.origin,
  );
  if (url.hostname === 'localhost' && url.port === '3000') url.port = '7007';

  const method = 'GET';

  const headers = new Headers();

  const request = new Request(url.toString(), {
    method,
    headers,
  });

  const res = await fetch(request);
  if (!res.ok) {
    throw Error('Cannot retrieve entity catalog-info.yaml');
  }

  return await res.text();
}

export const OauthField = ({
  formData = {},
  schema,
  uiSchema,
  errorSchema,
  onChange,
}: FieldExtensionComponentProps<any>) => {
  const api = useApi(bitbucketAuthApiRef);
  const errorApi = useApi(errorApiRef);
  const [mode, setMode] = useState('admin' as 'admin' | 'user' | 'token');
  const [name, setName] = useState('Admin Bitbucket');
  const [username, setUsername] = useState('');
  const [token, setToken] = useState('');
  let [workspaces, setWorkspaces] = useState([] as any[]);
  const [workspace, setWorkspace] = useState('');
  const [projects, setProjects] = useState([] as any[]);
  const [project, setProject] = useState('');
  const [repoName, setRepoName] = useState('');
  const [workspaceErrors, setWorkspaceErrors] = useState([] as string[]);
  const [projectErrors, setProjectErrors] = useState([] as string[]);
  const [repoNameErrors, setRepoNameErrors] = useState([] as string[]);
  const [loading, setLoading] = useState(false);
  let [axiosConfig, setAxiosConfig] = useState({} as AxiosRequestConfig);
  const templateSecrets = useTemplateSecrets();
  const [subscription, setSubscription] = useState<Subscription>();
  const [loadingRepoName, setLoadingRepoName] = useState<boolean>(false);

  useEffect(() => {
    (async () => {
      api.sessionState$().subscribe((state: SessionState) => {
        if (state === SessionState.SignedIn) {
          useUser();
        } else {
          useAdmin();
        }
      });
    })();
  }, []);

  const loadData = async () => {
    workspaces = await fetchWorkspaces();
    setWorkspaces(workspaces);
    const { workspace, project, repoName } = formData;
    if (workspace) {
      await handleWorkspaceChange(workspace);
    }
    if (project) {
      handleProjectChange(project);
    }
    if (repoName) {
      await handleRepoNameChange(repoName);
    }
  };

  const handleOAuthSignIn = async () => {
    try {
      await api.signIn();
    } catch (error) {
      console.error('OAuth sign-in error:', error);
    }
  };

  const useAdmin = async () => {
    setLoading(true);
    setWorkspaces([]);
    setProjects([]);
    setWorkspaceErrors([]);
    setProjectErrors([]);
    setRepoNameErrors([]);
    setMode('admin');
    setName('Admin Bitbucket');
    templateSecrets.setSecrets({ BITBUCKET_TOKEN: '' });
    try {
      const config = await getBitbucketConfig();
      const parsedConfig = JSON.parse(config);
      const appUserId = parsedConfig.username as string;
      const appPassword = parsedConfig.appPassword as string;
      axiosConfig = {
        auth: {
          username: appUserId,
          password: appPassword,
        },
      };
      setAxiosConfig(axiosConfig);
    } catch (error) {
      console.error('Error fetching config:', error);
    }
    await loadData();
    setLoading(false);
  };

  const useUser = async () => {
    setWorkspaces([]);
    setProjects([]);
    setWorkspaceErrors([]);
    setProjectErrors([]);
    setRepoNameErrors([]);
    const userToken = await api.getAccessToken();
    setLoading(true);
    setMode('user');
    setName((await api.getProfile())?.displayName ?? 'User');
    axiosConfig = {
      headers: {
        Authorization: `Bearer ${userToken}`,
      },
    };
    setAxiosConfig(axiosConfig);
    templateSecrets.setSecrets({ BITBUCKET_TOKEN: userToken });
    console.log(userToken);
    console.log(templateSecrets.secrets);
    workspaces = await fetchWorkspaces();
    setWorkspaces(workspaces);
    loadData();
    setLoading(false);
  };

  const useToken = async () => {
    setLoading(true);
    setWorkspaces([]);
    setProjects([]);
    setWorkspaceErrors([]);
    setProjectErrors([]);
    setRepoNameErrors([]);
    setMode('token');
    templateSecrets.setSecrets({ BITBUCKET_USERNAME: username });
    templateSecrets.setSecrets({ BITBUCKET_TOKEN: token });
    console.log(templateSecrets.secrets);
    axiosConfig = {
      headers: {
        Authorization: `Basic ${Buffer.from(`${username}:${token}`).toString(
          'base64',
        )}`,
      },
    };
    setAxiosConfig(axiosConfig);
    try {
      const response = await axios.get(
        `${BITBUCKET_BASE_URL}/user`,
        axiosConfig,
      );
      setName(response.data.display_name);
    } catch (error) {
      console.log(error);
      errorApi.post({
        name: 'Invalid token',
        message: 'Invalid token',
      });
      clearToken();
      return;
    }
    await loadData();
    setLoading(false);
  };

  const clearToken = async () => {
    setUsername('');
    templateSecrets.setSecrets({ BITBUCKET_USERNAME: '' });
    setToken('');
    await useAdmin();
  };

  const fetchWorkspaces = async () => {
    try {
      const pageSize = 100; // Adjust this to your desired page size

      let workspaces: any[] = [];
      let page = 1;

      let next = `${BITBUCKET_BASE_URL}/workspaces?fields=next,values.name,values.slug&page=${page}&pagelen=${pageSize}`;
      while (true) {
        const response = await axios.get(next, axiosConfig);

        workspaces.push(...response.data.values);

        if (!response.data.next) {
          break;
        }

        next = response.data.next;
      }
      return workspaces;
    } catch (error) {
      console.error('Error fetching workspaces:', error);
      return [];
    }
  };

  const fetchProjects = async (workspace: string) => {
    try {
      let allProjects: any[] | ((prevState: never[]) => never[]) = [];
      const pageSize = 100; // Adjust this to your desired page size

      let next = `${BITBUCKET_BASE_URL}/workspaces/${workspace}/projects?fields=next,values.name,values.key,values.uuid&pagelen=${pageSize}`;
      while (true) {
        const response = await axios.get(next, axiosConfig);

        if (response.data.values && response.data.values.length > 0) {
          allProjects = allProjects.concat(response.data.values);
        }

        if (!response.data.next) {
          break;
        }

        next = response.data.next;
      }

      return allProjects;
    } catch (error) {
      console.error('Error fetching projects:', error);
      return [];
    }
  };

  const handleWorkspaceChange = async (workspace: string) => {
    setWorkspace(workspace);
    setWorkspaceErrors([]);
    formData.workspace = workspace;
    onChange(formData);

    if (!workspaces.some(w => w.slug === workspace)) {
      switch (mode) {
        case 'admin':
          setWorkspaceErrors([
            'app-bs-pro@mapfre.com does not have access to this workspace',
          ]);
          break;
        case 'user':
          setWorkspaceErrors(['You do not have access to this workspace']);
          break;
        case 'token':
          setWorkspaceErrors(['Token does not have access to this workspace']);
          break;
      }
      onChange(formData);
    } else {
      const projects = await fetchProjects(workspace);
      setProjects(projects);
      if (projects.length === 0) {
        setProjectErrors(['Workspace with empty projects']);
      }
    }
  };

  const handleProjectChange = (project: string) => {
    setProject(project);
    setProjectErrors([]);
    if (project) {
      formData.project = project;
      onChange(formData);
    }
  };

  const handleRepoNameChange = async (repoName: string) => {
    setLoadingRepoName(true);
    setRepoName(repoName);
    if (subscription) {
      subscription.unsubscribe();
    }
    setSubscription(
      timer(3000).subscribe(async () => {
        formData.repoName = repoName;
        onChange(formData);
        if (repoName) {
          try {
            await axios.get(
              `${BITBUCKET_BASE_URL}/repositories/${workspace}/${repoName}?fields=slug`,
              axiosConfig,
            );
            setRepoNameErrors(['Repository already exists']);
            setLoadingRepoName(false);
          } catch (error) {
            setRepoNameErrors([]);
            setLoadingRepoName(false);
          }
        }
      }),
    );
  };

  const classes = useStyles();

  if (loading) {
    return <div className={classes.loading}></div>;
  }

  const signIn = (
    <Grid container spacing={2}>
      <Grid item>
        <Button
          variant="outlined"
          color="primary"
          style={{ width: '100px', height: '40px' }}
          onClick={async () => {
            await handleOAuthSignIn();
          }}
        >
          Sign in
        </Button>
      </Grid>
      <Grid item>
        <Tooltip
          title="Sign in to create repository with your own bitbucket user"
          arrow
        >
          <IconButton>
            <InfoIcon />
          </IconButton>
        </Tooltip>
      </Grid>
    </Grid>
  );

  const signOut = (
    <Grid container spacing={2}>
      <Grid item>
        <Button
          variant="outlined"
          color="primary"
          style={{ width: '100px', height: '40px' }}
          onClick={async () => {
            await api.signOut();
          }}
        >
          Sign out
        </Button>
      </Grid>
      <Grid item>
        <Tooltip
          title="Sign out to create repository with admin bitbucket user"
          arrow
        >
          <IconButton>
            <InfoIcon />
          </IconButton>
        </Tooltip>
      </Grid>
    </Grid>
  );

  const tokenField = (
    <Grid container spacing={2}>
      <Grid item>
        <Button
          variant="outlined"
          color="primary"
          disabled={!token}
          style={{ width: '150px', height: '40px' }}
          onClick={async () => {
            if (mode === 'token') {
              await clearToken();
            } else {
              await useToken();
            }
          }}
        >
          {mode !== 'token' ? 'Use token' : 'Clear token'}
        </Button>
      </Grid>
      <Grid item>
        <FormControl key="username" margin="normal">
          <Input
            value={username}
            placeholder="Bitbucket name"
            disabled={mode === 'token'}
            onChange={event => setUsername(event.target.value)}
            style={{ width: '150px' }}
          />
        </FormControl>
      </Grid>
      <Grid item>
        <FormControl key="token" margin="normal">
          <Input
            value={token}
            placeholder="Bitbucket token"
            disabled={mode === 'token'}
            onChange={event => setToken(event.target.value)}
            style={{ width: '150px' }}
          />
        </FormControl>
      </Grid>
      <Grid item>
        <Tooltip
          title="Use a token insted of the admin user, it need this permissions: repository:write, repository:admin, project:write, workspace:read, account:read"
          arrow
        >
          <IconButton>
            <InfoIcon />
          </IconButton>
        </Tooltip>
      </Grid>
    </Grid>
  );

  let modeChanger;
  switch (mode) {
    case 'user':
      modeChanger = <>{signOut}</>;
      break;
    case 'admin':
    case 'token':
      modeChanger = (
        <>
          <div style={{ marginBottom: '20px' }}>{signIn}</div>
          {tokenField}
        </>
      );
      break;
  }

  return (
    <>
      <Card style={{ marginBottom: '20px', width: '400px' }}>
        <CardContent>
          <Typography variant="h3">{schema.title}</Typography>
          <Typography variant="subtitle1">
            {schema.description}{' '}
            {mode === 'admin' && (
              <>
                Admin user <strong>app-bs-pro@mapfre.com</strong> must have
                invited to workspace and project with admin privileges.
              </>
            )}
          </Typography>
          <FormControl margin="normal">
            <FormControl key="workspace" margin="normal">
              <InputLabel>
                {`${(schema.properties?.workspace as any).title}${
                  schema.required?.includes('workspace') && '*'
                }`}
              </InputLabel>
              {mode === 'user' || mode === 'token' ? (
                <Select
                  value={workspace}
                  onChange={event =>
                    handleWorkspaceChange(event.target.value as string)
                  }
                  autoFocus
                  disabled={uiSchema.workspace['ui:disabled']}
                  error={
                    workspaceErrors.length > 0 ||
                    (errorSchema.workspace?.__errors &&
                      (errorSchema.workspace.__errors as any).length > 0)
                  }
                  style={{ width: '200px' }}
                >
                  {workspaces.map(workspace => (
                    <MenuItem key={workspace.name} value={workspace.slug}>
                      {workspace.slug}
                    </MenuItem>
                  ))}
                </Select>
              ) : (
                <Input
                  value={workspace}
                  onChange={async event =>
                    await handleWorkspaceChange(event.target.value)
                  }
                  autoFocus
                  disabled={uiSchema.workspace['ui:disabled']}
                  error={
                    workspaceErrors.length > 0 ||
                    (errorSchema.workspace?.__errors &&
                      (errorSchema.workspace?.__errors as any).length > 0)
                  }
                  style={{ width: '200px' }}
                />
              )}
              <FormHelperText>
                {(schema.properties?.workspace as any).description}
              </FormHelperText>
              <div>
                {[
                  ...workspaceErrors,
                  ...(errorSchema.project?.__errors
                    ? (errorSchema.project?.__errors as any)
                    : []),
                ].map((error: string) => (
                  <FormHelperText key={error} error>
                    {error}
                  </FormHelperText>
                ))}
              </div>
            </FormControl>

            <div></div>
            <FormControl key="project" margin="normal">
              <InputLabel>
                {`${(schema.properties?.project as any).title}${
                  schema.required?.includes('project') && '*'
                }`}
              </InputLabel>
              <Select
                value={project}
                onChange={event =>
                  handleProjectChange(event.target.value as string)
                }
                autoFocus
                disabled={projects.length === 0}
                error={projectErrors.length > 0}
                style={{ width: '200px' }}
              >
                {projects.map(project => (
                  <MenuItem key={project.uuid} value={project.key}>
                    {project.name}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>
                {(schema.properties?.project as any).description}
              </FormHelperText>
              <div>
                {[
                  ...projectErrors,
                  ...(errorSchema.project?.__errors
                    ? (errorSchema.project?.__errors as any)
                    : []),
                ].map((error: string) => (
                  <FormHelperText key={error} error>
                    {error}
                  </FormHelperText>
                ))}
              </div>
            </FormControl>

            <div></div>
            {schema.properties?.repoName && (
              <FormControl key="repoName" margin="normal">
                <InputLabel>
                  {`${(schema.properties?.repoName as any).title}${
                    schema.required?.includes('repoName') && '*'
                  }`}
                </InputLabel>
                <Input
                  value={repoName}
                  onChange={async event =>
                    await handleRepoNameChange(event.target.value)
                  }
                  autoFocus
                  disabled={!workspace || !project}
                  error={repoNameErrors.length > 0}
                  style={{ width: '200px' }}
                />
                <FormHelperText>
                  {(schema.properties?.repoName as any).description}
                </FormHelperText>
                <div>
                  {[
                    ...repoNameErrors,
                    ...(errorSchema.repoName?.__errors
                      ? (errorSchema.repoName?.__errors as any)
                      : []),
                  ].map((error: string) => (
                    <FormHelperText key={error} error>
                      {error}
                    </FormHelperText>
                  ))}
                </div>
                {loadingRepoName && (
                  <CircularProgress
                    style={{ position: 'absolute', right: '100px' }}
                  />
                )}
              </FormControl>
            )}
          </FormControl>
        </CardContent>
      </Card>
      <Card style={{ marginBottom: '5px', width: '600px' }}>
        <CardContent>
          <Typography variant="subtitle1" style={{ marginBottom: '20px' }}>
            Change bitbucket user between admin, your user or token
            <br />
            Using <strong>{name}</strong> user
          </Typography>
          {modeChanger}
        </CardContent>
      </Card>
    </>
  );
};
