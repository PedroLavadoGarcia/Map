import React, { useEffect, useState } from 'react';
import { FieldProps } from '@rjsf/core';
import FormControl from '@material-ui/core/FormControl';
import {
  FormGroup,
  FormControlLabel,
  Checkbox,
  TextField,
  Typography,
  Grid,
  CardContent,
  Card,
} from '@mui/material';
import axios from 'axios';
import { useApi, configApiRef } from '@backstage/core-plugin-api';
import { Select } from '@backstage/core-components';
import { IconButton } from '@material-ui/core';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ClearIcon from '@material-ui/icons/Clear';

interface MetadataResponse {
  [param: string]: Param;
}

type Param = TextParam | SingleSelectParam | ActionParam | HierarchicalMultiSelectParam;

interface IParam {
  type: 'hierarchical-multi-select' | 'single-select' | 'action' | 'text';
  default: any;
}

interface TextParam extends IParam {
  type: 'text';
  default: string;
}

interface SingleSelectParam extends IParam {
  type: 'single-select';
  default: string;
  values: {
    id: string;
    name: any;
  }[];
}

interface ActionParam extends IParam {
  type: 'action';
  default: string;
  values: {
    id: string;
    name: any;
  }[];
}

interface HierarchicalMultiSelectParam extends IParam {
  type: 'hierarchical-multi-select';
  values: {
    name: string;
    values: {
      id: string;
      name: string
    }[];
  }[];
}

export const MetadataExtension = ({
  onChange,
  rawErrors,
  required,
  formData,
  uiSchema,
  formContext
}: FieldProps) => {
  const componentId = formContext.formData.componentId;
  const { metadataType } = uiSchema['ui:options'] as {
    metadataType: 'gaia' | 'spring';
  };
  const [metadata, setMetadata] = useState<MetadataResponse>();
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [show, setShow] = useState(false);

  const configApi = useApi(configApiRef);
  const baseUrl = configApi.getString('backend.baseUrl');

  useEffect(() => {
    const fetchDependencies = async () => {
      try {
        const response = await axios.get<MetadataResponse>(`${baseUrl}/api/metadata/${metadataType}?name=${componentId}`);
        setMetadata(response.data);
        setDefaultFormData(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dependencies:', error);
        setLoading(false);
      }
    };

    fetchDependencies();
  }, []);

  const setDefaultFormData = (data: MetadataResponse) => {
    const defaultFormData: any = {};
    for (const key in data) {
      const param = data[key];
      defaultFormData[key] = param.default;
    }
    onChange(defaultFormData);
  }

  const handleChange = (key: string, value: any) => {
    const updatedFormData = {
      ...formData,
      [key]: value
    };
    onChange(updatedFormData);
  };

  if (loading) {
    return <div>Loading gaia boot initializr metadata...</div>;
  }

  if (!metadata) {
    return <div>Error loading gaia boot initializr metadata</div>;
  }

  return (
    <FormControl
      margin="normal"
      required={required}
      error={rawErrors?.length > 0 && !formData}
    >
      {
        Object.keys(metadata).sort((a, b) => {
          const typeOrder = {
            text: 0,
            action: 1,
            'single-select': 2,
            'hierarchical-multi-select': 3
          }
          const typeA = metadata[a].type;
          const typeB = metadata[b].type;

          return typeOrder[typeA] - typeOrder[typeB];
        }).map(paramName => {
          const param = metadata[paramName];
          if (param.type === 'text') {
            return (
              <TextField
                key={paramName}
                label={paramName}
                value={formData[paramName]}
                onChange={e => handleChange(paramName, e.target.value)}
                fullWidth
                margin="normal"
                InputLabelProps={{ shrink: true }}
                style={{
                  textTransform: 'capitalize'
                }}
              />
            );
          }
          if (param.type === 'single-select' || param.type === 'action') {
            return (
              <div key={paramName} style={{
                marginBottom: '10px',
                textTransform: 'capitalize'
              }}>
                <Select
                  label={paramName}
                  items={param.values.map(v => ({label: v.name, value: v.id}))}
                  selected={formData[paramName]}
                  onChange={value => handleChange(paramName, value)}
                />
              </div>
            );
          }
          if (param.type === 'hierarchical-multi-select') {
            const filteredValues = param.values.filter((item) =>
              item.values.some((value) =>
                value.name.toLowerCase().includes(searchQuery.toLowerCase()),
              ),
            ) ?? [];
            return (
              <FormGroup key={paramName}>
                <label
                  style={{
                    textTransform: 'capitalize',
                    fontSize: '0.875rem',
                    fontWeight: 'bold'
                  }}
                >{paramName}</label>
                <TextField
                  label="Search"
                  value={searchQuery}
                  onChange={e => {
                    if (e.target.value) {
                      setShow(true)
                    }
                    setSearchQuery(e.target.value)
                  }}
                  fullWidth
                  margin="normal"
                  style={{
                    marginBottom: '20px'
                  }}
                  InputProps={{
                    endAdornment:
                      <IconButton edge="end" onClick={() => setSearchQuery('')}>
                        <ClearIcon />
                      </IconButton>
                  }}
                />
                <IconButton edge="end" onClick={() => setShow(!show)}>
                  {show ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                </IconButton>
                {
                  searchQuery || show ?
                    <Grid container spacing={2} sx={{ flexGrow: 1 }}>
                      {filteredValues.map((item) => (
                        <Grid item xs={12} sm={6} md={4} key={item.name}>
                          <Card sx={{ backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
                            <CardContent sx={{ padding: '16px', display: 'block' }}>
                              <Typography
                                variant="h6"
                                sx={{ fontWeight: 'bold', marginBottom: '8px' }}
                              >
                                {item.name}
                              </Typography>
                              {item.values.map(value => {
                                const paramValue = formData[paramName] ? (formData[paramName] as string).split(',') : [];
                                const checked = paramValue.includes(value.id);
                                const handleChangeChecked = (key: string, c: boolean) => {
                                  if (c) {
                                    paramValue.push(key);
                                  } else {
                                    const index = paramValue.indexOf(key, 0);
                                    if (index > -1) {
                                      paramValue.splice(index, 1);
                                    }
                                  }
                                  const updatedFormData = {
                                    ...formData,
                                    [paramName]: paramValue.join(',')
                                  };
                                  console.log(updatedFormData);
                                  onChange(updatedFormData);
                                };
                                return (
                                  <FormControlLabel
                                    key={value.id}
                                    control={
                                      <Checkbox
                                        // @ts-ignore
                                        checked={checked}
                                        // @ts-ignore
                                        onChange={() => handleChangeChecked(value.id, !checked)}
                                      />
                                    }
                                    // @ts-ignore
                                    label={value.name}
                                  />
                                )
                              })}
                            </CardContent>
                          </Card>
                        </Grid>
                      ))}
                    </Grid> : null
                }
              </FormGroup>
            );
          }
          return null;
        })
      }
    </FormControl>
  );
};


