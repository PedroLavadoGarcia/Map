/* eslint-disable @typescript-eslint/no-explicit-any */
import { type EntityFilterQuery } from '@backstage/catalog-client';
import { useApi } from '@backstage/core-plugin-api';
import { TextField } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Autocomplete from '@material-ui/lab/Autocomplete';
import React, { useEffect } from 'react';
import useAsync from 'react-use/lib/useAsync';
import { EntityPickerProps } from './schema';
import { useTranslation } from 'react-i18next';
import {
  catalogApiRef,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import { UserEntityV1alpha1 } from '@backstage/catalog-model';

/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */
export const OwnerExtension = (props: EntityPickerProps) => {
  const { t } = useTranslation();

  const {
    onChange,
    schema: { title = 'Owner', description = t('The owner of the component') },
    required,
    uiSchema,
    rawErrors,
    formData,
    idSchema,
  } = props;
  const allowedKinds = uiSchema['ui:options']?.allowedKinds;

  const catalogFilter: EntityFilterQuery | undefined =
    (uiSchema['ui:options']?.catalogFilter as EntityFilterQuery) ||
    (allowedKinds && { kind: allowedKinds });

  const catalogApi = useApi(catalogApiRef);

  const { value: entities, loading } = useAsync(() =>
    catalogApi.getEntities(
      catalogFilter ? { filter: catalogFilter } : undefined,
    ),
  );

  const userEntity = entities?.items as UserEntityV1alpha1[];

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const entityRefs = userEntity
    ?.map(e => `<${e.spec?.profile?.email}> : ${e.spec?.profile?.displayName}`)
    .filter(ent => !ent.includes('undefined'));

  const onSelect = (_: any, value: string | null) => {
    if (entities) {
      const entity = entities?.items.find(
        e =>
          e.metadata.name ===
          value
            ?.split(':')[0]
            .replaceAll('<', '')
            .replaceAll('>', '')
            .replaceAll('@', '_')
            .toLowerCase()
            .trim(),
      );

      if (entity) {
        onChange('user:' + entity?.metadata?.name);
      } else {
        onChange(undefined);
      }
    }
  };

  return (
    <FormControl
      margin="normal"
      required={required}
      error={rawErrors?.length > 0 && !formData}
    >
      <Autocomplete
        id={idSchema?.$id}
        value={(formData as string) || ''}
        loading={loading}
        options={entityRefs || []}
        onChange={onSelect}
        freeSolo={
          (uiSchema['ui:options']?.allowArbitraryValues as boolean) ?? true
        }
        renderInput={params => (
          <TextField
            {...params}
            label={title}
            margin="dense"
            helperText={description}
            FormHelperTextProps={{ margin: 'dense', style: { marginLeft: 0 } }}
            variant="outlined"
            required={required}
            InputProps={params.InputProps}
          />
        )}
      />
    </FormControl>
  );
};
