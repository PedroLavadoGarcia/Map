/* eslint-disable @typescript-eslint/no-explicit-any */
import { IconButton } from '@material-ui/core';
import React from 'react';
import { EntityPickerProps } from './schema';
import CancelIcon from '@material-ui/icons/Cancel';

/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */
export const DeleteFileExtension = (props: EntityPickerProps) => {
  const { uiSchema, formContext } = props;
  const contentKey = uiSchema['ui:options']?.content_key as string;

  function handleDeleteFile() {
    formContext.formData[contentKey] = undefined;
    const contentField = document.querySelector(
      `#root_${contentKey}`,
    ) as HTMLInputElement;
    contentField.value = '';
    const contentFieldParagraph = contentField.closest('p');
    const bulletedFilelist = contentFieldParagraph?.nextElementSibling;
    if (bulletedFilelist?.tagName.toLowerCase() === 'ul') {
      while (bulletedFilelist.firstChild) {
        bulletedFilelist.removeChild(bulletedFilelist.firstChild);
      }
    }
  }

  return (
    <p style={{ marginTop: -95, marginLeft: 250 }}>
      <IconButton
        aria-label="delete"
        style={{ width: '20px', display: 'inline' }}
        onClick={handleDeleteFile}
      >
        <CancelIcon />
      </IconButton>{' '}
    </p>
  );
};
