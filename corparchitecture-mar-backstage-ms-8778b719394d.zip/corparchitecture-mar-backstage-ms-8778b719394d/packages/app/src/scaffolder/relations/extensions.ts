import { scaffolderPlugin } from '@backstage/plugin-scaffolder';
import { createScaffolderFieldExtension } from '@backstage/plugin-scaffolder-react';
import { RelationsExtension } from './RelationsExtension';
import { SystemExtension } from './SystemExtension';
import { OwnerExtension } from './OwnerExtension';
import { DeleteFileExtension } from './DeleteFileExtension';
import { ActionsFileExtension } from './ActionsFileExtension';
import { TypologyExtension } from './TypologyExtension';
import { OauthField } from '../oauthExtension';

export const OauthFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'OauthFieldExtension',
    component: OauthField,
  }),
);

export const RelationsFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'RelationsExtension',
    component: RelationsExtension,
  }),
);

export const SystemFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'SystemExtension',
    component: SystemExtension,
  }),
);

export const DeleteFileFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'DeleteFileExtension',
    component: DeleteFileExtension,
  }),
);

export const ActionsFileFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'ActionsFileExtension',
    component: ActionsFileExtension,
  }),
);

export const OwnerFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'OwnerExtension',
    component: OwnerExtension,
  }),
);
export const TypologyFieldExtension = scaffolderPlugin.provide(
  createScaffolderFieldExtension({
    name: 'TypologyExtension',
    component: TypologyExtension,
  }),
);
