export const RELATION_AUTHORIZES_API = 'authorizesApis';
export const RELATION_API_AUTHORIZED_BY = 'apiAuthorizedBy';
export const RELATION_INVOKES_API = 'invokesApis';
export const RELATION_API_INVOKED_BY = 'apiInvokedBy';
export const RELATION_NEXT_VERSION_OF = 'nextVersionOf';
export const RELATION_PREVIOUS_VERSION_OF = 'previousVersionOf';
