import { TextField } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import React, { useState } from 'react';
import { EntityPickerProps } from './schema';
import MenuItem from '@mui/material/MenuItem';

/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */

export const TypologyExtension = (props: EntityPickerProps) => {
  const typologyRefs = [
    'API Consumer',
    'API Provider',
    'BFF API',
    'Business API',
    'Edge API',
    'Event',
    'External Services',
    'Login API',
    'Mediation API',
    'GW Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
  ];

  const {
    schema: { title = 'Typology' },
    required,
    rawErrors,
    idSchema,
    formContext,
  } = props;

  const initialValue = new URLSearchParams(window.location.search).get(
    'template',
  )
    ? new URLSearchParams(window.location.search).get('template')
    : formContext.formData.general_data.typology;
  const [value, setValue] = useState<string | null>(initialValue);

  const handleChange = (handleValue: string) => {
    const filterUrl = window.location.href.indexOf('&');
    const baseUrl =
      filterUrl !== -1
        ? window.location.href.substring(0, filterUrl)
        : window.location.href;
    const newUrl = `${baseUrl}&template=${handleValue}`;

    setValue(handleValue);

    // update the url and reload page
    window.history.replaceState(null, '', newUrl);
    window.location.reload();
  };
  return (
    <>
      <FormControl
        margin="normal"
        required={required}
        error={rawErrors?.length > 0 && !value}
      >
        <TextField
          select
          id={idSchema?.$id}
          label={title}
          margin="dense"
          variant="standard"
          required={required}
          value={value || ''}
          onChange={event => {
            handleChange(event.target.value as string);
          }}
        >
          {typologyRefs.map((option, i) => (
            <MenuItem key={i} value={option}>
              {option}
            </MenuItem>
          ))}
        </TextField>
      </FormControl>
    </>
  );
};
