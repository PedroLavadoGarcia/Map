/* eslint-disable @typescript-eslint/no-explicit-any */
import { type EntityFilterQuery } from '@backstage/catalog-client';
import { useApi } from '@backstage/core-plugin-api';
import {
  catalogApiRef,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import { TextField } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Autocomplete from '@material-ui/lab/Autocomplete';
import React from 'react';
import useAsync from 'react-use/lib/useAsync';
import { EntityPickerProps } from './schema';

/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */
export const SystemExtension = (props: EntityPickerProps) => {
  let { formData } = props;

  const {
    onChange,
    schema: { title = 'System' },
    required,
    uiSchema,
    rawErrors,
    formContext,
    idSchema,
  } = props;

  const allowedKinds = uiSchema['ui:options']?.allowedKinds;
  const country = formContext.formData.general_data.country as string;
  const catalogFilter: EntityFilterQuery | undefined =
    (uiSchema['ui:options']?.catalogFilter as EntityFilterQuery) ||
    (allowedKinds && { kind: allowedKinds });

  const defaultKind = uiSchema['ui:options']?.defaultKind;
  const defaultNamespace = uiSchema['ui:options']?.defaultNamespace;

  const catalogApi = useApi(catalogApiRef);

  const { value: entities, loading } = useAsync(() =>
    catalogApi.getEntities(
      catalogFilter ? { filter: catalogFilter } : undefined,
    ),
  );

  let entityRefs: string | any[] | undefined = [];

  if (country) {
    entityRefs = entities?.items
      .map(
        e =>
          // humanizeEntityRef(e, { defaultKind, defaultNamespace }),
          `${e.metadata.name}`,
      )
      .filter(ent => ent.includes(country.toLowerCase() + '-'));

    //Removes value if country changes
    if (formData) {
      if (!formData.includes(country.toLowerCase() + '-')) {
        formData = '';
        onChange(undefined);
      }
    }
  } else {
    entityRefs = [];
  }

  const onSelect = (_: any, value: string | null) => {
    if (entities) {
      const entity = entities?.items.find(e => e.metadata.name === value);

      const entityRef =
        entity &&
        humanizeEntityRef(entity, {
          defaultKind: defaultKind as string,
          defaultNamespace: defaultNamespace as string,
        });

      onChange(entityRef ?? undefined);
    }
  };

  return (
    <FormControl
      margin="normal"
      required={required}
      error={rawErrors?.length > 0}
    >
      <Autocomplete
        id={idSchema?.$id}
        value={(formData as string) || ''}
        loading={loading}
        onChange={onSelect}
        options={entityRefs || []}
        renderInput={params => (
          <TextField
            {...params}
            label={title}
            margin="dense"
            FormHelperTextProps={{ margin: 'dense', style: { marginLeft: 0 } }}
            variant="outlined"
            required={false}
            InputProps={params.InputProps}
          />
        )}
      />
    </FormControl>
  );
};
