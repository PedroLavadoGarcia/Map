/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { IconButton, Tooltip, Button } from '@material-ui/core';
import CancelIcon from '@material-ui/icons/Cancel';
import GetAppIcon from '@material-ui/icons/GetApp';
import { EntityPickerProps } from './schema';
/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */
export const ActionsFileExtension = (props: EntityPickerProps) => {
  const { onChange, uiSchema, formContext, idSchema } = props;
  const contentKey = uiSchema['ui:options']?.content_key as string;
  const contentKeyId = idSchema['$id'] as string;
  const acceptFileType = uiSchema['ui:options']?.accept as string;
  const downloadUrl = uiSchema['ui:options']?.download_url as string;
  const title = uiSchema['ui:options']?.title as string;
  const description = uiSchema['ui:options']?.description as string;
  let storedValue = formContext.formData[contentKey];

  if (contentKeyId.includes('instances')) {
    const index = contentKeyId.split('_')[2];
    if (
      formContext.formData['instances'] &&
      formContext.formData['instances'][index] &&
      contentKeyId.includes('gwDeployment') &&
      formContext.formData['instances'][index].gwDeployment_content
    ) {
      storedValue =
        formContext.formData['instances'][index].gwDeployment_content;

      let fileNameValue = storedValue.split(';name=')[1].split(';base64')[0];
      if (!(fileNameValue as string).includes('instance')) {
        storedValue = (storedValue as string).replace(
          /name=(.*);base64,/,
          'name=instance-' + index + '-' + fileNameValue + ';base64,',
        );
        fileNameValue =
          'doc/gwDeployment/instance-' + index + '-' + fileNameValue;
        formContext.formData['instances'][index].gwDeployment = fileNameValue;
      } else {
        formContext.formData['instances'][index].gwDeployment =
          'doc/gwDeployment/' + fileNameValue;
      }

      formContext.formData['instances'][index].gwDeployment_content =
        storedValue;
    }
  }

  const instancesWsrr = [
    'wsrr_files_ic',
    'wsrr_files_desa',
    'wsrr_files_pre',
    'wsrr_files_pro',
  ];
  const index = contentKeyId.split('_')[2];
  const subindex = contentKeyId.split('_')[6];

  instancesWsrr.forEach(env => {
    if (contentKeyId.includes('instances') && contentKeyId.includes(env)) {
      if (
        formContext.formData['instances'][index] &&
        formContext.formData['instances'][index][env] &&
        formContext.formData['instances'][index][env][subindex]
      ) {
        storedValue = formContext.formData['instances'][index][env][subindex];
      }
    }
  });

  const fileName = storedValue
    ? storedValue.split(';name=')[1].split(';base64')[0]
    : '';

  function handleDeleteFile() {
    //Remove file list message
    const fileList = document.getElementById('fileList_' + contentKeyId);
    if (fileList) {
      fileList.innerHTML = '';
      fileList.style.display = 'none';
    }

    //Remove file list error message
    const fileListError_ = document.getElementById(
      'fileListError_' + contentKeyId,
    );
    if (fileListError_) {
      fileListError_.innerHTML = '';
      fileListError_.style.display = 'none';
    }

    //Remove file preview message in input file
    const fileInput = document.getElementById(
      'fileInput_' + contentKeyId,
    ) as HTMLInputElement;
    if (fileInput) {
      fileInput.type = '';
      fileInput.type = 'file';
    }

    onChange(undefined);
  }

  function handleDownloadFile() {
    if (downloadUrl) {
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = '';
      link.target = '_blank';
      link.click();
    }
  }

  function handleFileInputChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) {
      const fileList = document.getElementById('fileList_' + contentKeyId);
      if (fileList) {
        fileList.innerHTML = '';
        fileList.style.display = 'none';
      }

      const fileListError_ = document.getElementById(
        'fileListError_' + contentKeyId,
      );
      if (fileListError_) {
        fileListError_.innerHTML = '';
        fileListError_.style.display = 'none';
      }

      const parts = file.name.split('.');
      const fileExtension = '.' + parts[parts.length - 1];

      //Check valid extension
      if (acceptFileType.includes(fileExtension) || acceptFileType === '*') {
        const reader = new FileReader();
        reader.onload = () => {
          const fileData = (reader.result as string).split(',')[1];

          const fileList = document.getElementById('fileList_' + contentKeyId);
          if (fileList) {
            fileList.style.display = 'block';
            const listItem = document.createElement('li');
            listItem.textContent = file.name;
            if (
              contentKeyId.includes('instances') &&
              contentKeyId.includes('gwDeployment')
            ) {
              const index = contentKeyId.split('_')[2];
              listItem.textContent = 'instance-' + index + '-' + file.name;
            }
            listItem.style.fontWeight = 'bold';
            fileList.appendChild(listItem);
          }
          onChange(
            `data:application/octet-stream;name=${file.name};base64,${fileData}`,
          );
        };
        reader.readAsDataURL(file);
      } else {
        const fileList = document.getElementById(
          'fileListError_' + contentKeyId,
        );
        if (fileList) {
          fileList.style.display = 'block';
          const listItem = document.createElement('li');
          listItem.textContent =
            'Invalid file, no file has been added. Allowed extensions ' +
            acceptFileType;
          listItem.style.fontWeight = 'bold';
          listItem.style.color = '#DB271C';
          fileList.appendChild(listItem);
        }

        onChange(undefined);
      }
    } else {
      onChange(undefined);
    }
  }

  return (
    <div>
      <div
        style={{
          display: downloadUrl == null ? 'none' : 'flex',
          alignItems: 'center',
          marginBottom: '10px',
        }}
      >
        <Tooltip title={downloadUrl || 'No download URL'}>
          <IconButton
            aria-label="download"
            style={{ marginRight: '10px' }}
            onClick={handleDownloadFile}
          >
            <GetAppIcon />
          </IconButton>
        </Tooltip>
        <span style={{ flexGrow: 1 }}>Download template</span>
      </div>

      <div
        className={'MuiTypography-h6'}
        style={{ display: 'flex', alignItems: 'center' }}
      >
        {title}
      </div>
      {description}
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <Button component="label">
          <input
            id={`fileInput_${contentKeyId}`}
            type="file"
            accept={acceptFileType}
            onChange={handleFileInputChange}
          />
        </Button>
        {!contentKeyId.includes('wsrr_files') ? (
          <IconButton
            aria-label="delete"
            style={{ marginLeft: '10px' }}
            onClick={handleDeleteFile}
          >
            <CancelIcon />
          </IconButton>
        ) : (
          <></>
        )}
      </div>
      <div
        style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}
      >
        <ul
          id={`fileList_${contentKeyId}`}
          style={{
            listStyleType: 'disc',
            marginLeft: '10px',
            display: fileName !== '' ? 'block' : 'none',
          }}
        >
          <li>
            <strong>{fileName}</strong>
          </li>
        </ul>
        <ul
          id={`fileListError_${contentKeyId}`}
          style={{
            listStyleType: 'disc',
            marginLeft: '10px',
            display: 'none',
          }}
        ></ul>
      </div>
    </div>
  );
};
