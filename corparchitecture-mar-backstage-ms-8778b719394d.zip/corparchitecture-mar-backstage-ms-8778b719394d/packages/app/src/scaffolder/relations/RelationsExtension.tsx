/* eslint-disable @typescript-eslint/no-explicit-any */
import { type EntityFilterQuery } from '@backstage/catalog-client';
import { useApi } from '@backstage/core-plugin-api';
import {
  catalogApiRef,
  humanizeEntityRef,
} from '@backstage/plugin-catalog-react';
import { TextField } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Autocomplete from '@material-ui/lab/Autocomplete';
import React, { useState } from 'react';
import useAsync from 'react-use/lib/useAsync';
import { EntityPickerProps } from './schema';
import { useTranslation } from 'react-i18next';

/**
 * The underlying component that is rendered in the form for the `EntityPicker`
 * field extension.
 *
 * @public
 */
export const RelationsExtension = (props: EntityPickerProps) => {
  const { t } = useTranslation();

  const {
    onChange,
    schema: {
      title = 'API',
      description = t('Legend: Country code / Typology / Name / Version'),
    },
    required,
    uiSchema,
    rawErrors,
    formData,
    idSchema,
  } = props;

  const country = props.formContext.formData.general_data.country;

  const allowedKinds = uiSchema['ui:options']?.allowedKinds;

  const defaultKind = uiSchema['ui:options']?.defaultKind;
  const defaultNamespace = uiSchema['ui:options']?.defaultNamespace;

  const catalogApi = useApi(catalogApiRef);

  const [entityRefs, setEntityRefs] = useState<string[]>([]);

  const invokesApis = [
    'BFF API',
    'Business API',
    'GW Services',
    'Edge API',
    'External Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
    'Mediation API',
    'Event',
  ];
  const invokesApisWithLogin = [
    'BFF API',
    'Business API',
    'GW Services',
    'Edge API',
    'External Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
    'Mediation API',
    'Event',
    'Login API',
  ];
  const apiInvokedBy = [
    'Business API',
    'GW Services',
    'Edge API',
    'External Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
    'Login API',
    'Mediation API',
    'Event',
  ];
  const consumesApis = [
    'BFF API',
    'Business API',
    'GW Services',
    'Edge API',
    'External Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
    'Login API',
    'Mediation API',
  ];
  const apiConsumedBy = ['API Provider', 'API Consumer'];
  const uthorizesApis = [
    'BFF API',
    'Business API',
    'GW Services',
    'Edge API',
    'External Services',
    'REST Services',
    'SOAP Services',
    'Virtual Services',
  ];
  const apiAuthorizedBy = ['Login API'];

  const relations = {
    'API Provider': {
      consumesApis: consumesApis,
      previousVersionOf: ['API Provider'],
      nextVersionOf: ['API Provider'],
    },
    'API Consumer': {
      consumesApis: consumesApis,
    },
    'BFF API': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['BFF API'],
      nextVersionOf: ['BFF API'],
    },
    'Business API': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['Business API'],
      nextVersionOf: ['Business API'],
    },
    'Edge API': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['Edge API'],
      nextVersionOf: ['Edge API'],
    },
    'External Services': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['External Services'],
      nextVersionOf: ['External Services'],
    },
    'GW Services': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['GW Services'],
      nextVersionOf: ['GW Services'],
    },
    'REST Services': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['REST Services'],
      nextVersionOf: ['REST Services'],
    },
    'SOAP Services': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['SOAP Services'],
      nextVersionOf: ['SOAP Services'],
    },
    'Virtual Services': {
      apiConsumedBy: apiConsumedBy,
      apiAuthorizedBy: apiAuthorizedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['Virtual Services'],
      nextVersionOf: ['Virtual Services'],
    },
    'Login API': {
      apiConsumedBy: apiConsumedBy,
      uthorizesApis: uthorizesApis,
      invokesApis: invokesApisWithLogin,
      apiInvokedBy: ['Login API'],
    },
    'Mediation API': {
      apiConsumedBy: apiConsumedBy,
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['Mediation API'],
      nextVersionOf: ['Mediation API'],
    },
    Event: {
      invokesApis: invokesApis,
      apiInvokedBy: apiInvokedBy,
      previousVersionOf: ['Event'],
      nextVersionOf: ['Event'],
    },
  };

  const { value: entities, loading } = useAsync(async () => {
    type ApiTypology = keyof typeof relations;
    const typology = props.formContext.formData.general_data.typology as
      | ApiTypology
      | undefined;

    const schemaField =
      typology &&
      (Object.keys(relations[typology] || {}).find(key =>
        props.idSchema.$id?.includes(key),
      ) as keyof (typeof relations)[ApiTypology] | undefined);

    if (typology && schemaField) {
      const rentitiesLoad = relations[typology][schemaField] as string[];
      if (rentitiesLoad) {
        const catalogFilter: EntityFilterQuery | undefined =
          (uiSchema['ui:options']?.catalogFilter as EntityFilterQuery) ||
          (allowedKinds && {
            kind: allowedKinds,
            'metadata.country': country,
            'metadata.typology': rentitiesLoad,
          });

        const entities = await catalogApi.getEntities(
          catalogFilter
            ? {
                filter: catalogFilter,
                fields: [
                  'apiVersion',
                  'kind',
                  'metadata.namespace',
                  'metadata.name',
                  'metadata.country',
                  'metadata.typology',
                  'metadata.title',
                  'metadata.version',
                ],
              }
            : undefined,
        );

        setEntityRefs(
          entities?.items.map(
            e =>
              `${e.metadata.country} / ${e.metadata.typology} / ${e.metadata.title} / ${e.metadata.version}`,
          ),
        );

        return entities;
      }
    }
    return undefined;
  });

  const onSelect = (_: any, value: string | null) => {
    if (entities) {
      const entity = entities?.items.find(
        e =>
          e.metadata.country === value?.split(' / ')[0] &&
          e.metadata.typology === value?.split(' / ')[1] &&
          e.metadata.title === value?.split(' / ')[2] &&
          e.metadata.version === value?.split(' / ')[3],
      );
      const entityRef =
        entity &&
        humanizeEntityRef(entity, {
          defaultKind: defaultKind as string,
          defaultNamespace: defaultNamespace as string,
        });

      onChange(entityRef ?? undefined);
    }
  };

  return (
    <FormControl
      margin="normal"
      required={required}
      error={rawErrors?.length > 0 && !formData}
    >
      <Autocomplete
        //disabled={entityRefs?.length === 1}
        id={idSchema?.$id}
        value={(formData as string) || ''}
        loading={loading}
        onChange={onSelect}
        options={entityRefs || []}
        freeSolo={
          (uiSchema['ui:options']?.allowArbitraryValues as boolean) ?? true
        }
        renderInput={params => (
          <TextField
            {...params}
            label={title}
            margin="dense"
            helperText={description}
            FormHelperTextProps={{ margin: 'dense', style: { marginLeft: 0 } }}
            variant="outlined"
            required={required}
            InputProps={params.InputProps}
          />
        )}
      />
    </FormControl>
  );
};
