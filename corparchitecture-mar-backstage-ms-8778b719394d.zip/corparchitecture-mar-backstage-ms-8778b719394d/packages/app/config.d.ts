export interface Config {
  app: {
    /**
     * Frontend root URL
     * @visibility frontend
     */
    env: string;
  };
}
