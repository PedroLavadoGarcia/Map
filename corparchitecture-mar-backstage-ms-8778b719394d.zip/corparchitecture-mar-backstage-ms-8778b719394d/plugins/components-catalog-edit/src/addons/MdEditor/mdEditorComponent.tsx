import React, { useEffect, useState, useCallback } from 'react';
import {
  Button,
  makeStyles,
  IconButton,
  DialogActions,
  DialogContent,
  Grid,
  Card,
  DialogTitle,
  Dialog,
  Snackbar,
  SnackbarContent,
} from '@material-ui/core';

import { Backdrop } from '@material-ui/core';

import { useEntity } from '@backstage/plugin-catalog-react';
import { getComponentSpecificFile } from '../../lib/getComponentSpecificFile';
import {
  useApi,
  identityApiRef,
  alertApiRef,
} from '@backstage/core-plugin-api';
import CachedIcon from '@material-ui/icons/Cached';
import { useTechDocsReaderPage } from '@backstage/plugin-techdocs-react';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { stringifyEntityRef } from '@backstage/catalog-model';
import usePrevious from './usePrevious';
import MDEditor from '@uiw/react-md-editor';
import { useShadowRootElements } from '@backstage/plugin-techdocs-react';
import { BackstageTheme } from '@backstage/theme';
//import { useUserProfile } from '@backstage/plugin-user-settings';
import { updateFile } from '../../lib/update';

const useStyles = makeStyles((theme: BackstageTheme) => ({
  container: {},
  showModalButton: {},
  content: {
    overflowY: 'auto',
  },
  modalContainer: {
    position: 'fixed',
    zIndex: 1100,
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    padding: 32,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalWrapper: {
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    padding: 32,
    height: '100%',
    overflow: 'auto',
    backgroundColor: theme.palette.background.default,
    boxShadow: '0px 8px 12px black',
    borderRadius: 8,
  },
  crossButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    cursor: 'pointer',
    width: 24,
    height: 24,
    padding: 0,
    marginBottom: 8,
    border: 'none',
    backgroundColor: 'transparent',
    '&:before, &:after': {
      position: 'absolute',
      content: '""',
      height: '100%',
      width: 3,
      top: '50%',
      left: '50%',
      backgroundColor: 'gray',
    },
    '&:before': {
      transform: 'translate(-50%, -50%) rotate(45deg)',
    },
    '&:after': {
      transform: 'translate(-50%, -50%) rotate(-45deg)',
    },
  },
  buttonGroup: {
    display: 'flex',
    marginTop: 16,
    '& button:first-child': {
      marginRight: 16,
    },
  },
}));

export const mdEditorComponentAddon = () => {
  const classes = useStyles();
  const PAGE_EDIT_LINK_SELECTOR = '[title^="Edit this page"]';
  const { entity } = useEntity();
  const identityApi = useApi(identityApiRef);
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const [fileContent, setFileContent] = useState<string | undefined>('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const prevIsModalVisible = usePrevious(isModalVisible);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  //const { profile } = useUserProfile();
  const { entityRef } = useTechDocsReaderPage();
  const refreshEntity = useCallback(async () => {
    await catalogApi.refreshEntity(stringifyEntityRef(entityRef));
    alertApi.post({ message: 'Refresh scheduled', severity: 'info' });
  }, [catalogApi, alertApi, entityRef]);

  const [editLink] = useShadowRootElements([PAGE_EDIT_LINK_SELECTOR]);
  const url = (editLink as HTMLAnchorElement)?.href ?? '';
  console.log('href md', url);

  useEffect(() => {
    if (prevIsModalVisible && !isModalVisible) {
      setFileContent('');
    }
  }, [isModalVisible, prevIsModalVisible]);

  const handleCurrentFile = async () => {
    const { token } = await identityApi.getCredentials();
    const entityDocsRepo =
      entity.metadata?.annotations?.['backstage.io/techdocs-ref'];
    console.log('Entity repo: ' + entityDocsRepo);
    if (!entityDocsRepo) {
      throw Error('Cannot retrieve entity repository view URL.');
    }
    console.log('Current file: ' + url);

    let modifiedHref = url.split('https://bitbucket.org/')[1];
    console.log('modifiedHref split: ' + modifiedHref);
    if (modifiedHref) {
      modifiedHref = modifiedHref.split('?')[0];
    }

    console.log(modifiedHref);
    if (modifiedHref) {
      // If there are selected files, fetch the content of the current doc file
      const replacedString = modifiedHref.replace(/\//g, '|');
      const fileContent = await getComponentSpecificFile(replacedString, token);
      console.log('File content: ' + fileContent);
      setFileContent(fileContent);
    } else {
      // Reset the file content if no files are selected
      console.log('You should check (edit href): ' + url);
      setFileContent('');
    }
  };

  const handleSave = async (fileContent: string, cb: () => void) => {
    const { token } = await identityApi.getCredentials();
    let modifiedHref = url.split('https://bitbucket.org/')[1];
    console.log('[handle save] modifiedHref split: ' + modifiedHref);
    if (modifiedHref) {
      modifiedHref = modifiedHref.split('?')[0];
    }
    console.log('[handle save]: ' + modifiedHref);
    if (modifiedHref) {
      // If there are selected files, fetch the content of the current doc file
      const replacedString = modifiedHref.replace(/\//g, '|');
      const res = await updateFile(replacedString, fileContent, token);

      if (res === 'ok') {
        console.log('[handle save] File updated successfully');
        setSnackbarMessage('File updated successfully');
        setSnackbarOpen(true);
      } else {
        console.log('[handle save] Something went wrong');
        setSnackbarMessage(
          'Failed file update. Something went wrong on our api side. Please try again later.',
        );
        setSnackbarOpen(true);
      }
    } else {
      // Reset the file content if no files are selected
      console.log('[handle save] You should check (edit href): ' + url);
      setFileContent('');
    }
    cb();
  };

  const [newFileContent, setNewFileContent] = useState<string | undefined>(
    fileContent,
  );
  useEffect(() => {
    if (fileContent !== undefined) {
      setNewFileContent(fileContent);
    }
  }, [fileContent]);

  return (
    <Grid item xs={9}>
      <Button
        onClick={async () => {
          await handleCurrentFile();
          setIsModalVisible(true);
        }}
      >
        Edit Online
      </Button>
      <IconButton
        aria-label="Refresh"
        title="Schedule entity refresh"
        onClick={refreshEntity}
      >
        <CachedIcon />
      </IconButton>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <SnackbarContent
          message={snackbarMessage}
          style={{
            backgroundColor: snackbarMessage.includes('Failed')
              ? 'red'
              : 'green',
          }}
        />
      </Snackbar>
      <div>
        <Dialog
          open={isModalVisible}
          onClose={() => setIsModalVisible(false)}
          aria-labelledby="scroll-dialog-title"
          aria-describedby="scroll-dialog-description"
          maxWidth="xl"
          style={{
            position: 'absolute',
          }}
          PaperProps={{
            style: {
              width: '70%',
              padding: '20px',
              backgroundColor: 'aliceblue', // Adjust background color as needed
              margin: 'auto',
              marginTop: '40px',
            },
          }}
        >
          <Backdrop open={isModalVisible} className={classes.modalContainer}>
            <DialogTitle id="scroll-dialog-title">Edit Online</DialogTitle>
            <DialogContent dividers className={classes.content}>
              <Grid container spacing={2} alignItems="flex-start">
                <Grid item xs={12}>
                  <Card>
                    <MDEditor
                      height={'auto'}
                      value={newFileContent}
                      onChange={setNewFileContent}
                    />
                  </Card>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button
                variant="contained"
                onClick={() =>
                  handleSave(newFileContent || '', () =>
                    setIsModalVisible(false),
                  )
                }
              >
                Save
              </Button>
              <Button
                variant="outlined"
                onClick={async () => {
                  setFileContent('');
                  setIsModalVisible(false);
                }}
              >
                Close
              </Button>
            </DialogActions>
          </Backdrop>
        </Dialog>
      </div>
    </Grid>
  );
};
