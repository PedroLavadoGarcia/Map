import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  useShadowRootElements,
  useTechDocsReaderPage,
  techdocsApiRef,
} from '@backstage/plugin-techdocs-react';
import { scmIntegrationsApiRef } from '@backstage/integration-react';
import {
  useApi,
  appThemeApiRef,
  alertApiRef,
} from '@backstage/core-plugin-api';
import {
  replaceGitHubUrlType,
  replaceGitLabUrlType,
} from '@backstage/integration';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { BackstageTheme } from '@backstage/theme';
import { useUserProfile } from '@backstage/plugin-user-settings';
import { stringifyEntityRef } from '@backstage/catalog-model';
// @ts-ignore
import parseGitUrl from 'git-url-parse';
import MDEditor from '@uiw/react-md-editor';
import { makeStyles } from '@material-ui/styles';
import {
  Grid,
  TextField,
  Button,
  InputAdornment,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  IconButton,
} from '@material-ui/core';
import CachedIcon from '@material-ui/icons/Cached';
import useAsync from 'react-use/lib/useAsync';

import usePrevious from './usePrevious';

const hostname = window.location.hostname;
const baseUrl = `http://${hostname}:7007/api/techdocsMdEditor`;

const PAGE_EDIT_LINK_SELECTOR = '[title^="Edit this page"]';
const resolveBlobUrl = (url: string, type: string) => {
  if (type === 'github') {
    return replaceGitHubUrlType(url, 'blob');
  } else if (type === 'gitlab') {
    return replaceGitLabUrlType(url, 'blob');
  } else if (type === 'bitbucketCloud') {
    return url.replace('/src/', '/src/master/');
  }
  // eslint-disable-next-line no-console
  console.error(
    `Invalid SCM type ${type} found in ReportIssue addon for URL ${url}!`,
  );
  return url;
};

const useGitRepository = () => {
  const scmIntegrationsApi = useApi(scmIntegrationsApiRef);

  const [editLink] = useShadowRootElements([PAGE_EDIT_LINK_SELECTOR]);
  const url = (editLink as HTMLAnchorElement)?.href ?? '';

  const type = useMemo(
    () => (url ? scmIntegrationsApi.byUrl(url)?.type : null),
    [url, scmIntegrationsApi],
  );

  const result = useMemo(
    () => (type ? { ...parseGitUrl(resolveBlobUrl(url, type)), type } : null),
    [type, url],
  );

  return result;
};

const useProjectId = () => {
  const { entityRef } = useTechDocsReaderPage();
  const techdocsApi = useApi(techdocsApiRef);
  const entityMetadata = useAsync(async () => {
    return techdocsApi.getEntityMetadata(entityRef);
  }, [entityRef]);
  const projectId = useMemo(() => {
    if (entityMetadata) {
      return entityMetadata.value?.metadata?.annotations?.[
        'gitlab.com/project-id'
      ];
    }
    return null;
  }, [entityMetadata]);
  return projectId;
};

const useStyles = makeStyles((theme: BackstageTheme) => ({
  container: {},
  showModalButton: {},
  modalContainer: {
    position: 'fixed',
    zIndex: 1100,
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    padding: 32,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalWrapper: {
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    padding: 32,
    height: '100%',
    overflow: 'auto',
    backgroundColor: theme.palette.background.default,
    boxShadow: '0px 8px 12px black',
    borderRadius: 8,
  },
  crossButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    cursor: 'pointer',
    width: 24,
    height: 24,
    padding: 0,
    marginBottom: 8,
    border: 'none',
    backgroundColor: 'transparent',
    '&:before, &:after': {
      position: 'absolute',
      content: '""',
      height: '100%',
      width: 3,
      top: '50%',
      left: '50%',
      backgroundColor: 'gray',
    },
    '&:before': {
      transform: 'translate(-50%, -50%) rotate(45deg)',
    },
    '&:after': {
      transform: 'translate(-50%, -50%) rotate(-45deg)',
    },
  },
  buttonGroup: {
    display: 'flex',
    marginTop: 16,
    '& button:first-child': {
      marginRight: 16,
    },
  },
}));

const handleCommit = (
  projectId: string,
  filePath: string,
  fileContent: string,
  commitMessage: string,
  user: { username: string; email: string },
  cb: () => void,
) => {
  if (projectId && filePath && user.username && user.email) {
    fetch(`${baseUrl}/updateFile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        projectId,
        filePath,
        email: user.email,
        name: user.username,
        content: fileContent,
        message: commitMessage,
      }),
    }).then(cb);
  }
};

const MdEditorModal: React.FC<{
  setIsModalVisible: (v: boolean) => void;
  fileName: string;
  fileContent: string | undefined;
  projectId: string;
  filePath: string;
  branchList: string[];
  selectedBranch: string | null;
  setSelectedBranch: (v: string) => void;
  user: { username: string; email: string };
}> = ({
  setIsModalVisible,
  fileName,
  fileContent,
  projectId,
  filePath,
  user,
  branchList,
  selectedBranch,
  setSelectedBranch,
}) => {
  const classes = useStyles();
  const themeApi = useApi(appThemeApiRef);
  const currentTheme = themeApi.getActiveThemeId();

  const [newFileContent, setNewFileContent] = useState<string | undefined>(
    fileContent,
  );
  const [commitMessage, setCommitMessage] = useState<string | undefined>('');
  const commitPrefix = '[backstage]';
  const handleCommitMessageChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setCommitMessage(e.target.value),
    [],
  );

  useEffect(() => {
    if (fileName) {
      setCommitMessage(`${fileName} update`);
    }
  }, [fileName]);

  useEffect(() => {
    if (fileContent !== undefined) {
      setNewFileContent(fileContent);
    }
  }, [fileContent]);

  return (
    <div className={classes.modalContainer}>
      <div data-color-mode={currentTheme} className={classes.modalWrapper}>
        <button
          className={classes.crossButton}
          onClick={() => setIsModalVisible(false)}
        />
        <MDEditor
          // @ts-ignore
          height="80%"
          value={newFileContent}
          onChange={setNewFileContent}
          visibleDragbar={false}
        />
        <Grid container>
          <Grid item xs={2} style={{ paddingTop: 24 }}>
            <FormControl fullWidth>
              <InputLabel id="branch-select">Branch</InputLabel>
              <Select
                id="branch-select"
                value={selectedBranch}
                label="Branch"
                onChange={e =>
                  setSelectedBranch((e.target.value as string) || '')
                }
              >
                {branchList.map(branch => (
                  <MenuItem value={branch} key={branch}>
                    {branch}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={10}>
            <TextField
              InputProps={{
                startAdornment: commitPrefix && (
                  <InputAdornment position="start">
                    {commitPrefix}
                  </InputAdornment>
                ),
              }}
              value={commitMessage}
              onChange={handleCommitMessageChange}
              label="Commit message"
              margin="normal"
              fullWidth
              multiline
            />
          </Grid>
        </Grid>
        <div className={classes.buttonGroup}>
          <Button
            variant="contained"
            onClick={() =>
              handleCommit(
                projectId,
                filePath,
                newFileContent || '',
                `${commitPrefix}: ${commitMessage}`,
                user,
                () => setIsModalVisible(false),
              )
            }
          >
            Commit
          </Button>
          <Button variant="outlined" onClick={() => setIsModalVisible(false)}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
};

export const MdEditor = () => {
  const classes = useStyles();
  const gitRepo = useGitRepository();
  const projectId = useProjectId();
  const { profile } = useUserProfile();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  // @ts-ignore
  const { username, emails } = profile || {};
  const email = emails && emails[0].value;
  const filePath = useMemo(
    () => (gitRepo ? gitRepo.filepath : null),
    [gitRepo],
  );
  const [fileContent, setFileContent] = useState<string | undefined>('');
  const fileName = useMemo(
    () => (gitRepo ? gitRepo.href.split('/').slice(-1)[0] : null),
    [gitRepo],
  );
  const [isModalVisible, setIsModalVisible] = useState(false);
  const prevIsModalVisible = usePrevious(isModalVisible);
  const [branchList, setBranchList] = useState<string[]>([]);
  const [selectedBranch, setSelectedBranch] = useState<string>('');

  const { entityRef } = useTechDocsReaderPage();

  const refreshEntity = useCallback(async () => {
    await catalogApi.refreshEntity(stringifyEntityRef(entityRef));
    alertApi.post({ message: 'Refresh scheduled', severity: 'info' });
  }, [catalogApi, alertApi, entityRef]);

  useEffect(() => {
    if (gitRepo && !fileContent && isModalVisible) {
      fetch(`${baseUrl}/readFile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: gitRepo.href }),
      })
        .then(res => res.json())
        .then(data => setFileContent(data.fileData));
    }
  }, [gitRepo, fileContent, isModalVisible]);

  useEffect(() => {
    if (gitRepo && isModalVisible && !branchList.length) {
      fetch(`${baseUrl}/branches?projectId=${projectId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then(res => res.json())
        .then(data => {
          const { data: branches } = data;
          const formattedBranches = branches
            .sort((a: { default: boolean }) => (a.default ? 1 : -1))
            .map((branch: { name: string }) => branch.name);
          setBranchList(formattedBranches);
          setSelectedBranch(formattedBranches[0]);
        });
    }
  }, [gitRepo, projectId, isModalVisible, branchList]);

  useEffect(() => {
    if (prevIsModalVisible && !isModalVisible) {
      setFileContent('');
      setBranchList([]);
      setSelectedBranch('');
    }
  }, [isModalVisible, prevIsModalVisible]);

  return (
    <div className={classes.container}>
      <Button onClick={() => setIsModalVisible(p => !p)}>Edit Online</Button>
      <IconButton
        aria-label="Refresh"
        title="Schedule entity refresh"
        onClick={refreshEntity}
      >
        <CachedIcon />
      </IconButton>
      {isModalVisible && (
        <MdEditorModal
          setIsModalVisible={setIsModalVisible}
          user={{ username, email }}
          projectId={projectId || ''}
          // @ts-ignore
          filePath={filePath}
          // @ts-ignore
          fileName={fileName}
          fileContent={fileContent}
          branchList={branchList}
          selectedBranch={selectedBranch}
          setSelectedBranch={setSelectedBranch}
        />
      )}
    </div>
  );
};
