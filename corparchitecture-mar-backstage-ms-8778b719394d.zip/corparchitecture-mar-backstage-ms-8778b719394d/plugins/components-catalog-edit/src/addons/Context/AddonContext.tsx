import React, { createContext, useState } from 'react';

export const AddonContext = createContext<AddonContextType>({} as AddonContextType);
interface AddonContextType {
  hrefValue: string;
  setHrefValue: (value: string) => void;
}

export const AddonContextProvider = ({ children }: any) => {
  const [hrefValue, setHrefValue] = useState('');

  return (
    <AddonContext.Provider value={{ hrefValue, setHrefValue }}>
      {children}
    </AddonContext.Provider>
  );
};