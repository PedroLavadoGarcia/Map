import { createPlugin } from '@backstage/core-plugin-api';
import { rootRouteRef } from './routes';
import {
  createTechDocsAddonExtension,
  TechDocsAddonLocations,
} from '@backstage/plugin-techdocs-react';
import { mdEditorComponentAddon } from './addons/MdEditor/mdEditorComponent';
import { MdEditor } from './addons/MdEditor/MdEditor';
import { HideEditButton } from './addons/HideEditButton';

export const componentsCatalogEditPlugin = createPlugin({
  id: 'components-catalog-edit',
  routes: {
    root: rootRouteRef,
  },
});

export const MdEditorComponent = componentsCatalogEditPlugin.provide(
  // This function "creates" the Addon given a component and location. If your
  // component can be configured via props, pass the prop type here too.
  createTechDocsAddonExtension({
    name: 'mdEditorComponentAddon',
    location: TechDocsAddonLocations.PrimarySidebar,
    component: mdEditorComponentAddon,
  }),
);

export const MdEditorAddon = componentsCatalogEditPlugin.provide(
  createTechDocsAddonExtension({
    name: 'MdEditor',
    location: TechDocsAddonLocations.PrimarySidebar,
    component: MdEditor,
  }),
);

export const HideEditButtonAddon = componentsCatalogEditPlugin.provide(
  createTechDocsAddonExtension({
    name: 'HideEditButton',
    location: TechDocsAddonLocations.Content,
    component: HideEditButton,
  }),
);
