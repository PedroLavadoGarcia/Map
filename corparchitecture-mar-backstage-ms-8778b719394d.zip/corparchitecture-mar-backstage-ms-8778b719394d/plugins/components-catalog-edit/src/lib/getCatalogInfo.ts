async function getCatalogInfo(
  entityViewUrl: string,
  token: string | undefined,
): Promise<string> {
  const url = new URL(
    `/api/components-editor/get-component/${
      entityViewUrl.split('/')[2].split('.')[0]
    }/${entityViewUrl.split('/')[3]}/catalog-info.yaml`,
    window.location.origin,
  );
  if (url.hostname === 'localhost' && url.port === '3000') url.port = '7007';

  const method = 'GET';

  const headers = new Headers();
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const request = new Request(url.toString(), {
    method,
    headers,
  });

  const res = await fetch(request);
  if (!res.ok) {
    throw Error('Cannot retrieve entity catalog-info.yaml');
  }

  return await res.text();
}

export { getCatalogInfo };
