export async function updateFile(
  filePath: string,
  fileContent: string | undefined,
  token: string | undefined,
): Promise<string> {
  const headers = new Headers();

  headers.set('Content-Type', 'application/json');
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const requestBody = { fileContent: `${fileContent}` };

  const res = await fetch(
    new Request(
      new URL(
        `/api/components-editor/update-component/${filePath}`,
        window.location.origin,
      ).toString(),
      {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody),
      },
    ),
  );
  if (res.ok) {
    return 'ok';
  }else{
    return "Couldn't commit the changes to the repository.";
  }
}
