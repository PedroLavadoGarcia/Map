async function getComponentSpecificFile(
  nodeIds: string,
  token: string | undefined,
): Promise<string> {
  const url = new URL(
    `/api/components-editor/get-component-file-bitbucket/${nodeIds}`,
    window.location.origin,
  );
  if (url.hostname === 'localhost' && url.port === '3000') url.port = '7007';

  const method = 'GET';

  const headers = new Headers();
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const request = new Request(url.toString(), {
    method,
    headers,
  });

  const res = await fetch(request);
  console.log(JSON.stringify(res));
  if (!res.ok) {
    throw Error(await res.text());
  }

  return await res.text();
}

export { getComponentSpecificFile };
