export async function uploadFiles(
  repositoryUrl: string,
  files: Record<string, string>,
  token: string | undefined,
): Promise<string> {
  const headers = new Headers();
  headers.set('Content-Type', 'application/json');
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const res = await fetch(
    new Request(
      new URL(
        `/api/components-editor/upload-component/${
          repositoryUrl.split('/')[2].split('.')[0]
        }/${repositoryUrl.split('/')[3]}`,
        window.location.origin.replace('3000', '7007'),
      ).toString(),
      {
        method: 'POST',
        headers,
        body: JSON.stringify({ files }),
      },
    ),
  );
  if (res.ok) {
    const text = await res.text();
    return text;
  }

  throw Error("Couldn't commit the changes to the repository.");
}
