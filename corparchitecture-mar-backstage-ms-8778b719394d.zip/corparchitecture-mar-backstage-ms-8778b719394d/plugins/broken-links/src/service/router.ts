import { errorHandler } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import axios from 'axios';

export interface RouterOptions {
  logger: Logger;
  appUrl: string;
  backendUrl: string;
}
export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const router = Router();
  router.use(express.json());

  const { appUrl, backendUrl } = options;

  router.put('/check', async (req, res) => {
    let { url } = req.body;
    url = url.replace(appUrl, `${backendUrl}/api/techdocs/static`);
    if (url.match(/component\/[^/]+\/docs/)) {
      url = url.replace('/docs', '');
    }
    if (url.includes('/catalog/')) {
      url = url.replace('/catalog/', '/docs/');
    }
    url += '/index.html';
    await axios.get(url).catch(error => {
      if (error.response?.status === 404) {
        console.log(url)
        return res.status(200).send('invalid');
      }
      return res.sendStatus(200);
    });
    return res.sendStatus(200);
  });

  router.use(errorHandler());
  return router;
}
