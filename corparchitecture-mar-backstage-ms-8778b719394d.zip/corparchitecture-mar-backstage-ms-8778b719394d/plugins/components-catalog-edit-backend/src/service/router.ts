import { errorHandler } from '@backstage/backend-common';
import { Config } from '@backstage/config';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import axios from 'axios';
import FormData from 'form-data';
import fetch from 'node-fetch';

//import { getBearerTokenFromAuthorizationHeader } from '@backstage/plugin-auth-node';
import {
  /*   AuthorizeResult, */
  PermissionEvaluator,
} from '@backstage/plugin-permission-common';
// import { componentsEditPermission } from '@backstage/plugin-components-catalog-edit-common';
// import { NotAllowedError } from '@backstage/errors';
import {
  S3Client,
  GetObjectCommand,
  DeleteObjectCommand,
  PutObjectCommand,
  S3ClientConfig,
  ListObjectsV2Command,
} from '@aws-sdk/client-s3';

export interface RouterOptions {
  logger: Logger;
  auth: Config[];
  permissions: PermissionEvaluator;
  zeus: Config;
}

export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const router = Router();
  const { auth /*permissions*/, zeus } = options;
  const accessKeyId: string = auth[0].getString('accessKeyId');
  const secretAccessKey: string = auth[0].getString('secretAccessKey');
  const region: string = auth[0].getString('region');

  const username: string = auth[2].getString('username');
  const appPassword: string = auth[2].getString('appPassword');

  const zeusUrl: string = zeus.getString('url');

  router.use(express.json());

  async function getBitbucketConfig(username: string, appPassword: string) {
    return {
      username,
      appPassword,
    };
  }

  async function getZeusUrl() {
    return {
      zeusUrl,
    };
  }
  async function getRepoFile(
    bucket: string,
    repo: string,
    filename: string,
  ): Promise<string> {
    try {
      const config: S3ClientConfig = {
        credentials: {
          accessKeyId: accessKeyId,
          secretAccessKey: secretAccessKey,
        },
        region: region,
      };

      const s3Client = new S3Client(config);
      const response = await s3Client.send(
        new GetObjectCommand({
          Bucket: bucket,
          Key: `${repo}/${filename}`,
        }),
      );

      console.log(response.Body);
      if (response.Body) {
        return await response.Body?.transformToString();
      }
      return 'Repository currently not available.';

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      return `Repository currently not available. ${error}`;
    }
  }

  async function getRepoFileGit(filepath: string) {
    try {
      const replacedString = filepath.replace(/\|/g, '/');
      const apiUrl = `https://api.bitbucket.org/2.0/repositories/${replacedString}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization:
            'Basic ' +
            Buffer.from(username + ':' + appPassword).toString('base64'),
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      console.error(error);
      return 'Could not retrieve from its remote location.';
    }
  }

  async function getRepo(bucket: string, repo: string): Promise<any> {
    try {
      const config: S3ClientConfig = {
        credentials: {
          accessKeyId: accessKeyId,
          secretAccessKey: secretAccessKey,
        },
        region: region,
      };

      const s3Client = new S3Client(config);

      const listParams = {
        Bucket: bucket,
        Prefix: `${repo}/`,
      };
      const listCommand = new ListObjectsV2Command(listParams);
      const { Contents } = await s3Client.send(listCommand);
      console.log(JSON.stringify(Contents));
      return Contents;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      return undefined;
    }
  }

  async function updateFile(filepath: string, fileContent: string) {
    // I do this because express doesn't allow the / character in the url to be parsed for requests. So I replace it with a | character and then replace it back here.
    const replacedString = filepath.replace(/\|/g, '/');
    const modifiedHref = replacedString.split('src/')[1];
    // Here I get the index of the first / character and then get the right part of the string after that.
    const firstSlashIndex = modifiedHref.indexOf('/');
    // Here I get the right part of the string after the first / character. Which is the file path.
    const rightPart = modifiedHref.substring(firstSlashIndex + 1);
    // Here I get the left part of the string before the first /src/ character. Which is the repo name.
    const modifiedHref2 = replacedString.split('/src/')[0];
    // Here I get the branch name from the url.
    const branch = modifiedHref.split('/')[0];
    const apiUrl = `https://api.bitbucket.org/2.0/repositories/${modifiedHref2}/src`;
    try {
      const formData = new FormData();
      formData.append('branch', branch);
      formData.append('message', `Updated ${filepath}`);
      const files: Record<string, string> = {
        [rightPart]: fileContent,
      };

      for (const [k, v] of Object.entries(files)) {
        if (v.startsWith('data:'))
          formData.append(k, Buffer.from(v.split(',')[1], 'base64'));
        else formData.append(k, Buffer.from(v, 'utf8'));
      }

      const response = await fetch(apiUrl.toString(), {
        method: 'POST',
        body: formData,
        headers: {
          Authorization: `Basic ${Buffer.from(
            `${username}:${appPassword}`,
            'binary',
          ).toString('base64')}`,
        },
      });
      console.log(response);

      return 'File updated successfully! ' + JSON.stringify(response);
    } catch (error: any) {
      console.log(error);
      return error;
    }
  }

  async function uploadFilesToRepo(
    bucket: string,
    repo: string,
    files: Record<string, string>,
  ): Promise<number | undefined> {
    let response = 201;
    if (Object.keys(files).length > 0) {
      try {
        const config: S3ClientConfig = {
          credentials: {
            accessKeyId: accessKeyId,
            secretAccessKey: secretAccessKey,
          },
          region: region,
        };

        const s3Client = new S3Client(config);

        for (const [k, v] of Object.entries(files)) {
          if (k.startsWith('delete_s3_file')) {
            console.log('Delete');
            console.log(k);
            await s3Client.send(
              new DeleteObjectCommand({
                Bucket: bucket,
                Key: `${repo}/${v}`,
              }),
            );
          } else {
            console.log('Add');
            console.log(k);

            if (v.startsWith('data:')) {
              await s3Client.send(
                new PutObjectCommand({
                  Bucket: bucket,
                  Key: `${repo}/${k}`.replaceAll('//', '/').replaceAll(':', ''),
                  Body: Buffer.from(v.split(',')[1], 'base64'),
                }),
              );
            } else {
              await s3Client.send(
                new PutObjectCommand({
                  Bucket: bucket,
                  Key: `${repo}/${k}`.replaceAll('//', '/').replaceAll(':', ''),
                  Body: Buffer.from(v, 'utf8').toString('utf8'),
                }),
              );
            }
          }
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      } catch (error: any) {
        if (error) {
          console.log(error);
          response = 500;
        }
      }
    }
    return response;
  }
  router.get('/get-component-files/:bucket/:repo', async (req, res) => {
    const text = await getRepo(req.params.bucket, req.params.repo);
    res.send(text);
  });

  router.get(
    '/get-component-file/:bucket/:repo/:filepath',
    async (req, res) => {
      const text = await getRepoFile(
        req.params.bucket,
        req.params.repo,
        req.params.filepath,
      );

      res.send(text);
    },
  );

  router.get('/get-bitbucket-config', async (_req, res) => {
    const text = await getBitbucketConfig(username, appPassword);
    res.send(text);
  });

  router.get('/get-zeus-url', async (_req, res) => {
    const text = await getZeusUrl();
    res.send(text);
  });

  router.get('/get-component-file-bitbucket/:filepath', async (req, res) => {
    const text = await getRepoFileGit(req.params.filepath);

    res.send(text);
  });

  router.get('/get-component/:bucket/:repo/:filename', async (req, res) => {
    const text = await getRepoFile(
      req.params.bucket,
      req.params.repo,
      req.params.filename,
    );

    res.send(text);
  });

  router.post('/update-component/:filepath', async (req, res) => {
    const status = await updateFile(req.params.filepath, req.body.fileContent);
    res.send(status);
  });

  router.post('/upload-component/:bucket/:repo', async (req, res) => {
    try {
      const status = await uploadFilesToRepo(
        req.params.bucket,
        req.params.repo,
        req.body.files,
      );

      res.send(status);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      if (error) {
        res.send(error);
      }
    }
  });

  // Eliminamos el archivo old-catalog-info.yaml
  router.get('/deletefile-component/:bucket/:repo', async (req, res) => {
    const config: S3ClientConfig = {
      credentials: {
        accessKeyId: accessKeyId,
        secretAccessKey: secretAccessKey,
      },
      region: region,
    };

    const s3Client = new S3Client(config);

    const deleteCommand = new DeleteObjectCommand({
      Bucket: req.params.bucket,
      Key: `${req.params.repo}/catalog-info.yaml`,
    });

    s3Client
      .send(deleteCommand)
      .then(data => {
        res.send(data);
      })
      .catch(error => {
        if (error) {
          res.send(error);
        }
      });
  });

  router.use(errorHandler());
  return router;
}
