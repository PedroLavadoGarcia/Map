/* eslint-disable @backstage/no-undeclared-imports */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { errorHandler, resolvePackagePath } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import AWS from 'aws-sdk';
import Ajv from 'ajv';
import { InputError } from '@backstage/errors';
import { gzipSync, gunzipSync } from 'zlib';
import fs from 'fs-extra';
import yaml from 'yaml';
import { Config } from '@backstage/config';
import handlebars from 'handlebars';
import path from 'path';
import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  S3ClientConfig,
} from '@aws-sdk/client-s3';

export interface RouterOptions {
  logger: Logger;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
  bucket: string;
  catalogClientThemesTable: string;
  catalogPropertiesTable: string;
  catalogTemplatesTable: string;
  catalogFormsTable: string;
  auth: Config[];
}

const ajv = new Ajv();

const schemaNewClient = {
  type: 'object',
  properties: {
    country: { type: 'string' },
    system: { type: 'string' },
    color: { type: 'string' },
    documentation: { type: 'string' },
    logo: { type: 'string' },
    smallLogo: { type: 'string' },
    nameSmallLogo: { type: 'string' },
    nameLogo: { type: 'string' },
  },
  required: ['system', 'color', 'documentation', 'logo', 'smallLogo'],
  additionalProperties: false,
};

const schemaNewProperty = {
  type: 'object',
  properties: {
    propertyName: { type: 'string' },
    propertyNameOption: { type: 'string' },
    propertyType: { type: 'string' },
    description: { type: 'string' },
    defaultValue: { type: 'string' },
    enum: { type: 'array' },
    required: { type: 'boolean' },
    newValue: { type: 'string' },
  },
  required: ['propertyName', 'propertyType', 'description'],
  additionalProperties: false,
};

const schemaNewTemplate = {
  type: 'object',
  properties: {
    templateName: { type: 'string' },
    general_data: { type: 'object' },
    liable_people: { type: 'object' },
    context_data: { type: 'object' },
    technical_data: { type: 'object' },
    service_availability: { type: 'object' },
    execution_permissions: { type: 'object' },
    functional_category: { type: 'object' },
    relations: { type: 'array' },
    tabs: { type: 'array' },
    extTabs: { type: 'array' },
  },
};

const schemaEnum = {
  type: 'object',
  properties: {
    propertyName: { type: 'string' },
    enumValue: { type: 'string' },
  },
  required: ['propertyName', 'enumValue'],
  additionalProperties: false,
};
export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const { auth } = options;
  const accessKeyIdS3: string = auth[0].getString('accessKeyId');
  const secretAccessKeyS3: string = auth[0].getString('secretAccessKey');
  const regionS3: string = auth[0].getString('region');
  const bucket: string = options.bucket;
  const accessKeyIdDynamo: string = options.accessKeyId;
  const secretAccessKeyDynamo: string = options.secretAccessKey;
  const regionDynamo: string = options.region;
  const catalogClientThemesTable = options.catalogClientThemesTable;
  const catalogPropertiesTable = options.catalogPropertiesTable;
  const catalogTemplatesTable = options.catalogTemplatesTable;
  const catalogFormsTable = options.catalogFormsTable;

  const creds = new AWS.Credentials(accessKeyIdDynamo, secretAccessKeyDynamo);
  const dynamoDB = new AWS.DynamoDB.DocumentClient({
    region: regionDynamo,
    apiVersion: '2012-08-10',
    credentials: creds,
  });

  const router = Router();
  router.use(express.json());

  // Listado de todos los temas de clientes externos existentes en la tabla
  router.get('/themes', (request, response, next) => {
    let params;

    if (request.query && request.query.country) {
      params = {
        FilterExpression: '#country = :country',
        ExpressionAttributeValues: {
          ':country': request.query.country,
        },
        ExpressionAttributeNames: { '#country': 'country' },
        TableName: catalogClientThemesTable,
      };
    } else {
      params = {
        TableName: catalogClientThemesTable,
      };
    }

    dynamoDB
      .scan(params)
      .promise()
      .then(data => {
        const dataThemes = data.Items as Record<string, unknown>[];

        const uncompressedThemes = dataThemes.map(theme => {
          const uncompressedTheme: Record<string, unknown> = {
            ...theme,
          };

          if (theme.logo) {
            const uncompressedLogo = gunzipSync(
              Buffer.from(theme.logo as string),
            ).toString();
            uncompressedTheme.logo = uncompressedLogo;
          }

          if (theme.smallLogo) {
            const uncompressedSmallLogo = gunzipSync(
              Buffer.from(theme.smallLogo as string),
            ).toString();
            uncompressedTheme.smallLogo = uncompressedSmallLogo;
          }

          return uncompressedTheme;
        });

        response.send(uncompressedThemes);
      })
      .catch(next);
  });

  router.get('/themescolors', (_request, response, next) => {
    const params = {
      TableName: catalogClientThemesTable,
    };
    dynamoDB
      .scan(params)
      .promise()
      .then(data => {
        const dataThemes = data.Items as Record<string, unknown>[];

        const simplifiedThemes = dataThemes.map(theme => ({
          system: theme.system,
          primaryColor: theme.color,
        }));

        response.send(simplifiedThemes);
      })
      .catch(next);
  });

  router.get('/themes/:systemName', (request, response, next) => {
    const params = {
      TableName: catalogClientThemesTable,
      KeyConditionExpression: '#system = :systemValue',
      ExpressionAttributeNames: {
        '#system': 'system',
      },
      ExpressionAttributeValues: {
        ':systemValue': request.params.systemName,
      },
    };
    dynamoDB
      .query(params)
      .promise()
      .then(data => {
        const item = data.Items?.[0];

        if (item) {
          const uncompressedItem: Record<string, unknown> = {
            ...item,
          };

          if (item.logo) {
            const compressedLogo = Buffer.from(item.logo, 'base64');
            const inflatedLogo = gunzipSync(compressedLogo).toString();
            uncompressedItem.logo = inflatedLogo;
          }

          if (item.smallLogo) {
            const compressedSmallLogo = Buffer.from(item.smallLogo, 'base64');
            const inflatedSmallLogo =
              gunzipSync(compressedSmallLogo).toString();
            uncompressedItem.smallLogo = inflatedSmallLogo;
          }

          response.send(uncompressedItem);
        } else {
          response.send(item);
        }
      })
      .catch(next);
  });

  // Creación de un nuevo tema para un cliente externo o modificación de uno existente
  router.post('/themes/new', async (request, response) => {
    try {
      const res = await putNewTheme(
        dynamoDB,
        request.body,
        catalogClientThemesTable,
      );
      response.send(res);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });

  // Añadir sistema al repositorio
  router.post('/themes/repo', async (request, response) => {
    try {
      const config: S3ClientConfig = {
        credentials: {
          accessKeyId: accessKeyIdS3,
          secretAccessKey: secretAccessKeyS3,
        },
        region: regionS3,
      };

      const s3Client = new S3Client(config);

      const miTemplate = handlebars.compile(
        Buffer.from(request.body.template, 'utf8').toString('utf8'),
      );

      const FILE_CONTENT = miTemplate({
        country: request.body.data.country,
        system: request.body.data.system,
        government: request.body.government,
      });

      await s3Client.send(
        new PutObjectCommand({
          Bucket: bucket,
          Key: `${(request.body.data.country as string).toUpperCase()}/${
            request.body.data.system
          }.yaml`,
          Body: Buffer.from(FILE_CONTENT, 'utf8').toString('utf8'),
        }),
      );

      const protocol = 'https://';
      const s3 = '.s3.';
      const amazonaws = '.amazonaws.com/';

      let catalogInfoUrl = '';
      catalogInfoUrl = protocol
        .concat(bucket)
        .concat(s3)
        .concat(regionS3)
        .concat(amazonaws)
        .concat(
          `${(request.body.data.country as string).toUpperCase()}/${
            request.body.data.system
          }.yaml`,
        );

      response.send(catalogInfoUrl);
    } catch (error) {
      response.send(error);
    }
  });

  // Modificación de un tema pasando como parámetro el sistema (key)
  router.put('/themes/edit/:system', async (request, response) => {
    try {
      const res = await editTheme(
        dynamoDB,
        request.body,
        request.params.system,
        catalogClientThemesTable,
      );
      response.send(res);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });
  // Eliminación de un tema pasando como parámetro el sistema (key)
  router.delete('/themes/delete/:system', async (request, response, next) => {
    const system = request.params.system;

    // Delete from Dynamo
    const params = {
      TableName: catalogClientThemesTable,
      Key: {
        system: system,
      },
    };
    dynamoDB
      .delete(params)
      .promise()
      .then(data => {
        response.send(data);
      })
      .catch(next);

    // Delete from S3
    const config: S3ClientConfig = {
      credentials: {
        accessKeyId: accessKeyIdS3,
        secretAccessKey: secretAccessKeyS3,
      },
      region: regionS3,
    };

    const s3Client = new S3Client(config);

    // Delete from S3
    await s3Client.send(
      new DeleteObjectCommand({
        Bucket: bucket,
        Key: `${(system.split('-')[0] as string).toUpperCase()}/${
          system.split('-')[1] as string
        }.yaml`,
      }),
    );
  });

  // Rutas de la pestaña metamodelo
  router.post('/properties/new', async (request, response) => {
    try {
      const res = await createNewProperty(
        dynamoDB,
        request.body,
        catalogPropertiesTable,
      );
      response.send(res);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });

  router.get('/properties', (_request, response, next) => {
    const params = {
      TableName: catalogPropertiesTable,
    };
    dynamoDB
      .scan(params)
      .promise()
      .then(data => {
        const dataProperties = data.Items as Record<string, unknown>[];
        dataProperties.sort((a, b) => {
          const nameA = (a.propertyName as string).toLowerCase();
          const nameB = (b.propertyName as string).toLowerCase();
          return nameA.localeCompare(nameB);
        });
        response.send(dataProperties);
      })
      .catch(next);
  });

  router.put(
    '/properties/edit/:propertyName/:propertyNameOption',
    async (request, response) => {
      try {
        const res = await editProperty(
          dynamoDB,
          request.body,
          request.params.propertyName,
          request.params.propertyNameOption,
          catalogPropertiesTable,
        );
        response.send(res);
      } catch (error) {
        if (error instanceof Error) {
          response.send(error.message);
        }
      }
    },
  );
  router.put(
    '/properties/enum/:propertyName',
    async (request, response, next) => {
      const valid = ajv.validate(schemaEnum, request.body);
      if (valid) {
        const params = {
          TableName: catalogPropertiesTable,
          Key: {
            propertyName: request.params.propertyName,
          },
          UpdateExpression:
            'SET #enum = list_append(if_not_exists(#enum, :empty_list), :newValue)',
          ExpressionAttributeNames: {
            '#enum': 'newValue',
          },
          ExpressionAttributeValues: {
            ':newValue': [request.body.newValue],
            ':empty_list': [],
          },
          ReturnValues: 'ALL_NEW',
        };

        dynamoDB
          .update(params)
          .promise()
          .then(data => response.send(data))
          .catch(next);
      } else {
        response.send(ajv.errors);
      }
    },
  );

  router.delete(
    '/properties/delete/:propertyName/:propertyNameOption',
    (request, response, next) => {
      const params = {
        TableName: catalogPropertiesTable,
        Key: {
          propertyName: request.params.propertyName,
          propertyNameOption: request.params.propertyNameOption,
        },
      };
      dynamoDB
        .delete(params)
        .promise()
        .then(data => {
          response.send(data);
        })
        .catch(next);
    },
  );

  // Rutas de la pestaña templates

  router.post('/templates/new', async (request, response) => {
    try {
      const res = await createNewTemplate(
        dynamoDB,
        request.body,
        catalogTemplatesTable,
      );
      response.send(res);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });

  router.get('/templates', (_request, response, next) => {
    const params = {
      TableName: catalogTemplatesTable,
    };
    dynamoDB
      .scan(params)
      .promise()
      .then(data => {
        const dataTemplates = data.Items as Record<string, unknown>[];
        dataTemplates.sort((a, b) => {
          const nameA = (a.templateName as string).toLowerCase();
          const nameB = (b.templateName as string).toLowerCase();
          return nameA.localeCompare(nameB);
        });
        response.send(dataTemplates);
      })
      .catch(next);
  });

  router.get('/templates/:templateName', (request, response, next) => {
    const templateName = request.params.templateName;

    const params = {
      TableName: catalogTemplatesTable,
      Key: {
        templateName: templateName,
      },
    };

    dynamoDB
      .get(params)
      .promise()
      .then(data => {
        const templateData = data.Item as Record<string, unknown>;
        if (templateData) {
          response.send(templateData);
        } else {
          response.status(404).send('Template not found');
        }
      })
      .catch(next);
  });

  router.delete('/templates/delete/:template', (request, response, next) => {
    const params = {
      TableName: catalogTemplatesTable,
      Key: {
        templateName: request.params.template,
      },
    };
    try {
      dynamoDB
        .delete(params)
        .promise()
        .then(data => {
          response.send(data);
        })
        .catch(next);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });

  router.post('/templates/createYaml', async (request, response) => {
    try {
      const TEMPLATE = request.body.template;

      const yamlResult = yaml.stringify(TEMPLATE);
      const yamlFilePath = 'template.yaml'; // Cambia el nombre si lo deseas

      fs.outputFileSync(yamlFilePath, yamlResult);
      response.send(yamlResult);
    } catch (error) {
      if (error instanceof Error) {
        response.send(error.message);
      }
    }
  });

  router.get('/catalogforms', (_request, response, next) => {
    const params = {
      TableName: catalogFormsTable,
    };
    dynamoDB
      .scan(params)
      .promise()
      .then(data => {
        const dataCatalogForms = data.Items as Record<string, unknown>[];

        response.send(dataCatalogForms);
      })
      .catch(next);
  });
  router.use(errorHandler());
  return router;
}

export async function putNewTheme(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, any>,
  catalogClientThemesTable: string,
) {
  const valid = ajv.validate(schemaNewClient, body.data);
  if (valid) {
    const compressedLogo = body?.data.logo
      ? gzipSync(body?.data.logo as string)
      : '';
    const compressedSmallLogo = body?.data.smallLogo
      ? gzipSync(body?.data.smallLogo as string)
      : '';

    const params = {
      TableName: catalogClientThemesTable,
      Key: {
        system: `${body.data.country}-${body.data.system}`,
      },
      UpdateExpression: `SET 
        #country = :country, 
        #color = :color, 
        #logo = :logo, 
        #nameLogo = :nameLogo, 
        #smallLogo = :smallLogo, 
        #nameSmallLogo = :nameSmallLogo, 
        #documentation = :documentation`,

      ExpressionAttributeNames: {
        '#country': 'country',
        '#color': 'color',
        '#logo': 'logo',
        '#nameLogo': 'nameLogo',
        '#smallLogo': 'smallLogo',
        '#nameSmallLogo': 'nameSmallLogo',
        '#documentation': 'documentation',
      },
      ExpressionAttributeValues: {
        ':country': body?.data.country,
        ':color': body?.data.color,
        ':logo': compressedLogo,
        ':nameLogo': body?.data.nameLogo,
        ':smallLogo': compressedSmallLogo,
        ':nameSmallLogo': body?.data.nameSmallLogo,
        ':documentation': body?.data.documentation,
      },
      ReturnValues: 'ALL_NEW',
    };

    return dynamoDB.update(params).promise();
  }
  const ajvErrorsString = JSON.stringify(ajv.errors, null, 2);
  throw new InputError('Invalid payload', ajvErrorsString);
}

export async function editTheme(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, any>,
  system: string,
  catalogClientThemesTable: string,
) {
  const valid = ajv.validate(schemaNewClient, body.dataEdit);
  if (valid) {
    const compressedLogo = gzipSync(body?.dataEdit.logo);
    const compressedSmallLogo = gzipSync(body?.dataEdit.smallLogo);
    const params = {
      TableName: catalogClientThemesTable,
      Key: {
        system: system,
      },
      UpdateExpression:
        'SET #color = :color, #documentation = :documentation, #logo = :logo, #smallLogo = :smallLogo, #nameSmallLogo = :nameSmallLogo, #nameLogo = :nameLogo',

      ExpressionAttributeNames: {
        '#color': 'color',
        '#documentation': 'documentation',
        '#logo': 'logo',
        '#smallLogo': 'smallLogo',
        '#nameSmallLogo': 'nameSmallLogo',
        '#nameLogo': 'nameLogo',
      },
      ExpressionAttributeValues: {
        ':color': body?.dataEdit.color,
        ':documentation': body?.dataEdit.documentation,
        ':logo': compressedLogo,
        ':smallLogo': compressedSmallLogo,
        ':nameSmallLogo': body?.dataEdit.nameSmallLogo,
        ':nameLogo': body?.dataEdit.nameLogo,
      },
      ReturnValues: 'ALL_NEW',
    };

    return dynamoDB.update(params).promise();
  }
  const ajvErrorsString = JSON.stringify(ajv.errors, null, 2);
  throw new InputError('Invalid payload', ajvErrorsString);
}

export async function createNewProperty(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, any>,
  catalogPropertiesTable: string,
) {
  const valid = ajv.validate(schemaNewProperty, body.data);
  if (valid) {
    const params = {
      TableName: catalogPropertiesTable,
      Key: {
        propertyName: body.data.propertyName,
        propertyNameOption: body.data.propertyNameOption
          ? body.data.propertyNameOption
          : body.data.propertyName,
      },

      UpdateExpression: `SET  
        #propertyType = :propertyType, 
        #defaultValue = :defaultValue, #description = :description, 
        #enum = list_append(if_not_exists(#enum, :empty_list), :enum), 
        #required = :required`,

      ExpressionAttributeNames: {
        '#propertyType': 'propertyType',
        '#enum': 'enum',
        '#defaultValue': 'defaultValue',
        '#description': 'description',
        '#required': 'required',
      },
      ExpressionAttributeValues: {
        ':propertyType': body?.data.propertyType,
        ':enum': body?.data.enum,
        ':empty_list': [],
        ':defaultValue': body?.data.defaultValue ? body?.data.defaultValue : '',
        ':description': body?.data.description ? body?.data.description : '',
        ':required': body?.data.required ? body?.data.required : false,
      },
      ReturnValues: 'ALL_NEW',
    };

    return dynamoDB.update(params).promise();
  }
  throw new InputError('Invalid payload', ajv.errors);
}
export async function editProperty(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, any>,
  propertyName: string,
  propertyNameOption: string,
  catalogPropertiesTable: string,
) {
  const valid = ajv.validate(schemaNewProperty, body.dataEdit);
  if (valid) {
    const params = {
      TableName: catalogPropertiesTable,
      Key: {
        propertyName: propertyName,
        propertyNameOption: propertyNameOption,
      },
      UpdateExpression:
        'SET  #propertyType = :propertyType, #defaultValue = :defaultValue, #description = :description, #enum = :enum, #required = :required',

      ExpressionAttributeNames: {
        '#propertyType': 'propertyType',
        '#enum': 'enum',
        '#defaultValue': 'defaultValue',
        '#description': 'description',
        '#required': 'required',
      },
      ExpressionAttributeValues: {
        ':propertyType': body?.dataEdit.propertyType,
        ':enum': body?.dataEdit.enum,
        ':defaultValue': body?.dataEdit.defaultValue,
        ':description': body?.dataEdit.description,
        ':required': body?.dataEdit.required,
      },
      ReturnValues: 'ALL_NEW',
    };

    return dynamoDB.update(params).promise();
  }
  throw new InputError('Invalid payload', ajv.errors);
}

export async function createNewTemplate(
  dynamoDB: AWS.DynamoDB.DocumentClient,
  body: Record<string, any>,
  catalogTemplatesTable: string,
) {
  const valid = ajv.validate(schemaNewTemplate, body.data);
  if (valid) {
    const params = {
      TableName: catalogTemplatesTable,
      Key: {
        templateName: body.data.templateName,
      },
      UpdateExpression: `
      SET
        #general_data = :general_data,
        #liable_people = :liable_people,
        #context_data = :context_data,
        #technical_data = :technical_data,
        #service_availability = :service_availability,
        #execution_permissions = :execution_permissions,
        #functional_category = :functional_category,
        #relations = :relations,
        #descriptionTemplate = :descriptionTemplate,
        #tabs = :tabs,
        #extTabs = :extTabs
      `,
      ExpressionAttributeNames: {
        '#general_data': 'general_data',
        '#technical_data': 'technical_data',
        '#liable_people': 'liable_people',
        '#context_data': 'context_data',
        '#service_availability': 'service_availability',
        '#execution_permissions': 'execution_permissions',
        '#functional_category': 'functional_category',
        '#relations': 'relations',
        '#descriptionTemplate': 'descriptionTemplate',
        '#tabs': 'tabs',
        '#extTabs': 'extTabs',
      },
      ExpressionAttributeValues: {
        ':general_data': body?.data?.general_data,
        ':technical_data': body?.data?.technical_data,
        ':liable_people': body?.data?.liable_people,
        ':context_data': body?.data?.context_data,
        ':service_availability': body?.data?.service_availability,
        ':execution_permissions': body?.data?.execution_permissions,
        ':functional_category': body?.data?.functional_category,
        ':relations': body?.data?.relations,
        ':descriptionTemplate': body?.data?.descriptionTemplate,
        ':tabs': body?.data?.tabs,
        ':extTabs': body?.data?.extTabs,
      },
      ReturnValues: 'ALL_NEW',
    };

    return dynamoDB.update(params).promise();
  }
  throw new InputError('Invalid payload', ajv.errors);
}
