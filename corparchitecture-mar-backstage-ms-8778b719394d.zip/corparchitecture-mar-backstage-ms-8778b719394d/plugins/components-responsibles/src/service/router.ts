import { errorHandler } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import {
  DynamoDBClient,
  PutItemCommand,
  QueryCommand,
  DeleteItemCommand,
} from '@aws-sdk/client-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';

export interface RouterOptions {
  logger: Logger;
  componentsResponsiblesTableName: string;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
  email: string;
  appUrl: string;
}
export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const router = Router();
  router.use(express.json());
  const { accessKeyId, secretAccessKey, region } = options;
  const dynamo = new DynamoDBClient({
    credentials: {
      accessKeyId,
      secretAccessKey,
    },
    region,
  });

  const { componentsResponsiblesTableName } = options;

  router.post(
    '/:entity',
    async (
      req: {
        params: { entity: string };
        body: {
          user: string;
          type: 'functional' | 'technical';
          kind: string;
          approval: 'pending' | 'rejected';
        };
      },
      res,
    ) => {
      const { entity } = req.params;
      const { user, approval, type, kind } = req.body;
      console.log(`Post ${type} responsible ${user}...`);

      try {
        await dynamo.send(
          new PutItemCommand({
            TableName: componentsResponsiblesTableName,
            Item: marshall({
              entity,
              'responsible-type': `${user}-${type}`,
              approval,
              kind,
            }),
          }),
        );
        res.sendStatus(200);
      } catch (error) {
        console.log(error);
        res.status(500).send(error);
      }
    },
  );

  router.get('/:entity', async (req, res) => {
    const { entity } = req.params;
    try {
      const response = await dynamo.send(
        new QueryCommand({
          TableName: componentsResponsiblesTableName,
          KeyConditionExpression: 'entity = :entity',
          ExpressionAttributeValues: marshall({
            ':entity': entity,
          }),
        }),
      );
      if (!response.Items) {
        res.send([]);
        return;
      }
      const responsibles = response.Items.map(i => {
        const item = unmarshall(i);
        return {
          entity: item.entity,
          responsible: item['responsible-type'].split('-')[0],
          type: item['responsible-type'].split('-')[1],
          kind: item.kind,
          approval: item.approval,
        };
      });
      res.send(responsibles);
    } catch (error) {
      res.status(500).send(error);
    }
  });

  router.get('/:entity/:responsible/:type', async (req, res) => {
    const { entity, responsible, type } = req.params;
    try {
      const response = await dynamo.send(
        new QueryCommand({
          TableName: componentsResponsiblesTableName,
          KeyConditionExpression:
            '#entity = :entity and #responsibleType = :responsibleType',
          ExpressionAttributeValues: marshall({
            ':entity': entity,
            ':responsibleType': `${responsible}-${type}`,
          }),
          ExpressionAttributeNames: {
            '#entity': 'entity',
            '#responsibleType': 'responsible-type',
          },
        }),
      );
      if (!response.Items) {
        res.send(undefined);
        return;
      }
      const responsibles = response.Items.map(i => {
        const item = unmarshall(i);
        return {
          entity: item.entity,
          responsible: item['responsible-type'].split('-')[0],
          type: item['responsible-type'].split('-')[1],
          kind: item.kind,
          approval: item.approval,
        };
      });
      res.send(responsibles[0]);
    } catch (error) {
      res.status(500).send(error);
    }
  });

  router.delete(
    '/:entity/:responsible/:type',
    async (
      req: { params: { entity: string; responsible: string; type: string } },
      res,
    ) => {
      const { entity, responsible, type } = req.params;
      try {
        await dynamo.send(
          new DeleteItemCommand({
            TableName: componentsResponsiblesTableName,
            Key: marshall({
              entity,
              'responsible-type': `${responsible}-${type}`,
            }),
          }),
        );
        res.sendStatus(200);
      } catch (error) {
        res.status(500).send(error);
      }
    },
  );

  router.use(errorHandler());
  return router;
}
