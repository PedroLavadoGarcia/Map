import { createPlugin } from '@backstage/core-plugin-api';
import {
  createTechDocsAddonExtension,
  TechDocsAddonLocations,
} from '@backstage/plugin-techdocs-react';
import { AdaptBitbucketHrefsWithRouter } from './addons/AdaptBitbucketHrefs';
import { CustomBreadcrumbsWithRouter } from './addons/CustomBreadcrumbs';
import { ExpandableAddon } from './addons/ExpandableAddon';
import { HidePrevNextButtons } from './addons/HidePrevNextButtons';
import { BrokenLinks } from './addons/BrokenLinks';

export const customAddonsPlugin = createPlugin({
  id: 'customAddons',
});
export const CustomExpandableAddon = customAddonsPlugin.provide(
  createTechDocsAddonExtension({
    name: 'CustomExpandableAddon',
    location: TechDocsAddonLocations.PrimarySidebar,
    component: ExpandableAddon,
  }),
);
export const CustomBreadcrumbsAddon = customAddonsPlugin.provide(
  createTechDocsAddonExtension({
    name: 'CustomBreadcrumbsAddon',
    location: TechDocsAddonLocations.Header,
    component: CustomBreadcrumbsWithRouter,
  }),
);
export const AdaptBitbucketHrefsAddon = customAddonsPlugin.provide(
  createTechDocsAddonExtension({
    name: 'AdaptBitbucketHrefs',
    location: TechDocsAddonLocations.PrimarySidebar,
    component: AdaptBitbucketHrefsWithRouter,
  }),
);
export const HidePrevNextButtonsAddon = customAddonsPlugin.provide(
  createTechDocsAddonExtension({
    name: 'HidePrevNextButtons',
    location: TechDocsAddonLocations.Content,
    component: HidePrevNextButtons,
  }),
);

export const BrokenLinksAddon = customAddonsPlugin.provide(
  createTechDocsAddonExtension({
    name: 'BrokenLinks',
    location: TechDocsAddonLocations.Content,
    component: BrokenLinks,
  }),
);
