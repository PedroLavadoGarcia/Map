import React, { useState } from 'react';
import { Button, makeStyles } from '@material-ui/core';
import { useShadowRootElements } from '@backstage/plugin-techdocs-react';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';

export const ExpandableAddon = () => {
  const useStyles = makeStyles(theme => ({
    primarySidebarClose: {
      '@media (min-width: 1280px)': {
        width: '4rem',
        marginRight: '2px',
        display: 'block',
        '& nav': {
          display: 'none',
        },
      },
    },

    contentClose: {
      '@media (min-width: 1280px)': {
        marginLeft: '2rem',
        maxWidth: 'calc(100% - 18rem)',
        marginRight: '4rem',
        textAlign: 'justify',
        transition: 'all 0.2s linear',
      },
    },
    primarySidebarOpen: {
      '@media (min-width: 1280px)': {
        display: 'block',
        transition: 'all 0.2s linear',
        '& nav': {
          display: 'block',
        },
      },
    },

    contentOpen: {
      '@media (min-width: 1280px)': {
        maxWidth: 'calc(100% - 16rem*2)',
        marginLeft: '16rem',
        textAlign: 'justify',
        flexWrap: 'nowrap',
        transition: 'all 0.2s linear',
      },
    },
    button: {
      backgroundColor: theme.palette.grey[200],
      marginBottom: '15px',
      padding: '2px',
      minWidth: '50px',
      '& svg': {
        width: '20px',
        filter:
          'invert(29%) sepia(13%) saturate(542%) hue-rotate(169deg) brightness(94%) contrast(86%)',
      },
      '&:hover': {
        backgroundColor: theme.palette.grey[700],
        '& svg': {
          filter:
            'invert(100%) sepia(3%) saturate(0%) hue-rotate(222deg) brightness(105%) contrast(102%)',
          width: '20px',
        },
      },
    },
  }));
  const classes = useStyles();
  const [primarySidebar] = useShadowRootElements(['.md-sidebar--primary']);
  const [content] = useShadowRootElements(['.md-content']);
  const [isOpen, setState] = useState<boolean>(true);

  if (!isOpen) {
    primarySidebar.classList.add(`${classes.primarySidebarClose}`);
    content.classList.add(`${classes.contentClose}`);
  } else {
    primarySidebar.classList.add(`${classes.primarySidebarOpen}`);
    content.classList.add(`${classes.contentOpen}`);
  }

  //Workaround techdocs sidebars
  const sidebars: HTMLElement[] = useShadowRootElements([
    '.md-sidebar__scrollwrap',
  ]);
  sidebars.forEach(sidebar => {
    sidebar.style.height = `300px`;
  });

  const handleState = () => {
    setState(!isOpen);
  };

  return (
    <Button
      variant="text"
      classes={{ root: classes.button }}
      onClick={() => handleState()}
    >
      {isOpen ? (
        <KeyboardDoubleArrowLeftIcon />
      ) : (
        <KeyboardDoubleArrowRightIcon />
      )}
    </Button>
  );
};
