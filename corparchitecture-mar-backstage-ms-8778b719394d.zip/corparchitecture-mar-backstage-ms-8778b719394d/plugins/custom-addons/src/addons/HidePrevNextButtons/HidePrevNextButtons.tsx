import React from 'react';
import { useShadowRootElements } from '@backstage/plugin-techdocs-react';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { useAsync } from 'react-use';
import { AuditService } from 'app/src/api/audit';
import { useParams } from 'react-router';

export const HidePrevNextButtons = () => {
  const [prev] = useShadowRootElements(['.md-footer__link--prev']);
  const [next] = useShadowRootElements(['.md-footer__link--next']);

  if (prev) {
    prev.style.display = 'none';
  }

  if (next) {
    next.style.display = 'none';
  }

  const { name } = useParams();
  const identityApi = useApi(identityApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl');
  const audit = new AuditService(backendUrl ?? '');

  useAsync(async () => {
    const { email } = await identityApi.getProfileInfo();
    if (email && name) {
      audit.pushViewDocLog(email, name);
    }
  }, []);

  return <></>;
};
