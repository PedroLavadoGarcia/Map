import React, { useEffect, useState } from 'react';
import { useShadowRootElements } from '@backstage/plugin-techdocs-react';
import { useApi, configApiRef } from '@backstage/core-plugin-api';
import axios from 'axios';
import {
  CircularProgress,
  Collapse,
  Link,
  List,
  ListItem,
  ListItemText,
  IconButton
} from '@material-ui/core';
import { Alert, AlertTitle } from '@material-ui/lab';
import { ExpandLess, ExpandMore } from '@material-ui/icons';

export const BrokenLinks = () => {
  const configApi = useApi(configApiRef);
  const appUrl = configApi.getString('app.baseUrl');
  const backendUrl = configApi.getString('backend.baseUrl');
  let links: {title: string; url: string}[] = [];
  const [brokenLinks] = useState([] as {title: string; url: string;}[]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = React.useState(false);

  links = useShadowRootElements<HTMLAnchorElement>(['a'])
    .filter(link => link.classList.length === 0 && link.getAttribute('href')?.includes(appUrl))
    .map(link => ({
      title: link.textContent ?? '',
      url: link.getAttribute('href')!
    }));

  useEffect(() => {
    (async () => {
      for (const link of links) {
        const url = link.url;
        const response = await axios.put(`${backendUrl}/api/broken-links/check`, {
          url
        });
        if (response.data === 'invalid') {
          if (!brokenLinks.some(blink => blink.url === url)) {
            brokenLinks.push({
              url,
              title: link.title
            });
          }
        }
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <Alert severity="info" variant="filled" icon={<CircularProgress size={20}/>}>Checking links...</Alert>
    );
  }

  if (brokenLinks.length === 0) {
    return <></>;
  }

  return (
    <Alert
      style={{ overflow: 'hidden' }}
      severity="warning"
      variant="filled"
      icon={(
        <IconButton style={{ width: '40px', height: '40px' }} onClick={() => setOpen(!open)}>
          {open ? <ExpandLess /> : <ExpandMore />}
        </IconButton>
      )}
    >
      <AlertTitle style={{ marginTop: '5px' }}>{brokenLinks.length} broken links!</AlertTitle>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List>
          {brokenLinks.map(link => (
            <ListItem key={link.title}>
              <ListItemText
                primaryTypographyProps={{variant: 'subtitle1'}}
                secondaryTypographyProps={{variant: 'subtitle2'}}
                primary={link.title}
                secondary={<Link href={link.url}>{link.url}</Link>}
              />
            </ListItem>
          ))}
        </List>
      </Collapse>
    </Alert>
  );
};
