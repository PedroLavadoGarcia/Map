import React, { useLayoutEffect, useState } from 'react';
import { useApi } from '@backstage/core-plugin-api';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { JsonObject } from '@backstage/types';
import { useNavigate } from 'react-router-dom';

import { useTranslation } from 'react-i18next';
import { makeStyles } from '@material-ui/core';

export const CustomBreadcrumbs = () => {
  const { t } = useTranslation();
  const useStyles = makeStyles({
    customBreadcrumbs: {
      fontSize: '12px',
      flexWrap: 'nowrap',
      '& [class*=breadcrumbsSeparator]': {
        marginLeft: '0px',
        display: 'none',
      },
      '& [class*=breadcrumbsItem]': {
        marginLeft: '0px',
        display: 'block',
      },
      '& li': {
        whitespace: 'nowrap',
        background: '#f1f4fa',
        color: '#475059',
        position: 'relative',
        height: '30px',
        lineHeight: '30px',
        marginRight: '20px',
        padding: '0 20px',
        display: 'inline-flex',

        '&:last-child': {
          marginRight: 0,
          background: '#475059',
          '& a': {
            color: 'white',
          },
        },
        '&:last-child::before': {
          borderTopColor: '#475059',
          borderBottomColor: '#475059',
          display: 'inline-flex',
        },
        '&:last-child::after': {
          borderLeftColor: '#475059',
        },
        '&::before': {
          position: 'absolute',
          content: '""',
          height: '30px',
          top: 0,
          left: '-14px',
          borderLeft: '15px solid transparent',
          borderTop: '15px solid #f1f4fa',
          borderBottom: '15px solid #f1f4fa',
          display: 'inline-flex',
          margin: 0,
        },
        '&:first-child::before': {
          display: 'none',
        },
        '&::after': {
          position: 'absolute',
          content: '""',
          height: '30px',
          top: 0,
          right: '-14px',
          borderLeft: '15px solid #f1f4fa',
          borderTop: '15px solid transparent',
          borderBottom: '15px solid transparent',
          display: 'inline-flex',
        },
        '& a, a:hover': {
          textDecoration: 'none',
        },
        '&:hover': {
          background: '#475059',
          color: 'white',
        },
        '&:hover::before': {
          borderTopColor: '#475059',
          borderBottomColor: '#475059',
        },
        '&:hover::after': {
          borderLeftColor: '#475059',
        },
        '&:first-child': {
          borderTopLeftRadius: '0px',
          borderBottomLeftRadius: '0px',
        },
      },
    },
    header: {
      marginTop: '20px',
    },
  });
  const classes = useStyles();
  const [href, setHref] = useState<string>('');
  const [text, setText] = useState<string>('');
  const [parentRefArch, setParentRefArch] = useState('');
  const [parentRefArchTitle, setParentRefArchTitle] = useState('');
  const [type, setType] = useState<string | null>('');
  const catalogApi = useApi(catalogApiRef);
  const navigate = useNavigate();

  async function setScenarioParentHref() {
    const { items } = await catalogApi.getEntities({
      filter: { kind: 'refArch' },
    });
    const refArch = items.find(arch => {
      const scenarios =
        arch.metadata.referenceArchDocs &&
        ((arch.metadata.referenceArchDocs as JsonObject).scenarios as Record<
          string,
          string
        >[]);
      if (scenarios)
        return scenarios?.find(scenario => {
          return Object.values(scenario).find(url =>
            url.includes(window.location.pathname.split('/')[4]),
          );
        });

      return false;
    });
    if (refArch?.metadata.name && refArch?.metadata.title) {
      setParentRefArch(
        `/catalog/default/refarch/${refArch?.metadata.name}/scenarios`,
      );
      setParentRefArchTitle(`${refArch?.metadata.title}`);
    }
  }
  async function setTypeAndText(name: string) {
    const { items } = await catalogApi.getEntities({
      filter: [{ 'metadata.name': name }],
    });
    if (items[0]) {
      if (items[0].spec) setType((items[0].spec as JsonObject).type as string | null);
      if (items[0].metadata.title) setText(items[0].metadata.title);
    }
  }

  useLayoutEffect(() => {
    setTypeAndText(window.location.pathname.split('/')[4]);
    const docs: Element | null | undefined = document.querySelector(
      ' #root > div > main > header > div > nav > ol > li:nth-child(1) > a',
    );
    const separator: Element | null | undefined = document.querySelector(
      '#root > div > main > header > div > nav > ol > li[class*=MuiBreadcrumbs-separator]',
    );
    const element: Element | null | undefined = document.body.querySelector(
      'header > div > div:nth-child(1) > span > p > a',
    );
    const header: Element | null | undefined = document.body.querySelector(
      '#root > div > main > header > div > h1',
    );

    if (header) {
      header.classList.add(`${classes.header}`);
    }

    if (docs) {
      docs.textContent = `${t('Documentation')}`;
      docs.parentElement?.parentElement?.classList.add(
        `${classes.customBreadcrumbs}`,
      );
    }
    if (separator) {
      separator.innerHTML = '';
    }
    if (separator) {
      if (type === 'service') {
        const anchor = document.createElement('a');
        anchor.href = '/catalog/default/refarch/arqref_catalogo';
        anchor.innerText = `${t('Catálogo de Servicios Cloud')}`;
        anchor.style.marginLeft = '10px';
        anchor.style.marginRight = '10px';
        anchor.onclick = e => {
          e.preventDefault();
          navigate('/catalog/default/refarch/arqref_catalogo');
        };
        separator.innerHTML = '';
        separator.appendChild(anchor);
        separator.classList.add('breadcrumbsItem');
      } else if (type === 'scenario') {
        setScenarioParentHref();
        if (parentRefArchTitle) {
          const anchor = document.createElement('a');
          anchor.href = parentRefArch;
          anchor.innerText = t(parentRefArchTitle);
          anchor.style.marginLeft = '10px';
          anchor.style.marginRight = '10px';
          anchor.onclick = e => {
            e.preventDefault();
            navigate(parentRefArch);
          };
          separator.innerHTML = '';
          separator.appendChild(anchor);
          separator.classList.add('breadcrumbsItem');
        }
      } else {
        separator.classList.add('breadcrumbsSeparator');
      }
    }
    const elementHref = element?.getAttribute('href');
    if (elementHref) {
      setHref(elementHref);
      element?.parentElement?.parentElement?.remove();
    }

    const breadcrumbEntityName: Element | null | undefined =
      document.querySelector(
        '#root > div > main > header > div > nav > ol > li:nth-child(3) > div',
      );
    if (breadcrumbEntityName && breadcrumbEntityName != undefined) {
      const anchor = document.createElement('a');
      anchor.href = href;
      anchor.innerText = `${t(text)}`;
      anchor.onclick = e => {
        e.preventDefault();
        navigate(href);
      };
      breadcrumbEntityName.innerHTML = '';
      breadcrumbEntityName.appendChild(anchor);
    }
  }, [document.body, text, parentRefArch, parentRefArchTitle, classes]);

  return <></>;
};

export const CustomBreadcrumbsWithRouter = () => {
  return (
    <>
      <CustomBreadcrumbs />
    </>
  );
};
