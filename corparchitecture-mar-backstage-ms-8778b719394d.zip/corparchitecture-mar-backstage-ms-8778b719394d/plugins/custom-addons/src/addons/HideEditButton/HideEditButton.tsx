import { useShadowRootElements } from '@backstage/plugin-techdocs-react';

// This is a normal react component; in order to make it an Addon, you would
// still create and provide it via your plugin as described above. The only
// difference is that you'd set `location` to `TechDocsAddonLocations.Content`.
export const HideEditButton = () => {
  // This hook can be used to get references to specific elements. If you need
  // access to the whole shadow DOM, use the the underlying useShadowRoot()
  // hook instead.
  const [button] = useShadowRootElements(['a.md-content__button']);

  if (button) {
    button.style.opacity = '0';
  }
  // Nothing to render directly, so we can just return null.
  return null;
};
