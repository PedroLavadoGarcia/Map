import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useShadowRootElements } from '@backstage/plugin-techdocs-react';

export const AdaptBitbucketHrefs = () => {
  const navigate = useNavigate();
  const [content] = useShadowRootElements(['.md-content']);

  content.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement;
    const anchor = target.closest('a') as HTMLAnchorElement;
    let href = anchor?.getAttribute('href');
    const re =
      /^https:\/\/bitbucket\.org\/corparchitecture\/(\w+)\/\w+\/\w+\/docs\/(.*)/;
    if (!href?.match(re)) return;
    href = href
      ?.replace(re, `${window.location.origin}/docs/default/refarch/$1/$2`)
      .replace('.md', '');
    anchor.setAttribute('href', href);
    if (
      href?.startsWith(window.location.origin) &&
      !target.hasAttribute('download')
    ) {
      e.preventDefault();
      // detect if CTRL or META keys are pressed so that links can be opened in a new tab with `window.open`
      const modifierActive = e.ctrlKey || e.metaKey;
      const parsedUrl = new URL(href);

      // hash exists when anchor is clicked on secondary sidebar
      if (parsedUrl.hash) {
        if (modifierActive) {
          window.open(`${parsedUrl.pathname}${parsedUrl.hash}`, '_blank');
        } else {
          navigate(`${parsedUrl.pathname}${parsedUrl.hash}`);
        }
      } else {
        if (modifierActive) {
          window.open(parsedUrl.pathname, '_blank');
        } else {
          navigate(parsedUrl.pathname);
        }
      }
    }
  });

  return <></>;
};

export const AdaptBitbucketHrefsWithRouter = () => {
  return (
    <>
      <AdaptBitbucketHrefs />
    </>
  );
};
