# Description

MAPFRE's own custom cards for specific metadata keys defined in the entities' YAMLs.

_This plugin was created through the Backstage CLI_

# How it works

Include the card component as follows:

```jsx
import MetadataTableCard from '@internal/plugin-custom-cards/src/components/MetadataTableCard';

<MetadataTableCard key="YAML key" />
```

...in your Entity Page. Specify the key throught which you want to iterate to include the table rows.