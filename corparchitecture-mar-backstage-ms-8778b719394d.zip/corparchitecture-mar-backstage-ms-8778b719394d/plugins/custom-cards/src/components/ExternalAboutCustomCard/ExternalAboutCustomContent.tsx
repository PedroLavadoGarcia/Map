import { Entity } from '@backstage/catalog-model';
import { JsonValue } from '@backstage/types';
import { Chip, Grid, makeStyles, Typography } from '@material-ui/core';
import { t } from 'i18next';
import React from 'react';
import { ExternalAboutCustomField } from './ExternalAboutCustomField';
const useStyles = makeStyles({
  description: {
    wordBreak: 'break-word',
  },
});
/**
 * Props for {@link AboutCustomContent}.
 *
 * @public
 */
export interface AboutContentProps {
  entity: Entity;
}
export const refStrings: Record<string, string> = {
  ARG: 'Argentina',
  BRA: 'Brasil',
  CHL: 'Chile',
  COL: 'Colombia',
  CRI: 'Costa Rica',
  DEU: 'Germany',
  DOM: 'Dominican Republic',
  ECU: 'Ecuador',
  ESP: 'Spain',
  ITA: 'Italy',
  MEX: 'Mexico',
  MLT: 'Malta',
  PAN: 'Panama',
  PER: 'Perú',
  PRI: 'Puerto Rico',
  PRY: 'Paraguay',
  TUR: 'Turkey',
  URY: 'Uruguay',
  USA: 'United States of America',
  VEN: 'Venezuela',
  ASIS: 'Mawdy',
  DIG: 'Digital',
  INV: 'Investment',
  RE: 'Re',
  GLOBAL: 'Global',
  SOL: 'Solunion',
  TRON: 'Tron',
  CAN: 'Canada',
  PHL: 'Philippines',
  GTM: 'Guatemala',
  SLV: 'El Salvador',
  HND: 'Honduras',
  NIC: 'Nicaragua',
  SGP: 'Singapore',
  DZA: 'Algeria',
  MYS: 'Malaysia',
  JPN: 'Japan',
  TUN: 'Tunez',
  CHN: 'China',
  BEL: 'Belgium',
  HUN: 'Hungary',
  IRL: 'Ireland',
  GBR: 'United Kingdom',
};
/** @public */
export function ExternalAboutCustomContent(props: AboutContentProps) {
  const { entity } = props;
  const classes = useStyles();
  const isResource = entity.kind.toLocaleLowerCase('en-US') === 'resource';
  const isComponent = entity.kind.toLocaleLowerCase('en-US') === 'component';
  const isAPI = entity.kind.toLocaleLowerCase('en-US') === 'api';
  const isMapfreApi = entity.kind.toLocaleLowerCase('en-US') === 'mapfreapi';
  const isTemplate = entity.kind.toLocaleLowerCase('en-US') === 'template';
  const isLocation = entity.kind.toLocaleLowerCase('en-US') === 'location';
  const isGroup = entity.kind.toLocaleLowerCase('en-US') === 'group';
  // const partOfSystemRelations = getEntityRelations(entity, RELATION_PART_OF, {
  //   kind: 'system',
  // });
  // const ownedByRelations = getEntityRelations(entity, RELATION_OWNED_BY);
  const countryValue: JsonValue = entity.metadata?.country as string;
  const refString = refStrings[countryValue]
    ? refStrings[countryValue]
    : countryValue;
  const modDate: string = entity.metadata?.modDate as string;
  const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } = {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  };
  const optionsHours: {
    hour: '2-digit';
    minute: '2-digit';
    second: '2-digit';
  } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
  const formatted = `${new Date(Number(modDate))
    .toLocaleDateString('es-ES', optionsDate)
    .split(' ')
    .join('-')} ${new Date(Number(modDate)).toLocaleTimeString(
    'es-ES',
    optionsHours,
  )}`;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const instances: any = entity?.metadata?.instances;

  const endpointsPRO = instances?.map(
    (instance: Record<string, string>) => instance['mapfre.com/endpoint_PRO'],
  );
  const endpointInstance = endpointsPRO?.join(', ');
  const endpointService = (
    entity?.metadata?.serviceAvailability as Record<string, string>
  )?.['mapfre.com/endpoint_PRO'];

  return (
    <Grid container>
      <ExternalAboutCustomField label={t('Description')} gridSizes={{ xs: 12 }}>
        <Typography variant="body2" paragraph className={classes.description}>
          {entity?.metadata?.description || 'No description'}
        </Typography>
      </ExternalAboutCustomField>
      {(isAPI ||
        isMapfreApi ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.metadata?.country === 'string') && (
        <ExternalAboutCustomField
          label={t('Country')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">{t(refString) as string}</Typography>
        </ExternalAboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.metadata?.typology === 'string') && (
        <ExternalAboutCustomField
          label={t('Typology')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {entity?.metadata?.typology as string}
          </Typography>
        </ExternalAboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.metadata?.modDate === 'string') && (
        <ExternalAboutCustomField
          label={t('Modified')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2"> {formatted}</Typography>
        </ExternalAboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        typeof entity?.metadata?.version === 'string') && (
        <ExternalAboutCustomField
          label={t('Version')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {entity?.metadata?.version as string}
          </Typography>
        </ExternalAboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        typeof endpointInstance === 'string' ||
        typeof endpointService) && (
        <ExternalAboutCustomField
          label={t('Endpoint PRO')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {endpointService || (endpointInstance as string)}
          </Typography>
        </ExternalAboutCustomField>
      )}

      <ExternalAboutCustomField
        label={t('Tags')}
        value="No Tags"
        gridSizes={{ xs: 12 }}
      >
        {(entity?.metadata?.tags || []).map(t => (
          <Chip key={t} size="small" label={t} />
        ))}
      </ExternalAboutCustomField>
    </Grid>
  );
}
