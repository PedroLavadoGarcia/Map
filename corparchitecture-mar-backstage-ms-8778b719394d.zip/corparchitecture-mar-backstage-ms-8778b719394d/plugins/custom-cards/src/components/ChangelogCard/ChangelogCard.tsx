import { Table, TableColumn } from '@backstage/core-components';
import { alertApiRef, configApiRef, useApi } from '@backstage/core-plugin-api';
import { useEntity } from '@backstage/plugin-catalog-react';
import Button from '@material-ui/core/Button';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import useAsync from 'react-use/lib/useAsync';
import * as Diff from 'diff';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogContentComment from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme } from '@material-ui/core/styles';
import { gunzipSync } from 'zlib';
import { ApiChangelogService } from '@backstage/plugin-mapfreapi-editor';
import { SolutionChangelogService } from 'app/src/api/changelog/solutionService';

export function showChangedData(differences: string): Diff.Change[] {
  const diffTemplate: Diff.Change[] = [];
  try {
    const parsedDifferences = JSON.parse(differences);
    Object.entries(parsedDifferences).map(([key, value]) => {
      const diffPart = value as {
        added?: boolean;
        removed?: boolean;
        value?: any;
      };
      if (key) {
        if (
          diffPart.added ||
          diffPart.removed ||
          diffPart.value === 'File too big to display content' ||
          diffPart.value === 'Binary content' ||
          diffPart.value === 'Contenido binario' ||
          diffPart.value === 'Conteúdo binário' ||
          diffPart.value === 'File deleted' ||
          diffPart.value === 'Fichero eliminado' ||
          diffPart.value === 'Arquivo excluído'
        ) {
          diffTemplate.push(diffPart as Diff.Change);
        }
      }
    });
  } catch (error) {
    console.error('Error en la función showChangedData:', error);
  }
  return diffTemplate;
}

function formatDate(date: Date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
}

export type ChangelogTableRow = {
  diff: Diff.Change[];
  modifiedBy: string;
  desc: string;
  date: string;
  comment: string;
};

function ChangelogCard() {
  const { entity } = useEntity();
  const { t } = useTranslation();
  const alertApi = useApi(alertApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getOptionalString('backend.baseUrl') ?? '';
  const changelogApi = new ApiChangelogService(backendUrl);
  const changelogSolution = new SolutionChangelogService();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogSubtitle, setDialogSubtitle] = useState('');
  const [diffContent, setDiffContent] = useState<Diff.Change[]>([]);
  const [dialogComment, setDialogComment] = useState('');
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [content, setContent] = useState<ChangelogTableRow[]>([]);

  const columns: TableColumn<ChangelogTableRow>[] = [
    {
      title: 'Author',
      field: 'modifiedBy',
      width: 'auto',
    },
    {
      title: 'Date',
      field: 'date',
      type: 'datetime',
      sorting: true,
      defaultSort: 'desc',
      defaultGroupSort: 'desc',
      render: ({ date }) => formatDate(new Date(date)),
      width: 'auto',
    },
    {
      title: 'Description',
      field: 'desc',
      width: 'auto',
    },
    {
      title: 'Comment',
      field: 'comment',
      width: 'auto',
    },
  ];

  const { loading: isLoading } = useAsync(async () => {
    try {
      let logs;
      if (entity.kind === 'MapfreSolution') {
        logs = await changelogSolution.getAll(entity.metadata.name);
      } else {
        logs = await changelogApi.getLogs(entity.metadata.name);
      }

      setContent(
        logs.map(({ diff, modifiedBy, desc, date, comment, descParams }) => {
          // Check if compressed
          try {
            JSON.parse(diff);
          } catch (error) {
            diff = gunzipSync(Buffer.from(diff)).toString();
          }

          const descTranslate = desc.split('---');

          const params = descParams
            ? Object.keys(descParams).length > 0
              ? Object.keys(descParams)
                  .map(key => ({ [key]: t(descParams[key]) }))
                  .reduce((acc, obj) => {
                    return {
                      ...acc,
                      ...obj,
                    };
                  })
              : {}
            : {};

          return {
            diff: showChangedData(diff) as unknown as Diff.Change[],
            modifiedBy,
            desc: `${t(descTranslate[0].trim(), params)} ${
              descTranslate[1] ? descTranslate[1] : ''
            }`,
            comment: comment ? t(comment) : '',
            date: new Date(date).toISOString(),
          };
        }),
      );
    } catch (err) {
      if (err instanceof Error) {
        alertApi.post({ message: err.message, severity: 'error' });
      }
    }
  });

  return (
    <>
      <Dialog
        fullScreen={fullScreen}
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        aria-labelledby="responsive-dialog-title"
        maxWidth="xl"
      >
        <DialogTitle id="responsive-dialog-title">{dialogTitle}</DialogTitle>
        <DialogContent>
          <DialogContentComment>{dialogComment}</DialogContentComment>
          <DialogContentText>{dialogSubtitle}</DialogContentText>
          {Array.isArray(diffContent) ? (
            diffContent.map((part, idx) => {
              return (
                <pre
                  style={{
                    backgroundColor: part.added
                      ? '#dfd'
                      : part.removed
                      ? '#fee8e9'
                      : 'none',
                    marginTop: 0,
                    marginBottom: 0,
                  }}
                  key={idx}
                >
                  {part.value}
                </pre>
              );
            })
          ) : (
            <p>Error: diffContent no es un array.</p>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={() => setIsDialogOpen(false)}
            color="primary"
          >
            {t('Close')}
          </Button>
        </DialogActions>
      </Dialog>
      <Table
        options={{ paging: true, pageSize: 20, padding: 'dense' }}
        data={content}
        columns={columns}
        isLoading={isLoading}
        onRowClick={(_event, rowData) => {
          setDiffContent(rowData?.diff ?? []);
          setDialogTitle(rowData?.desc ?? '');
          setDialogComment(rowData?.comment ?? '');
          setDialogSubtitle(
            `${t('Modification by')} ${rowData?.modifiedBy} - ${
              rowData?.date ? formatDate(new Date(rowData?.date)) : ''
            }`,
          );
          setIsDialogOpen(true);
        }}
      />
    </>
  );
}

export { ChangelogCard };
