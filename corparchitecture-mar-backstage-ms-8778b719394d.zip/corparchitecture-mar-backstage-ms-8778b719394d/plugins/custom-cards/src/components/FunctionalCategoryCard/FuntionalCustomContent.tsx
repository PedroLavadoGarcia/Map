import { Entity } from '@backstage/catalog-model';
import { Chip, Grid } from '@material-ui/core';
import { t } from 'i18next';
import React from 'react';
import { LabelCustomField } from './LabelCustomField';
import { SubLabelCustomField } from './SubLabelCustomField';

/**
 * Props for {@link AboutCustomContent}.
 *
 * @public
 */
export interface AboutContentProps {
  entity: Entity;
}

/** @public */
export function FunctionalCustomContent(props: AboutContentProps) {
  const { entity } = props;

  const businessEntityValue = entity?.metadata[
    'mapfre.com/businessEntity'
  ] as string;
  const businessLineValue = entity?.metadata[
    'mapfre.com/business_line'
  ] as string[];
  const resultLife = businessLineValue
    ?.filter(e => e.match(/^Life::/))
    .map(e => e.replace(/^Life::/, ''));

  const resultNoLife = businessLineValue
    ?.filter(e => e.match(/^NoLife::/))
    .map(e => e.replace(/^NoLife::/, ''));
  const resultHealth = businessLineValue
    ?.filter(e => e.match(/^Health::/))
    .map(e => e.replace(/^Health::/, ''));

  const resultCross = businessLineValue
    ?.filter(e => e.includes('Cross'))
    .map(e => e);

  return (
    <Grid container>
      <LabelCustomField
        label={t('Business Entity')}
        value={businessEntityValue}
        gridSizes={{ xs: 12 }}
      >
        <Chip
          size="medium"
          label={
            businessEntityValue ? t(businessEntityValue) : t('Not applicable')
          }
          color="default"
          variant="outlined"
        />
      </LabelCustomField>
      <LabelCustomField
        label={t('Business Line')}
        gridSizes={{ xs: 12 }}
        value={t('Not applicable') as string}
      >
        {resultLife?.length && (
          <SubLabelCustomField
            label={t('Life')}
            gridSizes={{ xs: 12 }}
            value="No Values"
          >
            {resultLife.map(i => (
              <Chip
                key={i}
                size="small"
                label={t(i)}
                color="default"
                variant="outlined"
              />
            ))}
          </SubLabelCustomField>
        )}
        {resultNoLife?.length && (
          <SubLabelCustomField label={t('No Life')} gridSizes={{ xs: 12 }}>
            {resultNoLife.map(i => (
              <Chip
                key={i}
                size="small"
                label={t(i)}
                color="default"
                variant="outlined"
              />
            ))}
          </SubLabelCustomField>
        )}
        {resultHealth?.length && (
          <SubLabelCustomField
            label={t('Health')}
            gridSizes={{ xs: 12 }}
            value="No Values"
          >
            {resultHealth.map(i => (
              <Chip
                key={i}
                size="small"
                label={t(i)}
                color="default"
                variant="outlined"
              />
            ))}
          </SubLabelCustomField>
        )}
        {resultCross?.length && (
          <SubLabelCustomField
            label={t('Cross')}
            gridSizes={{ xs: 12 }}
            value="No Values"
          >
            {resultCross.map(i => (
              <Chip
                key={i}
                size="small"
                label={t(i)}
                color="default"
                variant="outlined"
              />
            ))}
          </SubLabelCustomField>
        )}
      </LabelCustomField>
    </Grid>
  );
}
