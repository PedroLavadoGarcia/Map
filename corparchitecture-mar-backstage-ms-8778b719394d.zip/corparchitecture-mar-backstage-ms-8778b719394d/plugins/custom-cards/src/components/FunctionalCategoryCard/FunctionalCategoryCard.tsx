import { InfoCardVariants } from '@backstage/core-components';

import { useEntity } from '@backstage/plugin-catalog-react';
import {
  Card,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  makeStyles,
} from '@material-ui/core';

import { t } from 'i18next';
import React from 'react';
import { FunctionalCustomContent } from './FuntionalCustomContent';

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100%)', // for pages without content header
  },
  fullHeightCardContent: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  },
  gridItemCardContent: {
    flex: 1,
  },
  cardHeader: {
    marginBottom: '24px',
  },
});

/**
 * Props for {@link EntityAboutCard}.
 *
 * @public
 */
export interface AboutCardProps {
  variant?: InfoCardVariants;
}

/**
 * Exported publicly via the EntityAboutCard
 */
export function FunctionalCategoryCard(props: AboutCardProps) {
  const { variant } = props;
  const classes = useStyles();
  const { entity } = useEntity();

  let cardClass = '';
  if (variant === 'gridItem') {
    cardClass = classes.gridItemCard;
  } else if (variant === 'fullHeight') {
    cardClass = classes.fullHeightCardContent;
  }

  let cardContentClass = '';
  if (variant === 'gridItem') {
    cardContentClass = classes.gridItemCardContent;
  } else if (variant === 'fullHeight') {
    cardContentClass = classes.fullHeightCardContent;
  }

  return (
    <Grid item xs={6}>
      <Card className={cardClass}>
        <CardHeader
          className={classes.cardHeader}
          title={t('Functional Category')}
        />

        <Divider />
        <CardContent className={cardContentClass}>
          <FunctionalCustomContent entity={entity} />
        </CardContent>
      </Card>
    </Grid>
  );
}
