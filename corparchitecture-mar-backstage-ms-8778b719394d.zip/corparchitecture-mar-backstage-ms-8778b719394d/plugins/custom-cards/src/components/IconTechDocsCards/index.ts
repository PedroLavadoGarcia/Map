export { IconTechDocsCards } from './IconTechDocsCards';
