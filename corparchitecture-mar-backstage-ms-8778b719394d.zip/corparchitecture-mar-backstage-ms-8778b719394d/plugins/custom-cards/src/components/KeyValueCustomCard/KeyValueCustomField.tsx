import { useElementFilter } from '@backstage/core-plugin-api';
import { Chip, makeStyles, Typography } from '@material-ui/core';
import React, { ChangeEvent, useEffect, useState } from 'react';

const useStyles = makeStyles(theme => ({
  value: {
    overflow: 'hidden',
    lineHeight: '24px',
    fontSize: '12px',
  },
  label: {
    color: theme.palette.text.secondary,
    textTransform: 'uppercase',
    fontSize: '10px',
    fontWeight: 'bold',
    overflow: 'hidden',
    height: '24px',
    lineHeight: '24px',
    marginRight: '100px',
    marginTop: '5px',
    display: 'flex',
    justifyContent: 'center',
  },
  chip: {
    overflow: 'hidden',
    whiteSpace: 'pre-wrap',
  },
  discontinuedBorder: {
    border: `1px dashed ${theme.palette.grey[400]}`,
    borderRadius: '100px',
    borderColor: theme.palette.common.black,
    borderWidth: '1px',
    backgroundColor: theme.palette.grey[100],
  },
}));

export interface KeyValueFieldProps {
  label: string;
  value?: string;
  gridSizes?: Record<string, number>;
  children?: React.ReactNode;
  isEditable?: boolean;
  isSaving?: boolean;
  dataColor?: string;
  onSave?: (value: string) => void; // Fix the type of onSave prop
}

export function KeyValueCustomField(props: KeyValueFieldProps) {
  const { label, value, children, isEditable, onSave } = props;
  const classes = useStyles();
  const [editedValue, setEditedValue] = useState(value || '');

  const childElements = useElementFilter(children, c => c.getElements());

  const handleValueChange = (event: ChangeEvent<HTMLDivElement>) => {
    setEditedValue(event.target.textContent || '');
    if (onSave) {
      onSave(event.target.textContent || ''); // Pass the edited value to onSave
    }
  };

  useEffect(() => {
    setEditedValue(value || '');
  }, [value]);

  const renderContent = () => {
    if (isEditable) {
      return (
        <div className={classes.chip}>
          <Typography
            variant="caption"
            component="div"
            contentEditable
            suppressContentEditableWarning
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            onBlur={(event: any) => {
              handleValueChange(event); // Save the edited value
              event.target.removeAttribute('contentEditable'); // Disable content editing after blur
            }}
            style={{
              display: 'inline-flex',
              textOverflow: 'ellipsis',
              borderRadius: '100px',
              border: 'none',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              outline: 'none',
            }}
          >
            {editedValue}
          </Typography>
        </div>
      );
    } else if (editedValue) {
      return (
        <Typography variant="caption" className={classes.value}>
          {editedValue || `unknown`}
        </Typography>
      );
    } else if (childElements.length > 0) {
      return childElements;
    } else {
      return (
        <Typography variant="caption" className={classes.value}>
          {value || `unknown`}
        </Typography>
      );
    }
  };

  return (
    <div>
      <Typography variant="h2" className={classes.label}>
        {label}
      </Typography>
      <Chip
        label={renderContent()}
        variant="default"
        size="small"
        style={{
          backgroundColor: props.dataColor,
        }}
        className={
          isEditable
            ? `${classes.chip} ${classes.discontinuedBorder}`
            : classes.chip
        } // Add the discontinued border class for Chip when editable
      />
    </div>
  );
}
