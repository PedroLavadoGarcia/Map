import { Entity } from '@backstage/catalog-model';
import { t } from 'i18next';
import React from 'react';
import { JsonValue } from '@backstage/types';
import { KeyValueCustomField } from './KeyValueCustomField';
import {
  EntityRefLinks,
  getEntityRelations,
} from '@backstage/plugin-catalog-react';
import { RELATION_OWNED_BY } from '@backstage/catalog-model';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  fullHeightCardContent: {
    padding: '0',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    '& thead tr th': {
      padding: 0,
    },
    '& thead tr th span': {
      display: 'none',
    },
    '& > div > div': {
      boxShadow: 'none',
    },
  },
});

/**
 * Props for {@link KeyValueCustomContent}.
 *
 * @public
 */
export interface KeyValueContentProps {
  title?: string;
  yamlKey: string;
  entity: Entity;
  isEditable?: boolean;
  isSaveable?: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onDataModified?: any;
  dataColor?: string;
}

export function KeyValueCustomContent(
  props: KeyValueContentProps,
): JSX.Element {
  const { entity, isEditable, onDataModified } = props;
  const ownedByRelations = getEntityRelations(entity, RELATION_OWNED_BY);
  const linkToUser = (
    <div>
      <EntityRefLinks entityRefs={ownedByRelations} defaultKind="user" />
    </div>
  );
  const data: Record<string, string>[] = [];
  // changed, i was having issues with the linting. threw this error:
  /*
  const [modifiedData, setModifiedData] = React.useState<{}>({});

  /Desktop/work/aws-cdk-backstage-aurora/src/backstage/plugins/custom-cards/src/components/KeyValueCustomCard/KeyValueCustomContent.tsx
  60:58  error  Don't use `{}` as a type. `{}` actually means "any non-nullish value".
- If you want a type meaning "any object", you probably want `object` instead.
- If you want a type meaning "any value", you probably want `unknown` instead.
- If you want a type meaning "empty object", you probably want `Record<string, never>` instead  @typescript-eslint/ban-types

✖ 1 problem (1 error, 0 warnings)
  */
  const [modifiedData, setModifiedData] = React.useState({});

  const content: JsonValue = entity.metadata?.[props.yamlKey] as Record<
    string,
    string
  >;
  if (content) {
    for (const k in content) {
      if (k === 'title' || k === 'dataType' || k === 'dataColor') {
        continue; // Skip the 'title' and 'dataType' keys
      }
      let value = content[k] as string;
      if (
        [
          'mapfre.com/resp_func',
          'mapfre.com/resp_tech',
          'mapfre.com/owners',
        ].includes(k)
      ) {
        value = value && (linkToUser as unknown as string);
      }
      data.push({
        key: k,
        value: value,
      });
    }
  }
  const handleFieldChange = (key: string, value: JsonValue) => {
    // Update the modified data when a field is changed
    const updatedData = { ...modifiedData, [key]: value };
    console.log('updated: ' + JSON.stringify(updatedData));
    setModifiedData(updatedData);

    // Notify the parent component about the modified data
    onDataModified?.(updatedData);
  };

  const classes = useStyles();
  const renderFields = () => {
    return data.map(item => (
      <KeyValueCustomField
        key={item.key}
        label={t(item.key) as string}
        dataColor={props.dataColor}
        value={item.value}
        isEditable={isEditable}
        onSave={editedValue => handleFieldChange(item.key, editedValue)} // Pass the onChange callback
      />
    ));
  };
  //when isAdmin is true show the edit button. If not show nothing
  //if isAdmin and is editing I want to render the KeyValueCustomField with isAdmin false. If then the edit button is clicked I want to render the KeyValueCustomField with isAdmin true
  return <div className={classes.container}>{renderFields()}</div>;
}
