import { InfoCardVariants } from '@backstage/core-components';
import { useEntity } from '@backstage/plugin-catalog-react';
import { Grid, Tooltip } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import Divider from '@material-ui/core/Divider';
import { makeStyles } from '@material-ui/core/styles';
import { t } from 'i18next';
import React, { useCallback } from 'react';
import { KeyValueCustomContent } from './KeyValueCustomContent';
import IconButton from '@material-ui/core/IconButton';
import EditIcon from '@material-ui/icons/Edit';
import { RequirePermission } from '@backstage/plugin-permission-react';
import { componentsEditPermission } from '@backstage/plugin-components-catalog-edit-common';
import { ErrorPage } from '@backstage/core-components';
import SaveIcon from '@mui/icons-material/Save';
import { JsonValue } from '@backstage/types';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import {
  getCatalogInfo,
  uploadFiles,
  deleteOldCatalogInfo,
} from '@backstage/plugin-components-catalog-edit';
import {
  useApi,
  identityApiRef,
  errorApiRef,
} from '@backstage/core-plugin-api';
import { stringifyEntityRef } from '@backstage/catalog-model';
import { JsonObject } from '@backstage/config';
import * as yaml from 'js-yaml';
import yaml2 from 'yaml';

interface CatalogInfo {
  metadata: {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [key: string]: any;
  };
}

const useStyles = makeStyles({
  gridItemCard: {
    flexDirection: 'column',
    height: 'calc(100% - 10px)', // for pages without content header
    marginBottom: '10px',
  },
  fullHeightCard: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  },
  fullHeightCardContent: {
    flex: 1,
  },
});

/**
 * Props for {@link EntityKeyValueCard}.
 *
 * @public
 */
export interface KeyValueCardProps {
  dataColor: string;
  yamlKey: string;
  title?: string;
  variant?: InfoCardVariants;
}

export function KeyValueCustomCard(props: KeyValueCardProps) {
  const classes = useStyles();
  const { entity } = useEntity();
  const [isEditable, setIsEditable] = React.useState(false);
  const [isSaveable, setIsSaveable] = React.useState(false);
  const catalogApi = useApi(catalogApiRef);
  const errorApi = useApi(errorApiRef);
  const files: Record<string, string> = {};
  const [modifiedData, setModifiedData] = React.useState<JsonValue>(); // modifiedData is a key value pair of the modified data
  const handleDataModified = (key: JsonValue) => {
    setModifiedData?.(key);
  };

  const refreshEntity = useCallback(async () => {
    try {
      await catalogApi.refreshEntity(stringifyEntityRef(entity));
    } catch (e) {
      if (e instanceof Error) errorApi.post(e);
    }
  }, [catalogApi, entity]);

  const handleEditClick = () => {
    setIsEditable(!isEditable);
  };

  const handleSaveClick = () => {
    setIsSaveable(!isSaveable);
    setIsEditable(!isEditable);
    setModifiedData(modifiedData);
    saveData(modifiedData);
    // Save the modified data
  };

  const identityApi = useApi(identityApiRef);

  const saveData = async (modifiedData: JsonValue | undefined) => {
    // Send the modified data to the backend and update the YAML values
    if (!modifiedData) {
      return;
    }
    const { token } = await identityApi.getCredentials();
    const entityRepo =
      entity.metadata?.annotations?.['backstage.io/managed-by-origin-location'];
    if (!entityRepo) {
      throw Error('Cannot retrieve entity repository view url.');
    }
    // Get the catalog info from the backend
    const catalogInfo = yaml.load(await getCatalogInfo(entityRepo, token));
    // Create a copy of the catalog info
    const updatedCatalogInfo: CatalogInfo = { ...(catalogInfo as CatalogInfo) };

    // Update the catalog info with the modified data
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    for (const _key in modifiedData as JsonObject) {
      // console.log('key: '+_key)
      // console.log('value: '+modifiedData[_key])
      const context = updatedCatalogInfo.metadata[props.yamlKey] as JsonObject;
      context[_key] = (modifiedData as JsonObject)[_key];
    }

    files['catalog-info.yaml'] = yaml2.stringify(updatedCatalogInfo);

    // Await to delete the file. This is to ensure that the file is deleted before uploading the new file.
    await deleteOldCatalogInfo(entityRepo, token);
    await uploadFiles(entityRepo, files, token);

    await refreshEntity(); // Refresh the entity to reflect the changes

    // Update the catalog info in the backend updatedCatalogInfo
  };

  return (
    <Grid item xs={6}>
      <Card className={classes.gridItemCard}>
        <CardHeader
          title={t(props.title || 'KeyValue')}
          action={
            <RequirePermission
              permission={componentsEditPermission}
              resourceRef={`component:${entity.metadata.name}`}
              errorPage={ErrorPage}
            >
              {!isEditable && (
                <Tooltip title="Edit" enterDelay={500}>
                  <IconButton onClick={handleEditClick}>
                    <EditIcon />
                  </IconButton>
                </Tooltip>
              )}

              {isEditable && (
                <Tooltip title="Save" enterDelay={500}>
                  <IconButton onClick={handleSaveClick}>
                    <SaveIcon />
                  </IconButton>
                </Tooltip>
              )}
            </RequirePermission>
          }
        />
        <Divider />
        <CardContent className={classes.fullHeightCardContent}>
          <KeyValueCustomContent
            entity={entity}
            dataColor={props.dataColor}
            title={props.title}
            yamlKey={props.yamlKey}
            isEditable={isEditable}
            isSaveable={isSaveable}
            onDataModified={handleDataModified}
          />
        </CardContent>
      </Card>
    </Grid>
  );
}
