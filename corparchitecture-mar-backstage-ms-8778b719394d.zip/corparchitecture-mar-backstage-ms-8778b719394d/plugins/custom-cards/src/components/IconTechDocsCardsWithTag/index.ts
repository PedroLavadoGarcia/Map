export { IconTechDocsCardsWithTag } from './IconTechDocsCardsWithTag';
