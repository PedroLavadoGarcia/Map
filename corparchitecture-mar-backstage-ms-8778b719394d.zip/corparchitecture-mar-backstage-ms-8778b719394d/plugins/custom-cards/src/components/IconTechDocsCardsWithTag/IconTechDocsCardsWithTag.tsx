import { ItemCardGrid, ItemCardHeader } from '@backstage/core-components';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import { useEntity } from '@backstage/plugin-catalog-react';
import { ImageDisplay } from '../../utils';
import {
  Box,
  Card,
  CardActions,
  CardMedia,
  Container,
  Grid,
  makeStyles,
  Tooltip,
  Typography,
} from '@material-ui/core';
import MonetizationOnOutlined from '@material-ui/icons/MonetizationOnOutlined';
import LockOutlined from '@material-ui/icons/LockOutlined';
import Visibility from '@material-ui/icons/Visibility';
import HomeOutlined from '@material-ui/icons/HomeOutlined';
import CodeIcon from '@material-ui/icons/Code';
import React from 'react';
import { useNavigate } from 'react-router';
import { Alert, AlertTitle } from '@material-ui/lab';

import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { useTranslation } from 'react-i18next';
import fs from 'fs';

export interface IconTechDocsCardsProps {
  metadataItem: Array<Record<string, string>>;
  type: string;
  cloudProviderType: string;
}

// a function that returns true if the name has "L3" string in it
function checkL3(name: string) {
  if (name.includes('L3')) {
    return false;
  }
  return true;
}

function IconTechDocsCardsWithTag(props: IconTechDocsCardsProps) {
  const { metadataItem, type, cloudProviderType } = props;
  const { t } = useTranslation();
  const { entity } = useEntity();
  const config = useApi(configApiRef);
  const backendBaseUrl = config.getString('backend.baseUrl');
  const navigate = useNavigate();

  const useStyles = makeStyles(theme => ({
    header: {
      color: '#475059',
      backgroundColor: '#f1f4fa !important',
      paddingBottom: '16px',
      '& h4': {
        marginBottom: '0 !important',
      },
      '& h6': {
        marginBottom: '0 !important',
      },
    },
    content: {
      overflow: 'hidden',
      height: '400px',
    },

    grid: {
      gridGap: '24px',
    },
    icons: {
      color: 'inherit',
      width: '28px',
      height: '28px',
      cursor: 'pointer',
      '&:hover': {
        color: '#DB271C',
      },
    },
    iconImg: {
      width: '28px',
      height: '28px',
      cursor: 'pointer',
      filter:
        'invert(29%) sepia(10%) saturate(658%) hue-rotate(169deg) brightness(95%) contrast(88%)',
      '&:hover': {
        filter:
          'invert(26%) sepia(29%) saturate(6912%) hue-rotate(356deg) brightness(93%) contrast(85%)',
      },
    },
    imageBox: {
      '& img': {
        marginTop: '16px',
        display: 'block',
        width: '100%',
        cursor: 'pointer',
      },
    },
    imageContent: {
      overflow: 'hidden',
      height: '350px',
      background: 'white',
    },
    iconGridContent: {
      padding: '5px',
      textAlign: 'justify',
      flexWrap: 'nowrap',
    },
    cardsActions: {
      padding: '10px 0 10px 0',
      background: theme.palette.background.paper,
    },
    description: {
      marginTop: '16px',
      textAlign: 'justify',
      height: '100%',
      '&:hover': {
        overflowX: 'hidden',
        '&::-webkit-scrollbar': {
          width: '0',
        },
      },
    },
  }));

  const classes = useStyles();
  const filteredMetadataItems = metadataItem?.filter(
    item => item.cloudProviderType === cloudProviderType,
  );

  // Check if filteredMetadataItems is empty
  if (!filteredMetadataItems || filteredMetadataItems.length === 0) {
    return (
      <Alert severity="info" style={{ width: '24%' }}>
        <AlertTitle>Work in Progress</AlertTitle>
        Content coming soon for {cloudProviderType}!
      </Alert>
    );
  }

  return (
    <>
      <ItemCardGrid classes={{ root: classes.grid }}>
        {metadataItem
          ?.filter(item => item.cloudProviderType === cloudProviderType)
          .map((item, idx) => (
            <div key={idx}>
              <Card classes={{ root: classes.content }}>
                {type === 'scenario' && (
                  <>
                    <CardMedia>
                      <ItemCardHeader
                        title={t(item.title)}
                        classes={{ root: classes.header }}
                      />
                    </CardMedia>

                    <Container
                      classes={{
                        root: classes.imageContent,
                      }}
                    >
                      <Box
                        className={classes.imageBox}
                        onClick={() => navigate(`/${item?.scenarioLink}`)}
                      >
                        <ImageDisplay
                          src={`${backendBaseUrl}/api/techdocs/static/docs/default/${entity.kind}/${entity.metadata.name}/${item.imagePath}`}
                        />
                      </Box>
                    </Container>
                  </>
                )}

                {type === 'service' && (
                  <>
                    <CardMedia>
                      <ItemCardHeader classes={{ root: classes.header }}>
                        <Grid container spacing={0}>
                          <Box sx={{ width: '30px', marginRight: '20px' }}>
                            {checkL3(`${item.title}`) ? (
                              <img
                                src={
                                  item.imagePath
                                    ? `${backendBaseUrl}/api/techdocs/static/docs/default/${entity.kind}/${entity.metadata.name}/${item.imagePath}`
                                    : `/icons/serviceIcons/${item.title}.svg`
                                }
                                width="30px"
                              />
                            ) : (
                              <img
                                src={`/icons/serviceIcons/API Gateway L3.svg`}
                                width="30px"
                              />
                            )}
                          </Box>

                          <a
                            href={`/${item.serviceLink}`}
                            onClick={e => {
                              e.preventDefault();
                              navigate(`/${item.serviceLink}`);
                            }}
                          >
                            <Typography variant="h6">{item.title}</Typography>
                          </a>
                        </Grid>
                      </ItemCardHeader>
                    </CardMedia>
                    <Container
                      classes={{
                        root: classes.content,
                      }}
                    >
                      {!item.description && (
                        <Box sx={{ margin: '-32px', textAlign: 'justify' }}>
                          <TechDocsCardContent
                            withTitle={false}
                            withSubtitle={false}
                            withImage={false}
                            withLineBreak={false}
                            path={item.path}
                          />
                        </Box>
                      )}

                      {item.description && (
                        <Box className={classes.description}>
                          <Typography variant="body2">
                            {item.description}
                          </Typography>
                        </Box>
                      )}
                    </Container>
                  </>
                )}
                <CardActions classes={{ root: classes.cardsActions }}>
                  <Grid
                    container
                    justifyContent="space-evenly"
                    classes={{ root: classes.iconGridContent }}
                  >
                    <Grid item>
                      {type === 'scenario' && item.scenarioLink && (
                        <Tooltip title={`${t('View scenario')}`}>
                          <HomeOutlined
                            classes={{ root: classes.icons }}
                            onClick={() => navigate(`/${item?.scenarioLink}`)}
                          />
                        </Tooltip>
                      )}
                      {type === 'service' && item.serviceLink && (
                        <Tooltip title={`${t('View service')}`}>
                          <HomeOutlined
                            classes={{ root: classes.icons }}
                            onClick={() => navigate(`/${item?.serviceLink}`)}
                          />
                        </Tooltip>
                      )}
                    </Grid>

                    {item.codeLink && (
                      <Grid item>
                        <Tooltip title={`${t('Code')}`}>
                          <CodeIcon
                            classes={{ root: classes.icons }}
                            onClick={() => navigate(`/${item?.codeLink}`)}
                          />
                        </Tooltip>
                      </Grid>
                    )}
                    {item.costLink && (
                      <Grid item>
                        <Tooltip title={`${t('Costs')}`}>
                          <MonetizationOnOutlined
                            classes={{ root: classes.icons }}
                            onClick={() => navigate(`/${item?.costLink}`)}
                          />
                        </Tooltip>
                      </Grid>
                    )}
                    {item.operationLink && (
                      <Grid item>
                        <Tooltip title={`${t('Operation/DR')}`}>
                          <div>
                            <img
                              src="/icons/OperationIcon.webp"
                              className={`iconImg ${classes.iconImg}`}
                              onClick={() =>
                                navigate(`/${item?.operationLink}`)
                              }
                            />
                          </div>
                        </Tooltip>
                      </Grid>
                    )}
                    {item.securityLink && (
                      <Grid item>
                        <Tooltip title={`${t('Security')}`}>
                          <LockOutlined
                            classes={{ root: classes.icons }}
                            onClick={() => navigate(`/${item?.securityLink}`)}
                          />
                        </Tooltip>
                      </Grid>
                    )}
                    {item.observabilityLink && (
                      <Grid item>
                        <Tooltip title={`${t('Observability')}`}>
                          <Visibility
                            classes={{ root: classes.icons }}
                            onClick={() =>
                              navigate(`/${item?.observabilityLink}`)
                            }
                          />
                        </Tooltip>
                      </Grid>
                    )}
                    {item.eiopaLink && (
                      <Grid item>
                        <Tooltip title="EIOPA">
                          <div>
                            <img
                              src="/icons/EiopaIcon.webp"
                              className={`iconImg ${classes.iconImg}`}
                              onClick={() => navigate(`/${item?.eiopaLink}`)}
                            />
                          </div>
                        </Tooltip>
                      </Grid>
                    )}
                  </Grid>
                </CardActions>
              </Card>
            </div>
          ))}
      </ItemCardGrid>
    </>
  );
}

export { IconTechDocsCardsWithTag };
