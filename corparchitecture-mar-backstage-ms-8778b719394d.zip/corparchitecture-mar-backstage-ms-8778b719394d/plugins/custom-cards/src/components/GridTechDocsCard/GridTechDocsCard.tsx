import React from 'react';
import {
  Box,
  Button,
  Card,
  CardActions,
  CardMedia,
  Container,
  makeStyles,
  Typography,
} from '@material-ui/core';
import { TechDocsCardContent } from '@internal/plugin-custom-techdocs';
import { ItemCardHeader } from '@backstage/core-components';
import { useEntity } from '@backstage/plugin-catalog-react';
import { useNavigate } from 'react-router-dom';
import { t } from 'i18next';

function GridTechDocsCard({
  title,
  path,
  customMessage,
}: {
  title: string;
  path: string;
  customMessage?: string;
}): JSX.Element {
  const { entity } = useEntity();
  const navigate = useNavigate();

  const useStyles = makeStyles(theme => ({
    header: {
      color: '#475059',
      backgroundColor: '#f1f4fa !important',
      paddingBottom: '16px',
      '& h4': {
        marginBottom: '0 !important',
      },
      '& h6': {
        marginBottom: '0 !important',
      },
    },

    content: {
      overflow: 'hidden',
      height: '400px',
    },
    cardsActions: {
      padding: '10px 0 10px 0',
      background: theme.palette.background.paper,
    },
    button: {
      marginLeft: '-16px',
      fontWeight: 'bold',
      textAlign: 'left',
      color: theme.palette.primary.main,
    },
    message: {
      marginTop: '16px',
      textAlign: 'justify',
      height: '100%',
      '&:hover': {
        overflowX: 'hidden',
        '&::-webkit-scrollbar': {
          width: '0',
        },
      },
    },
  }));

  const classes = useStyles();

  return (
    <div>
      <Card classes={{ root: classes.content }}>
        <CardMedia>
          <ItemCardHeader title={t(title)} classes={{ root: classes.header }} />
        </CardMedia>
        <Container
          classes={{
            root: classes.content,
          }}
        >
          {!customMessage && (
            <Box sx={{ margin: '-32px', textAlign: 'justify' }}>
              <TechDocsCardContent
                withTitle={false}
                withSubtitle={false}
                withImage={false}
                withLineBreak={false}
                path={path}
              />
            </Box>
          )}
          {customMessage && (
            <Box className={classes.message}>
              <Typography variant="body2">{customMessage}</Typography>
            </Box>
          )}
        </Container>
        <CardActions style={{ padding: '20px' }}>
          <Button
            variant="text"
            color="default"
            onClick={() => {
              navigate(
                `/docs/default/${entity.kind}/${entity.metadata.name}/${path}`,
              );
            }}
            classes={{
              root: classes.button,
            }}
          >
            {t('Access')}
          </Button>
        </CardActions>
      </Card>
    </div>
  );
}
export { GridTechDocsCard };
