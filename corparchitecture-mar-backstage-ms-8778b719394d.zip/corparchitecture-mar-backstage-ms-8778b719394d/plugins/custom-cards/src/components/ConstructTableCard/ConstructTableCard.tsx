import React from 'react';
import {
  Content,
  ContentHeader,
  TableFilter,
  TableProps,
} from '@backstage/core-components';
import {
  EntityListProvider,
  UserListFilterKind,
  EntityTypePicker,
} from '@backstage/plugin-catalog-react';
import { SearchContextProvider } from '@backstage/plugin-search-react';

import { CatalogTable, CatalogTableRow } from '@backstage/plugin-catalog';
import { nameDescriptionColumns } from '../../../../../packages/app/src/components/columns/nameDescriptionColumns';
import { Box } from '@material-ui/core';

const constructColumns = [
  nameDescriptionColumns.createNameColumn({ defaultKind: 'component' }),
  nameDescriptionColumns.createMetadataDescriptionColumn(),
  nameDescriptionColumns.createTypeColumn({ hidden: true }),
];

export interface CatalogPageProps {
  initiallySelectedFilter?: UserListFilterKind;
  actions?: TableProps<CatalogTableRow>['actions'];
  initialKind?: string;
  tableOptions?: TableProps<CatalogTableRow>['options'];
  filters?: TableFilter;
}

export const ConstructTableCard = ({
  actions,
  tableOptions,
}: CatalogPageProps) => {
  return (
    <Content>
      <ContentHeader title="Construct"></ContentHeader>
      <Box>
        <SearchContextProvider>
          <EntityListProvider>
            <EntityTypePicker initialFilter={'construct'} hidden={true} />
            <CatalogTable
              columns={constructColumns}
              tableOptions={tableOptions}
              actions={actions}
            />
          </EntityListProvider>
        </SearchContextProvider>
      </Box>
    </Content>
  );
};
