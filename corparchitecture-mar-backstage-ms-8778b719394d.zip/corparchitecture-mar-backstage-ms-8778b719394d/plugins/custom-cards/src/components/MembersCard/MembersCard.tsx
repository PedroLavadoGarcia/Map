/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useState } from 'react';
import {
  DocsIcon,
  HeaderIconLinkRow,
  IconLinkVerticalProps,
  Table,
} from '@backstage/core-components';
import {
  Card,
  CardContent,
  CardHeader,
  Grid,
  LinearProgress,
  Link,
  Typography,
  makeStyles,
} from '@material-ui/core';
import {
  EntityRefLink,
  useEntity,
  catalogApiRef,
} from '@backstage/plugin-catalog-react';
import { JsonValue } from '@backstage/types';
import { TFunction } from 'i18next';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import useAsync from 'react-use/lib/useAsync';
import { CompoundEntityRef, Entity } from '@backstage/catalog-model';
import {
  EntityUserProfileCard,
  EntityGroupProfileCard,
  EntityMembersListCard,
} from '@backstage/plugin-org';

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100%)',
  },
  fullHeightCardContent: {
    padding: '0',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    '& thead tr th': {
      padding: 0,
    },
    '& thead tr th span': {
      display: 'none',
    },
    '& > div > div': {
      boxShadow: 'none',
    },
  },
});
function MembersCard(): JSX.Element {
  const { entity } = useEntity();
  const classes = useStyles();
  const config = useApi(configApiRef);
  const env = config.getOptionalString('app.env');

  const data: Record<string, string>[] = [];
  const content: JsonValue = entity.metadata?.name as string;

  data.push({
    value: content,
  });

  if (data.length > 0)
    if (
      !entity.metadata.name.includes('gazr') &&
      window.location.pathname.includes('/members')
    ) {
      entity.metadata.name =
        'gazr-api-backstage-ext-' +
        entity.metadata.name.toLowerCase() +
        '-' +
        env;
    }

  return (
    <Grid>
      <Card className={classes.gridItemCard}>
        <EntityMembersListCard />
      </Card>
    </Grid>
  );
}

export { MembersCard };
