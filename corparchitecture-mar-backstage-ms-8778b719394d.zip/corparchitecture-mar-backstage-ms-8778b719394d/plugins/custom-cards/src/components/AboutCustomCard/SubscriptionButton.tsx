import React, { useEffect, useState } from 'react';
import { useEntity } from '@backstage/plugin-catalog-react';
import { EntitySwitch, isKind } from '@backstage/plugin-catalog';
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogProps,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormGroup,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
} from '@material-ui/core';
import { t } from 'i18next';
import { useUserProfile } from '@backstage/plugin-user-settings';
import {
  catalogUnsubscription,
  getSubscriptionsGetReq,
  newCatalogSubscription,
} from '../../../../../packages/app/src/api/subscriptions/requests';
import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
import NotificationsOffIcon from '@material-ui/icons/NotificationsOff';
import { configApiRef, useApi } from '@backstage/core-plugin-api';
import { ANNOTATION_SOURCE_LOCATION } from '@backstage/catalog-model';

export const SubscriptionButton = () => {
  const { profile } = useUserProfile();
  const isGuest = profile.email === 'guest@example.com';
  const { entity } = useEntity();
  const configApi = useApi(configApiRef);
  const baseUrl = configApi.getString('backend.baseUrl');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isDialogSubOpen, setIsDialogSubOpen] = useState(false);
  const [freq, setFreq] = useState('7');
  const [isMetadataCheck, setIsMetadataCheck] = useState<undefined | boolean>();
  const [isInterfaceCheck, setIsInterfaceCheck] = useState<
    undefined | boolean
  >();
  const [fullWidth /* eslint-disable-line */] = useState(true);
  const [maxWidth /* eslint-disable-line */] =
    useState<DialogProps['maxWidth']>('sm');

  useEffect(() => {
    (async function () {
      if (profile.email && !isGuest)
        setIsSubscribed(await getIsSubscribed(profile.email));
    })();
  }, [profile]);

  function isApi() {
    const kind = entity.kind.toLowerCase();
    return kind.includes('mapfreapi');
  }

  async function getIsSubscribed(email: string) {
    try {
      const response = await fetch(getSubscriptionsGetReq(baseUrl, email));
      if (response.status === 200) {
        const json = await response.json();
        const isSubscribed = json.Items.some((sub: Record<string, unknown>) => {
          if (sub.entity === entity.metadata.name) {
            setFreq(sub.freq as string);
            if (isApi()) {
              setIsInterfaceCheck(sub.swagger as boolean);
              setIsMetadataCheck(sub.metadata as boolean);
            }
          }
          return sub.entity === entity.metadata.name;
        });
        return isSubscribed;
      } else {
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  async function subscribe() {
    try {
      const subscriber = profile.email ?? '';
      const name = entity.metadata.name;
      const sourceLocation =
        entity.metadata.annotations?.[ANNOTATION_SOURCE_LOCATION]?.replace(
          'url:',
          '',
        ) ?? undefined;
      const response = await fetch(
        newCatalogSubscription(
          name,
          subscriber,
          freq,
          isMetadataCheck,
          isInterfaceCheck,
          sourceLocation,
        ),
      );
      if (response.status === 200) {
        setIsDialogSubOpen(false);
        setIsSubscribed(true);

        return;
      } else {
        setIsSubscribed(false);
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  async function unsubscribe() {
    try {
      const subscriber = profile.email ?? '';
      const name = entity.metadata.name;
      const response = await fetch(catalogUnsubscription(name, subscriber));
      if (response.status === 200) {
        setIsSubscribed(false);
        setIsDialogSubOpen(false);
        setFreq('7');
        if (isApi()) {
          setIsInterfaceCheck(false);
          setIsMetadataCheck(false);
        }
        return;
      } else {
        setIsSubscribed(true);
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  if (isGuest) {
    return <></>;
  }

  const subscriptionOptions = (
    <EntitySwitch>
      <EntitySwitch.Case if={isApi}>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={isMetadataCheck}
                onChange={event => setIsMetadataCheck(event.target.checked)}
              />
            }
            label={t('Metadata')}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={isInterfaceCheck}
                onChange={event => setIsInterfaceCheck(event.target.checked)}
              />
            }
            label={t('Interface')}
          />
        </FormGroup>
      </EntitySwitch.Case>
    </EntitySwitch>
  );

  return (
    <>
      {!isSubscribed && (
        <IconButton
          aria-label="Subscribe"
          title="Subscribe"
          onClick={() => setIsDialogSubOpen(true)}
        >
          <NotificationsActiveIcon />
        </IconButton>
      )}
      {isSubscribed && (
        <IconButton
          aria-label="Unsubscribe"
          title="Unsubscribe"
          onClick={() => setIsDialogSubOpen(true)}
        >
          <NotificationsOffIcon />
        </IconButton>
      )}
      <Dialog
        fullWidth={fullWidth}
        maxWidth={maxWidth}
        open={isDialogSubOpen}
        onClose={() => setIsDialogSubOpen(false)}
      >
        <DialogTitle>{entity.metadata.title}</DialogTitle>
        <DialogContent>
          <Box sx={{ minWidth: 120 }}>
            <InputLabel id="select-frequency">{t('Frequency')}</InputLabel>
            <FormControl fullWidth variant="outlined">
              <Select
                labelId="select-frequency"
                id="select-frequency"
                value={freq}
                label="Frequency"
                onChange={event => setFreq(event.target.value as string)}
              >
                <MenuItem value={'1'}>{t('Daily')}</MenuItem>
                <MenuItem value={'7'}>{t('Weekly')}</MenuItem>
                <MenuItem value={'30'}>{t('Monthly')}</MenuItem>
              </Select>
            </FormControl>
          </Box>
          {subscriptionOptions}
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            autoFocus
            onClick={() => setIsDialogSubOpen(false)}
          >
            {t('Close')}
          </Button>
          {!isSubscribed && (
            <Button
              variant="outlined"
              autoFocus
              onClick={subscribe}
              disabled={isApi() && !isMetadataCheck && !isInterfaceCheck}
            >
              {t('Subscribe')}
            </Button>
          )}
          {isSubscribed && (
            <>
              <Button
                variant="outlined"
                autoFocus
                onClick={subscribe}
                disabled={isApi() && !isMetadataCheck && !isInterfaceCheck}
              >
                {t('Update')}
              </Button>
              <Button variant="outlined" autoFocus onClick={unsubscribe}>
                {t('Unsubscribe')}
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};
