export const wsrrFile = {
  serviceAddress: '',
  serviceID: '',
  serviceName: '',
  servicePort: '80',
  port: '',
  secureServicePort: '443',
  securePort: '',
  statusPageRelativeUrl: '/info',
  healthCheckRelativeUrl: '/health',
};