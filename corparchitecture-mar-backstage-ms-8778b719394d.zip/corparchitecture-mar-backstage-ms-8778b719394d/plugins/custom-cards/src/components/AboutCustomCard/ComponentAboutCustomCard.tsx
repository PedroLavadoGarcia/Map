import React, { useCallback } from 'react';
import { AboutCardProps } from '@backstage/plugin-catalog';
import {
  Card,
  CardContent,
  CardHeader,
  Divider,
  IconButton,
  Grid,
  Typography,
  Chip,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { t } from 'i18next';
import { catalogApiRef, useEntity } from '@backstage/plugin-catalog-react';
import {
  stringifyEntityRef,
  ANNOTATION_EDIT_URL,
  ANNOTATION_LOCATION,
  ANNOTATION_SOURCE_LOCATION,
} from '@backstage/catalog-model';
import { usePermission } from '@backstage/plugin-permission-react';
import { catalogEntityRefreshPermission } from '@backstage/plugin-catalog-common/alpha';
import CachedIcon from '@material-ui/icons/Cached';
import EditIcon from '@material-ui/icons/Edit';
import CodeIcon from '@material-ui/icons/Code';
import DescriptionIcon from '@material-ui/icons/Description';
import { alertApiRef, errorApiRef, useApi } from '@backstage/core-plugin-api';
import {
  HeaderIconLinkRow,
  IconLinkVerticalProps,
  Link,
} from '@backstage/core-components';
import { AboutCustomField } from '.';
import { SubscriptionButton } from './SubscriptionButton';

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100% - 10px)', // for pages without content header
    marginBottom: '10px',
  },
  fullHeightCard: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  },
  gridItemCardContent: {
    flex: 1,
  },
  fullHeightCardContent: {
    flex: 1,
  },
  scrollableContent: {
    width: '500px',
    maxHeight: '300px',
    overflowY: 'auto',
  },
  description: {
    wordBreak: 'break-word',
  },
  tag: {
    marginRight: '5px',
  },
  field: {
    fontWeight: 'bold',
  },
});

export function ComponentAboutCustomCard(props: AboutCardProps) {
  const { variant } = props;
  const classes = useStyles();
  const { entity } = useEntity();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const errorApi = useApi(errorApiRef);
  let cardClass = '';
  if (variant === 'gridItem') {
    cardClass = classes.gridItemCard;
  } else if (variant === 'fullHeight') {
    cardClass = classes.fullHeightCard;
  }
  let cardContentClass = '';
  if (variant === 'gridItem') {
    cardContentClass = classes.gridItemCardContent;
  } else if (variant === 'fullHeight') {
    cardContentClass = classes.fullHeightCardContent;
  }
  const entityLocation = entity.metadata.annotations?.[ANNOTATION_LOCATION];
  const allowRefresh =
    entityLocation?.startsWith('url:') || entityLocation?.startsWith('file:');
  const refreshEntity = useCallback(async () => {
    try {
      await catalogApi.refreshEntity(stringifyEntityRef(entity));
      alertApi.post({ message: 'Refresh scheduled', severity: 'info' });
    } catch (e) {
      if (e instanceof Error) errorApi.post(e);
    }
  }, [catalogApi, alertApi, errorApi, entity]);
  const canRefresh = usePermission({
    permission: catalogEntityRefreshPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });
  const subheaderLinks: IconLinkVerticalProps[] = [
    {
      label: t('component.card.view_source'),
      icon: <CodeIcon />,
      href:
        entity.metadata.annotations?.[ANNOTATION_SOURCE_LOCATION].replace(
          'url:',
          '',
        ) || '',
    },
    {
      label: t('component.card.view_techdocs'),
      icon: <DescriptionIcon />,
      href: `/docs/${entity.metadata.namespace}/${entity.kind}/${entity.metadata.name}`,
    },
  ];
  return (
    <Card className={cardClass}>
      <CardHeader
        title={t('General Data')}
        action={
          <>
            {canRefresh.loading === false &&
              canRefresh.allowed === true &&
              allowRefresh && (
                <IconButton
                  aria-label="Refresh"
                  title="Schedule entity refresh"
                  onClick={refreshEntity}
                >
                  <CachedIcon />
                </IconButton>
              )}
            <SubscriptionButton />
            {entity.metadata.annotations?.[ANNOTATION_EDIT_URL] && (
              <IconButton>
                <Link
                  to={entity.metadata.annotations[ANNOTATION_EDIT_URL]}
                  target="_blank"
                  rel="noopener"
                >
                  <EditIcon />
                </Link>
              </IconButton>
            )}
          </>
        }
        subheader={<HeaderIconLinkRow links={subheaderLinks} />}
      />
      <Divider />
      <CardContent className={cardContentClass}>
        <Grid container>
          <AboutCustomField
            label={t('component.card.description')}
            gridSizes={{ xs: 12 }}
          >
            <Typography
              variant="body2"
              paragraph
              className={classes.description}
            >
              {entity?.metadata?.description || 'component.card.no_description'}
            </Typography>
          </AboutCustomField>
          <AboutCustomField
            label={t('component.card.owner')}
            gridSizes={{ xs: 12, sm: 6, lg: 4 }}
          >
            <Link
              to={`/catalog/${entity.metadata.namespace}/group/${entity.spec?.owner}`}
            >
              <Typography variant="body2" className={classes.field}>
                {entity.spec?.owner ?? ''}
              </Typography>
            </Link>
          </AboutCustomField>
          <AboutCustomField
            label={t('component.card.system')}
            gridSizes={{ xs: 12, sm: 6, lg: 4 }}
          >
            <Typography variant="body2" className={classes.field}>
              {entity.spec?.system ?? t('component.card.no_system')}
            </Typography>
          </AboutCustomField>
          <AboutCustomField
            label={t('component.card.type')}
            gridSizes={{ xs: 12, sm: 6, lg: 4 }}
          >
            <Typography variant="body2" className={classes.field}>
              {entity.kind}
            </Typography>
          </AboutCustomField>
          <AboutCustomField
            label={t('component.card.lifecycle')}
            gridSizes={{ xs: 12, sm: 6, lg: 4 }}
          >
            <Typography variant="body2" className={classes.field}>
              {entity.spec?.lifecycle ?? ''}
            </Typography>
          </AboutCustomField>
          <AboutCustomField
            label={t('component.card.tags')}
            gridSizes={{ xs: 12, sm: 6, lg: 4 }}
          >
            {entity.metadata.tags?.map((tag, index) => (
              <Chip
                key={index}
                label={tag}
                size="small"
                className={classes.tag}
              />
            )) ?? (
              <Typography variant="body2" className={classes.field}>
                {t('component.card.no_tags')}
              </Typography>
            )}
          </AboutCustomField>
        </Grid>
      </CardContent>
    </Card>
  );
}
