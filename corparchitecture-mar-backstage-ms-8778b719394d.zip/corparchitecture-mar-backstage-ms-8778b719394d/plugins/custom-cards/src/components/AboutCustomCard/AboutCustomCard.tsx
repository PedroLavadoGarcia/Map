/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ANNOTATION_LOCATION,
  Entity,
  parseEntityRef,
  stringifyEntityRef,
} from '@backstage/catalog-model';
import { useNavigate } from 'react-router-dom';
import {
  HeaderIconLinkRow,
  IconLinkVerticalProps,
  InfoCardVariants,
} from '@backstage/core-components';
import {
  alertApiRef,
  errorApiRef,
  useApi,
  identityApiRef,
  configApiRef,
} from '@backstage/core-plugin-api';
import { catalogApiRef, useEntity } from '@backstage/plugin-catalog-react';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import LinearProgress from '@material-ui/core/LinearProgress';
import TextField from '@material-ui/core/TextField';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme, makeStyles } from '@material-ui/core/styles';
import Button from '@mui/material/Button';
import CachedIcon from '@material-ui/icons/Cached';
import { t } from 'i18next';
import React, {
  Fragment,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import { useAsync } from 'react-use';
import { AboutCustomContent } from './AboutCustomContent';
import {
  getCatalogInfo,
  uploadFiles,
  ApiChangelogService,
  ComponentsResponsiblesService,
  EmailService,
} from '@backstage/plugin-mapfreapi-editor';
import { readFileAsync } from '../../utils';
import yaml from 'yaml';
import {
  usePermission,
  AsyncPermissionResult,
} from '@backstage/plugin-permission-react';
import {
  mapfreapiEditPermission,
  mapfreapiReviewPermission,
  mapfredocEditPermission,
} from '@backstage/plugin-mapfreapi-editor-common';
import { catalogEntityRefreshPermission } from '@backstage/plugin-catalog-common/alpha';
import { sendEmailChangeState } from '../../../../mapfreapi-editor/src/lib/sendEmailChangeState';
import {
  copyRepoBucketContent,
  deleteRepoBucket,
} from '@backstage/plugin-mapfreapi-editor/src/lib/getCatalogInfo';
import { newSubscriptionCatalogApi } from '@backstage/plugin-mapfreapi-editor/src/lib/subscriptionsCatalog';
import { getSubscriptionsGetReq } from '../../../../../packages/app/src/api/subscriptions/requests';
import {
  MetadataValidationResult,
  ReviewValidationService,
  ApiValidationResult,
} from '../../../../../packages/app/src/api/review-validation';
import { SubscriptionButton } from './SubscriptionButton';
import { wsrrFile } from './wsrrFileTemplate';
import json2xml from 'json2xml';
import { CircularProgress } from '@material-ui/core';
import { updateCatalogInfoBeta } from '@backstage/plugin-forms/src/lib/updateCatalogInfoBeta';
import { setRepoBetaUrl } from '@backstage/plugin-forms/src/lib/getRepositoryUrl';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import { ResponsibleContext } from '../../../../../packages/app/src/components/catalog/ResponsibleContext';
import { DismaService } from '../../../../../packages/app/src/api/disma';
import { severities } from '../../../../../packages/app/src/api/review-validation/service';
import { WsdlToHtmlService } from '@backstage/plugin-mapfreapi-editor/src/lib/wsdlToHtml';
import { GroupChecker } from 'app/src/utils/GroupChecker';

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100% - 10px)', // for pages without content header
    marginBottom: '10px',
  },
  fullHeightCard: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  },
  gridItemCardContent: {
    flex: 1,
  },
  fullHeightCardContent: {
    flex: 1,
  },
  scrollableContent: {
    width: '500px',
    maxHeight: '300px',
    overflowY: 'auto',
  },
});

/**
 * Props for {@link EntityAboutCard}.
 *
 * @public
 */
export interface AboutCardProps {
  variant?: InfoCardVariants;
}

export async function handleWsrrFiles(
  state: string,
  files: Record<string, string>,
  catalogInfo: any,
  entity: Entity,
) {
  const COUNTRIES = [
    'ESP',
    'GLOBAL',
    'MLT',
    'ITA',
    'DEU',
    'INV',
    'ASIS',
    'RE',
    'SOL',
    'TRON',
  ];

  const TEMPLATES = [
    'EDGE API',
    'BFF API',
    'BUSINESS API',
    'EXTERNAL SERVICES',
    'MEDIATION API',
    'REST SERVICES',
    'SOAP SERVICES',
  ];

  //// Approved state and country validation ////
  if (
    state == 'approved' &&
    COUNTRIES?.includes(catalogInfo.metadata.country.toUpperCase()) &&
    TEMPLATES?.includes(catalogInfo.metadata.typology.toUpperCase())
  ) {
    //if (catalogInfo.metadata.typology == 'Edge API') { catalogInfo.spec.nextVersionOf
    if (catalogInfo.spec.type == 'openapi') {
      //Loop instances
      for (let i = 0; i < catalogInfo.metadata.instances.length; i++) {
        // Validate instance type (Validation Deleted)

        //Loop instance endpoint_IC
        for (
          let j = 0;
          j <
          catalogInfo.metadata.instances[i]['mapfre.com/endpoint_IC'].length;
          j++
        ) {
          const regex = /https?:\/\/(.*)\//g;

          if (
            regex.exec(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_IC'][
                j
              ].toString(),
            )
          ) {
            createWsrrFile(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_IC'][
                j
              ].toString(),
            );

            let fileName = '';
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][j]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][j];
            } else {
              fileName =
                i + '_' + wsrrFile.serviceName.replaceAll('/', '_') + '.json';
            }

            catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][j] =
              fileName;
            files[
              'ic/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              JSON.stringify(wsrrFile),
              'utf8',
            ).toString('base64')}`;
          }
        }

        //Loop instance endpoint_DEV
        for (
          let j = 0;
          j <
          catalogInfo.metadata.instances[i]['mapfre.com/endpoint_DEV'].length;
          j++
        ) {
          const regex = /https?:\/\/(.*)\//g;

          if (
            regex.exec(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_DEV'][
                j
              ].toString(),
            )
          ) {
            createWsrrFile(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_DEV'][
                j
              ].toString(),
            );

            let fileName = '';
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'][j]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'][
                  j
                ];
            } else {
              fileName =
                i + '_' + wsrrFile.serviceName.replaceAll('/', '_') + '.json';
            }

            catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'][j] =
              fileName;
            files[
              'desa/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              JSON.stringify(wsrrFile),
              'utf8',
            ).toString('base64')}`;
          }
        }

        //Loop instance endpoint_PRE
        for (
          let j = 0;
          j <
          catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRE'].length;
          j++
        ) {
          const regex = /https?:\/\/(.*)\//g;

          if (
            regex.exec(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRE'][
                j
              ].toString(),
            )
          ) {
            createWsrrFile(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRE'][
                j
              ].toString(),
            );

            let fileName = '';
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][j]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][j];
            } else {
              fileName =
                i + '_' + wsrrFile.serviceName.replaceAll('/', '_') + '.json';
            }

            catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][j] =
              fileName;
            files[
              'pre/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              JSON.stringify(wsrrFile),
              'utf8',
            ).toString('base64')}`;
          }
        }

        //Loop instance endpoint_PRO
        for (
          let j = 0;
          j <
          catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRO'].length;
          j++
        ) {
          const regex = /https?:\/\/(.*)\//g;

          if (
            regex.exec(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRO'][
                j
              ].toString(),
            )
          ) {
            createWsrrFile(
              catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRO'][
                j
              ].toString(),
            );

            let fileName = '';
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][j]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][j];
            } else {
              fileName =
                i + '_' + wsrrFile.serviceName.replaceAll('/', '_') + '.json';
            }

            catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][j] =
              fileName;
            files[
              'pro/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              JSON.stringify(wsrrFile),
              'utf8',
            ).toString('base64')}`;
          }
        }
      }
    }
    //else if (catalogInfo.metadata.typology == 'SOAP Services'){
    else if (
      catalogInfo.spec.type == 'other' &&
      catalogInfo.spec.wsdl &&
      catalogInfo.spec.wsdl.$text
    ) {
      const soapFileName = catalogInfo.spec.wsdl.$text.slice(
        catalogInfo.spec.wsdl.$text.lastIndexOf('/') + 1,
      );
      const soapGwFileName =
        soapFileName.substring(0, soapFileName.lastIndexOf('.')) +
        '_GW' +
        soapFileName.substring(
          soapFileName.lastIndexOf('.'),
          soapFileName.length,
        );

      //Transformation of the wsdl from json object to xml String
      const specFile = JSON.stringify(entity.spec?.['wsdl']);
      const jsonObject = JSON.parse(specFile);
      let xmlString = json2xml(jsonObject);
      xmlString = xmlString.replaceAll('&lt;', '<');
      xmlString = xmlString.replaceAll('&gt;', '>');
      xmlString = xmlString.replaceAll('&quot;', '"');
      xmlString = xmlString.replaceAll(' />', '/>');

      /* eslint-disable */
      const regExp = new RegExp(
        ':address.*[^.].*location[^=]*=[^=]*[\'"]([^\'"]+)[\'"][ /]',
      );
      /* eslint-enable */

      const found = regExp.exec(xmlString);

      if (found) {
        let fileName = '';

        //Loop instances
        for (let i = 0; i < catalogInfo.metadata.instances.length; i++) {
          const regexDEV = /https?:\/\/(.*)\//g;
          // Create and modify DEV wsdl file
          if (
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_DEV'] &&
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_DEV'][0] &&
            regexDEV.exec(
              catalogInfo.metadata.instances[i][
                'mapfre.com/endpoint_DEV'
              ][0].toString(),
            )
          ) {
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'][0]
            ) {
              fileName =
                catalogInfo.metadata.instances[i][
                  'mapfre.com/url_wsrr_desa'
                ][0];
            } else if (
              catalogInfo.metadata.instances[i]['mapfre.com/serv_type'] ==
              'External Gateway (DMZ) Alcalá'
            ) {
              fileName = soapGwFileName;
            } else {
              fileName = soapFileName;
            }

            if (catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa']) {
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_desa'][0] =
                fileName;
            }

            files[
              'desa/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              xmlString.replaceAll(
                found?.[1],
                catalogInfo.metadata.instances[i][
                  'mapfre.com/endpoint_DEV'
                ][0].toString(),
              ),
              'utf8',
            ).toString('base64')}`;
          }

          const regexIC = /https?:\/\/(.*)\//g;
          // Create and modify IC wsdl file
          if (
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_IC'] &&
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_IC'][0] &&
            regexIC.exec(
              catalogInfo.metadata.instances[i][
                'mapfre.com/endpoint_IC'
              ][0].toString(),
            )
          ) {
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][0]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][0];
            } else if (
              catalogInfo.metadata.instances[i]['mapfre.com/serv_type'] ==
              'External Gateway (DMZ) Alcalá'
            ) {
              fileName = soapGwFileName;
            } else {
              fileName = soapFileName;
            }

            if (catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic']) {
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_ic'][0] =
                fileName;
            }
            files[
              'ic/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              xmlString.replaceAll(
                found?.[1],
                catalogInfo.metadata.instances[i][
                  'mapfre.com/endpoint_IC'
                ][0].toString(),
              ),
              'utf8',
            ).toString('base64')}`;
          }

          const regexPRE = /https?:\/\/(.*)\//g;

          // Create and modify PRE wsdl file
          if (
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRE'] &&
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRE'][0] &&
            regexPRE.exec(
              catalogInfo.metadata.instances[i][
                'mapfre.com/endpoint_PRE'
              ][0].toString(),
            )
          ) {
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][0]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][0];
            } else if (
              catalogInfo.metadata.instances[i]['mapfre.com/serv_type'] ==
              'External Gateway (DMZ) Alcalá'
            ) {
              fileName = soapGwFileName;
            } else {
              fileName = soapFileName;
            }

            if (catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre']) {
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pre'][0] =
                fileName;
            }
            files[
              'pre/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              xmlString.replaceAll(
                found?.[1],
                catalogInfo.metadata.instances[i][
                  'mapfre.com/endpoint_PRE'
                ][0].toString(),
              ),
              'utf8',
            ).toString('base64')}`;
          }

          const regexPRO = /https?:\/\/(.*)\//g;

          // Create and modify PRO wsdl file
          if (
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRO'] &&
            catalogInfo.metadata.instances[i]['mapfre.com/endpoint_PRO'][0] &&
            regexPRO.exec(
              catalogInfo.metadata.instances[i][
                'mapfre.com/endpoint_PRO'
              ][0].toString(),
            )
          ) {
            if (
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'] &&
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][0]
            ) {
              fileName =
                catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][0];
            } else if (
              catalogInfo.metadata.instances[i]['mapfre.com/serv_type'] ==
              'External Gateway (DMZ) Alcalá'
            ) {
              fileName = soapGwFileName;
            } else {
              fileName = soapFileName;
            }

            if (catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro']) {
              catalogInfo.metadata.instances[i]['mapfre.com/url_wsrr_pro'][0] =
                fileName;
            }
            files[
              'pro/' + fileName
            ] = `data:text/plain;name=${fileName};base64,${Buffer.from(
              xmlString.replaceAll(
                found?.[1],
                catalogInfo.metadata.instances[i][
                  'mapfre.com/endpoint_PRO'
                ][0].toString(),
              ),
              'utf8',
            ).toString('base64')}`;
          }
        }
      }
    }
  }

  files['catalog-info.yaml'] = yaml.stringify(catalogInfo);
  return files;
}

export async function createWsrrFile(endpoint: string) {
  // Secure port or not
  let stringSplitted = endpoint.split(':');
  if (stringSplitted[0] === 'http') {
    wsrrFile.port = 'true';
    wsrrFile.securePort = 'false';
  } else {
    wsrrFile.port = 'false';
    wsrrFile.securePort = 'true';
  }

  // Extract ServiceId and Name
  let iOf = endpoint.indexOf('/');
  iOf = endpoint.indexOf('/', iOf + 2);
  wsrrFile.serviceID = endpoint.slice(iOf + 1);
  wsrrFile.serviceName = endpoint.slice(iOf + 1);

  // Extract ServiceAddress
  stringSplitted = endpoint.split('/');
  iOf = stringSplitted[2].indexOf(':');
  if (iOf == -1) {
    wsrrFile.serviceAddress = stringSplitted[2];
  } else {
    stringSplitted = stringSplitted[2].split(':');
    wsrrFile.serviceAddress = stringSplitted[0];
  }

  return wsrrFile;
}

/**
function getFileExtensions(mimeType: string) {
  switch (mimeType) {
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
      return 'xlsx';
    case 'application/vnd.ms-excel':
      return 'xls';
    case 'application/pdf':
      return 'pdf';
    case 'application/msword':
      return 'doc';
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
      return 'docx';
    case 'text/plain':
      return 'txt';
    case 'application/x-zip-compressed':
      return 'zip';
    case 'application/zip':
       return 'zip';
    default:
      return '';
  }
}*/

function MapfreApiButtonGroup({
  setNextState,
  setIsVFBtnDisabled,
  setVFWindowOpen,
  setIsChangingState,
  setIsRejectEdition,
  setIsApproveEdition,
  entity,
  canEdit,
  canReview,
  isRejectEdition,
  isApproveEdition,
}: {
  setNextState: React.Dispatch<React.SetStateAction<string>>;
  setIsVFBtnDisabled: React.Dispatch<React.SetStateAction<boolean>>;
  setVFWindowOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsChangingState: React.Dispatch<React.SetStateAction<boolean>>;
  setIsRejectEdition: React.Dispatch<React.SetStateAction<boolean>>;
  setIsApproveEdition: React.Dispatch<React.SetStateAction<boolean>>;
  entity: Entity;
  canEdit: AsyncPermissionResult;
  canReview: AsyncPermissionResult;
  isRejectEdition: boolean;
  isApproveEdition: boolean;
}) {
  const navigate = useNavigate();
  const editLabel = t('Edit');
  const cloneLabel = t('Clone');
  const reviewLabel = t('Request Review');
  const deprecateLabel = t('Deprecate');
  const approveLabel = t('Approve');
  const rejectLabel = t('Reject');
  const rejectDeprecationLabel = t('Back to approved');
  const rejectEditLabel = t('Reject edition');
  const approveEditLabel = t('Approve edition');
  const identityApi = useApi(identityApiRef);
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const config = useApi(configApiRef);
  const backendUrl = config.getString('backend.baseUrl');
  const env = config.getOptionalString('app.env');
  const reviewValidation = new ReviewValidationService(backendUrl);
  const componentsResponsibles = new ComponentsResponsiblesService(config);
  const wsdlToHtmlService = new WsdlToHtmlService(config);
  const disma = new DismaService();
  const [isDialogValidatedOpen, setIsDialogValidatedOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isDialogLoadingOpen, setIsDialogLoadingOpen] = useState(false);
  const [isDialogApprovedLoadingOpen, setIsDialogApprovedLoadingOpen] =
    useState(false);
  const [isEditedinApprove, setIsEditedinApprove] = useState(false);
  const [comment, setComment] = useState('');
  const apiChangelog = new ApiChangelogService(backendUrl);
  const [finalStateAfterValidation, setFinalStateAfterValidation] =
    useState('review');
  const { responsibleApproval } = useContext(ResponsibleContext);
  const str =
    entity.metadata.annotations?.['backstage.io/view-url'].split(
      'catalog-info',
    )[0];
  const title = entity.metadata.title as string;
  const bucket = str?.split('/')[2].split('.')[0];
  const repo = str?.split('/')[3];

  const classes = useStyles();

  const token =
    useAsync(async () => (await identityApi.getCredentials()).token).value ??
    '';

  const profileInfo = useAsync(
    async () => await identityApi.getProfileInfo(),
  ).value;

  const { value: groupChecker } = useAsync(async () => {
    return await GroupChecker.init(identityApi);
  });

  function handleCloseValidate() {
    if (isApproveEdition) {
      const oldEntityName = entity.metadata.name.split('_')[0];
      const namespace = entity.metadata.namespace;
      navigate(
        `/catalog/${namespace}/${entity?.kind.toLowerCase()}/${oldEntityName}`,
      );
    } else {
      catalogApi.refreshEntity(stringifyEntityRef(entity));
    }
    window.location.reload();
    setIsDialogValidatedOpen(false);
  }
  function handleApprovedEdit(clone = true, approved = true) {
    const typology = entity.metadata.typology as string;
    const formattedTypology = typology.replaceAll(' ', '_');

    switch (formattedTypology) {
      case 'REST_Services':
      case 'Edge_API':
      case 'Mediation_API':
      case 'Login_API':
      case 'SOAP_Services':
      case 'External_Services':
        navigate(
          `/forms/${entity.kind.toLocaleLowerCase()}/${
            entity.metadata.name
          }?typology=${formattedTypology}&clone=${clone}&approved=${approved}`,
        );
        break;

      default:
        navigate(
          `/mapfreapi-editor/${
            entity.metadata.name
          }${`?clone=${clone}&approved=${approved}`}`,
        );
        break;
    }
  }

  function handleEdit(clone = false) {
    const typology = entity.metadata.typology as string;
    const formattedTypology = typology.replaceAll(' ', '_');

    switch (formattedTypology) {
      case 'REST_Services':
      case 'Edge_API':
      case 'Mediation_API':
      case 'Login_API':
      case 'SOAP_Services':
      case 'External_Services':
        navigate(
          `/forms/${entity.kind.toLocaleLowerCase()}/${
            entity.metadata.name
          }?typology=${formattedTypology}&clone=${clone}`,
        );
        break;

      default:
        navigate(
          `/mapfreapi-editor/${entity.metadata.name}${`?clone=${clone}`}`,
        );
        break;
    }
  }
  async function handleChangeState(nextState: string, edit = false) {
    if (nextState === 'reject' && edit) {
      setIsRejectEdition(true);
      setIsApproveEdition(false);
    }

    if (nextState === 'approved' && edit) {
      setIsApproveEdition(true);
      setIsRejectEdition(false);
    }

    setNextState(nextState);
    setIsVFBtnDisabled(false);
    setVFWindowOpen(true);
  }

  async function validateApi(edited = false) {
    setIsLoading(true);
    setIsDialogValidatedOpen(true);

    let validationFailed = false;
    let responseValidateMetadata: MetadataValidationResult = {
      errors: [],
    };
    let responseValidateApi: ApiValidationResult = {
      errors: [],
    };
    let finalStateAfterValidation = 'approved';

    try {
      if (bucket && repo) {
        responseValidateMetadata = await reviewValidation.validateMetadata(
          bucket,
          repo,
        );
        if (
          entity.metadata.typology !== 'External Services' &&
          entity.metadata.typology !== 'API Consumer'
        ) {
          responseValidateApi = await reviewValidation.validateApi(
            bucket,
            repo,
          );
        }
      }
    } catch (error) {
      console.error('Error validating API', error);
      finalStateAfterValidation = 'review';
      setFinalStateAfterValidation(finalStateAfterValidation);
      validationFailed = true;
    }

    if (!validationFailed) {
      finalStateAfterValidation = generateFinalState(
        responseValidateMetadata,
        responseValidateApi,
        edited,
      );
    }

    if (
      responseValidateMetadata.errors.length > 0 ||
      responseValidateApi.errors.length > 0
    ) {
      generateReport(
        responseValidateMetadata,
        responseValidateApi,
        finalStateAfterValidation,
      );
    }
    setNextState(finalStateAfterValidation);
    await stateChangeAfterValidation(
      finalStateAfterValidation,
      !validationFailed,
    );
    setIsLoading(false);
  }

  function ValidationDialog({ state }: { state: string }) {
    return (
      <DialogContent className={classes.scrollableContent}>
        <DialogContentText>
          <strong> {t('api.review.title')}:</strong>
          <p>{t(`api.review.state.${state}`)}</p>
        </DialogContentText>
      </DialogContent>
    );
  }

  async function unRegisterEntity(repository: string) {
    const location = await catalogApi.getLocationByRef(repository);
    if (location) {
      return catalogApi.removeLocationById(location.id);
    }
    throw Error('Missing MapfreApi entity');
  }

  async function stateChangeAfterValidation(
    state: string,
    isAutoValidation = false,
    isGovForced = false,
  ) {
    setIsChangingState(true);
    if (state === 'warn' || state === 'info') {
      state = 'approved';
    }
    const now = Date.now().toString();
    let files: Record<string, string> = {};
    const repositoryUrl =
      entity.metadata.annotations?.['backstage.io/view-url'];

    if (!repositoryUrl) {
      throw Error('Cannot retrieve entity repository view url.');
    }

    try {
      const catalogInfo = yaml.parse(
        await getCatalogInfo(repositoryUrl, token),
      );

      const calatogInfoOriginal = JSON.parse(JSON.stringify(catalogInfo));

      catalogInfo.metadata['mapfre.com/state'] =
        // eslint-disable-next-line react/prop-types
        state.charAt(0).toUpperCase() + state.slice(1);
      if (catalogInfo.spec) {
        catalogInfo.spec.lifecycle =
          // eslint-disable-next-line react/prop-types
          state.charAt(0).toUpperCase() + state.slice(1);
      }
      catalogInfo.metadata.modDate = now;
      if (
        catalogInfo.spec.type === 'other' &&
        state === 'approved' &&
        catalogInfo.spec.wsdl &&
        catalogInfo.spec.wsdl.$text &&
        (catalogInfo.spec.wsdl.$text as string).length > 0
      ) {
        const definitionPath = await wsdlToHtmlService.generateDefinitionReport(
          entity,
        );
        if (definitionPath) {
          catalogInfo.spec = {
            ...catalogInfo.spec,
            definition: {
              $text: definitionPath,
            },
          };
        }
      }
      if (isApproveEdition) {
        catalogInfo.metadata.name = catalogInfo.metadata.name.split('_')[0];
        catalogInfo.metadata.version =
          catalogInfo.metadata.version.split('_')[0];
        catalogInfo.spec.nextVersionOf = [];
      }
      if (catalogInfo.metadata.historyLog) {
        (catalogInfo.metadata.historyLog as Record<string, string>)[
          'mapfre.com/modDate'
        ] = now;
        (catalogInfo.metadata.historyLog as Record<string, string>)[
          'mapfre.com/user_mod'
        ] = (await identityApi.getBackstageIdentity()).userEntityRef;
      }

      //// handle creation of wsrr files ////
      files = await handleWsrrFiles(state, files, catalogInfo, entity);

      const profileInfo = await identityApi.getProfileInfo();
      await uploadFiles(repositoryUrl, files, token);

      /////////////////////////////////////////////////////////////////////////////////

      await apiChangelog.pushLogFromEntity(
        yaml.stringify(calatogInfoOriginal),
        files,
        profileInfo?.email as string,
        catalogInfo,
        isAutoValidation
          ? t('api.review.auto')
          : isGovForced
          ? `${t('gov.forced')}. ${comment}`
          : comment,
        isRejectEdition
          ? (`Entity edition rejected` as string)
          : isApproveEdition
          ? (`Entity edition accepted` as string)
          : (`Entity state transitioned to ${state}` as string),
      );

      try {
        await sendEmailChangeState(
          state,
          isApproveEdition,
          isRejectEdition,
          undefined,
          catalogInfo,
          catalogApi,
          '',
          env as string,
        );
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error sending email ${error.message} `, error);
        }
      }

      if (state === 'approved') {
        const owners: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/owners'];
        const resp_func: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/resp_func'];
        const resp_tech: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/resp_tech'];
        const liablePeople: string[] = owners
          .concat(resp_func)
          .concat(resp_tech)
          .filter(entityRef => {
            if (!entityRef) return false;
            const entity = parseEntityRef(entityRef);
            return entity.kind.toLocaleLowerCase() === 'user';
          })
          .map(entityRef => {
            const entity = parseEntityRef(entityRef);
            return entity.name.replace(/_(?=[^_]*$)/, '@');
          });

        const subscribers: string[] = [...new Set(liablePeople)];
        const uidApi: string = catalogInfo.metadata.name;
        for (const subscriber of subscribers) {
          if (!(await getIsSubscribed(subscriber))) {
            await newSubscriptionCatalogApi(
              uidApi,
              subscriber,
              true,
              true,
              '7',
            );
          }
        }
      }
      const locationRef =
        entity.metadata.annotations?.['backstage.io/managed-by-location'] ?? '';
      const bucket = locationRef.split('/')[2].split('.')[0];
      const repo = locationRef.split('/')[3];
      if (isApproveEdition) {
        //Delete parent repo
        if (repo.includes('_edit')) {
          await deleteRepoBucket(
            backendUrl,
            bucket,
            repo.replace('_edit', ''),
            token,
          );
        }
        await copyRepoBucketContent(backendUrl, bucket, repo, token);
        const logs = await apiChangelog.getLogs(entity.metadata.name);
        const oldEntityName = entity.metadata.name.split('_')[0];
        for (const log of logs) {
          await apiChangelog.pushLog({
            ...log,
            uidApi: oldEntityName,
          });
          await apiChangelog.deleteLog(entity.metadata.name, log.date);
        }
        const responsibles = await componentsResponsibles.getAll(
          entity.metadata.name,
        );
        for (const responsible of responsibles) {
          await componentsResponsibles.delete(
            entity,
            responsible.responsible,
            responsible.type,
          );
        }
        await deleteRepoBucket(backendUrl, bucket, repo, token);
      }
    } catch (error) {
      if (error instanceof Error) {
        alertApi.post({
          message: error.message,
          severity: 'error',
        });
      }
    }

    if (isApproveEdition) {
      const oldEntityName = entity.metadata.name.split('_')[0];
      const kind = entity.kind.toLowerCase();
      const namespace = entity.metadata.namespace;
      const oldEntity = `${kind}:${namespace}/${oldEntityName}`;
      const locationRef =
        entity.metadata.annotations?.['backstage.io/managed-by-location'] ?? '';
      await catalogApi.refreshEntity(oldEntity);
      await unRegisterEntity(locationRef);
    } else {
      catalogApi.refreshEntity(stringifyEntityRef(entity));
    }
  }

  function generateFinalState(
    responseValidateMetadata: MetadataValidationResult,
    responseValidateApi: ApiValidationResult,
    edited = false,
  ) {
    let finalStateAfterValidation = 'approved';
    const errors = [
      ...responseValidateMetadata.errors,
      ...responseValidateApi.errors,
    ];
    for (const severity of severities) {
      if (errors.some(error => error.severity === severity)) {
        switch (severity) {
          case 'error':
            finalStateAfterValidation = 'draft';
            break;
          case 'review':
          case 'warn':
          case 'info':
            finalStateAfterValidation = severity;
            break;
        }
        break;
      }
    }

    setFinalStateAfterValidation(finalStateAfterValidation);
    if (edited) {
      if (finalStateAfterValidation === 'review') {
        finalStateAfterValidation = 'review edited';
      }
      if (finalStateAfterValidation === 'draft') {
        finalStateAfterValidation = 'edited';
      }
      if (
        finalStateAfterValidation === 'warn' ||
        finalStateAfterValidation === 'info' ||
        finalStateAfterValidation === 'approved'
      ) {
        isApproveEdition = true;
        setIsApproveEdition(isApproveEdition);
      }
    }
    return finalStateAfterValidation;
  }

  async function generateReport(
    responseValidateMetadata: MetadataValidationResult,
    responseValidateApi: ApiValidationResult,
    state: string,
  ) {
    try {
      let responsibles: string[] = [];
      const liablePeople = entity.metadata.liablePeople as any;
      if (liablePeople['mapfre.com/owners']) {
        responsibles.push(
          ...liablePeople['mapfre.com/owners'].map((r: string) =>
            r.replace('_', '@'),
          ),
        );
      }
      if (liablePeople['mapfre.com/resp_func']) {
        responsibles.push(
          ...liablePeople['mapfre.com/resp_func'].map((r: string) =>
            r.replace('_', '@'),
          ),
        );
      }
      if (liablePeople['mapfre.com/resp_tech']) {
        responsibles.push(
          ...liablePeople['mapfre.com/resp_tech'].map((r: string) =>
            r.replace('_', '@'),
          ),
        );
      }
      responsibles = responsibles.filter(
        (r: string, index) => responsibles.indexOf(r) === index,
      );
      await reviewValidation.generateReport(
        title,
        responseValidateMetadata,
        responseValidateApi,
        state,
        bucket!,
        repo!,
        responsibles,
      );
    } catch (error) {
      console.error('Error generating report', error);
    }
  }

  async function isGlobalGroup(): Promise<boolean> {
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();

      return entityRefs.some(entityRef => {
        const parsedRef = parseEntityRef(entityRef);
        const groupName = parsedRef.name.toLowerCase();
        const isGroup = parsedRef.kind === 'group';

        return isGroup && groupName.startsWith('gazr-gov-backstage-global');
      });
    } catch (error) {
      console.error('Error al obtener entityRefs:', error);
      return false;
    }
  }

  async function isWsrrGroup(): Promise<boolean> {
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();

      //If they have 2 roles or less, it is verified if one of them is WSRR. If the user has more than 2 roles, the additional role allows them to clone
      if (entityRefs.length <= 2) {
        const foundGroupRef = entityRefs?.find((ref: string) => {
          const entityRef = parseEntityRef(ref);
          return (
            entityRef.kind.toLowerCase() === 'group' &&
            entityRef.name.toLowerCase().includes('gazr-api-backstage-wsrr')
          );
        });

        if (foundGroupRef) {
          return true;
        }
      }

      return false;
    } catch (error) {
      console.error('Error al obtener entityRefs:', error);
      return false;
    }
  }

  async function isDismaGroup(): Promise<boolean> {
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();

      //If they have 2 roles or less, it is verified if one of them is WSRR. If the user has more than 2 roles, the additional role allows them to clone
      if (entityRefs.length <= 2) {
        const foundGroupRef = entityRefs?.find((ref: string) => {
          const entityRef = parseEntityRef(ref);
          return (
            entityRef.kind.toLowerCase() === 'group' &&
            entityRef.name.toLowerCase().includes('gazr-gov-backstage-disma')
          );
        });

        if (foundGroupRef) {
          return true;
        }
      }

      return false;
    } catch (error) {
      console.error('Error al obtener entityRefs:', error);
      return false;
    }
  }

  async function isCountryGroup(): Promise<boolean> {
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();

      return entityRefs.some(entityRef => {
        const parsedRef = parseEntityRef(entityRef);
        const groupName = parsedRef.name.toLowerCase();
        const isGroup = parsedRef.kind === 'group';
        const country = (
          (entity.metadata.country as string) ?? ''
        ).toLowerCase();
        return isGroup && groupName.includes(`gazr-gov-backstage-${country}`);
      });
    } catch (error) {
      console.error('Error al obtener entityRefs:', error);
      return false;
    }
  }

  const [isGlobal, setIsGlobal] = useState(false);
  const [isCountry, setIsCountry] = useState(false);

  useEffect(() => {
    async function checkGlobalGroup() {
      const globalGroup = await isGlobalGroup();
      setIsGlobal(globalGroup);
    }

    checkGlobalGroup();
  }, []);

  const [isWsrr, setIsWsrr] = useState(false);
  const [isDisma, setIsDisma] = useState(false);

  useEffect(() => {
    async function checkWsrrGroup() {
      const wsrrGroup = await isWsrrGroup();
      setIsWsrr(wsrrGroup);
    }

    async function checkDismaGroup() {
      const dismaGroup = await isDismaGroup();
      setIsDisma(dismaGroup);
    }

    checkWsrrGroup();
    checkDismaGroup();
  }, []);

  useAsync(async () => {
    setIsCountry(await isCountryGroup());
  });

  async function getIsSubscribed(email: string) {
    try {
      const response = await fetch(getSubscriptionsGetReq(backendUrl, email));
      if (response.status === 200) {
        const json = await response.json();
        const isSubscribed = json.Items.some((sub: Record<string, unknown>) => {
          return (
            sub.entity === (entity.metadata.name as string).replace('_edit', '')
          );
        });
        return isSubscribed;
      } else {
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  async function handleReview(edited = false) {
    const typology = entity.metadata.typology as string;

    if (
      typology.includes('REST Services') ||
      typology.includes('Edge API') ||
      typology.includes('Mediation API') ||
      typology.includes('Login API')
    ) {
      window.location.href = `/forms/${entity.kind.toLocaleLowerCase()}/${
        entity.metadata.name
      }?typology=${typology.replaceAll(' ', '_')}&clone=false`;
      return;
    }

    if (
      typology.includes('SOAP Services') ||
      typology.includes('External Services')
    ) {
      window.location.href = `/forms/${entity.kind.toLocaleLowerCase()}2/${
        entity.metadata.name
      }?typology=${typology.replaceAll(' ', '_')}&clone=false`;
      return;
    }

    switch (responsibleApproval) {
      case 'approved':
        if ((entity.metadata.features as any)?.apiAutoValidation ?? false) {
          validateApi(edited);
        } else {
          setIsDialogLoadingOpen(true);
          const finalStateAfterValidation = 'review';
          setFinalStateAfterValidation(finalStateAfterValidation);
          await stateChangeAfterValidation(
            finalStateAfterValidation,
            false,
            true,
          );
          setIsDialogLoadingOpen(false);
          catalogApi.refreshEntity(stringifyEntityRef(entity));
          window.location.reload();
        }
        break;
      case 'pending':
      case 'rejected':
        alertApi.post({
          message: t(`api.review.responsibles.${responsibleApproval}`),
          severity: 'info',
        });
        break;
    }
  }

  async function handleApproveDialog(edited = false) {
    setIsDialogApprovedLoadingOpen(true);
    setIsEditedinApprove(edited);
  }

  async function handleApprove(edited = false) {
    setIsDialogApprovedLoadingOpen(false);
    setIsDialogLoadingOpen(true);

    const responsibles = await componentsResponsibles.getAll(
      entity.metadata.name,
    );
    for (const responsible of responsibles) {
      await componentsResponsibles.delete(
        entity,
        responsible.responsible,
        responsible.type,
        true,
        profileInfo?.email,
      );
    }
    const finalStateAfterValidation = 'approved';
    setFinalStateAfterValidation(finalStateAfterValidation);
    if (edited) {
      isApproveEdition = true;
      setIsApproveEdition(isApproveEdition);
    }
    await stateChangeAfterValidation('approved', false, true);
    if (isApproveEdition) {
      const oldEntityName = entity.metadata.name.split('_')[0];
      const namespace = entity.metadata.namespace;
      navigate(
        `/catalog/${namespace}/${entity?.kind.toLowerCase()}/${oldEntityName}`,
      );
    } else {
      catalogApi.refreshEntity(stringifyEntityRef(entity));
    }
    setIsDialogLoadingOpen(false);
    window.location.reload();
  }

  function handleCloseApprovedLoadingOpen() {
    setIsDialogApprovedLoadingOpen(false);
  }

  return (
    <>
      <Dialog open={isDialogLoadingOpen}>
        <DialogContent>
          <CircularProgress
            style={{ width: '100px', height: '100px', margin: '40px' }}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={isDialogValidatedOpen}>
        {isLoading ? (
          <DialogContent>
            <DialogContentText className={classes.scrollableContent}>
              {t('Validating...')}
            </DialogContentText>
            <LinearProgress />
          </DialogContent>
        ) : (
          <>
            <ValidationDialog state={finalStateAfterValidation} />
          </>
        )}
        <DialogActions>
          {!isLoading && (
            <Button
              variant="contained"
              autoFocus
              color="error"
              onClick={handleCloseValidate}
            >
              {t('Accept')}
            </Button>
          )}
        </DialogActions>
      </Dialog>
      <Dialog
        open={isDialogApprovedLoadingOpen}
        aria-labelledby="validation-flow-dialog"
        onClose={() => {
          setComment('');
        }}
      >
        <DialogTitle id="validation-flow-dialog">
          {t('Approve (no review)')}
        </DialogTitle>
        <DialogContent>
          <DialogContentText></DialogContentText>
          <InputLabel htmlFor="approved-comment">
            {t('Tell us why:')}
          </InputLabel>
          <TextField
            style={{ marginTop: 5 }}
            helperText={t(
              'Add a comment to indicate us why you decide to approved it without using automatic validation.',
            )}
            fullWidth
            margin="normal"
            InputLabelProps={{
              shrink: true,
            }}
            variant="outlined"
            inputProps={{
              maxLength: 100,
            }}
            onChange={event => {
              setComment(event.target.value);
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleCloseApprovedLoadingOpen}
            autoFocus
            color="inherit"
          >
            {t('Discard')}
          </Button>
          <Button
            onClick={() => handleApprove(isEditedinApprove)}
            color="error"
            variant="contained"
            disabled={comment.length < 5}
            autoFocus
          >
            {t('Agree')}
          </Button>
        </DialogActions>
      </Dialog>
      <Fragment>
        {
          /** En estado REVIEW EDITED hay 2 botones:
           * APPROVED EDITION modifica el estado a APPROVED. Representa que se aprueba la edición y se queda en estado aprobado.
           * REJECT EDITION  modifica el estado y vuelve al estado anterior (APPROVED). Representa que se rechaza la modificación del activo y
           * se recupera el estado anterior descartando los cambios realizados.
           */
          canReview.loading === false &&
            canReview.allowed === true &&
            entity.spec?.lifecycle === 'Review edited' && (
              <>
                <ButtonGroup
                  variant="contained"
                  aria-label="draft temp button group"
                >
                  {isGlobal && (
                    <Button
                      variant="outlined"
                      color="warning"
                      onClick={() => handleEdit()}
                    >
                      {editLabel}
                    </Button>
                  )}
                  <Button
                    variant="contained"
                    color="success"
                    onClick={async () => {
                      if (await disma.haveChanges(entity)) {
                        handleChangeState('security review edited', true);
                      } else {
                        handleChangeState('approved', true);
                      }
                    }}
                  >
                    {approveEditLabel}
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    onClick={() => handleChangeState('edited', true)}
                  >
                    {rejectEditLabel}
                  </Button>
                </ButtonGroup>
              </>
            )
        }
        {
          /** En estado EDITED hay 2 botones:
           * EDIT lleva al formulario de edición por si es necesario volver a modificar.
           * REVIEW lanza el script para revisión automática. Se muestra un mensaje con el resultado de la validación.
           */
          canEdit.loading === false &&
            canEdit.allowed === true &&
            entity.spec?.lifecycle === 'Edited' && (
              <>
                <ButtonGroup
                  variant="contained"
                  aria-label="draft button group"
                >
                  <Button
                    variant="outlined"
                    color="warning"
                    onClick={() => handleEdit()}
                  >
                    {editLabel}
                  </Button>

                  <Button
                    variant="outlined"
                    color="warning"
                    onClick={() => handleReview(true)}
                  >
                    {reviewLabel}
                  </Button>

                  {(isCountry || isGlobal) && (
                    <Button
                      variant="outlined"
                      color="warning"
                      onClick={() => handleApproveDialog(true)}
                    >
                      {t('Approve (no review)')}
                    </Button>
                  )}
                </ButtonGroup>
              </>
            )
        }
        {
          /** En estado BORRADOR hay 2 botones:
           * EDIT lleva al formulario de edición por si ha habido algún error en el alta.
           * REVIEW  modifica el estado a Review. Representa que el alta la ha hecho bien y
           * manda el activo a revisión para ser aprobado o rechazado
           */
          canEdit.loading === false &&
            canEdit.allowed === true &&
            entity.spec?.lifecycle === 'Draft' && (
              <>
                <ButtonGroup
                  variant="contained"
                  aria-label="draft button group"
                >
                  <Button
                    variant="outlined"
                    color="warning"
                    onClick={() => handleEdit()}
                  >
                    {editLabel}
                  </Button>
                  {entity.kind === 'MapfreApiLegacyEsp' ||
                  entity.kind === 'MapfreApiLegacyBra' ||
                  entity.kind === 'MapfreApiLegacyGlobal' ||
                  entity.kind === 'MapfreApiLegacyPer' ||
                  isWsrr ||
                  isDisma ? (
                    ''
                  ) : (
                    <Button
                      variant="outlined"
                      color="warning"
                      onClick={() => handleEdit(true)}
                    >
                      {cloneLabel}
                    </Button>
                  )}

                  <Button
                    variant="outlined"
                    color="warning"
                    onClick={() => handleReview()}
                  >
                    {reviewLabel}
                  </Button>

                  {(isCountry || isGlobal) && (
                    <Button
                      variant="outlined"
                      color="warning"
                      onClick={() => handleApproveDialog()}
                    >
                      {t('Approve (no review)')}
                    </Button>
                  )}
                </ButtonGroup>
              </>
            )
        }
        {
          /** En estado APROBADO hay 2 botones:
           * EDIT lleva al formulario de edición por si quieren modificar algun campo.
           * DEPRECATE modifica el estado a RETIRED. En ppio si está deprecado no sale
           * ningún botón
           */

          entity.spec?.lifecycle === 'Approved' && (
            <ButtonGroup variant="contained" aria-label="approved button group">
              {canEdit.loading === false && canEdit.allowed === true && (
                <Button
                  variant="outlined"
                  color="warning"
                  onClick={() => handleApprovedEdit()}
                >
                  {editLabel}
                </Button>
              )}
              {entity.kind === 'MapfreApiLegacyEsp' ||
              entity.kind === 'MapfreApiLegacyBra' ||
              entity.kind === 'MapfreApiLegacyGlobal' ||
              entity.kind === 'MapfreApiLegacyPer' ||
              isWsrr ||
              isDisma ? (
                ''
              ) : (
                <Button
                  variant="outlined"
                  color="warning"
                  onClick={() => handleEdit(true)}
                >
                  {cloneLabel}
                </Button>
              )}

              {canEdit.loading === false && canEdit.allowed === true && (
                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleChangeState('retired candidate')}
                >
                  {deprecateLabel}
                </Button>
              )}
            </ButtonGroup>
          )
        }
        {
          /** En estado REVIEW hay 2 botones:
           * APPROVE manda un informe con los datos del activo y su aprobación al owner.
           * Este informe debe quedar subido a bitbucket y se debe crear la fecha de aprobación
           * en metadata. Toda esta info debe salir en Historial
           * REJECT manda un informe con los datos del activo y los motivos del rechazo.
           *Se pasa el estado a borrador.
           */
          canReview.loading === false &&
            canReview.allowed === true &&
            entity.spec?.lifecycle == 'Review' && (
              <ButtonGroup variant="contained" aria-label="draft button group">
                {isGlobal && (
                  <Button
                    variant="outlined"
                    color="warning"
                    onClick={() => handleEdit()}
                  >
                    {editLabel}
                  </Button>
                )}
                <Button
                  variant="contained"
                  color="success"
                  onClick={async () => {
                    if (await disma.haveChanges(entity)) {
                      handleChangeState('security review');
                    } else {
                      handleChangeState('approved');
                    }
                  }}
                >
                  {approveLabel}
                </Button>

                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleChangeState('draft')}
                >
                  {rejectLabel}
                </Button>
              </ButtonGroup>
            )
        }

        {
          /** Security review:
           */
          entity.spec?.lifecycle == 'Security review' &&
            (groupChecker?.isDisma() || groupChecker?.isAdmin()) && (
              <ButtonGroup variant="contained" aria-label="draft button group">
                <Button
                  variant="contained"
                  color="success"
                  onClick={() => handleChangeState('approved')}
                >
                  {approveLabel}
                </Button>

                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleChangeState('draft')}
                >
                  {rejectLabel}
                </Button>
              </ButtonGroup>
            )
        }

        {
          /** Security review edited:
           */
          entity.spec?.lifecycle == 'Security review edited' &&
            (groupChecker?.isDisma() || groupChecker?.isAdmin()) && (
              <ButtonGroup variant="contained" aria-label="draft button group">
                <Button
                  variant="contained"
                  color="success"
                  onClick={() => handleChangeState('approved', true)}
                >
                  {approveLabel}
                </Button>

                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleChangeState('edited', true)}
                >
                  {rejectLabel}
                </Button>
              </ButtonGroup>
            )
        }

        {entity.spec?.lifecycle == 'Approved' && <SubscriptionButton />}

        {canReview.loading === false &&
          canReview.allowed === true &&
          entity.spec?.lifecycle == 'Retired candidate' && (
            <ButtonGroup variant="contained" aria-label="draft button group">
              <Button
                variant="contained"
                color="success"
                onClick={() => handleChangeState('approved')}
              >
                {rejectDeprecationLabel}
              </Button>

              <Button
                variant="contained"
                color="error"
                onClick={() => handleChangeState('retired')}
              >
                {deprecateLabel}
              </Button>
            </ButtonGroup>
          )}
      </Fragment>
    </>
  );
}

function MapfreDocumentButtonGroup({
  setNextState,
  setIsVFBtnDisabled,
  setVFWindowOpen,
  setIsAcceptingMaster,
  setAcceptedFromPending,
  entity,
  canEditDoc,
  isUserEditorOrResp,
  isUserAdmin,
}: {
  setNextState: React.Dispatch<React.SetStateAction<string>>;
  setIsVFBtnDisabled: React.Dispatch<React.SetStateAction<boolean>>;
  setVFWindowOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsAcceptingMaster: React.Dispatch<React.SetStateAction<boolean>>;
  setAcceptedFromPending: React.Dispatch<React.SetStateAction<boolean>>;
  entity: Entity;
  canEditDoc: AsyncPermissionResult;
  isAcceptingMaster: boolean;
  isUserEditorOrResp: boolean;
  isUserAdmin: boolean;
  acceptedFromPending: boolean;
}) {
  const navigate = useNavigate();
  const acceptLabel = t('Accept');
  const rejectLabel = t('Reject');
  const reviewAcceptanceLabel = t('Review acceptance');
  const discardLabel = t('Discard');
  const reviewApprovalLabel = t('Review approval');
  const approveLabel = t('Approve');
  const editLabel = t('Edit');
  const approveDeprecateLabel = t('Deprecate');
  const approveDeprecationLabel = t('Retire');
  const rejectDeprecationLabel = t('Back to approved');
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const [isDialogValidatedOpen, setIsDialogValidatedOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [finalStateAfterValidation, setFinalStateAfterValidation] =
    useState('');

  const classes = useStyles();

  function handleCloseValidate() {
    window.location.reload();
    catalogApi.refreshEntity(stringifyEntityRef(entity));
    setIsDialogValidatedOpen(false);
  }

  async function handleEdit() {
    const repositoryUrl =
      entity.metadata.annotations?.['backstage.io/view-url'];
    setRepoBetaUrl(repositoryUrl as string);

    try {
      navigate(
        `/forms/${entity.kind.toLocaleLowerCase()}/${entity.metadata.name}`,
      );
    } catch (error) {
      if (error instanceof Error) {
        alertApi.post({
          message: error.message,
          severity: 'error',
        });
      }
    }
  }

  function handleChangeState(e: React.SyntheticEvent<EventTarget>) {
    if (!(e.target instanceof HTMLButtonElement)) {
      return;
    }
    const nextStateValue = e.target.dataset.state || '';

    if (
      entity.spec?.lifecycle === 'Pending approval' &&
      nextStateValue === 'accepted'
    ) {
      setAcceptedFromPending(true);
      setIsAcceptingMaster(false);
      setNextState('accepted');
    } else if (
      entity.spec?.lifecycle === 'Pending acceptance' &&
      nextStateValue === 'accepted'
    ) {
      setIsAcceptingMaster(true);
      setAcceptedFromPending(false);
      setNextState('accepted');
    } else {
      setIsAcceptingMaster(false);
      setAcceptedFromPending(false);
      setNextState(nextStateValue);
    }

    setIsVFBtnDisabled(false);
    setVFWindowOpen(true);
  }

  function ValidationDialog({ state }: { state: string }) {
    return (
      <DialogContent className={classes.scrollableContent}>
        <DialogContentText>
          <strong> {t('api.review.title')}:</strong>
          <p>{t(`api.review.state.${state}`)}</p>
        </DialogContentText>
      </DialogContent>
    );
  }

  return (
    <>
      <Dialog open={isDialogValidatedOpen}>
        {isLoading ? (
          <DialogContent>
            <DialogContentText className={classes.scrollableContent}>
              {t('Validating...')}
            </DialogContentText>
            <LinearProgress />
          </DialogContent>
        ) : (
          <>
            <ValidationDialog state={finalStateAfterValidation} />
          </>
        )}
        <DialogActions>
          <Button
            variant="contained"
            autoFocus
            color="error"
            onClick={handleCloseValidate}
          >
            {t('Accept')}
          </Button>
        </DialogActions>
      </Dialog>

      <Fragment>
        {
          /** En estado PENDIENTE ACEPTACION hay 2 botones:
           * ACEPTAR pasa el estado a ACEPTADO.
           * RECHAZAR  pasa al estado BORRADOR
           * DESCARTAR pasa al estado DESCARTADO
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Pending acceptance' && (
              <>
                {isUserAdmin ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="accepted"
                      id="accepted"
                      onClick={handleChangeState}
                    >
                      {acceptLabel}
                    </Button>

                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="draft"
                      onClick={handleChangeState}
                    >
                      {rejectLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="discarded"
                      onClick={handleChangeState}
                    >
                      {discardLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }
        {
          /** En estado  BORRADOR hay 2 botones:
           * REVIEW ACCEPTANCE pasa el estado a  PENDIENTE DE ACEPTACION.
           * EDITAR
           * DISCARD  pasa al estado DESCARTADO
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Draft' && (
              <>
                {isUserAdmin || isUserEditorOrResp ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="pending acceptance"
                      onClick={handleEdit}
                    >
                      {editLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="pending acceptance"
                      onClick={handleChangeState}
                    >
                      {reviewAcceptanceLabel}
                    </Button>

                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="discarded"
                      onClick={handleChangeState}
                    >
                      {discardLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }
        {
          /** En estado  ACCEPTED hay 2 botones:
           * PENDING APPROVAL pasa el estado a  PENDIENTE DE APROBACION.
           * EDIT para editar los metadatos a través del formulario
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Accepted' &&
            entity.spec?.type === 'Simple' && (
              <>
                {isUserAdmin || isUserEditorOrResp ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      onClick={handleEdit}
                    >
                      {editLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="pending approval"
                      onClick={handleChangeState}
                    >
                      {reviewApprovalLabel}
                    </Button>

                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="discarded"
                      onClick={handleChangeState}
                    >
                      {discardLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }
        {
          /** En estado  PENDIENTE APROBACION hay 3 botones:
           * APROBAR el estado cambia a APROBADO
           * RECHAZAR el estado cambia a ACEPTADO
           * DESCARTAR el estado cambia a DESCARTADO
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Pending approval' && (
              <>
                {isUserAdmin ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="approved"
                      onClick={handleChangeState}
                    >
                      {approveLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="accepted"
                      onClick={handleChangeState}
                    >
                      {rejectLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="discarded"
                      onClick={handleChangeState}
                    >
                      {discardLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }
        {
          /** En estado  APROBADO hay botones:
           * EDITAR la documentación a través del formulario
           *
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Approved' && (
              <>
                {isUserAdmin || isUserEditorOrResp ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      // data-state="approved"
                      onClick={handleEdit}
                    >
                      {editLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="retired candidate"
                      onClick={handleChangeState}
                    >
                      {approveDeprecateLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }{' '}
        {
          /** En estado  ASPIRANTE RETIRADO hay 2 botones:
           * APROBAR el estado cambia a APROBADO
           * RECHAZAR el estado cambia a ACEPTADO
           * DESCARTAR el estado cambia a DESCARTADO
           */
          canEditDoc.loading === false &&
            canEditDoc.allowed === true &&
            entity.spec?.lifecycle === 'Retired candidate' && (
              <>
                {isUserAdmin ? (
                  <ButtonGroup
                    variant="contained"
                    aria-label="draft button group"
                  >
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="retired"
                      onClick={handleChangeState}
                    >
                      {approveDeprecationLabel}
                    </Button>
                    <Button
                      variant="outlined"
                      color="warning"
                      data-state="approved"
                      onClick={handleChangeState}
                    >
                      {rejectDeprecationLabel}
                    </Button>
                  </ButtonGroup>
                ) : (
                  ''
                )}
              </>
            )
        }
        {/* <SubscriptionButton /> */}
      </Fragment>
    </>
  );
}

export function AboutCustomCard(props: AboutCardProps) {
  const { variant } = props;
  const classes = useStyles();
  const { entity } = useEntity();
  const catalogApi = useApi(catalogApiRef);
  const alertApi = useApi(alertApiRef);
  const errorApi = useApi(errorApiRef);
  const config = useApi(configApiRef);
  const appUrl = config.getString('app.baseUrl');
  const backendUrl = config.getString('backend.baseUrl');
  const env = config.getOptionalString('app.env');
  const apiChangelog = new ApiChangelogService(backendUrl);
  const disma = new DismaService();
  const emailService = new EmailService();
  const navigate = useNavigate();
  const [vFWindowOpen, setVFWindowOpen] =
    useState(false); /* VF stands for validation flow */
  const [nextState, setNextState] = useState('');
  const [isVFBtnDisabled, setIsVFBtnDisabled] = useState(true);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const identityApi = useApi(identityApiRef);
  const [isChangingState, setIsChangingState] = useState(false);
  const [isApproveEdition, setIsApproveEdition] = useState(false);
  const [isRejectEdition, setIsRejectEdition] = useState(false);
  const [isAcceptingMaster, setIsAcceptingMaster] = useState(false);
  const [isUserEditorOrResp, setIsUserEditorOrResp] = useState(false);
  const [isUserAdmin, setIsUserAdmin] = useState(false);
  const [acceptedFromPending, setAcceptedFromPending] = useState(false);
  const [comment, setComment] = useState('');
  const [files, setFiles] = useState<File[]>([]);

  const canEdit = usePermission({
    permission: mapfreapiEditPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });
  const canEditDoc = usePermission({
    permission: mapfredocEditPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });
  const canReview = usePermission({
    permission: mapfreapiReviewPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });
  const canRefresh = usePermission({
    permission: catalogEntityRefreshPermission,
    resourceRef: `${entity.kind}:${entity.metadata.name}`,
  });

  let downloadDocs: IconLinkVerticalProps | undefined;

  if (entity.metadata.annotations?.['backstage.io/view-url']) {
    const str =
      entity.metadata.annotations?.['backstage.io/view-url'].split(
        'catalog-info',
      )[0];

    const bucket = str?.split('/')[2].split('.')[0];
    const repo = str?.split('/')[3];

    const downloadUrl = new URL(
      `/api/s3-zip-download/${bucket}/${repo}.zip`,
      window.location.origin,
    );
    if (downloadUrl.port === '3000') {
      downloadUrl.port = '7007';
    }

    downloadDocs = {
      label: t('Download'),
      icon: <DownloadOutlinedIcon />,
      href: downloadUrl.toString(),
    };
  }

  let cardClass = '';
  if (variant === 'gridItem') {
    cardClass = classes.gridItemCard;
  } else if (variant === 'fullHeight') {
    cardClass = classes.fullHeightCard;
  }

  let cardContentClass = '';
  if (variant === 'gridItem') {
    cardContentClass = classes.gridItemCardContent;
  } else if (variant === 'fullHeight') {
    cardContentClass = classes.fullHeightCardContent;
  }
  async function getUserAsEditorOrResp() {
    const user = (
      await identityApi.getBackstageIdentity()
    ).userEntityRef.replace('default/', '');
    const isEditor = (
      entity.metadata.liableTeam as Record<string, string[]>
    ).writers?.includes(user);
    const isResponsible = (
      entity.metadata.liableTeam as Record<string, string[]>
    ).responsible?.includes(user);

    const isEditorOrResp = isResponsible || isEditor;

    return isEditorOrResp;
  }
  async function isGlobalGroup(): Promise<boolean> {
    try {
      const { ownershipEntityRefs: entityRefs } =
        await identityApi.getBackstageIdentity();

      return entityRefs.some(entityRef => {
        const parsedRef = parseEntityRef(entityRef);
        const groupName = parsedRef.name.toLowerCase();
        const isGroup = parsedRef.kind === 'group';
        return (
          isGroup &&
          (groupName.includes('gazr-gov-backstage-global') ||
            groupName.includes('gazr-gov-backstage-doc-global'))
        );
      });
    } catch (error) {
      console.error('Error al obtener entityRefs:', error);
      return false;
    }
  }

  if (entity.kind === 'MapfreDocument') {
    useEffect(() => {
      async function fetchUserAsEditorOrResp() {
        const isEditorOrResp = await getUserAsEditorOrResp();
        const isAdmin = await isGlobalGroup();
        setIsUserEditorOrResp(isEditorOrResp);
        setIsUserAdmin(isAdmin);
      }

      fetchUserAsEditorOrResp();
    }, []);
  }

  const entityLocation = entity.metadata.annotations?.[ANNOTATION_LOCATION];
  // Limiting the ability to manually refresh to the less expensive locations
  const allowRefresh =
    entityLocation?.startsWith('url:') || entityLocation?.startsWith('file:');
  const refreshEntity = useCallback(async () => {
    try {
      await catalogApi.refreshEntity(stringifyEntityRef(entity));
      alertApi.post({ message: 'Refresh scheduled', severity: 'info' });
    } catch (e) {
      if (e instanceof Error) errorApi.post(e);
    }
  }, [catalogApi, alertApi, errorApi, entity]);

  async function getIsSubscribed(email: string) {
    try {
      const response = await fetch(getSubscriptionsGetReq(backendUrl, email));
      if (response.status === 200) {
        const json = await response.json();
        const isSubscribed = json.Items.some((sub: Record<string, unknown>) => {
          return sub.entity === entity.metadata.name;
        });
        return isSubscribed;
      } else {
        throw new Error('Something went wrong on API server!');
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  function handleClose() {
    setComment('');
    setVFWindowOpen(false);
  }

  function handleInputFile(e: React.SyntheticEvent<EventTarget>) {
    if (!(e.target instanceof HTMLInputElement)) {
      return;
    }
    setIsVFBtnDisabled(false);
  }

  async function unRegisterEntity(repository: string) {
    const location = await catalogApi.getLocationByRef(repository);
    if (location) {
      return catalogApi.removeLocationById(location.id);
    }
    throw Error('Missing MapfreApi entity');
  }

  async function getUsersByGroup(groupName: string) {
    const groupEntity = await catalogApi.getEntityByRef({
      kind: 'Group',
      namespace: 'default',
      name: groupName,
    });

    if (!groupEntity) {
      return [];
    }

    const members =
      groupEntity.relations?.filter(
        relation => relation.type === 'hasMember',
      ) ?? [];
    const users = await Promise.all(
      members.map(async member => {
        const userEntity = await catalogApi.getEntityByRef(member.targetRef);
        return userEntity;
      }),
    );
    return users;
  }

  async function sendDismaEmails() {
    const dismaUsers = await getUsersByGroup(`gazr-gov-backstage-disma-${env}`);
    const emails = dismaUsers.map(u => (u?.spec?.profile as any).email);
    const apiName = entity.metadata.title;
    const apiUrl = `${appUrl}/catalog/default/${entity.kind.toLowerCase()}/${
      entity.metadata.name
    }`;
    const subject = t('api.review.disma.email.subject', { apiName });
    const title = t('api.review.disma.email.title');
    const subtitle = t('api.review.disma.email.subtitle');
    const message = t('api.review.disma.email.message', { apiName, apiUrl });
    emailService.send({ to: emails, subject, title, subtitle, message });
  }

  function getConfirmationDialogTitle() {
    if (nextState === 'approved' && isApproveEdition) {
      return t('Do you want to approve the edit?');
    }
    if (nextState === 'approved' && isRejectEdition) {
      return t('Do you want to reject the edit?');
    }
    if (nextState === 'approved' && entity.kind === 'MapfreDocument') {
      return t('Do you want to set this entity as approved?');
    }
    if (
      (entity.spec?.lifecycle === 'Pending approval' ||
        entity.spec?.lifecycle === 'Pending acceptance') &&
      nextState === 'accepted'
    ) {
      return t('Do you want to set this entity as accepted?');
    }
    if (nextState === 'pending acceptance') {
      return t('Do you want to set this entity as pending acceptance?');
    }
    if (nextState === 'pending approval') {
      return t('Do you want to set this entity as pending approval?');
    }
    if (nextState === 'discarded') {
      return t('Are you sure you want to discard this entity?');
    }
    return t(
      `api.confirmation_dialog.${(entity.spec?.lifecycle as string)
        .toLowerCase()
        .replaceAll(' ', '_')}.${nextState.toLowerCase().replaceAll(' ', '_')}`,
    );
  }

  async function handleConfirmation() {
    setIsChangingState(true);
    let now = Date.now().toString();
    const user = (await identityApi.getBackstageIdentity()).userEntityRef;
    let textFiles: Record<string, string> = {};
    const repositoryUrl =
      entity.metadata.annotations?.['backstage.io/view-url'];

    if (!repositoryUrl) {
      throw Error('Cannot retrieve entity repository view url.');
    }

    let catalogInfo;
    try {
      const token = (await identityApi.getCredentials()).token ?? '';

      for (const file of files) {
        const contentBuffer = await readFileAsync(file);
        textFiles[
          `reports/${(
            entity.spec?.lifecycle as string
          ).toLowerCase()}_to_${nextState}-${new Date().toISOString()}.${
            file.name.split('.').pop() ?? ''
          }`
        ] = contentBuffer;
      }

      catalogInfo = yaml.parse(await getCatalogInfo(repositoryUrl, token));

      const calatogInfoOriginal = JSON.parse(JSON.stringify(catalogInfo));

      if (catalogInfo.kind === 'MapfreDocument') {
        catalogInfo.metadata.state =
          nextState.charAt(0).toUpperCase() + nextState.slice(1);
      } else {
        catalogInfo.metadata['mapfre.com/state'] =
          nextState.charAt(0).toUpperCase() + nextState.slice(1);
      }

      if (catalogInfo.spec) {
        catalogInfo.spec.lifecycle =
          nextState.charAt(0).toUpperCase() + nextState.slice(1);
      }
      if (entity.kind.toLowerCase().includes('mapfreapi')) {
        catalogInfo.metadata.modDate = now;
        if (isApproveEdition) {
          catalogInfo.metadata.name = catalogInfo.metadata.name.split('_')[0];
          catalogInfo.metadata.version =
            catalogInfo.metadata.version.split('_')[0];
          catalogInfo.spec.nextVersionOf = [];
          //handlee creation of wsrr files
          textFiles = await handleWsrrFiles(
            'approved',
            textFiles,
            catalogInfo,
            entity,
          );
        }
      }
      if (entity.kind === 'MapfreDocument') {
        if (catalogInfo.metadata.historyLog) {
          catalogInfo.metadata.historyLog.last_update_date = now;
          catalogInfo.metadata.historyLog.last_update_user = user;
          if (nextState === 'retired') {
            catalogInfo.metadata.historyLog.retired_date = now;
            catalogInfo.metadata.historyLog.retired_user = user;
          } else if (nextState === 'accepted') {
            catalogInfo.metadata.historyLog.acceptance_date = now;
            catalogInfo.metadata.state =
              nextState.charAt(0).toUpperCase() + nextState.slice(1);
            catalogInfo.spec.lifecycle =
              nextState.charAt(0).toUpperCase() + nextState.slice(1);
          } else if (nextState === 'approved') {
            catalogInfo.metadata.historyLog.publication_date = now;
          }
        }
      } else {
        catalogInfo.metadata.modDate = now;
        if (catalogInfo.metadata.historyLog) {
          (catalogInfo.metadata.historyLog as Record<string, string>)[
            'mapfre.com/modDate'
          ] = now;
          (catalogInfo.metadata.historyLog as Record<string, string>)[
            'mapfre.com/user_mod'
          ] = user;
          if (nextState === 'retired') {
            (catalogInfo.metadata.historyLog as Record<string, string>)[
              'mapfre.com/deprecationDate'
            ] = now;
          }
          if (nextState === 'approved') {
            (catalogInfo.metadata.historyLog as Record<string, string>)[
              'mapfre.com/approvalDate'
            ] = now;
          }
        }
      }
      //handle creation of wsrr files
      if (
        entity.kind === 'MapfreApi' &&
        (isApproveEdition || nextState === 'approved')
      ) {
        textFiles = await handleWsrrFiles(
          'approved',
          textFiles,
          catalogInfo,
          entity,
        );
      } else {
        textFiles['catalog-info.yaml'] = yaml.stringify(catalogInfo);
      }
      await uploadFiles(repositoryUrl, textFiles, token);

      await updateCatalogInfoBeta(
        catalogInfo,
        nextState,
        isAcceptingMaster,
        repositoryUrl,
        token,
      );

      const target =
        entity.metadata.annotations?.['backstage.io/managed-by-location'] ?? '';
      const url = target.split('/')[2];
      const repoBeta = `${target.split('/')[3]}/catalog-info-beta.yaml`;
      const finalTarget = `${url}/${repoBeta}`;
      if (!acceptedFromPending && nextState === 'accepted') {
        catalogApi.addLocation({
          dryRun: false,
          type: 'url',
          target: `https://${finalTarget}`,
        });
      }

      const profileInfo = await identityApi.getProfileInfo();
      try {
        await apiChangelog.pushLogFromEntity(
          yaml.stringify(calatogInfoOriginal),
          textFiles,
          profileInfo?.email as string,
          catalogInfo,
          comment,
          isRejectEdition
            ? (`Entity edition rejected` as string)
            : isApproveEdition
            ? (`Entity edition accepted` as string)
            : (`Entity state transitioned to ${nextState}` as string),
        );
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error : ${error.message} `, error);
        }
      }

      if (
        nextState === 'security review' ||
        nextState === 'security review edited'
      ) {
        sendDismaEmails();
      }

      try {
        await sendEmailChangeState(
          nextState,
          isApproveEdition,
          isRejectEdition,
          textFiles,
          catalogInfo,
          catalogApi,
          comment,
          env as string,
        );
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error al enviar el correo: ${error.message} `, error);
        }
      }
      if (entity.kind.toLowerCase().includes('mapfreapi')) {
        const owners: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/owners'];
        const resp_func: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/resp_func'];
        const resp_tech: string[] =
          catalogInfo.metadata.liablePeople['mapfre.com/resp_tech'];
        const liablePeople: string[] = owners
          .concat(resp_func)
          .concat(resp_tech)
          .filter(entityRef => {
            if (!entityRef) return false;
            const entity = parseEntityRef(entityRef);
            return entity.kind.toLocaleLowerCase() === 'user';
          })
          .map(entityRef => {
            const entity = parseEntityRef(entityRef);
            return entity.name.replace(/_(?=[^_]*$)/, '@');
          });

        const subscribers: string[] = [...new Set(liablePeople)];
        if (nextState === 'approved') {
          const uidApi: string = catalogInfo.metadata.name;
          for (const subscriber of subscribers) {
            if (!(await getIsSubscribed(subscriber))) {
              await newSubscriptionCatalogApi(
                uidApi,
                subscriber,
                true,
                true,
                '7',
              );
            }
          }
        }
        if (
          entity.spec?.lifecycle === 'Security review' ||
          entity.spec?.lifecycle === 'Security review edited'
        ) {
          const apiName = entity.metadata.title;
          const state =
            nextState === 'approved' ? t('approved') : t('rejected');
          const subject = t('api.security_review.email.subject', {
            apiName,
            state,
          });
          const title = t('api.security_review.email.title');
          const subtitle = t('api.security_review.email.subtitle', {
            state,
          });
          const message = t('api.security_review.email.body', {
            apiName,
            comment,
            state,
          });
          emailService.send({
            to: subscribers,
            subject,
            title,
            subtitle,
            message,
            attachments: files,
          });
        }
      }
      const locationRef =
        entity.metadata.annotations?.['backstage.io/managed-by-location'] ?? '';
      const bucket = locationRef.split('/')[2].split('.')[0];
      const repo = locationRef.split('/')[3];
      if (isApproveEdition) {
        //Delete parent repo
        if (repo.includes('_edit')) {
          await deleteRepoBucket(
            backendUrl,
            bucket,
            repo.replace('_edit', ''),
            token,
          );
        }
        await copyRepoBucketContent(backendUrl, bucket, repo, token);
        const logs = await apiChangelog.getLogs(entity.metadata.name);
        const oldEntityName = entity.metadata.name.split('_')[0];
        for (const log of logs) {
          await apiChangelog.pushLog({
            ...log,
            uidApi: oldEntityName,
          });
        }
        await deleteRepoBucket(backendUrl, bucket, repo, token);
        for (const log of logs) {
          await apiChangelog.deleteLog(entity.metadata.name, log.date);
        }
      }
      if (isRejectEdition) {
        catalogInfo.metadata['mapfre.com/state'] = 'Edited rejected';
        if (catalogInfo.spec) {
          catalogInfo.spec.lifecycle = 'Edited rejected';
        }
        now = Date.now().toString();
        catalogInfo.metadata.modDate = now;
        if (catalogInfo.metadata.historyLog) {
          (catalogInfo.metadata.historyLog as Record<string, string>)[
            'mapfre.com/modDate'
          ] = now;
          (catalogInfo.metadata.historyLog as Record<string, string>)[
            'mapfre.com/user_mod'
          ] = user;
        }

        textFiles['catalog-info.yaml'] = yaml.stringify(catalogInfo);

        await uploadFiles(repositoryUrl, textFiles, token);
      }
    } catch (error) {
      if (error instanceof Error) {
        alertApi.post({
          message: error.message,
          severity: 'error',
        });
      }
    }
    if (isApproveEdition) {
      const oldEntityName = entity.metadata.name.split('_')[0];
      const kind = entity.kind.toLowerCase();
      const namespace = entity.metadata.namespace;
      const oldEntity = `${kind}:${namespace}/${oldEntityName}`;
      const locationRef =
        entity.metadata.annotations?.['backstage.io/managed-by-location'];
      await catalogApi.refreshEntity(oldEntity);
      await unRegisterEntity(locationRef as string);
      navigate(
        `/catalog/${namespace}/${entity?.kind.toLowerCase()}/${oldEntityName}`,
      );
    } else {
      catalogApi.refreshEntity(stringifyEntityRef(entity));
    }
    setTimeout(() => {
      window.location.reload();
      setIsChangingState(false);
      setVFWindowOpen(false);
    }, 1000);
  }

  return (
    <>
      <Dialog fullScreen={fullScreen} open={vFWindowOpen} onClose={handleClose}>
        <>
          {isChangingState && <LinearProgress />}
          <DialogTitle
            style={{
              minWidth: '400px',
            }}
          >
            {getConfirmationDialogTitle()}
          </DialogTitle>
          <DialogContent>
            <InputLabel>{t('Validation report')}:</InputLabel>
            <Input
              style={{
                marginBottom: '10px',
              }}
              inputProps={{
                accept:
                  'application/pdf, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel.sheet.macroEnabled.12, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/msword, application/x-zip-compressed, application/zip',
              }}
              type="file"
              onChange={(e: any) => {
                setFiles(e.target.files);
              }}
            ></Input>
            <DialogContentText>{t('Tell us why:')}</DialogContentText>
            <TextField
              style={{ marginTop: 0 }}
              fullWidth
              margin="normal"
              multiline
              minRows={3}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
              onChange={e => {
                setComment(e.target.value);
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={handleClose}
              color="inherit"
              disabled={isChangingState}
            >
              {t('Discard')}
            </Button>
            <Button
              onClick={handleConfirmation}
              color="error"
              variant="contained"
              autoFocus
              disabled={isChangingState}
            >
              {t('Agree')}
            </Button>
          </DialogActions>
        </>
      </Dialog>

      <Card className={cardClass}>
        <CardHeader
          title={t('General Data')}
          action={
            <>
              {(entity.kind === 'MapfreApi' ||
                entity.kind === 'MapfreApiLegacyEsp' ||
                entity.kind === 'MapfreApiLegacyBra' ||
                entity.kind === 'MapfreApiLegacyGlobal' ||
                entity.kind === 'MapfreApiLegacyPer') && (
                <MapfreApiButtonGroup
                  {...{
                    canEdit,
                    canReview,
                    entity,
                    setNextState,
                    setIsVFBtnDisabled,
                    setVFWindowOpen,
                    setIsChangingState,
                    setIsRejectEdition,
                    setIsApproveEdition,
                    isRejectEdition,
                    isApproveEdition,
                  }}
                />
              )}
              {entity.kind === 'MapfreDocument' && (
                <MapfreDocumentButtonGroup
                  isUserEditorOrResp={isUserEditorOrResp}
                  isUserAdmin={isUserAdmin}
                  {...{
                    canEditDoc,
                    entity,
                    setNextState,
                    setIsVFBtnDisabled,
                    setVFWindowOpen,
                    setIsChangingState,
                    setIsAcceptingMaster,
                    isAcceptingMaster,
                    acceptedFromPending,
                    setAcceptedFromPending,
                  }}
                />
              )}
              {canRefresh.loading === false &&
                canRefresh.allowed === true &&
                allowRefresh && (
                  <IconButton
                    aria-label="Refresh"
                    title="Schedule entity refresh"
                    onClick={refreshEntity}
                  >
                    <CachedIcon />
                  </IconButton>
                )}
            </>
          }
          subheader={
            <>
              {(entity.kind === 'MapfreApi' ||
                entity.kind === 'MapfreApiLegacyEsp' ||
                entity.kind === 'MapfreApiLegacyBra' ||
                entity.kind === 'MapfreApiLegacyGlobal' ||
                entity.kind === 'MapfreApiLegacyPer') &&
              downloadDocs ? (
                <HeaderIconLinkRow links={[downloadDocs]} />
              ) : (
                <></>
              )}
            </>
          }
        />
        <Divider />
        <CardContent className={cardContentClass}>
          <AboutCustomContent entity={entity} />
        </CardContent>
      </Card>
    </>
  );
}
