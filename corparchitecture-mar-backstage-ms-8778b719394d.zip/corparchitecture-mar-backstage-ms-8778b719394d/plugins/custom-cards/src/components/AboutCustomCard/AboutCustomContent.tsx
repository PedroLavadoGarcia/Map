import {
  Entity,
  RELATION_OWNED_BY,
  RELATION_PART_OF,
} from '@backstage/catalog-model';
import {
  EntityRefLinks,
  getEntityRelations,
} from '@backstage/plugin-catalog-react';
import { JsonValue } from '@backstage/types';
import { Chip, Grid, makeStyles, Typography } from '@material-ui/core';
import { t } from 'i18next';
import React from 'react';
import { AboutCustomField } from './AboutCustomField';

const useStyles = makeStyles({
  description: {
    wordBreak: 'break-word',
  },
});

/**
 * Props for {@link AboutCustomContent}.
 *
 * @public
 */
export interface AboutContentProps {
  entity: Entity;
}

export const refStrings: Record<string, string> = {
  ARG: 'Argentina',
  BRA: 'Brasil',
  CHL: 'Chile',
  COL: 'Colombia',
  CRI: 'Costa Rica',
  DEU: 'Germany',
  DOM: 'Dominican Republic',
  ECU: 'Ecuador',
  ESP: 'Spain',
  ITA: 'Italy',
  MEX: 'Mexico',
  MLT: 'Malta',
  PAN: 'Panama',
  PER: 'Perú',
  PRI: 'Puerto Rico',
  PRY: 'Paraguay',
  TUR: 'Turkey',
  URY: 'Uruguay',
  USA: 'United States of America',
  VEN: 'Venezuela',
  ASIS: 'Mawdy',
  DIG: 'Digital',
  INV: 'Investment',
  RE: 'Re',
  GLOBAL: 'Global',
  SOL: 'Solunion',
  TRON: 'Tron',
  CAN: 'Canada',
  PHL: 'Philippines',
  GTM: 'Guatemala',
  SLV: 'El Salvador',
  HND: 'Honduras',
  NIC: 'Nicaragua',
  SGP: 'Singapore',
  DZA: 'Algeria',
  MYS: 'Malaysia',
  JPN: 'Japan',
  TUN: 'Tunez',
  CHN: 'China',
  BEL: 'Belgium',
  HUN: 'Hungary',
  IRL: 'Ireland',
  GBR: 'United Kingdom',
};
export const refStringsDocs: Record<string, string> = {
  ARG: 'Argentina',
  BRA: 'Brasil',
  CHL: 'Chile',
  COL: 'Colombia',
  CRI: 'Costa Rica',
  DEU: 'Germany',
  DOM: 'Dominican Republic',
  ECU: 'Ecuador',
  ESP: 'Spain',
  ITA: 'Italy',
  MEX: 'Mexico',
  MLT: 'Malta',
  PAN: 'Panama',
  PER: 'Perú',
  PRI: 'Puerto Rico',
  PRY: 'Paraguay',
  TUR: 'Turkey',
  URY: 'Uruguay',
  USA: 'United States of America',
  VEN: 'Venezuela',
  ASIS: 'Mawdy',
  DIG: 'Digital',
  INV: 'Investment',
  RE: 'Re',
  GLOBAL: 'Corporate',
  SOL: 'Solunion',
  TRON: 'Tron',
  CAN: 'Canada',
  PHL: 'Philippines',
  GTM: 'Guatemala',
  SLV: 'El Salvador',
  HND: 'Honduras',
  NIC: 'Nicaragua',
  SGP: 'Singapore',
  DZA: 'Algeria',
  MYS: 'Malaysia',
  JPN: 'Japan',
  TUN: 'Tunez',
  CHN: 'China',
  BEL: 'Belgium',
  HUN: 'Hungary',
  IRL: 'Ireland',
  GBR: 'United Kingdom',
};

/** @public */
export function AboutCustomContent(props: AboutContentProps) {
  const { entity } = props;
  const classes = useStyles();
  const isResource = entity.kind.toLocaleLowerCase('en-US') === 'resource';
  const isComponent = entity.kind.toLocaleLowerCase('en-US') === 'component';
  const isAPI = entity.kind.toLocaleLowerCase('en-US') === 'api';
  const isMapfreApi = entity.kind.toLocaleLowerCase('en-US') === 'mapfreapi';
  const isMapfreDocument =
    entity.kind.toLocaleLowerCase('en-US') === 'mapfredocument';
  const isTemplate = entity.kind.toLocaleLowerCase('en-US') === 'template';
  const isLocation = entity.kind.toLocaleLowerCase('en-US') === 'location';
  const isGroup = entity.kind.toLocaleLowerCase('en-US') === 'group';

  const partOfSystemRelations = getEntityRelations(entity, RELATION_PART_OF, {
    kind: 'system',
  });

  const ownedByRelations = getEntityRelations(entity, RELATION_OWNED_BY);

  const countryValue: JsonValue = entity.metadata?.country as string;
  const stateValue: JsonValue = entity.spec?.lifecycle as string;
  const apiConsumerTypeValue = entity.metadata?.[
    'mapfre.com/consumer_type'
  ] as string;
  const apiProviderTypeValue = entity.metadata?.[
    'mapfre.com/provider_type'
  ] as string;
  const refString = refStrings[countryValue]
    ? refStrings[countryValue]
    : countryValue;
  const refStringDocs = refStringsDocs[countryValue]
    ? refStringsDocs[countryValue]
    : countryValue;

  const globalAreaKeys = [
    'ASIS',
    'DIG',
    'INV',
    'RE',
    'GLOBAL',
    'SOL',
    'TRON',
  ].includes(countryValue);

  return (
    <Grid container>
      {/* <Grid item xs={3}>
        <img src={logo} height="23px" width="120px" />
      </Grid> */}
      <AboutCustomField label={t('Description')} gridSizes={{ xs: 9 }}>
        <Typography variant="body2" paragraph className={classes.description}>
          {entity?.metadata?.description || 'No description'}
        </Typography>
      </AboutCustomField>
      {(isAPI ||
        isMapfreApi ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.metadata?.country === 'string') && (
        <AboutCustomField
          label={
            isMapfreDocument && globalAreaKeys
              ? t('Entity/Corporate Area')
              : t('Country')
          }
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {isMapfreDocument
              ? (t(refStringDocs) as string)
              : (t(refString) as string)}
          </Typography>
        </AboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.metadata?.typology === 'string') && (
        <AboutCustomField
          label={t('Typology')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {entity?.metadata?.typology as string}
          </Typography>
        </AboutCustomField>
      )}

      {(isAPI ||
        isComponent ||
        isResource ||
        isTemplate ||
        isGroup ||
        isLocation ||
        typeof entity?.spec?.lifecycle === 'string') && (
        <AboutCustomField
          label={t('State')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">{t(stateValue)}</Typography>
        </AboutCustomField>
      )}
      {isMapfreDocument && typeof entity?.spec?.type === 'string' && (
        <AboutCustomField
          label={t('Type')}
          gridSizes={{ xs: 12, sm: 6, lg: 4 }}
        >
          <Typography variant="body2">
            {entity?.spec?.type as string}
          </Typography>
        </AboutCustomField>
      )}

      {(isAPI ||
        isComponent ||
        typeof entity?.metadata?.version === 'string') && (
        <AboutCustomField
          label={t('Version')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {entity?.metadata?.version as string}
          </Typography>
        </AboutCustomField>
      )}
      {!isMapfreDocument && (
        <AboutCustomField
          label={t('Editor')}
          value="No Editor"
          gridSizes={{ xs: 12 }}
        >
          {ownedByRelations.length > 0 && (
            <EntityRefLinks entityRefs={ownedByRelations} defaultKind="user" />
          )}
        </AboutCustomField>
      )}

      {(isAPI ||
        isComponent ||
        typeof entity?.metadata?.['mapfre.com/consumer_type'] === 'string') && (
        <AboutCustomField
          label={t('Consumer Type')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">{t(apiConsumerTypeValue)}</Typography>
        </AboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        typeof entity?.metadata?.['mapfre.com/provider_type'] === 'string') && (
        <AboutCustomField
          label={t('Provider Type')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">{t(apiProviderTypeValue)}</Typography>
        </AboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        typeof entity?.metadata?.['mapfre.com/organization'] === 'string') && (
        <AboutCustomField
          label={t('Organization')}
          gridSizes={{ xs: 12, sm: 4, lg: 3 }}
        >
          <Typography variant="body2">
            {entity?.metadata?.['mapfre.com/organization'] as string}
          </Typography>
        </AboutCustomField>
      )}

      {(isAPI || isComponent || typeof entity?.metadata?.name === 'string') && (
        <AboutCustomField label={t('Unique ID')} gridSizes={{ xs: 12 }}>
          <Typography variant="body2">
            {entity?.metadata?.name as string}
          </Typography>
        </AboutCustomField>
      )}
      {(isAPI ||
        isComponent ||
        isResource ||
        partOfSystemRelations.length > 0) && (
        <AboutCustomField
          label={t('Collaborators')}
          value="No System"
          gridSizes={{ xs: 12 }}
        >
          {partOfSystemRelations.length > 0 && (
            <EntityRefLinks
              entityRefs={partOfSystemRelations}
              defaultKind="system"
            />
          )}
        </AboutCustomField>
      )}
      {isMapfreDocument && (
        <>
          <AboutCustomField
            label={t('Tags')}
            value="No Tags"
            gridSizes={{ xs: 10 }}
          >
            {(entity?.metadata?.tags || []).map(t => (
              <Chip key={t} size="small" label={t} />
            ))}
          </AboutCustomField>
        </>
      )}
    </Grid>
  );
}
