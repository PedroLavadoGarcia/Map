/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useState } from 'react';
import { useAsync } from 'react-use';
import {
  DocsIcon,
  HeaderIconLinkRow,
  IconLinkVerticalProps,
  Table,
} from '@backstage/core-components';
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Grid,
  Tab,
  Tabs,
  Typography,
  makeStyles,
} from '@material-ui/core';
import { useEntity } from '@backstage/plugin-catalog-react';
import { JsonValue } from '@backstage/types';
import { TFunction } from 'i18next';
import { identityApiRef, useApi } from '@backstage/core-plugin-api';
import { Responsible, ApiResponsible } from './Responsible';

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100%)',
  },
  fullHeightCardContent: {
    padding: '0',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    '& thead tr th': {
      padding: 0,
    },
    '& thead tr th span': {
      display: 'none',
    },
    '& > div > div': {
      boxShadow: 'none',
    },
  },
  indicator: {
    backgroundColor: '#DB271C',
  },
  tabRoot: {
    color: 'inherit',
    padding: '10px 10px',
    // transition: 'color 0.3s ease',
    '&:hover': {
      color: 'black',
      backgroundColor: 'inherit',
    },
  },
});
const refStrings: Record<string, string> = {
  'mapfre.com/instance': 'Instances',
  'mapfre.com/serv_type': 'Type',
  'mapfre.com/architecture': 'Architecture',
  'mapfre.com/businessEntity': 'Business entity',
  'mapfre.com/NNII_code': 'NNII Code',
  'mapfre.com/country': 'Community',
  'mapfre.com/mailOwner': 'Contact maintainer',
  'mapfre.com/NNII': 'It has a new initiative code',
  'mapfre.com/endpoint_IC': 'IC Endpoint',
  'mapfre.com/endpoint_DEV': 'DESA Endpoint',
  'mapfre.com/endpoint_PRE': 'PRE Endpoint',
  'mapfre.com/endpoint_PRO': 'PRO Endpoint',
  'mapfre.com/endpoint_ext_IC': 'IC External Endpoint',
  'mapfre.com/endpoint_ext_DEV': 'DESA External Endpoint',
  'mapfre.com/endpoint_ext_PRE': 'PRE External Endpoint',
  'mapfre.com/endpoint_ext_PRO': 'PRO External Endpoint',
  'mapfre.com/http_methods': 'HTTP methods',
  'mapfre.com/ipRangeDEV': 'IP range DESA',
  'mapfre.com/ipRangePRE': 'IP range PRE',
  'mapfre.com/ipRangePRO': 'IP range PRO',
  'mapfre.com/op_statistics': 'Statistics by operation',
  'mapfre.com/state': 'State',
  'mapfre.com/approvalDate': 'Approval date',
  'mapfre.com/deprecationDate': 'Retirement date',
  'mapfre.com/ip_filter': 'IP filtering',
  'mapfre.com/business_line': 'Business lines',
  'mapfre.com/modDate': 'Modified',
  'mapfre.com/creationDate': 'Creation date',
  'mapfre.com/creationUser': 'Creation user',
  'mapfre.com/owners': 'Editor',
  'mapfre.com/date_portal_DEV': 'Portal Publication Date DEV',
  'mapfre.com/date_portal_PRE': 'Portal Publication Date PRE',
  'mapfre.com/date_portal_PRO': 'Portal Publication Date PRO',
  'mapfre.com/portal_pub': 'Publish in Portal',
  'mapfre.com/resp_alt': 'Alternative Person in Charge',
  'mapfre.com/resp_func': 'Functional Manager',
  'mapfre.com/resp_tech': 'Technical Manager',
  'mapfre.com/scopes': 'Securing by scope',
  'mapfre.com/avrg_exec_time': 'Average response time',
  'mapfre.com/externalAccess': 'External access (from internet)',
  'mapfre.com/type': 'Asset Type',
  'mapfre.com/auth_type': 'Authentication Type',
  'mapfre.com/interface_type': 'Interface Type',
  'mapfre.com/perm_type': 'Permission type',
  'mapfre.com/avrg_daily_traffic': 'Average daily traffic',
  //'mapfre.com/serv_ubic': 'Service Location',
  'mapfre.com/unique': 'Unique ID',
  'mapfre.com/user_mod': 'Modification User',
  'mapfre.com/version': 'Version',
  'mapfre.com/wsrr_last_pub_IC': 'last_pub.EDIC',
  'mapfre.com/wsrr_last_pub_DEV': 'last_pub.INTEGRATION',
  'mapfre.com/wsrr_last_pub_PRE': 'last_pub.PREPRODUCTION',
  'mapfre.com/wsrr_last_pub_PRO': 'last_pub.PRODUCTION',
  'mapfre.com/wsrr_last_pub_PROBIS': 'last_pub.PROBIS',
  'mapfre.com/pub_first_date_runtime_IC':
    'Date of first publication in runtime in integration.',
  'mapfre.com/pub_first_date_runtime_PRE':
    'Date of first publication in runtime in pre.',
  'mapfre.com/pub_first_date_runtime_PRO':
    'Date of first publication in runtime in production.',
  'mapfre.com/pub_last_date_runtime_IC':
    'Date of last publication in runtime in integration.',
  'mapfre.com/pub_last_date_runtime_PRE':
    'Date of last publication in runtime in pre.',
  'mapfre.com/pub_last_date_runtime_PRO':
    'Date of last publication in runtime in production.',
  'mapfre.com/rol_serv_IC': 'Service role/user in integration',
  'mapfre.com/rol_serv_PRE': 'Service role/user in preproduction',
  'mapfre.com/rol_serv_PRO': 'Service role/user in production',
  'mapfre.com/max_response_time': 'Maximum response time',
  'mapfre.com/maxCallNumber': 'Expected service volume',
  'mapfre.com/businessApplication': 'Business Application (CMDB)',
  'mapfre.com/consumer_type': 'Consumer Type',
  'mapfre.com/provider_type': 'Provider Type',
  'mapfre.com/organization': 'Organization',
  'mapfre.com/scope_of_use': 'Scope of Use',
  'mapfre.com/event_classification': 'Event Classification',
  'mapfre.com/compaction_logs': 'Compaction Logs',
  'mapfre.com/sorted_message': 'Sorted Message',
  'mapfre.com/retention_time': 'Retention Time',
  'mapfre.com/num_partitions': 'Num Partitions',
  'mapfre.com/system': 'System',
  'mapfre.com/gwDeployment': 'GW Deployment',
  responsible: 'Site Owner(s)',
  writers: 'Editors of the asset',
  reviewers: 'Readers',
  pro_doc_repo_url: 'Url documentation in production',
  beta_doc_repo_url: 'Url documentation under construction (beta)',
  creation_date: 'Creation date',
  acceptance_date: 'Acceptance date',
  publication_date: 'Publication date',
  last_update_date: 'Last update date',
  retired_date: 'Retired date',
  creation_user: 'Creation user',
  last_update_user: 'Last update user',
  retired_user: 'Retired user',
  name: 'Name',
  architecture_solution: 'Solution Architecture',
  architecture: 'Architecture',
  scope: 'Scope',
  country: 'Country',
  global_business_areas: 'Global business areas',
  situation: 'Situation',
  idt: 'Is there an international transfer of personal data from the European Economic Area to a territory located outside the European Economic Area?',
  ia_use: 'Does it use Artificial Intelligence?',
  cloud_ready: 'Cloud ready',
  deployment_type: 'Deployment type',
  deployment_mode: 'Cloud Deployment Mode',
  ubication: 'Ubication',
  others_ubications: 'Others ubications',
  creationDate: 'Creation date',
  createDate: 'Creation date',
  approvalDate: 'Approval date',
  modDate: 'Modified',
  user_mod: 'Modification User',
  approvalPtcDate: 'Approval PTC date',
  deprecationPtcDate: 'Retirement PTC date',
  approvalReefDate: 'Approval REEF date',
  deprecationReefDate: 'Retirement REEF date',
  deprecationDate: 'Retirement date',
  'mapfre.com/url_wsrr_ic': 'IC WSRR file',
  'mapfre.com/url_wsrr_desa': 'DESA WSRR file',
  'mapfre.com/url_wsrr_pre': 'PRE WSRR file',
  'mapfre.com/url_wsrr_pro': 'PRO WSRR file',
  incorporation_PTC_date: 'Date of joining the PTC',
  retired_PTC_date: 'Date of disjoin the PTC',
  incorporation_REEF_date: 'Date of joining REEF',
  retired_REEF_date: 'Date of disjoin the REEF',
};

/**
 *
 * @param deleteKeys - To delete specific key of object
 * @returns Metadata table
 */
function MetadataTableCard({
  yamlKey,
  title,
  t,
  gateway,
  deleteKeys,
}: {
  yamlKey: string;
  title: string;
  t: TFunction;
  gateway?: boolean;
  deleteKeys?: string[];
}): JSX.Element {
  const { entity } = useEntity();
  const classes = useStyles();
  const identityApi = useApi(identityApiRef);
  const columns = [
    { field: 'key', highlight: true, width: '40%' },
    { field: 'value' },
  ];
  const data: Record<string, string>[] = [];
  let content: JsonValue = entity.metadata?.[yamlKey] as Record<string, string>;

  const email =
    useAsync(async () => (await identityApi.getProfileInfo()).email ?? '')
      .value ?? '';

  function translate(value: string) {
    if (typeof value !== 'string') {
      return { tValue: value, hasTranslation: false };
    }
    let valueKey = value.toLowerCase();
    if (yamlKey.includes('q_overview') || yamlKey.includes('tech_data')) {
      valueKey = value;
    }
    const tValue = t(valueKey);
    const hasTranslation = valueKey !== tValue;
    return { tValue, hasTranslation };
  }

  function downloadGw(value: string) {
    const str =
      entity.metadata.annotations?.['backstage.io/view-url'].split(
        'catalog-info',
      )[0];

    const bucket = str?.split('/')[2].split('.')[0];
    const repo = str?.split('/')[3];
    const GWFileInstance = value;

    const downloadUrl = new URL(
      `/api/s3-zip-download/${bucket}/${repo}/${GWFileInstance}`,
      window.location.origin,
    );
    if (downloadUrl.port === '3000') {
      downloadUrl.port = '7007';
    }
    const downloadGwFile: IconLinkVerticalProps = {
      label: '',
      icon: <DocsIcon />,
      href: downloadUrl.toString(),
    };
    return (
      <CardHeader subheader={<HeaderIconLinkRow links={[downloadGwFile]} />} />
    );
  }
  const groupsInstances = {
    'Technical Data': [
      'mapfre.com/serv_type',
      'mapfre.com/gwDeployment',
      //'mapfre.com/serv_ubic',
      'mapfre.com/architecture',
      'mapfre.com/http_methods',
      'mapfre.com/ip_filter',
      'mapfre.com/ipRangeDEV',
      'mapfre.com/ipRangePRE',
      'mapfre.com/ipRangePRO',
    ],
    'Service Availability': [
      'mapfre.com/endpoint_IC',
      'mapfre.com/endpoint_DEV',
      'mapfre.com/endpoint_PRE',
      'mapfre.com/endpoint_PRO',
      'mapfre.com/endpoint_ext_IC',
      'mapfre.com/endpoint_ext_DEV',
      'mapfre.com/endpoint_ext_PRE',
      'mapfre.com/endpoint_ext_PRO',
      'mapfre.com/portal_pub',
    ],
    'WSRR Files': [
      'mapfre.com/url_wsrr_ic',
      'mapfre.com/url_wsrr_desa',
      'mapfre.com/url_wsrr_pre',
      'mapfre.com/url_wsrr_pro',
      'mapfre.com/wsrr_last_pub_DEV',
      'mapfre.com/wsrr_last_pub_IC',
      'mapfre.com/wsrr_last_pub_PRE',
      'mapfre.com/wsrr_last_pub_PRO',
      'mapfre.com/wsrr_last_pub_PROBIS',
    ],
    'last_pub.title': [
      'mapfre.com/wsrr_last_pub_DEV',
      'mapfre.com/wsrr_last_pub_IC',
      'mapfre.com/wsrr_last_pub_PRE',
      'mapfre.com/wsrr_last_pub_PRO',
      'mapfre.com/wsrr_last_pub_PROBIS',
    ],
    'Execution Permissions': [
      'mapfre.com/auth_type',
      'mapfre.com/perm_type',
      'mapfre.com/scopes',
      'mapfre.com/rol_serv_IC',
      'mapfre.com/rol_serv_PRE',
      'mapfre.com/rol_serv_PRO',
      'mapfre.com/system',
    ],
  };

  if (content) {
    if (deleteKeys) {
      if (Array.isArray(content)) {
        for (const item of content) {
          for (const k of deleteKeys) {
            delete item[k];
          }
        }
      } else {
        for (const k of deleteKeys) {
          delete content[k];
        }
      }
    }
    const [tabIndex, setTabIndex] = useState(0);

    const handleTabChange = (event: any, newValue: any) => {
      const newEvent = event;
      setTabIndex(newValue);
    };

    //Add interface_type in generalTab with expect value
    if (yamlKey.includes('technicalData')) {
      content['mapfre.com/interface_type'] = entity.spec?.type
        ? entity.spec?.type
        : '';
    }
    if (yamlKey.includes('instances')) {
      const instanceData: Record<string, Record<string, string>[]>[] = [];

      content = entity.metadata?.['instances'] as Record<string, string>;

      if (Array.isArray(content)) {
        content.forEach((item: JsonValue) => {
          if (typeof item === 'object' && item !== null) {
            const subItem = item as Record<string, string>;
            if (!gateway && !subItem.isGateway) {
              instanceData.push({ item: [subItem] });
            } else if (gateway && subItem.isGateway) {
              instanceData.push({ item: [subItem] });
            }
          }
        });
      }
      console.log(instanceData);

      console.log(instanceData);
      return (
        <Grid
          container
          spacing={3}
          style={{
            paddingLeft: '24px',
            marginTop: '25px',
          }}
        >
          <Grid item xs={12}>
            <Tabs
              classes={{ indicator: classes.indicator }}
              value={tabIndex}
              onChange={handleTabChange}
              aria-label="instance data tabs"
              variant="scrollable"
              scrollButtons="auto"
            >
              {instanceData.map((dataInstance, index) => {
                const servName = Object.values(dataInstance).flatMap(values =>
                  values.flatMap(instance => instance['mapfre.com/serv_type']),
                )[0];
                return (
                  <Tab
                    disableRipple
                    classes={{ root: classes.tabRoot }}
                    key={index}
                    label={t(servName)}
                    style={{
                      maxWidth: 'none',
                      width: 'auto',
                      flexShrink: 0,
                    }}
                  />
                );
              })}
            </Tabs>
          </Grid>
          <Grid item xs={12}>
            {instanceData.map((dataInstance, index) => {
              const renderCardsForGroup = (
                groupKey: string,
                groupValues: string[],
              ) => {
                const renderedCards = Object.values(dataInstance).flatMap(
                  values =>
                    values.flatMap(instance =>
                      Object.entries(instance)

                        .filter(([key, _]) => groupValues.includes(key))
                        .filter(
                          ([_, value]) =>
                            value &&
                            (typeof value !== 'object' ||
                              Object.keys(value).length > 0),
                        )
                        .map(([subKey, subValue]) => {
                          return {
                            key: t(refStrings[subKey]) || subKey,
                            value: Array.isArray(subValue)
                              ? subValue.join(', ')
                              : subKey.includes('gwDeployment') && subValue
                              ? downloadGw(subValue)
                              : new Date(Number(subValue)) instanceof Date &&
                                !isNaN(Number(subValue))
                              ? formatDate(new Date(Number(subValue)))
                              : subValue,
                          };
                        }),
                    ),
                );

                if (renderedCards.length > 0) {
                  return (
                    <Grid item xs={12} key={groupKey}>
                      <Card className={classes.gridItemCard}>
                        <CardContent className={classes.fullHeightCardContent}>
                          <Table
                            title={
                              <Typography variant="h6">
                                {t(groupKey) as string}
                              </Typography>
                            }
                            options={{
                              paging: false,
                              padding: 'dense',
                              search: false,
                            }}
                            columns={columns}
                            data={renderedCards}
                          />
                        </CardContent>
                      </Card>
                    </Grid>
                  );
                }

                return null;
              };

              return (
                <TabPanel key={index} value={tabIndex} index={index}>
                  <Grid container item xs={12} spacing={3} key={index}>
                    {/* <Grid item xs={12}>
                      <Typography variant="h2" style={{ marginTop: '50px' }}>
                        {t(servName) as string}
                      </Typography>
                    </Grid> */}
                    {yamlKey.includes('instances') &&
                      Object.entries(groupsInstances).map(
                        ([groupKey, groupValues]) =>
                          renderCardsForGroup(groupKey, groupValues),
                      )}
                  </Grid>
                </TabPanel>
              );
            })}
          </Grid>
        </Grid>
      );
    }
  }

  //Remove url_wsrr fields
  for (const key in content) {
    if (key.startsWith('mapfre.com/url_wsr')) {
      delete content[key];
    }
  }

  for (const k in content) {
    if (k === 'title') {
      continue; // Skip the 'title' key
    }
    if (k === 'global_business_areas') {
      continue; // Don't show Global Business Areas
    }
    if (k === 'others_ubications') {
      continue;
    }

    if (
      yamlKey.includes('tech_data') &&
      k === 'ubication' &&
      content.ubication &&
      content['others_ubications'] &&
      !(content.ubication as any).includes(content['others_ubications'])
    ) {
      content['ubication'] = [
        ...(content['ubication'] as any),
        content['others_ubications'],
      ];
    }

    const refString = refStrings[k] ? refStrings[k] : k;

    let value = content[k] as string;
    let valueKey = value;
    if (
      (k !== 'country' && yamlKey.includes('q_overview')) ||
      yamlKey.includes('tech_data')
    ) {
      valueKey = `mapfresolution.${k}.${value}`;
    }
    const { tValue, hasTranslation } = translate(valueKey);

    if (Array.isArray(value)) {
      value = value
        .map(item => {
          let valueKey = item;
          if (yamlKey.includes('q_overview') || yamlKey.includes('tech_data')) {
            valueKey = `mapfresolution.${k}.${item}`;
          }
          const { tValue, hasTranslation } = translate(valueKey);
          return hasTranslation ? tValue : item;
        })
        .join(', ');
    }

    if (
      [
        'modDate',
        'mapfre.com/creationDate',
        'mapfre.com/modDate',
        'mapfre.com/approvalDate',
        'mapfre.com/deprecationDate',
        'mapfre.com/wsrr_last_pub_DEV',
        'mapfre.com/wsrr_last_pub_IC',
        'mapfre.com/wsrr_last_pub_PRE',
        'mapfre.com/wsrr_last_pub_PRO',
        'mapfre.com/wsrr_last_pub_PROBIS',
        'creation_date',
        'acceptance_date',
        'publication_date',
        'last_update_date',
        'retired_date',
        'createDate',
        'approvalDate',
        'approvalPtcDate',
        'deprecationPtcDate',
        'approvalReefDate',
        'deprecationReefDate',
        'deprecationDate',
      ].includes(k)
    ) {
      value = value && `${formatDate(new Date(Number(value)))}`;
    }

    if (['responsible', 'writers', 'reviewers'].includes(k)) {
      const values = value.replaceAll(' ', '').split(',');
      const type = k;

      const responsible = (
        <div>
          {values.map(ref => {
            return <Responsible key={type + ref} entityRef={ref} />;
          })}
        </div>
      );

      value = value && (responsible as unknown as string);
    }

    if (
      [
        'mapfre.com/resp_func',
        'mapfre.com/resp_tech',
        'mapfre.com/owners',
      ].includes(k)
    ) {
      const values = value.replaceAll(' ', '').split(',');
      const type =
        k === 'mapfre.com/resp_func'
          ? 'functional'
          : k === 'mapfre.com/resp_tech'
          ? 'technical'
          : 'owner';

      const responsible = (
        <div>
          {values.map(ref => {
            return (
              <ApiResponsible key={type + ref} entityRef={ref} type={type} />
            );
          })}
        </div>
      );

      value = value && (responsible as unknown as string);
    }

    let key = refString;
    if (yamlKey.includes('q_overview') || yamlKey.includes('tech_data')) {
      if (key === 'Country') {
        if (
          value === 'ASIS' ||
          value === 'INV' ||
          value === 'RE' ||
          value === 'SOL' ||
          value === 'TRON' ||
          value === 'FUN'
        ) {
          key = `mapfresolution.${k}.label2`;
        }
      } else {
        key = `mapfresolution.${k}.label`;
      }
    }

    data.push({
      key: t(key),
      value: hasTranslation ? tValue : value,
    });
  }

  if (data.length > 0)
    return (
      <Grid item xs={6}>
        <Card className={classes.gridItemCard}>
          <CardContent className={classes.fullHeightCardContent}>
            <Table
              title={t(title) as string}
              options={{ paging: false, padding: 'dense', search: false }}
              columns={columns}
              data={data}
            />
          </CardContent>
        </Card>
      </Grid>
    );
  return <></>;
}

function formatDate(date: Date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
}

function TabPanel(props: any) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

export { MetadataTableCard };
