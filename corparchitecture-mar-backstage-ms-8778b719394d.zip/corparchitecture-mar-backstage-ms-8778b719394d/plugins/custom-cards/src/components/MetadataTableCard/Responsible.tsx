import React, { useContext, useState } from 'react';
import { useAsync } from 'react-use';
import { LinearProgress, Link, Typography } from '@material-ui/core';
import {
  EntityRefLink,
  useEntity,
  catalogApiRef,
} from '@backstage/plugin-catalog-react';
import {
  configApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { ComponentsResponsiblesService } from '@backstage/plugin-mapfreapi-editor';
import { CompoundEntityRef, Entity } from '@backstage/catalog-model';
import { ResponsibleContext } from '../../../../../packages/app/src/components/catalog/ResponsibleContext';
import { t } from 'i18next';

export function Responsible({ entityRef }: { entityRef: string }): JSX.Element {
  const catalogApi = useApi(catalogApiRef);

  const [responsibleEntity, setResponsibleEntity] = useState<Entity>();
  const [compoundEntityRef, setCompoundEntityRef] =
    useState<CompoundEntityRef>();

  const [isLoading, setIsLoading] = useState(true);

  const responsibleEmail = entityRef.split(':')[1].replace('_', '@');

  useAsync(async () => {
    const responsibleEntity = await catalogApi.getEntityByRef(entityRef);
    if (responsibleEntity) {
      setResponsibleEntity(responsibleEntity);
    } else {
      setCompoundEntityRef({
        name: entityRef.split(':')[1] ? entityRef.split(':')[1] : '',
        namespace: 'default',
        kind: 'user',
      });
    }
    setResponsibleEntity(responsibleEntity);
    setIsLoading(false);
  });
  return (
    <div>
      {isLoading && <LinearProgress />}
      {!isLoading && (
        <>
          {(responsibleEntity || compoundEntityRef) && (
            <EntityRefLink
              style={{ marginRight: '5px' }}
              entityRef={responsibleEntity ?? compoundEntityRef ?? ''}
              defaultKind="user"
              title={
                responsibleEntity
                  ? (responsibleEntity.spec!.profile as any).displayName
                  : responsibleEmail
              }
            />
          )}
        </>
      )}
    </div>
  );
}

export function ApiResponsible({
  entityRef,
  type,
}: {
  entityRef: string;
  type: 'owner' | 'functional' | 'technical';
}): JSX.Element {
  const { entity } = useEntity();
  const config = useApi(configApiRef);
  const identityApi = useApi(identityApiRef);
  const componentsResponsiblesService = new ComponentsResponsiblesService(
    config,
  );
  const aprrovals: ('approved' | 'rejected')[] = ['approved', 'rejected'];

  const [responsibleApproval, setResponsibleApproval] = useState<{
    entity: string;
    responsible: string;
    type: 'functional' | 'technical';
    kind: string;
    approval: 'pending' | 'rejected' | 'approved';
  }>();
  const { getResponsibleApproval: getEntityResponsibleApproval } =
    useContext(ResponsibleContext);
  const [isLoading, setIsLoading] = useState(true);

  const responsibleEmail = entityRef
    .split(':')[1]
    .replace('_', '@')
    .toLowerCase();
  const owners =
    (entity.metadata.liablePeople as any)['mapfre.com/owners'].map(
      (o: string) => o.split(':')[1].replace('_', '@').toLowerCase(),
    ) ?? [];

  const email =
    useAsync(
      async () =>
        ((await identityApi.getProfileInfo()).email as string).toLowerCase() ??
        '',
    ).value ?? '';

  useAsync(async () => {
    if (type !== 'owner') {
      let responsibleApproval = await componentsResponsiblesService.get(
        entity.metadata.name,
        responsibleEmail,
        type,
      );
      if (!responsibleApproval) {
        responsibleApproval = {
          entity: entity.metadata.name,
          responsible: responsibleEmail,
          type: type,
          kind: entity.kind,
          approval: 'approved',
        };
      }
      setResponsibleApproval(responsibleApproval);
    }
    setIsLoading(false);
  });
  return (
    <div>
      {isLoading && <LinearProgress />}
      {!isLoading && (
        <>
          <Responsible entityRef={entityRef} />
          {((entity.spec as any).lifecycle === 'Draft' ||
            (entity.spec as any).lifecycle === 'Edited') && (
            <>
              {responsibleApproval &&
                (responsibleApproval?.approval !== 'pending' ||
                  (responsibleApproval?.approval === 'pending' &&
                    responsibleEmail !== email)) && (
                  <Typography variant="caption" style={{ marginRight: '5px' }}>
                    {`(${t(
                      `api.responsibles.${
                        responsibleApproval?.approval ?? 'approved'
                      }`,
                    )})`}
                  </Typography>
                )}
              {responsibleApproval && responsibleEmail === email && (
                <>
                  {aprrovals
                    .filter(a => a !== responsibleApproval?.approval)
                    .map(approval => (
                      <Link
                        key={`${email}-${type}-${approval}`}
                        style={{ cursor: 'pointer', marginRight: '10px' }}
                        onClick={async () => {
                          await componentsResponsiblesService.update(
                            entity,
                            email,
                            type,
                            approval,
                            entity.kind,
                            undefined,
                            owners,
                          );
                          setResponsibleApproval({
                            ...responsibleApproval,
                            approval,
                          });
                          getEntityResponsibleApproval();
                        }}
                      >
                        {t(`api.responsibles.to.${approval}`)}
                      </Link>
                    ))}
                </>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}
