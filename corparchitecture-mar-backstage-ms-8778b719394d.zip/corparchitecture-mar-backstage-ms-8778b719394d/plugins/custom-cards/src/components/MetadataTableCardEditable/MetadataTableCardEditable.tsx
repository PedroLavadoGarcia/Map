import React, { useCallback, useState } from 'react';
import { Table } from '@backstage/core-components';
import { Card, CardContent, Grid, makeStyles } from '@material-ui/core';
import { EntityRefLinks } from '@backstage/plugin-catalog-react';
import { useEntity } from '@backstage/plugin-catalog-react';
import { JsonValue } from '@backstage/types';
import { TFunction } from 'i18next';
import { CompoundEntityRef } from '@backstage/catalog-model';
import {
  getCatalogInfo,
  uploadFiles,
  deleteOldCatalogInfo,
} from '@backstage/plugin-components-catalog-edit';
import {
  useApi,
  identityApiRef,
  errorApiRef,
} from '@backstage/core-plugin-api';
import { stringifyEntityRef } from '@backstage/catalog-model';
import * as yaml from 'js-yaml';
import yaml2 from 'yaml';
import { catalogApiRef } from '@backstage/plugin-catalog-react';

interface CatalogInfo {
  metadata: {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [key: string]: any;
  };
}

const useStyles = makeStyles({
  gridItemCard: {
    display: 'flex',
    flexDirection: 'column',
    height: 'calc(100%)',
  },
  fullHeightCardContent: {
    padding: '0',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    '& thead tr th': {
      padding: 0,
    },
    '& thead tr th span': {
      display: 'none',
    },
    '& > div > div': {
      boxShadow: 'none',
    },
  },
});
const refStrings: Record<string, string> = {
  'mapfre.com/architecture': 'Architecture',
  'mapfre.com/resp_alt': 'Responsable Alternativo',
  'mapfre.com/resp_func': 'Responsable Funcional',
  'mapfre.com/resp_tech': 'Responsable Técnico',
  'mapfre.com/owners': 'Propietario',
};

function MetadataTableCardEditable({
  yamlKey,
  title,
  t,
  isAdmin,
}: {
  yamlKey: string;
  title: string;
  t: TFunction;
  isAdmin: boolean;
}): JSX.Element {
  const { entity } = useEntity();
  const classes = useStyles();
  const columns = [
    { field: 'key', highlight: true, width: '40%' },
    { field: 'value' },
  ];
  const data: Record<string, string>[] = [];
  const content: JsonValue = entity.metadata?.[yamlKey] as Record<
    string,
    string
  >;
  const optionsDate: { month: 'short'; day: 'numeric'; year: 'numeric' } = {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  };
  const optionsHours: {
    hour: '2-digit';
    minute: '2-digit';
    second: '2-digit';
  } = { hour: '2-digit', minute: '2-digit', second: '2-digit' };

  function translate(value: string) {
    const tValue = typeof value === 'string' ? t(value.toLowerCase()) : value;
    const hasTranslation =
      typeof value === 'string' ? value.toLowerCase() !== tValue : false;
    return { tValue, hasTranslation };
  }

  if (content) {
    for (const k in content) {
      if (k === 'title') {
        continue; // Skip the 'title' key
      }
      const refString = refStrings[k] ? refStrings[k] : k;

      let value = content[k] as string;
      const { tValue, hasTranslation } = translate(value);
      if (Array.isArray(value)) {
        value = value
          .map(item => {
            const { tValue, hasTranslation } = translate(item);
            return hasTranslation ? tValue : item;
          })
          .join(', ');
      }

      if (
        [
          'modDate',
          'mapfre.com/modDate',
          'mapfre.com/approvalDate',
          'mapfre.com/deprecationDate',
          'mapfre.com/wsrr_last_pub_DEV',
          'mapfre.com/wsrr_last_pub_IC',
          'mapfre.com/wsrr_last_pub_PRE',
          'mapfre.com/wsrr_last_pub_PRO',
        ].includes(k)
      ) {
        value =
          value &&
          `${new Date(Number(value))
            .toLocaleDateString('es-ES', optionsDate)
            .split(' ')
            .join('-')} ${new Date(Number(value)).toLocaleTimeString(
            'es-ES',
            optionsHours,
          )}`;
      }

      if (
        [
          'mapfre.com/resp_func',
          'mapfre.com/resp_tech',
          'mapfre.com/owners',
        ].includes(k)
      ) {
        const values = value.split(',');
        const userEntityRef: CompoundEntityRef[] = [];

        values.forEach(function (value) {
          userEntityRef.push({
            name: value.split(':')[1] ? value.split(':')[1] : '',
            namespace: 'default',
            kind: 'user',
          });
        });

        const linkToUser = (
          <div>
            <EntityRefLinks entityRefs={userEntityRef} defaultKind="user" />
          </div>
        );

        value = value && (linkToUser as unknown as string);
      }
      data.push({
        key: t(refString),
        value: hasTranslation ? tValue : value,
      });
    }
  }

  const [isEditable, setIsEditable] = useState(false);
  const [isSaveable, setIsSaveable] = useState(false);
  const catalogApi = useApi(catalogApiRef);
  const errorApi = useApi(errorApiRef);
  const files: Record<string, string> = {};
  const [modifiedData, setModifiedData] =
    React.useState<Record<string, string>>();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [removedData, setRemovedData] = React.useState<any>(); // modifiedData is a key value pair of the modified data

  const handleRemoveClick = async () => {
    setIsSaveable(!isSaveable);
    setIsEditable(!isEditable);
    setRemovedData(removedData);
    removeData(removedData);
  };

  const identityApi = useApi(identityApiRef);
  const refreshEntity = useCallback(async () => {
    try {
      await catalogApi.refreshEntity(stringifyEntityRef(entity));
    } catch (e) {
      if (e instanceof Error) errorApi.post(e);
    }
  }, [catalogApi, entity]);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const saveData = async (modifiedDataNew: any) => {
    // Send the modified data to the backend and update the YAML values
    setModifiedData(modifiedDataNew); // Store the modified data in state
    if (!modifiedDataNew) {
      console.log('No data to save');
      return;
    }
    const { token } = await identityApi.getCredentials();
    const entityRepo =
      entity.metadata?.annotations?.['backstage.io/managed-by-origin-location'];
    if (!entityRepo) {
      throw Error('Cannot retrieve entity repository view url.');
    }
    // Get the catalog info from the backend
    const catalogInfo = yaml.load(await getCatalogInfo(entityRepo, token));
    // Create a copy of the catalog info
    const updatedCatalogInfo = { ...(catalogInfo as CatalogInfo) };

    // Update the catalog info with the modified data
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const context = updatedCatalogInfo.metadata[yamlKey] as any;
    context[modifiedDataNew.key] = modifiedDataNew.value;
    console.log('modifiedData: ' + JSON.stringify(modifiedDataNew));
    console.log(context[modifiedDataNew._key]);

    files['catalog-info.yaml'] = yaml2.stringify(updatedCatalogInfo);

    console.log(
      'Updated catalog-info.yaml: ' + JSON.stringify(updatedCatalogInfo),
    );

    // Await to delete the file. This is to ensure that the file is deleted before uploading the new file.
    await deleteOldCatalogInfo(entityRepo, token);
    await uploadFiles(entityRepo, files, token);

    await refreshEntity(); // Refresh the entity to reflect the changes
    setModifiedData(context); // Clear the modified data
    // Update the catalog info in the backend updatedCatalogInfo
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const removeData = async (removedData: any) => {
    setRemovedData(removedData); // Store the removed data in state
    if (!removedData) {
      console.log('No data to remove');
      return;
    }
    const { token } = await identityApi.getCredentials();
    const entityRepo =
      entity.metadata?.annotations?.['backstage.io/managed-by-origin-location'];
    if (!entityRepo) {
      throw Error('Cannot retrieve entity repository view url.');
    }
    // Get the catalog info from the backend
    const catalogInfo = yaml.load(await getCatalogInfo(entityRepo, token));
    // Create a copy of the catalog info
    const updatedCatalogInfo = { ...(catalogInfo as CatalogInfo) };

    // Update the catalog info with the modified data
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const context = updatedCatalogInfo.metadata[yamlKey] as any;
    console.log(JSON.stringify(context));
    context[removedData.key] = undefined;
    console.log('modifiedData: ' + JSON.stringify(removedData));
    console.log(context[removedData]);

    files['catalog-info.yaml'] = yaml2.stringify(updatedCatalogInfo);

    console.log(
      'Updated catalog-info.yaml: ' + JSON.stringify(updatedCatalogInfo),
    );

    // Await to delete the file. This is to ensure that the file is deleted before uploading the new file.
    await deleteOldCatalogInfo(entityRepo, token);
    await uploadFiles(entityRepo, files, token);

    await refreshEntity(); // Refresh the entity to reflect the changes
    // Update the catalog info in the backend updatedCatalogInfo
  };
  const modifiedDataArray = modifiedData
    ? Object.values(data).concat(modifiedData)
    : Object.values(data);
  if (data.length > 0)
    return (
      <Grid item xs={6}>
        <Card className={classes.gridItemCard}>
          <CardContent className={classes.fullHeightCardContent}>
            {isAdmin ? ( // If isAdmin is true, show the editable table
              <Table
                title={t(title) as string}
                options={{ paging: false, padding: 'dense', search: true }}
                columns={columns}
                data={modifiedDataArray} // Use modifiedData in the table UI
                editable={{
                  onRowDelete: oldData =>
                    new Promise<void>(resolve => {
                      removeData(oldData);
                      setRemovedData(oldData);
                      console.log(oldData);
                      handleRemoveClick(); // Save the modified data
                      resolve();
                    }),
                  editTooltip: () => t('Edit'),
                  deleteTooltip: () => t('Delete'),
                  onRowAdd: newData =>
                    new Promise<void>(resolve => {
                      setModifiedData(newData);
                      saveData(newData);
                      //await handleSaveClick(); // Save the modified data
                      resolve();
                    }),
                  onRowUpdate(newData) {
                    return new Promise<void>(resolve => {
                      //setModifiedData(newData);
                      setModifiedData(newData);
                      saveData(newData);
                      //await handleSaveClick(); // Save the modified data
                      resolve();
                    });
                  },
                }}
              />
            ) : (
              // If isAdmin is false, show the non-editable table

              <Table
                title={t(title) as string}
                options={{ paging: false, padding: 'dense', search: false }}
                columns={columns}
                data={data}
              />
            )}
          </CardContent>
        </Card>
      </Grid>
    );

  return <></>;
}

export { MetadataTableCardEditable };
