import {
  BasicPermission,
  ResourcePermission,
} from '@backstage/plugin-permission-common';

const componentsEditPermission: ResourcePermission<'catalog-entity'> = {
  type: 'resource',
  name: 'catalog.components.edit',
  attributes: {
    action: 'update',
  },
  resourceType: 'catalog-entity',
};

const componentsReviewPermission: ResourcePermission<'catalog-entity'> = {
  type: 'resource',
  name: 'catalog.components.review',
  attributes: {
    action: 'update',
  },
  resourceType: 'catalog-entity',
};

const componentsManagePermission: BasicPermission = {
  type: 'basic',
  name: 'catalog.components.manage',
  attributes: {
    action: 'read',
  },
};

export {
  componentsEditPermission,
  componentsReviewPermission,
  componentsManagePermission,
};
