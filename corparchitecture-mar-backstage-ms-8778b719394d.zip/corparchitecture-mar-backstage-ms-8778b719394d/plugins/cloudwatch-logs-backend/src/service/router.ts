import { errorHandler } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import {
  CloudWatchLogsClient,
  DescribeLogStreamsCommand,
} from '@aws-sdk/client-cloudwatch-logs';

export interface RouterOptions {
  logger: Logger;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
}

export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const accessKeyId: string = options.accessKeyId;
  const secretAccessKey: string = options.secretAccessKey;
  const regionCloudWatch: string = options.region;
  const client = new CloudWatchLogsClient({
    region: regionCloudWatch,
    credentials: {
      accessKeyId: accessKeyId,
      secretAccessKey: secretAccessKey,
    },
  });

  const router = Router();
  router.use(express.json());

  router.get('/:dashboardName', async (request, response) => {
    const input = {
      // DescribeLogStreamsRequest
      logGroupName: request.params.dashboardName,
      // logGroupIdentifier: "STRING_VALUE",
      // logStreamNamePrefix: "STRING_VALUE",
      orderBy: 'LastEventTime',
      descending: true,
      // nextToken: "STRING_VALUE",
      limit: Number(10),
    };
    const command = new DescribeLogStreamsCommand(input);
    const res = await client.send(command);
    response.send(res);
  });
  router.use(errorHandler());
  return router;
}
