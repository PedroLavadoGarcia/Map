/*
 * Copyright 2020 The Backstage Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { errorHandler } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import AWS from 'aws-sdk';
import { gzipSync } from 'zlib';

export interface RouterOptions {
  logger: Logger;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
  apiLogsChangesTable: string;
  solutionHistoryLogTable: string;
}

export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const ACCESSKEY_ID_DYNAMO: string = options.accessKeyId;
  const SECRET_ACCESSKEY_DYNAMO: string = options.secretAccessKey;
  const REGION_DYNAMO: string = options.region;
  const API_LOGS_TABLE = options.apiLogsChangesTable;
  const SOLUTION_HISTORY_LOG_TABLE = options.solutionHistoryLogTable;
  const dynamoDB = new AWS.DynamoDB.DocumentClient({
    region: REGION_DYNAMO,
    apiVersion: '2012-08-10',
    credentials: {
      accessKeyId: ACCESSKEY_ID_DYNAMO,
      secretAccessKey: SECRET_ACCESSKEY_DYNAMO,
    },
  });

  const router = Router();
  router.use(express.json());

  router.put(
    '/log',
    async (
      req: {
        body: {
          uidApi: string;
          date: string;
          file: string;
          diff?: string | Buffer;
          modifiedBy: string;
          nameApi: string;
          kind: string;
          desc: string;
          descParams?: Record<string, string>;
          comment: string;
        };
      },
      res,
    ) => {
      try {
        let diff = req.body.diff;
        if (diff && typeof diff === 'string') {
          diff = gzipSync(diff);

          // Remove file content if size is bigger than 400kb Dynamo restriction
          const compressedSize = diff.length / 1024;
          if (compressedSize > 400) {
            diff = gzipSync(
              `[{"value":"File too big to display content","count":1}]`,
            );
          }
        }
        let UpdateExpression =
          'SET #file = :file, #diff = :diff, #modifiedBy = :modifiedBy, #nameApi = :nameApi, #kind = :kind, #desc = :desc, #comment = :comment';
        const ExpressionAttributeNames: AWS.DynamoDB.DocumentClient.ExpressionAttributeNameMap =
          {
            '#file': 'file',
            '#modifiedBy': 'modifiedBy',
            '#nameApi': 'nameApi',
            '#kind': 'kind',
            '#desc': 'desc',
            '#comment': 'comment',
            '#diff': 'diff',
          };
        const ExpressionAttributeValues: AWS.DynamoDB.DocumentClient.ExpressionAttributeValueMap =
          {
            ':file': req.body.file,
            ':modifiedBy': req.body.modifiedBy,
            ':nameApi': req.body.nameApi,
            ':kind': req.body.kind,
            ':desc': req.body.desc,
            ':comment': req.body.comment,
            ':diff': diff ?? '',
          };
        if (req.body.descParams) {
          UpdateExpression += ', #descParams = :descParams';
          ExpressionAttributeNames['#descParams'] = 'descParams';
          ExpressionAttributeValues[':descParams'] = req.body.descParams;
        }
        await dynamoDB
          .update({
            TableName: API_LOGS_TABLE,
            Key: {
              key: req.body.uidApi,
              date: req.body.date,
            },
            UpdateExpression,
            ExpressionAttributeNames,
            ExpressionAttributeValues,
            ReturnValues: 'ALL_NEW',
          })
          .promise();
        res.send(200);
      } catch (error) {
        res.status(500).send(error);
      }
    },
  );

  router.delete('/log/:uidApi/:date', async (req, res) => {
    const { uidApi, date } = req.params;
    try {
      await dynamoDB
        .delete({
          TableName: API_LOGS_TABLE,
          Key: {
            key: uidApi,
            date,
          },
        })
        .promise();
      res.sendStatus(200);
    } catch (error) {
      res.status(500).send(error);
    }
  });

  router.get('/log/:uidApi', async (request, response, next) => {
    const { uidApi } = request.params;
    let lastEvaluatedKey = undefined;
    let items: any[] = [];

    try {
      do {
        const res: AWS.DynamoDB.DocumentClient.QueryOutput = await dynamoDB
          .query({
            KeyConditionExpression: '#key = :uidApi',
            ExpressionAttributeValues: {
              ':uidApi': uidApi,
            },
            ExpressionAttributeNames: {
              '#key': 'key',
            },
            ScanIndexForward: false,
            TableName: API_LOGS_TABLE,
            ExclusiveStartKey: lastEvaluatedKey,
          })
          .promise();

        if (res.Items) {
          items = items.concat(res.Items);
        }
        lastEvaluatedKey = res.LastEvaluatedKey;
      } while (lastEvaluatedKey);
      response.send(items);
    } catch (e) {
      next(e);
    }
  });

  router.post(
    '/solution/log/:name',
    async (
      req: {
        params: {
          name: string;
        };
        body: {
          date: string;
          comment: string;
          diff: string | Buffer;
          desc: string;
          descParams: { [key: string]: string };
          file: string;
          modifiedBy: string;
        };
      },
      res,
    ) => {
      const { name } = req.params;
      const { date, comment, desc, descParams, file, modifiedBy } = req.body;
      let diff = req.body.diff;
      if (diff && typeof diff === 'string') {
        diff = gzipSync(diff);

        // Remove file content if size is bigger than 400kb Dynamo restriction
        const compressedSize = diff.length / 1024;
        if (compressedSize > 400) {
          diff = gzipSync(
            `[{"value":"File too big to display content","count":1}]`,
          );
        }
      }
      try {
        await dynamoDB
          .put({
            TableName: SOLUTION_HISTORY_LOG_TABLE,
            Item: {
              key: name,
              date,
              comment,
              diff,
              desc,
              descParams,
              file,
              modifiedBy,
            },
          })
          .promise();
        res.send(200);
      } catch (error) {
        res.status(500).send(error);
      }
    },
  );

  router.get('/solution/log/:name', async (req, res) => {
    const { name } = req.params;
    try {
      const response = await dynamoDB
        .query({
          TableName: SOLUTION_HISTORY_LOG_TABLE,
          KeyConditionExpression: '#k = :key',
          ExpressionAttributeValues: {
            ':key': name,
          },
          ExpressionAttributeNames: {
            '#k': 'key',
          },
        })
        .promise();
      res.send(response.Items);
    } catch (error) {
      res.status(500).send(error);
    }
  });

  router.put('/solution/log/:from/:to', async (req, res) => {
    const { from, to } = req.params;
    try {
      const response = await dynamoDB
        .query({
          TableName: SOLUTION_HISTORY_LOG_TABLE,
          KeyConditionExpression: '#k = :key',
          ExpressionAttributeValues: {
            ':key': from,
          },
          ExpressionAttributeNames: {
            '#k': 'key',
          },
        })
        .promise();

      if (response.Items) {
        await Promise.all(
          response.Items.map(async item => {
            await dynamoDB
              .put({
                TableName: SOLUTION_HISTORY_LOG_TABLE,
                Item: {
                  ...item,
                  key: to,
                },
              })
              .promise();
            await dynamoDB
              .delete({
                TableName: SOLUTION_HISTORY_LOG_TABLE,
                Key: {
                  key: item.key,
                  date: item.date,
                },
              })
              .promise();
          }),
        );
      }

      res.send(200);
    } catch (error) {
      console.log(error);
      res.send(500);
    }
  });

  router.delete('/solution/log/:name', async (req, res) => {
    const { name } = req.params;
    try {
      const response = await dynamoDB
        .query({
          TableName: SOLUTION_HISTORY_LOG_TABLE,
          KeyConditionExpression: '#k = :key',
          ExpressionAttributeValues: {
            ':key': name,
          },
          ExpressionAttributeNames: {
            '#k': 'key',
          },
        })
        .promise();

      if (response.Items) {
        await Promise.all(
          response.Items.map(async item => {
            await dynamoDB
              .delete({
                TableName: SOLUTION_HISTORY_LOG_TABLE,
                Key: {
                  key: item.key,
                  date: item.date,
                },
              })
              .promise();
          }),
        );
      }

      res.send(200);
    } catch (error) {
      console.log(error);
      res.send(500);
    }
  });

  router.use(errorHandler());
  return router;
}
