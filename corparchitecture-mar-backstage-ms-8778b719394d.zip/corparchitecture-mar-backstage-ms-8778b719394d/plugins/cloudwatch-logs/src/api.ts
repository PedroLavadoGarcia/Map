import {
  createApiRef,
  DiscoveryApi,
  IdentityApi,
} from '@backstage/core-plugin-api';
import { Dashboard } from './types';

export interface CloudwatchApi {
  listLogs(query: string): Promise<Record<string, unknown>[]>;
}

export const cloudwatchApiRef = createApiRef<CloudwatchApi>({
  id: 'plugin.cloudwatch.service',
});

export type Options = {
  discoveryApi: DiscoveryApi;
  identityApi: IdentityApi;

  /**
   * Domain used by users to access Grafana web UI.
   * Example: https://monitoring.my-company.com/
   */
  domain: string;

  /**
   * Path to use for requests via the proxy, defaults to /cloudwatch/api
   */
  proxyPath?: string;
};

const isSingleWord = (input: string): boolean => {
  return input.match(/^[\w-]+$/g) !== null;
};
function createUrlCloudwatch(arn: string | undefined) {
  const arrayUrl = arn?.split(':');
  const logGroup = arrayUrl?.[6].replaceAll('/', '$252F');
  const url = `https://${arrayUrl?.[3]}.console.aws.amazon.com/cloudwatch/home?region=${arrayUrl?.[3]}#logsV2:log-groups/log-group/${logGroup}/log-events/${arrayUrl?.[8]}`;
  return url;
}
class Client {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars, @typescript-eslint/no-empty-function
  constructor(_opts: Options) {}

  public async fetch<T = unknown>(input: string): Promise<T> {
    const apiUrl = await this.apiUrl();
    const url = new URL(`${apiUrl}/${input}`, window.location.origin);
    if (url.port === '3000') {
      url.port = '7007';
    }

    const resp = await fetch(url.toString());
    if (!resp.ok) {
      throw new Error(`Request failed with ${resp.status} ${resp.statusText}`);
    }

    return await resp.json();
  }

  async listLogs(query: string): Promise<Record<string, unknown>[]> {
    if (isSingleWord(query)) {
      return this.dashboardsByName(query);
    }

    return this.dashboardsForMultipleNames(query);
  }

  async dashboardsForMultipleNames(
    query: string,
  ): Promise<Record<string, unknown>[]> {
    const names = query.split(' ');
    const fullyQualifiedDashboardURLs = (
      await Promise.all(
        names.map(async name => {
          const fullyQualifiedURLs = await this.dashboardsByName(name);
          return fullyQualifiedURLs;
        }),
      )
    ).flat();
    return fullyQualifiedDashboardURLs;
  }

  async dashboardsByName(name: string): Promise<Record<string, unknown>[]> {
    const response = await this.fetch<Dashboard>(name);

    return this.fullyQualifiedDashboardURLs(response);
  }
  private fullyQualifiedDashboardURLs(
    dashboard: Dashboard,
  ): Record<string, unknown>[] {
    const response: Record<string, unknown>[] = [];
    if (dashboard.logStreams) {
      for (const log of dashboard.logStreams) {
        const cloudWatchLink = createUrlCloudwatch(log.arn);

        response.push({
          ...dashboard.logStreams,
          name: log.logStreamName,
          arn: log.arn,
          link: cloudWatchLink,
        });
      }
    }
    return response;
  }

  private async apiUrl() {
    return '/api/cloudwatch-logs';
  }
}

export class CloudwatchApiClient implements CloudwatchApi {
  private readonly client: Client;

  constructor(opts: Options) {
    this.client = new Client(opts);
  }

  async listLogs(query: string): Promise<Record<string, unknown>[]> {
    return this.client.listLogs(query);
  }
}
