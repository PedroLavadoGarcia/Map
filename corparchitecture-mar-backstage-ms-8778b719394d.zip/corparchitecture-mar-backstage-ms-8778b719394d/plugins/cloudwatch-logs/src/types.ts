export interface Dashboard {
  logStreams: [
    {
      logStreamName: string;
      arn: string;
      link: string;
    },
  ];
}
