import { Entity } from '@backstage/catalog-model';

export const CLOUDWATCH_ANNOTATION_NAME_SELECTOR = 'cloudwatch';

export const isNameSelectorAvailable = (entity: Entity) =>
  Boolean(entity?.metadata.annotations?.[CLOUDWATCH_ANNOTATION_NAME_SELECTOR]);

export const nameSelectorFromEntity = (entity: Entity) =>
  entity?.metadata.annotations?.[CLOUDWATCH_ANNOTATION_NAME_SELECTOR] ?? '';
