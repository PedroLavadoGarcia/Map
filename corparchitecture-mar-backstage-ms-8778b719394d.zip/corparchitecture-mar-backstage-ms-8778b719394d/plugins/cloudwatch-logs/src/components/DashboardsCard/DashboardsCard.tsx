import React from 'react';
import { Progress, TableColumn, Table, Link } from '@backstage/core-components';
import { Entity } from '@backstage/catalog-model';
import { useEntity } from '@backstage/plugin-catalog-react';
import {
  configApiRef,
  discoveryApiRef,
  identityApiRef,
  useApi,
} from '@backstage/core-plugin-api';
import { CloudwatchApiClient } from '../../api';
import { useAsync } from 'react-use';
import { Alert } from '@material-ui/lab';
import { Tooltip, makeStyles } from '@material-ui/core';

import {
  nameSelectorFromEntity,
  isNameSelectorAvailable,
} from '../cloudwatchData';

export const DashboardsTable = ({
  entity,
  dashboards,
  opts,
}: {
  entity: Entity;
  dashboards: Record<string, unknown>[];
  opts: DashboardCardOpts;
}) => {
  const columns: TableColumn<Record<string, unknown>>[] = [
    {
      title: 'Logs',
      field: 'name',
      render: (row: Record<string, unknown>) => (
        <Link to={row.link as string} target="_blank" rel="noopener">
          {row.name as string}
        </Link>
      ),
    },
  ];

  const titleElm = (
    <Tooltip
      title={`Note: only dashboard with the "${nameSelectorFromEntity(
        entity,
      )}" selector are displayed.`}
    >
      <span>{opts.title || 'Cloudwatch Logs'}</span>
    </Tooltip>
  );

  return (
    <Table
      title={titleElm}
      options={{
        paging: opts.paged ?? false,
        pageSize: opts.pageSize ?? 5,
        search: opts.searchable ?? false,
        emptyRowsWhenPaging: false,
        sorting: opts.sortable ?? false,
        draggable: false,
        padding: 'dense',
      }}
      data={dashboards}
      columns={columns}
    />
  );
};

const Dashboards = ({
  entity,
  opts,
}: {
  entity: Entity;
  opts: DashboardCardOpts;
}) => {
  const discoveryApi = useApi(discoveryApiRef);
  const identityApi = useApi(identityApiRef);
  const configApi = useApi(configApiRef);
  const cloudwatchApi = new CloudwatchApiClient({
    discoveryApi: discoveryApi,
    identityApi: identityApi,
    domain: '',
    proxyPath: configApi.getOptionalString('cloudwatch.proxyPath'),
  });
  const { value, loading, error } = useAsync(
    async () => await cloudwatchApi.listLogs(nameSelectorFromEntity(entity)),
  );

  if (loading) {
    return <Progress />;
  } else if (error) {
    return <Alert severity="error">{error.message}</Alert>;
  }

  return (
    <DashboardsTable entity={entity} dashboards={value || []} opts={opts} />
  );
};

export type DashboardCardOpts = {
  paged?: boolean;
  searchable?: boolean;
  pageSize?: number;
  sortable?: boolean;
  title?: string;
};

export const DashboardsCard = (opts?: DashboardCardOpts) => {
  const { entity } = useEntity();

  const useStyles = makeStyles(theme => ({
    empty: {
      padding: theme.spacing(2),
      display: 'flex',
      justifyContent: 'center',
    },
  }));
  const classes = useStyles();
  const columns: TableColumn[] = [
    {
      title: 'Logs',
      field: 'col1',
      highlight: true,
    },
  ];
  return !isNameSelectorAvailable(entity) ? (
    <Table
      options={{ paging: false, search: false }}
      data={[]}
      columns={columns}
      emptyContent={<div className={classes.empty}>No records to display</div>}
      title="Cloudwatch"
    />
  ) : (
    <Dashboards entity={entity} opts={opts || {}} />
  );
};
