export { DashboardsCard as EntityCloudwatchDashboardsCard } from './components/DashboardsCard/DashboardsCard';
export {
  isNameSelectorAvailable,
  CLOUDWATCH_ANNOTATION_NAME_SELECTOR,
} from './components/cloudwatchData';
