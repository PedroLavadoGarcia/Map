import { errorHandler } from '@backstage/backend-common';
import express from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import { DynamoDB } from 'aws-sdk';

export interface RouterOptions {
  logger: Logger;
  auditTableName: string;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
}
export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {
  const router = Router();
  router.use(express.json());
  const { accessKeyId, secretAccessKey, region } = options;
  const dynamo = new DynamoDB.DocumentClient({
    credentials: {
      accessKeyId,
      secretAccessKey,
    },
    region,
  });

  const { auditTableName } = options;

  router.post(
    '/login',
    async (
      req: {
        body: {
          user: string;
        };
      },
      res,
    ) => {
      const { user } = req.body;

      try {
        await dynamo
          .put({
            TableName: auditTableName,
            Item: {
              id: user,
              action: 'login',
              timestamp: new Date().toISOString(),
            },
          })
          .promise();
        res.sendStatus(200);
      } catch (error) {
        console.log(error);
        res.status(500).send(error);
      }
    },
  );

  router.post(
    '/view',
    async (
      req: {
        body: {
          user: string;
          entity: string;
        };
      },
      res,
    ) => {
      const { user, entity } = req.body;

      try {
        await dynamo
          .put({
            TableName: auditTableName,
            Item: {
              id: user,
              action: 'view',
              timestamp: new Date().toISOString(),
              entity,
            },
          })
          .promise();
        return res.sendStatus(200);
      } catch (error) {
        console.error(error);
        return res.status(500).send(error);
      }
    },
  );

  router.post(
    '/viewDoc',
    async (
      req: {
        body: {
          user: string;
          entity: string;
        };
      },
      res,
    ) => {
      const { user, entity } = req.body;

      try {
        await dynamo
          .put({
            TableName: auditTableName,
            Item: {
              id: user,
              action: 'viewDoc',
              timestamp: new Date().toISOString(),
              entity,
            },
          })
          .promise();
        return res.sendStatus(200);
      } catch (error) {
        console.error(error);
        return res.status(500).send(error);
      }
    },
  );

  router.post(
    '/search',
    async (
      req: {
        body: {
          user: string;
          text: string;
        };
      },
      res,
    ) => {
      const { user, text } = req.body;

      try {
        await dynamo
          .put({
            TableName: auditTableName,
            Item: {
              id: user,
              action: 'search',
              timestamp: new Date().toISOString(),
              text,
            },
          })
          .promise();
        return res.sendStatus(200);
      } catch (error) {
        console.error(error);
        return res.status(500).send(error);
      }
    },
  );

  router.use(errorHandler());
  return router;
}
