/* eslint-disable */
export default {
  displayName: 'infra',
  preset: './jest.preset.js',
  transform: {
    '^.+\\.[tj]s$': ['ts-jest', { tsconfig: '<rootDir>/tsconfig.spec.json' }],
  },
  moduleFileExtensions: ['ts', 'js', 'html'],
  coverageDirectory: './coverage/infra',
  testMatch: [
    '<rootDir>/test/**/__tests__/**/*.[jt]s?(x)',
    '<rootDir>/test/**/*(*.)@(spec|test).[jt]s?(x)',
  ],
};
