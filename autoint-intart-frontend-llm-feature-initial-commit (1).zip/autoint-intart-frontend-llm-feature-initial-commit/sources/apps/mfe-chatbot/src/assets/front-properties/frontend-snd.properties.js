(function (globalThis) {
  globalThis['environment'] = globalThis['env'] || {};

  // Environment variables
  globalThis['environment']['name'] = 'SND';
  globalThis['environment']['apiUrl'] = 'https://agent-web-app-dev.azurewebsites.net';
  globalThis['environment']['timeout'] = 2540;
  globalThis['environment']['customFeatureEnabled'] = false;
})(this);
