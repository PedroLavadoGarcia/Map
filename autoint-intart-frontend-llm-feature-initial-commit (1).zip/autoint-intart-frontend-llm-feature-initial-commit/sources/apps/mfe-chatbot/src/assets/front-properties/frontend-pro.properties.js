(function (globalThis) {
  globalThis['environment'] = globalThis['env'] || {};

  // Environment variables
  globalThis['environment']['name'] = 'PRO';
  globalThis['environment']['apiUrl'] = 'https://agent-web-app-dev.azurewebsites.net';
  globalThis['environment']['timeout'] = 7200;
  globalThis['environment']['customFeatureEnabled'] = false;
})(this);
