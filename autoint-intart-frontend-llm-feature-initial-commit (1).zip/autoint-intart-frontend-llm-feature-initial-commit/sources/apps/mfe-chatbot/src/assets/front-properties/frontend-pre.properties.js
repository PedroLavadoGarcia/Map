(function (globalThis) {
  globalThis['environment'] = globalThis['env'] || {};

  // Environment variables
  globalThis['environment']['name'] = 'PRE';
  globalThis['environment']['apiUrl'] = 'https://agent-web-app-dev.azurewebsites.net';
  globalThis['environment']['timeout'] = 3500;
  globalThis['environment']['customFeatureEnabled'] = true;
})(this);
