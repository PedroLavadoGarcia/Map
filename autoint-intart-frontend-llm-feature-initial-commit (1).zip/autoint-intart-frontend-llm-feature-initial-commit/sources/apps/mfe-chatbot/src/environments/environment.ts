/* eslint-disable @typescript-eslint/no-explicit-any */
export const environment = {
  production: false,
  name: (globalThis as any).environment?.name as string,
  apiUrl: (globalThis as any).environment?.apiUrl as string,
  timeout: (globalThis as any).environment?.timeout as number,
  customFeatureEnabled: (globalThis as any).environment
    ?.customFeatureEnabled as boolean,
};
