import { InferenceMetadata } from "../interfaces/inferenceMetadata";
import { FeedbackRequest } from "../interfaces/feedbackRequest";

export class GlobalConstants {
  public static settings : InferenceMetadata = { country: "", document_code: "", file_name : "" };
  public static favorites : string[] = ["Inmovilización por avería en Portugal, 2 ocupantes, solicitan grúa y taxi a España a 110Km", "Asegurado con pinchazo de rueda en Grecia, dispone de herramientas y rueda de repuesto, solicita asistencia"];
  public static history : string[] = ["Inmovilización por avería en Portugal, 2 ocupantes, solicitan grúa y taxi a España a 110Km", "Asegurado con pinchazo de rueda en Grecia, dispone de herramientas y rueda de repuesto, solicita asistencia", "Repatriar el vehículo averiado con reparación mayor a 24h desde autopista en Francia"];
  public static classFlag = false;
  public static feedback : FeedbackRequest = {score:0,question:"",answer:"",valoration:""};
}
