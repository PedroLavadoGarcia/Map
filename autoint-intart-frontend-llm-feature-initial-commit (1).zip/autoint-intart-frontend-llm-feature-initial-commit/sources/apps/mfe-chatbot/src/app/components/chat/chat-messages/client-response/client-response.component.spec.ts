import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClientResponseComponent } from './client-response.component';

describe('ClientResponseComponent', () => {
  let component: ClientResponseComponent;
  let fixture: ComponentFixture<ClientResponseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClientResponseComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ClientResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
