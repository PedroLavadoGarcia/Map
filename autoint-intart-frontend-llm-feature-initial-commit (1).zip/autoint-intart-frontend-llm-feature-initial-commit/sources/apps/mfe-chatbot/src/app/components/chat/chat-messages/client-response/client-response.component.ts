import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bIconComponent } from '@mapfre-tech/b2b-components';
import { GlobalConstants } from '../../../../common/global-constants';

@Component({
  selector: 'app-client-response',
  standalone: true,
  imports: [CommonModule,B2bIconComponent],
  templateUrl: './client-response.component.html',
  styleUrl: './client-response.component.css',
})
export class ClientResponseComponent {
  @Input() message = 'Texto de ejemplo';
  favorited = false;

  favoriteMessage() {
    this.favorited = !this.favorited;
    if(this.favorited){
      GlobalConstants.favorites.push(this.message);
    }else{
      const index = GlobalConstants.favorites.indexOf(this.message);
      GlobalConstants.favorites.splice(index, 1);
    }

  }
}
