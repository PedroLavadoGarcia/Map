import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bChipComponent, B2bIconComponent } from '@mapfre-tech/b2b-components';
import { MatMenuModule } from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { GlobalConstants } from '../../../common/global-constants';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule,B2bIconComponent, B2bChipComponent, MatMenuModule,MatDividerModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
})
export class SidebarComponent {

  isVisible = false;
  selected = true;

  historial = ["Inmovilización por avería en Portugal, 2 ocupantes, solicitan grúa y taxi a España a 110Km", "Asegurado con pinchazo de rueda en Grecia, dispone de herramientas y rueda de repuesto, solicita asistencia", "Repatriar el vehículo averiado con reparación mayor a 24h desde autopista en Francia"];
  favorites = ["Inmovilización por avería en Portugal, 2 ocupantes, solicitan grúa y taxi a España a 110Km", "Asegurado con pinchazo de rueda en Grecia, dispone de herramientas y rueda de repuesto, solicita asistencia"];

  toggleSidebar() {
    this.isVisible = !this.isVisible;
  }

  deleteHistorial(index: number) {
    this.historial.splice(index, 1);
  }

  deleteFavorites(index: number) {
    this.favorites.splice(index, 1);
  }

  moveUpFavorites(index: number) {
    const element = this.favorites[index];
    this.favorites.splice(index, 1);
    this.favorites.splice(index - 1, 0, element);
  }

  moveDownFavorites(index: number) {
    const element = this.favorites[index];
    this.favorites.splice(index, 1);
    this.favorites.splice(index + 1, 0, element);
  }

  ngAfterViewInit(): void {
    this.favorites = GlobalConstants.favorites;
    this.historial = GlobalConstants.history;
  }
}
