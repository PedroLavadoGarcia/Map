import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { CommonModule, NgStyle } from '@angular/common';
import { Subscription } from 'rxjs';
import { Cost } from '../../../interfaces/cost';
import { Mawdy } from '../../../interfaces/mawdy';
import { Policies } from '../../../interfaces/policies';
import { Reasons } from '../../../interfaces/reasons';
import { InferenceResponse } from '../../../interfaces/inferenceResponse';
import { GlobalConstants } from '../../../common/global-constants';
import { MawdyService } from '../../../services/mawdy.service';
import { ChatService } from '../../../services/chat.service';
import { TextboxComponent } from "../textbox/textbox.component";
import { B2bTagComponent } from '@mapfre-tech/b2b-components';
import { ClientResponseComponent } from "../chat-messages/client-response/client-response.component";
import { ServerResponseComponent } from "../chat-messages/server-response/server-response.component";
import { SidebarComponent } from "../sidebar/sidebar.component";
import { DowloadLinkComponent } from '../pre-chat/download-link/dowload-link.component';
import { MatDividerModule } from '@angular/material/divider';
import { ChatSettingsComponent } from '../pre-chat/chat-settings/chat-settings.component';
import { CarrouselComponent } from '../pre-chat/carrousel/carrousel.component';
import { MarkdownComponent } from 'ngx-markdown';
import { InferenceRequest } from '../../../interfaces/inferenceRequest';
import { InferenceMetadata } from '../../../interfaces/inferenceMetadata';
import { SidebarMobileComponent } from "../sidebar/sidebar-mobile/sidebar-mobile.component";

@Component({
  selector: 'app-chatbot-area',
  standalone: true,
  imports: [CommonModule, NgStyle, MatDividerModule, ChatSettingsComponent,
    DowloadLinkComponent, TextboxComponent, B2bTagComponent, CarrouselComponent,
    ClientResponseComponent, ServerResponseComponent, SidebarComponent,
    MarkdownComponent, SidebarMobileComponent],
  templateUrl: './chatbot-area.component.html',
  styleUrl: './chatbot-area.component.css',
})
export class ChatbotAreaComponent {

  metadata : InferenceMetadata = {
    country: '',
    document_code: '',
    file_name: '',
  };

  prompts = ["Repatriar el vehículo averiado con reparación mayor a 24h desde autopista en Francia","Avería de vehículo en carretera en Alemania, reparación más 24 horas. el cliente solicita taxi y hotel para esta noche. ¿le corresponde hotel y taxi?","Avería en Portugal , 24 horas, el proveedor de grúa ha tardado en llegar y cerraron el centro comercial donde estaba el vehículo, no podemos recogerlo ¿Se puede gestionar hotel?","Inmovilización por avería en Portugal, 2 ocupantes, solicitan grúa y taxi a España a 110Km.","Accidente con camion en Europa. Derecho a remolque a taller."];

  settings = { country : "", file_name : "", document_code : "" };

  messages: any[] = [];
  classFlag = false;
  tagString : string[] = [];
  @ViewChild('messageContainer') scroll!: ElementRef;
  currentClass = '';
  currentClassSidebar = '';
  disableTextarea = false;

  constructor(private mawdyService: MawdyService, private chatService: ChatService,
    private renderer: Renderer2, private el: ElementRef
  ) {}

  private subscription: Subscription = new Subscription();

  getQuestion(metadata:InferenceMetadata,txt:string):InferenceRequest{
    const question : InferenceRequest = {
      message: txt,
      session_id: null,
      current_message_id: null,
      previous_message_id: null,
      metadata: metadata,
    };

    return question;
  }


  getCleanResponse() : InferenceResponse {
    const cost: Cost = {
      total_tokens: 0,
      prompt_tokens: 0,
      completion_tokens: 0,
      total_cost: 0,
    };

    const mawdy: Mawdy = { reason: '', proceeds: false };

    const policies: Policies = {
      reason: '',
      proceeds: false,
      response: '',
    };

    const reason: Reasons = { mawdy: mawdy, policies: policies };

    const response: InferenceResponse = {
      answer: '',
      source_documents: [],
      reasons: reason,
      response_source: '',
      time: 0,
      cost: cost,
    };

    return response;
  }

  setMessage(txt: string) {
    this.disableTextarea = true;
    this.metadata = {
      file_name: GlobalConstants.settings.file_name+".pdf",
      country: GlobalConstants.settings.country.toLowerCase(),
      document_code: GlobalConstants.settings.document_code,
    };
    const question = this.getQuestion(this.metadata,txt)
    const message = { question: question, sender: 'client' };
    this.messages.push(message);
    this.tagString = ["**Canal:** "+this.settings.country,"**Poliza:** "+this.settings.document_code+" -- "+this.settings.file_name];
    this.messages.push({question: this.getCleanResponse(), sender: 'server'});
    setTimeout(() => {
      this.scroll.nativeElement.scrollTop = this.scroll.nativeElement.scrollHeight;
    }, 0);
    this.requestAnswer(question);
   }

  requestAnswer(question:InferenceRequest) {
    const lastIndex = this.messages.length-1;
    this.mawdyService.enviarMensaje(question).subscribe((data) => {
      const response : InferenceResponse = data;
      const answer = {question: response, sender: 'server'};
      this.messages[lastIndex] = answer;
      this.disableTextarea = false;
    });
  }


  onResize() {
    if (window.innerWidth <= 1281 && window.innerHeight <= 600) {
      this.classFlag = true;
      GlobalConstants.classFlag = true;
    } else {
      this.classFlag = false;
      GlobalConstants.classFlag = false;
    }
  }

  updateCurrentClass(): void {
    const element = this.el.nativeElement.querySelector('.main');
    const width = element.clientWidth;
    if (width >= 845) { // lg breakpoint
      this.currentClass = 'col-lg-9';
    } else { // sm breakpoint
      this.currentClass = 'col-sm-6';
    }
  }

  ngOnInit() {
    this.onResize();
    this.updateCurrentClass();
    this.renderer.listen('window', 'resize', () => {
      this.updateCurrentClass();
    });
    this.subscription = this.chatService.limpiarChat$.subscribe(() => {
      this.messages = [];
    });

  }

  ngAfterViewInit(): void {
    this.settings = GlobalConstants.settings;
  }
}
