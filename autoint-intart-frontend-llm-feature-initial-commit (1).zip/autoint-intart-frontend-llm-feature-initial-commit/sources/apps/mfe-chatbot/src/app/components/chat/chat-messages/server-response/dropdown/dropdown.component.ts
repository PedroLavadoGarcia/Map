import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MarkdownComponent } from 'ngx-markdown';
import { B2bAccordionComponent } from '@mapfre-tech/b2b-components';
import { MawdyDocument } from 'sources/apps/mfe-chatbot/src/app/interfaces/document';

@Component({
  selector: 'app-dropdown',
  standalone: true,
  imports: [CommonModule,MarkdownComponent, B2bAccordionComponent],
  templateUrl: './dropdown.component.html',
  styleUrl: './dropdown.component.css',
})
export class DropdownComponent {
  @Input() dropdownContent = '';
}
