import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DowloadLinkComponent } from './dowload-link.component';

describe('DowloadLinkComponent', () => {
  let component: DowloadLinkComponent;
  let fixture: ComponentFixture<DowloadLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DowloadLinkComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DowloadLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
