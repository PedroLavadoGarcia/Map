import { Component, EventEmitter, HostListener, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bIconComponent, B2bTextAreaComponent } from '@mapfre-tech/b2b-components';
import { ChatService } from '../../../services/chat.service';
import { GlobalConstants } from '../../../common/global-constants';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-textbox',
  standalone: true,
  imports: [CommonModule,B2bIconComponent,B2bTextAreaComponent,FormsModule],
  templateUrl: './textbox.component.html',
  styleUrl: './textbox.component.css',
})
export class TextboxComponent {
  @Output() messageSend: EventEmitter<string> = new EventEmitter();
  @Input() boostrap = '';
  @Input() isDisabled = false;

  message = '';
  zoomLevel = 0;
  dynamicWidth = '';
  backgroundLevel = '';
  cleanRight = '';
  classFlag = false;


  constructor(private chatService: ChatService) {}

  sendMessage() {
    GlobalConstants.history.push(this.message);
    GlobalConstants.feedback.question = this.message;
    if (this.message.trim()) {
      this.messageSend.emit(this.message);
      this.message = '';
    }
  }

  cleanMessage():void {
    this.message = '';

  }

  cleanChat() {
    this.chatService.limpiarChat();
  }

  getZoomLevel(): void {
    this.zoomLevel = Math.round((window.devicePixelRatio*0.67) * 100);
    this.calculateWidth();
  }

  calculateWidth(): void {
    if (this.zoomLevel < 101) {
      this.dynamicWidth = '3.5%';
    }
    if (this.zoomLevel > 110) {
      this.dynamicWidth = '4.5%';
    }
    if(this.zoomLevel === 101) {
      this.dynamicWidth = this.classFlag ? '4.1%' : '3.5%';
    }
  }

  @HostListener('window:resize')
  onResize() {
    this.getZoomLevel();
  }

  ngAfterContentInit(): void {
    const textarea = document.getElementById("my-text-area-default") as HTMLTextAreaElement;

    if (textarea) {
      textarea.addEventListener('input', autoResize, false);
    }

    function autoResize(this: HTMLTextAreaElement): void {
      this.style.height = 'auto';
      this.style.height = `${this.scrollHeight}px`;
    }

    this.chatService.currentText.subscribe((text) => {
      this.message = text;
    });
  }

  ngOnInit(): void {
    if (window.innerWidth <= 1281 && window.innerHeight <= 600) {
      this.classFlag = true;
    } else {
      this.classFlag = false;
    }
    this.dynamicWidth = this.classFlag ? '3.5%' : '4.1%';
    this.backgroundLevel = this.classFlag ? '72%' : '74%';
    this.cleanRight = this.classFlag ? '90%' : '95%';
  }

}
