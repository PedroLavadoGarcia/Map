import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bLabelComponent } from '@mapfre-tech/b2b-components';
import { GlobalConstants } from '../../../../common/global-constants';
import { MawdyService } from '../../../../services/mawdy.service';
import { CodesRequest } from '../../../../interfaces/codesRequest';
import { CodesResponse } from '../../../../interfaces/codesResponse';
import { FormControl, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-chat-settings',
  standalone: true,
  imports: [CommonModule, B2bLabelComponent,ReactiveFormsModule],
  templateUrl: './chat-settings.component.html',
  styleUrl: './chat-settings.component.css',
})
export class ChatSettingsComponent {

  @Input() boostrap = '';
  languages: string[] = [];
  request : CodesRequest = {language: ''};
  files : CodesResponse = {codesfiles: []};

  settingsForm = new FormGroup({
    selectedLanguage: new FormControl(''),
    selectedPolicy: new FormControl('')
  });

  constructor(private mawdyService: MawdyService) {}

  ngAfterViewInit(): void {
    this.settingsForm.valueChanges.subscribe(values => {
      GlobalConstants.settings.country = values.selectedLanguage?.toLowerCase() || "";
      GlobalConstants.settings.document_code = this.files.codesfiles[Number.parseInt(values.selectedPolicy||"")].code || "";
      GlobalConstants.settings.file_name = this.files.codesfiles[Number.parseInt(values.selectedPolicy||"")].file_name || "";
    })
  }

  ngOnInit() {
    this.mawdyService.obtenerIdioma().subscribe((data) => {
        this.languages = [...data];
        this.request.language = this.languages[0];
        GlobalConstants.settings.country = this.languages[0];
        this.mawdyService.obtenerPolizas(this.request).subscribe((data) => {
          this.files = data;
          GlobalConstants.settings.document_code = this.files.codesfiles[0].code;
          GlobalConstants.settings.file_name = this.files.codesfiles[0].file_name;
          this.settingsForm.setValue(
            {selectedLanguage: this.languages[0],
              selectedPolicy: "0"});
        }
      );
      }
    );
  }
}
