import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bButtonComponent, B2bTextAreaComponent } from '@mapfre-tech/b2b-components';
import { GlobalConstants } from 'sources/apps/mfe-chatbot/src/app/common/global-constants';
import { FeedbackRequest } from '../../../../../interfaces/feedbackRequest';
import { MawdyService } from 'sources/apps/mfe-chatbot/src/app/services/mawdy.service';

@Component({
  selector: 'app-feedback',
  standalone: true,
  imports: [CommonModule, B2bTextAreaComponent, B2bButtonComponent],
  templateUrl: './feedback.component.html',
  styleUrl: './feedback.component.css',
})
export class FeedbackComponent {
  @Input() answer = '';
  givedFeedback = false;
  liked = false;
  disliked = false;

  constructor(private mawdyService: MawdyService) {}

  copyText() : void{
    navigator.clipboard.writeText(this.answer);
  }

  pressFeedbackLike() {
    if(this.liked){
      this.givedFeedback = false;
      this.liked = false;
    }else{
      this.givedFeedback = true;
      this.liked = true;
      this.disliked = false;
    }
  }

  pressFeedbackDislike() {
    if(this.disliked){
      this.givedFeedback = false;
      this.disliked = false;
    }else{
      this.givedFeedback = true;
      this.disliked = true;
      this.liked = false;
    }
  }

  sendFeedback() {
    const textarea = document.getElementById("my-text-area-default") as HTMLTextAreaElement;
    GlobalConstants.feedback.score = this.liked ? 1 : 0;
    GlobalConstants.feedback.answer = this.answer;
    GlobalConstants.feedback.valoration = textarea.value;
    const feedback : FeedbackRequest = GlobalConstants.feedback;
    textarea.value = '';
    this.liked = false;
    this.disliked = false;
    this.givedFeedback = false;
    this.mawdyService.darFeedback(feedback);
  }
}
