import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bHeaderDesktopComponent, B2bHeaderMobileComponent, B2bMapfreLogoComponent, B2bIconComponent } from '@mapfre-tech/b2b-components';
import { MatMenuModule } from '@angular/material/menu';
import { OptionsDialogComponent } from '../options-dialog/options-dialog.component';
import {MatButtonModule} from '@angular/material/button';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatButtonModule,CommonModule,MatMenuModule,OptionsDialogComponent,B2bHeaderDesktopComponent, B2bHeaderMobileComponent, B2bMapfreLogoComponent, B2bIconComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {}
