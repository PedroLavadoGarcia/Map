import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatService } from '../../../../services/chat.service';
import { GlobalConstants } from '../../../../common/global-constants';

@Component({
  selector: 'app-prompt-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './prompt-card.component.html',
  styleUrl: './prompt-card.component.css',
})
export class PromptCardComponent {
  @Input() prompt = '';
  @Input() boostrap = '';
  classFlag = false;

  constructor(private chatService:ChatService) {
    this.classFlag = GlobalConstants.classFlag;
  }

  selectPrompt() {
    this.chatService.changeText(this.prompt);
  }

}
