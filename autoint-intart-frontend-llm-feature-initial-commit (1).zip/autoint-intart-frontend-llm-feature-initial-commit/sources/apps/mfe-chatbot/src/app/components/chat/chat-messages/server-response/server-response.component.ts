
import { Component, Input, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B2bLabelComponent } from '@mapfre-tech/b2b-components';
import { LoadingComponent } from '../loading/loading.component';
import { Mawdy } from '../../../../interfaces/mawdy';
import { Policies } from '../../../../interfaces/policies';
import { Reasons } from '../../../../interfaces/reasons';
import { Cost } from './../../../../interfaces/cost';
import { InferenceResponse } from '../../../../interfaces/inferenceResponse';
import { MarkdownComponent } from 'ngx-markdown';
import { FeedbackComponent } from './feedback/feedback.component';
import { DropdownComponent } from "./dropdown/dropdown.component";

@Component({
  selector: 'app-server-response',
  standalone: true,
  imports: [CommonModule, B2bLabelComponent, LoadingComponent,
    MarkdownComponent, FeedbackComponent, DropdownComponent],
  templateUrl: './server-response.component.html',
  styleUrl: './server-response.component.css',
})

export class ServerResponseComponent {

  error = 'No se ha podido obtener una respuesta, por favor intente de nuevo.';

  pageContent = '';

  cost: Cost = {
    total_tokens: 0,
    prompt_tokens: 0,
    completion_tokens: 0,
    total_cost: 0,
  };

  mawdy: Mawdy = { reason: '', proceeds: false };

  policies: Policies = {
    reason: '',
    proceeds: false,
    response: '',
  };

  reason: Reasons = { mawdy: this.mawdy, policies: this.policies };

  @Input() response: InferenceResponse = {
    answer: '',
    source_documents: [],
    reasons: this.reason,
    response_source: '',
    time: 0,
    cost: this.cost,
  };

  ngOnChanges(changes: SimpleChanges): void {
    if(changes['response'] &&this.response.source_documents.length > 0){
      this.pageContent = '';
      for(let i = 0; i < this.response.source_documents[0].length; i++){
        this.pageContent += this.response.source_documents[0][i].page_content + '\n';
      }
    }
  }

}
