import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dowload-link',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dowload-link.component.html',
  styleUrl: './dowload-link.component.css',
})
export class DowloadLinkComponent {
  @Input() link = '';
  @Input() message = '';
  @Input() external = false;
}
