import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ServerResponseComponent } from './server-response.component';

describe('ServerResponseComponent', () => {
  let component: ServerResponseComponent;
  let fixture: ComponentFixture<ServerResponseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServerResponseComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ServerResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
