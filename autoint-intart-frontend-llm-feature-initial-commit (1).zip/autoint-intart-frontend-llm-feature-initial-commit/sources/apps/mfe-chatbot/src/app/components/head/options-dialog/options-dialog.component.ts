import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalConstants } from '../../../common/global-constants';
import { FormControl, FormGroup, FormsModule} from '@angular/forms';
import { B2bLabelComponent } from '@mapfre-tech/b2b-components';
import { MatMenuModule } from '@angular/material/menu';

@Component({
  selector: 'app-options-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule, B2bLabelComponent,MatMenuModule],
  templateUrl: './options-dialog.component.html',
  styleUrl: './options-dialog.component.css',
})
export class OptionsDialogComponent {

  tokens = 0;
  temperature = 0;

  calculateMargin(number: number) {
    return number === 1 ? 1.8+"%" : number * 0.9+"%";
  }

}
