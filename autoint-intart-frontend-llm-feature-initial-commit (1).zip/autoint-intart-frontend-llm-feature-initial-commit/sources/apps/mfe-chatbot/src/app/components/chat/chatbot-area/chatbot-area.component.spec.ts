import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ChatbotAreaComponent } from './chatbot-area.component';

describe('ChatbotAreaComponent', () => {
  let component: ChatbotAreaComponent;
  let fixture: ComponentFixture<ChatbotAreaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChatbotAreaComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ChatbotAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
