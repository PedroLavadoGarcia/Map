import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PromptCardComponent } from '../prompt-card/prompt-card.component';
import { GlobalConstants } from '../../../../common/global-constants';

@Component({
  selector: 'app-carrousel',
  standalone: true,
  imports: [CommonModule, PromptCardComponent],
  templateUrl: './carrousel.component.html',
  styleUrl: './carrousel.component.css',
})
export class CarrouselComponent {
  @Input() prompts : string[] = [];
  @Input() boostrap = '';
  visiblePrompts : string[] = [];
  currentIndex = 0;
  dots : any[] = [];
  classFlag = false;
  carrouselWidth : string;

  constructor() {
    this.classFlag = GlobalConstants.classFlag;
    this.carrouselWidth = this.classFlag ? '245px' : '295px';
  }

  ngOnInit() {
    this.classFlag = GlobalConstants.classFlag;
    this.updateVisiblePrompts();
    if(this.boostrap === 'col-lg-9') {
      this.dots = new Array(Math.ceil(this.prompts.length/2)).fill(0);
    }else{
      this.dots = new Array(Math.ceil(this.prompts.length)).fill(0);
    }
  }

  updateVisiblePrompts() {
    if(this.boostrap === 'col-lg-9') {
      this.visiblePrompts = this.prompts.slice(this.currentIndex, this.currentIndex + 3);
    }else{
      this.visiblePrompts = this.prompts.slice(this.currentIndex, this.currentIndex+1);
    }
  }

  prev() {
    if(this.boostrap === 'col-lg-9') {
      if (this.currentIndex > 0) {
        this.currentIndex--;
        this.updateVisiblePrompts();
      } else {
        this.currentIndex = this.prompts.length - 3;
        this.updateVisiblePrompts();
      }
    }else{
      if (this.currentIndex > 0) {
        this.currentIndex--;
        this.updateVisiblePrompts();
      } else {
        this.currentIndex = this.prompts.length - 1;
        this.updateVisiblePrompts();
      }
    }

  }

  next() {
    if(this.boostrap === 'col-lg-9') {
      if (this.currentIndex < this.prompts.length - 3) {
        this.currentIndex++;
        this.updateVisiblePrompts();
      } else {
        this.currentIndex = 0;
        this.updateVisiblePrompts();
      }
    }else{
      if (this.currentIndex < this.prompts.length-1) {
        this.currentIndex++;
        this.updateVisiblePrompts();
      } else {
        this.currentIndex = 0;
        this.updateVisiblePrompts();
      }
    }

  }

  goToPage(index: number) {
    this.currentIndex = index;
    this.updateVisiblePrompts();
  }
}
