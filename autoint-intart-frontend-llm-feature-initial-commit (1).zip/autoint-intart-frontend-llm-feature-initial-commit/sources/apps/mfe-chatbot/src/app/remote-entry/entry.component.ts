import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NxWelcomeComponent } from './nx-welcome.component';
import { HeaderComponent } from "../components/head/header/header.component";
import { ChatbotAreaComponent } from "../components/chat/chatbot-area/chatbot-area.component";

@Component({
  standalone: true,
  imports: [CommonModule, NxWelcomeComponent, HeaderComponent, ChatbotAreaComponent],
  selector: 'app-mfe-chatbot-entry',
  templateUrl: './entry.html',
})
export class RemoteEntryComponent {}
