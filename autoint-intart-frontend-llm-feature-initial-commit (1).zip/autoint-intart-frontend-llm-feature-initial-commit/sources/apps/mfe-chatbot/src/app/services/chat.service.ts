import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  private limpiarChatSubject = new Subject<void>();
  private textSource = new BehaviorSubject<string>('');

  limpiarChat$ = this.limpiarChatSubject.asObservable();
  currentText = this.textSource.asObservable();

  limpiarChat() {
    this.limpiarChatSubject.next();
  }

  changeText(text: string) {
    this.textSource.next(text);
  }
}
