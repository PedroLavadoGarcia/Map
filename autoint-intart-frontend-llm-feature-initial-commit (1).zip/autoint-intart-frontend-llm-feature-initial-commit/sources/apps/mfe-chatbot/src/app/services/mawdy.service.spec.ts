import { TestBed } from '@angular/core/testing';

import { MawdyService } from './mawdy.service';

describe('MawdyService', () => {
  let service: MawdyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MawdyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
