import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FeedbackRequest } from '../interfaces/feedbackRequest';
import { catchError, map, of } from 'rxjs';
import { InferenceResponse } from '../interfaces/inferenceResponse';
import { Cost } from '../interfaces/cost';
import { Mawdy } from '../interfaces/mawdy';
import { Policies } from '../interfaces/policies';
import { Reasons } from '../interfaces/reasons';
import { CodesRequest } from '../interfaces/codesRequest';
import { CodesResponse } from '../interfaces/codesResponse';
import { environment } from '../../environments/environment';
import { InferenceRequest } from '../interfaces/inferenceRequest';


@Injectable({
  providedIn: 'root'
})
export class MawdyService {

  constructor(private http: HttpClient) {}

  errorObject() : InferenceResponse {
    const cost: Cost = {
      total_tokens: 0,
      prompt_tokens: 0,
      completion_tokens: 0,
      total_cost: 0,
    };

    const mawdy: Mawdy = { reason: '', proceeds: false };

    const policies: Policies = {
      reason: '',
      proceeds: false,
      response: '',
    };

    const reason: Reasons = { mawdy: mawdy, policies: policies };

    const response: InferenceResponse = {
      answer: 'No se ha podido obtener una respuesta, por favor intente de nuevo.',
      source_documents: [],
      reasons: reason,
      response_source: '',
      time: 0,
      cost: cost,
    };

    return response;
  }

  obtenerIdioma() {
    return this.http.get<string[]>(environment.apiUrl+'/get-channel').pipe();
  }

  obtenerPolizas(request: CodesRequest) {
    return this.http.post<CodesResponse>(environment.apiUrl+'/get-codes', request).pipe();
  }

  enviarMensaje(msg:InferenceRequest){
    return this.http.post<InferenceResponse>(environment.apiUrl+'/inference', msg, {
      observe: 'body' // Asegura que la respuesta sea el cuerpo de la respuesta HTTP
    }).pipe(
      map(response => {
        // Aquí puedes transformar la respuesta si es necesario
        return response; // Si no necesitas transformarla, simplemente devuélvela
      }),
      catchError((error) => {
        return of(this.errorObject());
      })
    );
  }

  darFeedback(feedback:FeedbackRequest){
    return this.http.post<FeedbackRequest>(environment.apiUrl+'/feedback', feedback).pipe();
  }
}
