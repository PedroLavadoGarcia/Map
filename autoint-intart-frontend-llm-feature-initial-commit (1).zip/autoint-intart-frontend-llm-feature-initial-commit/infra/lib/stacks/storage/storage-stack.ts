import * as cdk from 'aws-cdk-lib';
import * as certificatemanager from 'aws-cdk-lib/aws-certificatemanager';

import * as cdkFront from '@mapfre-tech/cdk-front-lib';
import { MARHelper } from '@mapfre-mar/mar-archetype-utils';
import { AppEnvProperties } from '../../../../config/app-env-properties';
import { Constants } from '../../../../config/constants';

/**
 * Class representing the storage stack. Defines the AWS services related data storage.
 * @extends Stack
 */
export class StorageStack extends cdk.Stack {
  /**
   * @description Constructor for the stack.
   * @param {Construct} scope The scope in which to define this construct.
   * @param {String} id id for the stack.
   * @param {MARHelper} marHelper MAR helper with environment and properties utilities.
   * @param {StackProps} props stack properties.
   */
  constructor(
    scope: cdk.App,
    id: string,
    marHelper: MARHelper<AppEnvProperties>,
    props: cdk.StackProps
  ) {
    super(scope, id, props);

    const { cloudfront: cfProps } = marHelper.properties;

    const certificate: certificatemanager.ICertificate =
      marHelper.getObject('spaCert');
    const domainNames = cfProps.spaDomainNames;

    new cdkFront.SpaL3Construct(this, 'spa')
      .init({ componentId: Constants.COMPONENT_ID, env: marHelper.env })
      .kms({ defaultKMSKey: marHelper.defaultKMSKey })
      .cfDistribution({
        certificate,
        domainNames,
      })
      .bucketDeployment({ distributionPaths: ['/*'] })
      .buildIt();
  }
}
