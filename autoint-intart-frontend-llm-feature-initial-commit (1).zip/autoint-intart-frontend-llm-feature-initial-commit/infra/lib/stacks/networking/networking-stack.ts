import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { MARHelper } from '@mapfre-mar/mar-archetype-utils';
import { AppEnvProperties } from '../../../../config/app-env-properties';
import { Constants } from '../../../../config/constants';

/**
 * Class representing the networking stack. Retrieves the VPC to expose it to other stacks.
 * @extends Stack
 */
export class NetworkingStack extends cdk.Stack {
  private readonly _marHelper: MARHelper<AppEnvProperties>;

  /**
   * @description Constructor for the stack.
   * @param {Construct} scope The scope in which to define this construct.
   * @param {String} id id for the stack.
   * @param {MARHelper} marHelper MAR helper with environment and properties utilities.
   * @param {StackProps} props stack properties.
   */

  constructor(
    scope: Construct,
    id: string,
    marHelper: MARHelper<AppEnvProperties>,
    props: cdk.StackProps
  ) {
    super(scope, id, props);
    this._marHelper = marHelper;

    this.registerVPCSubnets();
  }
  /**
   * @description retrieves default MAR VPC from AWS account
   *
   * @returns IVPC
   */
  protected registerVPCSubnets(): ec2.IVpc {
    let vpc: ec2.IVpc;
    if (this.marHelper.properties.vpc?.id) {
      vpc = ec2.Vpc.fromLookup(this, this.marHelper.fullName('VPC'), {
        vpcId: this.marHelper.properties.vpc.id,
      });
    } else {
      vpc = ec2.Vpc.fromLookup(this, this.marHelper.fullName('VPC'), {
        tags: { project: Constants.PRODUCT_ID.toLowerCase() },
      });
    }

    this.marHelper.vpc = vpc;
    this.marHelper.publicSubnets = vpc.publicSubnets;
    this.marHelper.privateSubnets = vpc.privateSubnets;
    this.marHelper.isolatedSubnets = vpc.isolatedSubnets;

    return vpc;
  }

  protected get marHelper(): MARHelper<AppEnvProperties> {
    return this._marHelper;
  }
}
