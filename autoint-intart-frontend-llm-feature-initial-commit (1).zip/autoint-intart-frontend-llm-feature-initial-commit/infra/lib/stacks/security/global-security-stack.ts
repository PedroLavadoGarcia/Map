import * as cdk from 'aws-cdk-lib';
import * as certificatemanager from 'aws-cdk-lib/aws-certificatemanager';

import * as cdkFront from '@mapfre-tech/cdk-front-lib';
import { MARHelper } from '@mapfre-mar/mar-archetype-utils';
import { AppEnvProperties } from '../../../../config/app-env-properties';
import { Constants } from '../../../../config/constants';

/**
 * Class representing the global security stack. Defines the AWS services related with security which always is deployed on us-east-1 region.
 * @extends Stack
 */
export class GlobalSecurityStack extends cdk.Stack {
  /**
   * @description Constructor for the stack.
   * @param {Construct} scope The scope in which to define this construct.
   * @param {String} id id for the stack.
   * @param {MARHelper} marHelper MAR helper with environment and properties utilities.
   * @param {StackProps} props stack properties.
   */
  constructor(
    scope: cdk.App,
    id: string,
    marHelper: MARHelper<AppEnvProperties>,
    props: cdk.StackProps
  ) {
    super(scope, id, props);

    const { certs } = marHelper.properties;

    if (certs.spaCert.arn) {
      const spaCert = certificatemanager.Certificate.fromCertificateArn(
        this,
        'spa-cert',
        certs.spaCert.arn
      );
      marHelper.putObject('spaCert', spaCert);
    }

    new cdkFront.WafL3Construct(this, 'waf')
      .init({ componentId: Constants.COMPONENT_ID, env: marHelper.env })
      .buildIt();
  }
}
