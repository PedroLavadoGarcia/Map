import * as cdk from 'aws-cdk-lib';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as certificatemanager from 'aws-cdk-lib/aws-certificatemanager';

import * as cdkFront from '@mapfre-tech/cdk-front-lib';
import { MARHelper } from '@mapfre-mar/mar-archetype-utils';
import { AppEnvProperties } from '../../../../config/app-env-properties';

/**
 * Class representing the security stack. Defines the AWS services related with security.
 * @extends Stack
 */
export class SecurityStack extends cdk.Stack {
  private readonly _marHelper: MARHelper<AppEnvProperties>;

  /**
   * @description Constructor for the stack.
   * @param {Construct} scope The scope in which to define this construct.
   * @param {String} id id for the stack.
   * @param {MARHelper} marHelper MAR helper with environment and properties utilities.
   * @param {StackProps} props stack properties.
   */
  constructor(
    scope: cdk.App,
    id: string,
    marHelper: MARHelper<AppEnvProperties>,
    props: cdk.StackProps
  ) {
    super(scope, id, props);
    this._marHelper = marHelper;

    this.setDefaultKMS();
  }
  /**
   * @description Retrieves default MAR kms encriptyon key
   */
  protected setDefaultKMS() {
    this._marHelper.defaultKMSKey = kms.Key.fromKeyArn(
      this,
      this._marHelper.fullName('defaultKey'),
      this._marHelper.properties.kms.arn
    );
  }
}
