import { EnvProperties } from '@mapfre-mar/mar-archetype-utils';
import { devProperties } from './dev-properties';
import { preProperties } from './pre-properties';
import { proProperties } from './pro-properties';
import { sndProperties } from './snd-properties';

export interface AppEnvProperties extends EnvProperties {
  serviceaccountname: string;
  accountid: string;
  region: string;
  env: string;
  certs: {
    spaCert: {
      arn: string;
    };
  };
  cloudfront: {
    spaDomainNames: string[];
  };
  route53: {
    privateHostedZone: {
      domainName: string;
      recordSubdomain: string;
    };
  };
}

export const properties: Map<string, AppEnvProperties> = new Map<
  string,
  AppEnvProperties
>([
  ['snd', sndProperties],
  ['dev', devProperties],
  ['pre', preProperties],
  ['pro', proProperties],
] as [string, AppEnvProperties][]);
