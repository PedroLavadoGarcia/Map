import { AppEnvProperties } from './app-env-properties';

export const preProperties: AppEnvProperties = {
  serviceaccountname: '',
  accountid: '',
  region: '',
  env: 'pre',

  kms: {
    arn: '',
  },

  certs: {
    spaCert: {
      arn: '',
    },
  },

  cloudfront: {
    spaDomainNames: [],
  },

  route53: {
    privateHostedZone: {
      domainName: '',
      recordSubdomain: '',
    },
  },
};
