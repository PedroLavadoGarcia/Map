import { AppEnvProperties } from './app-env-properties';

export const sndProperties: AppEnvProperties = {
  serviceaccountname: '',
  accountid: '',
  region: '',
  env: 'snd',

  kms: {
    arn: '',
  },

  certs: {
    spaCert: {
      arn: '',
    },
  },

  cloudfront: {
    spaDomainNames: [],
  },

  route53: {
    privateHostedZone: {
      domainName: '',
      recordSubdomain: '',
    },
  },
};
