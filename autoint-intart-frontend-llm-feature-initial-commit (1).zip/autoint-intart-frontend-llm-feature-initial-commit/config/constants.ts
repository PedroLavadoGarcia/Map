import { RefArchitectureTypes } from '@mapfre-mar/cdk-mar-aspects';

export class Constants {
  public static readonly PRODUCT_ID: string = 'PRODUCT_ID';
  public static readonly COMPONENT_ID: string = 'mfe-chatbot';
  public static readonly ARCHETYPE_TYPE: RefArchitectureTypes =
    RefArchitectureTypes.FRONT;
}
