import { App } from 'aws-cdk-lib';
import { StorageStack } from '../infra/lib/stacks/storage/storage-stack';
import { NetworkingStack } from '../infra/lib/stacks/networking/networking-stack';
import { SecurityStack } from '../infra/lib/stacks/security/security-stack';
import { Validator } from '../bin/validator';
import { GlobalSecurityStack } from '../infra/lib/stacks/security/global-security-stack';
import { Builder } from '../bin/builder';

export class MyTestAppBuilder extends Builder {
  constructor(app: App, envProps: unknown) {
    super(app, envProps);
  }

  protected override createValidatorInstance() {
    return new Validator(this.marHelper);
  }

  /**
   * @description Creates a SecurityStack to be deployed in AWS
   *
   * @returns SecurityStack
   */
  public addSecurityStack(): MyTestAppBuilder {
    const stack = new SecurityStack(
      this.app,
      this.marHelper.fullName('SecurityStack'),
      this.marHelper,
      { env: this.appEnv }
    );

    this.stacks.set(stack.stackName, stack);
    return this;
  }

  /**
   * @description Creates a NetworkingStack to be deployed in AWS
   *
   * @returns NetworkingStack
   */
  public addNetworkingStack(): MyTestAppBuilder {
    const stack = new NetworkingStack(
      this.app,
      this.marHelper.fullName('NetworkingStack'),
      this.marHelper,
      { env: this.appEnv }
    );
    this.stacks.set(stack.stackName, stack);

    return this;
  }

  /**
   * @description Creates a StorageStack to be deployed in AWS
   *
   * @returns MarBuilder
   */
  public addStorageStack(): MyTestAppBuilder {
    const stack = new StorageStack(
      this.app,
      this.marHelper.fullName('StorageStack'),
      this.marHelper,
      {
        env: this.appEnv,
      }
    );

    this.stacks.set(stack.stackName, stack);
    return this;
  }

  /**
   * @description Creates a GlobalSecurityStack to be deployed in AWS
   *
   * @returns GlobalSecurityStack
   */
  public addGlobalSecurityStack(): MyTestAppBuilder {
    const stack = new GlobalSecurityStack(
      this.app,
      'GlobalSecurityStack',
      this.marHelper,
      {
        stackName: this.marHelper.fullName('GlobalSecurityStack'),
        env: {
          ...this.appEnv,
          region: 'us-east-1',
        },
      }
    );
    this.stacks.set(stack.stackName, stack);

    return this;
  }
}
