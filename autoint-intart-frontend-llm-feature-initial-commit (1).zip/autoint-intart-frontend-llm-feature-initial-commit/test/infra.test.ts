import { Template } from 'aws-cdk-lib/assertions';
import * as stacks from '../infra/lib/stacks';

import * as cdk from 'aws-cdk-lib';
import { MyTestAppBuilder } from './my-test-app-builder';
import { Constants } from '../config/constants';
import { devProperties } from '../config/dev-properties';

import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import * as s3 from 'aws-cdk-lib/aws-s3';

jest.mock('aws-cdk-lib/aws-s3-deployment', () => {
  const module = jest.requireActual<
    typeof import('aws-cdk-lib/aws-s3-deployment')
  >('aws-cdk-lib/aws-s3-deployment');
  module.Source.asset = (): s3deploy.ISource => ({
    bind: (): s3deploy.SourceConfig => {
      return {
        bucket: new s3.Bucket(new cdk.Stack(), 'bucket', {
          bucketName: 'bucket-test-name',
        }),
        zipObjectKey: 'dist',
      };
    },
  });
  return module;
});

function configureTestEnv() {
  return {
    account: devProperties.accountid,
    region: devProperties.region,
    env: devProperties.env,
  };
}

const testEnv = configureTestEnv();

const appBuilder = new MyTestAppBuilder(new cdk.App(), testEnv)
  .addSecurityStack()
  .addGlobalSecurityStack()
  .addNetworkingStack()
  .addStorageStack();

describe('Testing stacks', () => {
  test('GlobalSecurityStack: Check for existance of resources', () => {
    const globalSecurityStackName =
      Constants.COMPONENT_ID +
      '-GlobalSecurityStack-' +
      testEnv.env.toLowerCase();
    const globalSecurityStack = appBuilder.stacks.get(
      globalSecurityStackName
    ) as stacks.SecurityStack;
    Template.fromStack(globalSecurityStack).hasResourceProperties(
      'AWS::WAFv2::WebACL',
      {}
    );
  });

  test('StorageStack: Check for existance of resources', () => {
    const storageStackName =
      Constants.COMPONENT_ID + '-StorageStack-' + testEnv.env.toLowerCase();
    const storageStack = appBuilder.stacks.get(
      storageStackName
    ) as stacks.StorageStack;
    Template.fromStack(storageStack).hasResourceProperties(
      'AWS::S3::Bucket',
      {}
    );
    Template.fromStack(storageStack).hasResourceProperties(
      'AWS::CloudFront::Distribution',
      {}
    );
    Template.fromStack(storageStack).hasResourceProperties(
      'AWS::CloudFront::CloudFrontOriginAccessIdentity',
      {}
    );
  });
});
